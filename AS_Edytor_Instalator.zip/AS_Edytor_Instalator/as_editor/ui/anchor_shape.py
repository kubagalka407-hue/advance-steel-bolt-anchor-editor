# -*- coding: utf-8 -*-
"""Schemat kotwy - wspólny rysunek dla okna 'Dodaj kotwę' i edytora kotew.

Znaczenie wymiarów (zrzuty Management Tools + opis użytkownika, 2026-10):
- Length         - długość całkowita kotwy; dla haków mierzona do spodu haka,
- ThreadLength   - długość gwintu liczona OD CZUBKA w dół,
- TopDistance    - ile kotwy wystaje ponad płaszczyznę przyłożenia (górną powierzchnię blachy),
- BottomDistance - odległość mierzona OD DOŁU kotwy w górę (typ gwintowany: początek strefy 3),
- HeadHeight     - wysokość główki na DOLE kotwy (typ młoteczkowy); HeadDiameter - średnica okręgu
                   opisanego na główce, NumberOfHeadEdges - liczba boków tego wieloboku,
- DistanceF      - wysokość odcinka ukośnego haka, DistanceE - wysokość prostego odcinka pod ukosem,
- DistanceO      - przesunięcie poziome ukosu, DistanceA - szerokość haka (od zewnętrznej krawędzi
                   dolnego odcinka pionowego do końca ramienia), DistanceC - wysokość powrotu haka (typ J),
- HookRadius     - promień gięcia.

Strefy zestawu (pozycje +1.., -1.., -101..); lista czyta się od góry do dołu jak kotwa:
- top   - nad blachą: wiersz 1 jest NAJDALEJ od blachy, ostatni wiersz przy blasze,
- below - pod blachą: wiersz 1 jest PRZY blasze (leży na niej), kolejne coraz niżej (potwierdzone modelem Advance Steel),
- end   - koniec kotwy, układane w górę od punktu odniesienia (wiersz 1 na dole).
Punkt odniesienia strefy 'end': BottomDistance od dołu kotwy (typ gwintowany) albo górna
powierzchnia główki (typ młoteczkowy), w pozostałych przypadkach dolny koniec kotwy.
"""
import math

from as_editor.anchors_logic import ANCHOR_LABELS, pick_dia
from as_editor.common import dia_text, fmt_dia
from as_editor.i18n import T
from as_editor.ui.widgets import COL_MISSING, COL_NUT, COL_WASHER

COL_SHANK_F = "#d9dde2"
COL_HEAD_F = "#b8c4d0"
COL_PLATE_F = "#f2d79b"
COL_GROUT_F = "#e8e4dc"
COL_LINE = "#333333"
COL_DIM = "#1f4e79"
COL_HI = "#c0392b"
FONT = ("TkDefaultFont", 8)
DEFAULT_PLATE = 12.0


def num(v, dflt=None):
    """Liczba z pola tekstowego albo wiersza bazy; None/'' -> wartość domyślna."""
    if v is None or v == "":
        return dflt
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return dflt


def resolve_items(db, comps, dia):
    """Elementy zestawu (std/mat) + wymiary z bazy: wysokość, Ø zewnętrzna, rodzaj."""
    out = []
    for c in comps:
        it, cd = None, None
        try:
            if db is not None and getattr(db, "conn", None) and dia:
                cd = pick_dia(db.nut_diameters(c["std"], c["mat"]), dia)
                it = db.nut_item(c["std"], c["mat"], cd) if cd is not None else None
        except Exception:                                   # brak bazy / błąd zapytania: rysuj zastępczo
            it = None
        d = dia or 16.0
        if it:
            h = num(it[0], 0.0) or max(2.0, 0.15 * d)
            od = num(it[2], 0.0) or 1.8 * d
            kind = "washer" if not it[1] else "nut"
            desc = "%s %s" % (c["std"], c["mat"])
        else:
            h, od, kind = max(2.0, 0.15 * d), 1.8 * d, "missing"
            desc = T("BRAK %s/%s") % (c["std"], c["mat"])
        out.append({"std": c["std"], "mat": c["mat"], "h": h, "od": od, "kind": kind, "desc": desc, "dia": cd})
    return out


def path_points(tid, P, dia, L):
    """Oś kotwy jako łamana [(x, y)] w mm; y=0 na czubku, rośnie w dół, x=0 to oś górnego trzpienia."""
    d = dia
    if tid in (3, 4):
        F, E = P.get("DistanceF") or 0.0, P.get("DistanceE") or 0.0
        O, A = P.get("DistanceO") or 0.0, P.get("DistanceA") or 0.0
        C = P.get("DistanceC") or 0.0
        y_arm = max(0.0, L - d / 2.0)                       # oś ramienia poziomego (spód ramienia = L)
        y1 = min(max(0.0, L - E - F), y_arm)                # początek ukosu
        y2 = min(max(y1, L - E), y_arm)                     # koniec ukosu
        pts = [(0.0, 0.0), (0.0, y1), (-O, y2), (-O, y_arm)]
        if A > d / 2.0:
            x_end = -O - d / 2.0 + A
            if tid == 4 and C > d:
                pts.append((x_end - d / 2.0, y_arm))
                pts.append((x_end - d / 2.0, max(0.0, L - C)))
            else:
                pts.append((x_end, y_arm))
        return pts
    head = (P.get("HeadHeight") or 0.0) if tid == 1 else 0.0      # główkę rysujemy tylko dla młoteczkowych
    return [(0.0, 0.0), (0.0, max(0.0, L - head))]


def across_flats(od, edges):
    """Szerokość wieloboku 'na płask' - wielobok wpisany w okrąg o średnicy od."""
    try:
        n = int(edges or 0)
    except (TypeError, ValueError):
        n = 0
    return od * math.cos(math.pi / n) if n >= 3 else od


def layout(tid, P, dia, L, zones, plate, grout):
    """Położenie blachy, podlewki i elementów zestawu w mm (y rośnie w dół, 0 = czubek)."""
    TD = P.get("TopDistance") or 0.0
    out = {"plate": (TD, TD + plate), "grout": (TD + plate, TD + plate + grout), "items": []}
    y = TD                                                  # nad blachą: od blachy w górę
    for it in reversed(zones.get("top") or []):
        out["items"].append(dict(it, y0=y - it["h"], y1=y, zone="top"))
        y -= it["h"]
    out["top_y"] = y
    y = TD + plate                                          # pod blachą: od blachy w dół
    for it in zones.get("below") or []:                    # wiersz 1 pod blachą leży NA blasze, kolejne coraz niżej
        out["items"].append(dict(it, y0=y, y1=y + it["h"], zone="below"))
        y += it["h"]
    out["below_y"] = y
    head = (P.get("HeadHeight") or 0.0) if tid == 1 else 0.0
    if tid == 2 and (P.get("BottomDistance") or 0.0) > 0:
        ref = L - (P.get("BottomDistance") or 0.0)
    elif tid == 1 and head > 0:
        ref = L - head
    else:
        ref = L
    out["end_ref"] = ref
    y = ref                                                 # koniec kotwy: w górę od punktu odniesienia
    for it in zones.get("end") or []:
        out["items"].append(dict(it, y0=y - it["h"], y1=y, zone="end"))
        y -= it["h"]
    return out


def embedment(P, L, plate, grout):
    """Głębokość zakotwienia poniżej podlewki: długość - wystawanie - blacha - podlewka."""
    if L is None:
        return None
    return L - (P.get("TopDistance") or 0.0) - (plate or 0.0) - (grout or 0.0)


def draw(cv, tid, P, dia, L, zones=None, plate=DEFAULT_PLATE, grout=0.0, focus=None, hint=None):
    """Rysuje schemat kotwy na kanwie. P: wymiary z formularza, zones: elementy z resolve_items().
    Zwraca tekst informacyjny (głębokość zakotwienia itp.) albo komunikat, czego brakuje."""
    cv.delete("all")
    W, H = cv.winfo_width(), cv.winfo_height()
    if W <= 1 or H <= 1:                                    # kanwa jeszcze nierozłożona
        W, H = int(cv.cget("width") or 0) or 400, int(cv.cget("height") or 0) or 320
    if not L or not dia or tid is None:
        cv.create_text(W / 2, H / 2, text=hint or T("Wpisz średnicę i długość, aby zobaczyć kształt."), fill="#888")
        return ""
    zones = zones or {}
    plate = plate if plate and plate > 0 else 0.0
    grout = grout if grout and grout > 0 else 0.0
    pts = path_points(tid, P, dia, L)
    lay = layout(tid, P, dia, L, zones, plate, grout)
    head_h = (P.get("HeadHeight") or 0.0) if tid == 1 else 0.0    # typ 0 (Zwykła) nie ma główki
    head_d = (P.get("HeadDiameter") or 0.0) if tid == 1 else 0.0
    # zakres rysunku: pionowo cała kotwa z zestawem, poziomo kształt i blacha
    ys = [p[1] for p in pts] + [0.0, L, lay["grout"][1], lay["top_y"], lay["below_y"]] + \
         [it["y0"] for it in lay["items"]] + [it["y1"] for it in lay["items"]]
    od_max = max([it["od"] for it in lay["items"]] + [dia])
    plate_w = max(3.0 * dia, 2.4 * od_max, 1.5 * head_d)
    xs_lo = [p[0] - dia / 2.0 for p in pts] + [-plate_w / 2.0, -head_d / 2.0, -od_max / 2.0]
    xs_hi = [p[0] + dia / 2.0 for p in pts] + [plate_w / 2.0, head_d / 2.0, od_max / 2.0]
    y_lo, y_hi = min(ys), max(ys)
    x_lo, x_hi = min(xs_lo), max(xs_hi)
    mt, mb, ml, mr = 18, 34, 60, 92                         # miejsce na opisy wymiarów
    aw, ah = max(W - ml - mr, 60), max(H - mt - mb, 60)
    sc = min(ah / max(y_hi - y_lo, 1.0), aw / max(x_hi - x_lo, 1.0))
    x0 = ml + aw / 2.0 - (x_lo + x_hi) / 2.0 * sc
    y0 = mt + (ah - (y_hi - y_lo) * sc) / 2.0 - y_lo * sc

    def X(x):
        return x0 + x * sc

    def Y(y):
        return y0 + y * sc

    def box(xa, ya, xb, yb, fill):
        cv.create_rectangle(X(xa), Y(ya), X(xb), Y(yb), fill=fill, outline=COL_LINE)

    def col(key):
        return COL_HI if (focus and key == focus) else COL_DIM

    used_l, used_r = [], []                                 # zajęte wysokości opisów (lewa / prawa strona)
    maxch = max(8, int((mr - 8) / 6))

    def free(used, y):
        yy = y
        for u in sorted(used):
            if abs(yy - u) < 11:
                yy = u + 11
        used.append(yy)
        return yy

    def dim_v(ya, yb, x, text, key):
        """Pionowa linia wymiarowa z opisem po lewej stronie kotwy; x w pikselach."""
        c = col(key)
        cv.create_line(x, Y(ya), x, Y(yb), fill=c, arrow="both")
        for yy in (ya, yb):
            cv.create_line(x + 2, Y(yy), X(0), Y(yy), fill=c, dash=(2, 2))
        cv.create_text(x + 3, free(used_l, (Y(ya) + Y(yb)) / 2), text=text, anchor="w", fill=c, font=FONT)

    def tag(y, text, fill="#444", x_from=None):
        """Opis po prawej stronie, przesuwany w dół, gdy opisy na siebie nachodzą (z linią odniesienia)."""
        yy = free(used_r, y)
        if x_from is not None and W - mr - x_from > 4:
            cv.create_line(x_from, y, W - mr, yy, fill="#b8bcc2")
        cv.create_text(W - mr + 4, yy, text=text[:maxch], anchor="w", fill=fill, font=FONT)

    # podlewka i blacha
    if grout > 0:
        box(-plate_w / 2, lay["grout"][0], plate_w / 2, lay["grout"][1], COL_GROUT_F)
    if plate > 0:
        box(-plate_w / 2, lay["plate"][0], plate_w / 2, lay["plate"][1], COL_PLATE_F)
        tag((Y(lay["plate"][0]) + Y(lay["plate"][1])) / 2, T("blacha %s") % fmt_dia(plate), "#8a6d1f",
            X(plate_w / 2))
    # trzpień
    line = [c for p in pts for c in (X(p[0]), Y(p[1]))]
    cv.create_line(line, width=max(dia * sc, 2.0) + 1.5, fill=COL_LINE, capstyle="butt", joinstyle="round")
    cv.create_line(line, width=max(dia * sc, 2.0), fill=COL_SHANK_F, capstyle="butt", joinstyle="round")
    # gwint od czubka w dół
    tl = P.get("ThreadLength") or 0.0
    if tl > 0:
        r = dia * sc / 2.0
        y_end = min(tl, L)
        yy = Y(0.0)
        while yy < Y(y_end) - 2:
            cv.create_line(X(0) - r, yy, X(0) + r, yy + 3, fill="#6b7279")
            yy += 4
        dim_v(0.0, y_end, max(X(x_lo) - 26, 26), "%s %s" % (T("gwint"), fmt_dia(tl)), "ThreadLength")
    # główka na dole
    if tid == 1 and head_h > 0 and head_d > 0:
        hw = across_flats(head_d, P.get("NumberOfHeadEdges")) / 2.0
        box(-hw, L - head_h, hw, L, COL_HEAD_F)
        tag(Y(L - head_h / 2.0), T("główka Ø%s, %s bok.") % (fmt_dia(head_d), P.get("NumberOfHeadEdges") or 0),
            col("HeadDiameter"), X(hw))
    # elementy zestawu
    for it in lay["items"]:
        fill = {"washer": COL_WASHER, "nut": COL_NUT, "missing": COL_MISSING}[it["kind"]]
        ya, yb = Y(it["y0"]), Y(it["y1"])
        if yb - ya < 3:                                     # cienka podkładka: pokaż ją mimo skali
            ya, yb = (ya + yb) / 2 - 1.5, (ya + yb) / 2 + 1.5
        cv.create_rectangle(X(-it["od"] / 2.0), ya, X(it["od"] / 2.0), yb, fill=fill, outline=COL_LINE)
        tag((Y(it["y0"]) + Y(it["y1"])) / 2, it["desc"], x_from=X(it["od"] / 2.0))
    # wymiary pionowe po lewej
    dim_v(0.0, L, max(X(x_lo) - 52, 4), "%s %s" % (T("dł."), fmt_dia(L)), "Length")
    td = P.get("TopDistance") or 0.0
    if td > 0:
        dim_v(0.0, td, max(X(x_lo) - 39, 15), fmt_dia(td), "TopDistance")
    bd = P.get("BottomDistance") or 0.0
    if bd > 0 and tid == 2:
        dim_v(L - bd, L, max(X(x_lo) - 13, 8), "%s %s" % (T("od dołu"), fmt_dia(bd)), "BottomDistance")
    # wymiary haka
    if tid in (3, 4):
        F, E = P.get("DistanceF") or 0.0, P.get("DistanceE") or 0.0
        O, A = P.get("DistanceO") or 0.0, P.get("DistanceA") or 0.0
        C = P.get("DistanceC") or 0.0
        xl = X(-O) - dia * sc / 2.0 - 10
        if F > 0:
            cv.create_line(xl, Y(L - E - F), xl, Y(L - E), fill=col("DistanceF"), arrow="both")
            cv.create_text(xl - 3, (Y(L - E - F) + Y(L - E)) / 2, text="F %s" % fmt_dia(F), anchor="e",
                           fill=col("DistanceF"), font=FONT)
        if E > 0:
            cv.create_line(xl, Y(L - E), xl, Y(L), fill=col("DistanceE"), arrow="both")
            cv.create_text(xl - 3, (Y(L - E) + Y(L)) / 2, text="E %s" % fmt_dia(E), anchor="e",
                           fill=col("DistanceE"), font=FONT)
        if O > 0:
            yo = Y(L - E) - 7
            cv.create_line(X(-O), yo, X(0), yo, fill=col("DistanceO"), arrow="both")
            cv.create_text((X(-O) + X(0)) / 2, yo - 8, text="O %s" % fmt_dia(O), fill=col("DistanceO"), font=FONT)
        if A > 0:
            ya = Y(L) + 10
            cv.create_line(X(-O) - dia * sc / 2.0, ya, X(-O - dia / 2.0 + A), ya, fill=col("DistanceA"), arrow="both")
            cv.create_text((X(-O) + X(-O - dia / 2.0 + A)) / 2, ya + 8, text="A %s" % fmt_dia(A),
                           fill=col("DistanceA"), font=FONT)
        if tid == 4 and C > 0:
            xc = X(-O - dia / 2.0 + A) + 6
            cv.create_line(xc, Y(L - C), xc, Y(L), fill=col("DistanceC"), arrow="both")
            cv.create_text(xc + 3, (Y(L - C) + Y(L)) / 2, text="C %s" % fmt_dia(C), anchor="w",
                           fill=col("DistanceC"), font=FONT)

    # mały rzut główki z góry (wielobok wpisany w okrąg)
    edges = 0
    try:
        edges = int(P.get("NumberOfHeadEdges") or 0)
    except (TypeError, ValueError):
        edges = 0
    if tid == 1 and edges >= 3 and head_d > 0:
        rr, cx, cy = 14, W - 30, H - 34
        cv.create_oval(cx - rr, cy - rr, cx + rr, cy + rr, outline=col("HeadDiameter"), dash=(2, 2))
        poly = []
        for i in range(edges):
            a = 2 * math.pi * i / edges - math.pi / 2
            poly += [cx + rr * math.cos(a), cy + rr * math.sin(a)]
        cv.create_polygon(poly, fill=COL_HEAD_F, outline=COL_LINE)
        cv.create_text(cx, cy + rr + 8, text="Ø%s" % fmt_dia(head_d), fill=col("HeadDiameter"), font=FONT)
    emb = embedment(P, L, plate, grout)
    info = T("Ø%s × %s mm.") % (dia_text(dia), fmt_dia(L))
    if emb is not None:
        info += T(" Zakotwienie poniżej podlewki: %s mm (długość - wystawanie - blacha - podlewka).") % fmt_dia(emb)
    return info


def check_dims(tid, P, L):
    """Ostrzeżenia o wymiarach, które nie składają się w sensowny kształt."""
    out = []
    if not L:
        return out
    tl = P.get("ThreadLength") or 0.0
    if tl > L:
        out.append(T("Gwint (%s) jest dłuższy niż cała kotwa (%s).") % (fmt_dia(tl), fmt_dia(L)))
    td = P.get("TopDistance") or 0.0
    if td >= L:
        out.append(T("Wystawanie ponad blachę (%s) jest większe niż długość kotwy (%s).") % (fmt_dia(td), fmt_dia(L)))
    if tid in (3, 4):
        fe = (P.get("DistanceF") or 0.0) + (P.get("DistanceE") or 0.0)
        if fe > L - tl:
            out.append(T("F + E (%s) wchodzi w gwint - zmieść je między dołem kotwy a początkiem gwintu (%s).")
                       % (fmt_dia(fe), fmt_dia(L - tl)))
    if tid == 2:
        bd = P.get("BottomDistance") or 0.0
        if bd and bd > L - td:
            out.append(T("Odległość od dołu (%s) sięga ponad blachę.") % fmt_dia(bd))
    return out
