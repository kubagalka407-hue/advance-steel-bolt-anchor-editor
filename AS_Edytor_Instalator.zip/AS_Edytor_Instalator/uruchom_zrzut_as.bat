@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ==============================================
echo   Zrzut schematu baz Advance Steel (odczyt)
echo ==============================================
echo.

if not exist "%~dp0as_schema_dump.py" (
  echo Brak pliku as_schema_dump.py w tym samym folderze. Umiesc oba pliki razem.
  pause
  exit /b 1
)

rem ---------- 1. Python ----------
set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY (
  echo [1/4] Nie znaleziono Pythona - instaluje przez winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo.
  echo Jesli instalacja sie powiodla: ZAMKNIJ to okno i uruchom plik ponownie
  echo ^(Windows musi odswiezyc sciezki^). Jesli winget nie dziala, pobierz Python
  echo z https://www.python.org/downloads/ i zaznacz "Add python.exe to PATH".
  pause
  exit /b 0
)
echo [1/4] Python: OK  (%PY%)

rem ---------- 2. pip + pyodbc ----------
%PY% -m ensurepip --upgrade >nul 2>nul
echo [2/4] Instalacja pip / pyodbc...
%PY% -m pip install --quiet --upgrade pip pyodbc
if errorlevel 1 (
  echo Nie udalo sie zainstalowac pyodbc. Sprawdz polaczenie z internetem.
  pause
  exit /b 1
)
echo [2/4] pip i pyodbc: OK

rem ---------- 3. Sterownik ODBC dla SQL Server ----------
powershell -NoProfile -Command "if (Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) { exit 0 } else { exit 1 }"
if errorlevel 1 (
  echo [3/4] Brak sterownika ODBC 17/18 - instaluje przez winget ^(moze poprosic o zgode administratora^)...
  winget install -e --id Microsoft.msodbcsql.18 --accept-package-agreements --accept-source-agreements
  powershell -NoProfile -Command "if (Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) { exit 0 } else { exit 1 }"
  if errorlevel 1 (
    echo Nie udalo sie zainstalowac sterownika automatycznie.
    echo Pobierz recznie: "Microsoft ODBC Driver 18 for SQL Server" ze strony Microsoft i uruchom ten plik ponownie.
    pause
    exit /b 1
  )
)
echo [3/4] Sterownik ODBC: OK

rem ---------- 4. Zrzut ----------
where sqllocaldb >nul 2>nul
if errorlevel 1 echo UWAGA: nie widze narzedzia sqllocaldb - Advance Steel zwykle instaluje LocalDB. Skrypt sprobuje mimo to.
echo.
echo [4/4] Uruchamiam zrzut ^(najlepiej miej wlaczony Advance Steel lub Management Tools^)...
echo.
%PY% "%~dp0as_schema_dump.py" %*
if errorlevel 1 (
  echo.
  echo Skrypt zakonczyl sie bledem - wklej mi powyzszy komunikat.
  pause
  exit /b 1
)

if exist "%~dp0schemat_as.txt" (
  type "%~dp0schemat_as.txt" | clip
  echo.
  echo Wynik zostal skopiowany do schowka - wklej go w rozmowie ^(Ctrl+V^).
  echo Plik z wynikiem: %~dp0schemat_as.txt
  start "" notepad "%~dp0schemat_as.txt"
)
echo.
pause
