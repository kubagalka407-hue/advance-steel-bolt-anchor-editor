# -*- coding: utf-8 -*-
"""Szybkie okno 'Nowy zestaw z wzoru': wzór (zestaw + klasa), średnice, ewentualna zmiana składu, nowy klucz -> zapis."""
from as_editor.common import dia_text, fmt_dia, is_own
from as_editor.config import MAX_ITEMS, recall, remember
from as_editor.i18n import T
from as_editor.ui.dialogs import CompDialog
from as_editor.ui.widgets import fit_window, make_list, messagebox, tk, ttk


class QuickSetDialog(tk.Toplevel):
    def __init__(self, app, std):
        super().__init__(app.root)
        self.app, self.db, self.std = app, app.db, std
        self.title(T("Nowy zestaw z wzoru") + " - " + std)
        self.transient(app.root)
        self.head, self.nut = [], []
        self.dia_vals = []
        self.done = False
        pad = dict(padx=8, pady=3)
        ttk.Label(self, text="Wzór: wybierz istniejący zestaw i klasę. Wszystko inne (długości śrub, średnice, źródło) "
                             "program bierze z normy i wzoru.", wraplength=620, style="Hint.TLabel").grid(
            row=0, column=0, columnspan=3, sticky="w", **pad)
        ttk.Label(self, text="Zestaw wzorcowy").grid(row=1, column=0, sticky="w", **pad)
        sets = [r[0] for r in self.db.std_sets(std)]
        self.cb_set = ttk.Combobox(self, values=sets, state="readonly", width=26)
        self.cb_set.grid(row=1, column=1, sticky="w", **pad)
        self.cb_set.bind("<<ComboboxSelected>>", self.on_set)
        ttk.Label(self, text="Klasa").grid(row=2, column=0, sticky="w", **pad)
        self.cb_mat = ttk.Combobox(self, state="readonly", width=26)
        self.cb_mat.grid(row=2, column=1, sticky="w", **pad)
        self.cb_mat.bind("<<ComboboxSelected>>", self.on_mat)

        ttk.Label(self, text="Średnice (Ctrl / Shift = kilka)").grid(row=1, column=2, sticky="w", **pad)
        fr, self.lb_dia = make_list(self, 7, 12)
        fr.grid(row=2, column=2, rowspan=3, sticky="ns", **pad)
        self.lb_dia.bind("<<ListboxSelect>>", lambda e: self.refresh())

        box = ttk.LabelFrame(self, text="Skład zestawu (zmień tylko jeśli ma być inny niż we wzorze)")
        box.grid(row=3, column=0, columnspan=2, sticky="nsew", **pad)
        self.lb_head = self._side(box, "Po stronie łba (od blachy na zewnątrz)", "head")
        self.lb_nut = self._side(box, "Po stronie nakrętki (od blachy na zewnątrz)", "nut")

        ttk.Label(self, text="Nowy klucz zestawu (max 32 znaki)").grid(row=5, column=0, sticky="w", **pad)
        self.v_key = tk.StringVar()
        ttk.Entry(self, textvariable=self.v_key, width=28).grid(row=5, column=1, sticky="w", **pad)
        ttk.Label(self, text="Nazwa na liście").grid(row=6, column=0, sticky="w", **pad)
        self.v_run = tk.StringVar()
        ttk.Entry(self, textvariable=self.v_run, width=28).grid(row=6, column=1, sticky="w", **pad)
        ttk.Label(self, text="Właściciel wpisu").grid(row=7, column=0, sticky="w", **pad)
        self.v_owner = tk.StringVar(value=recall("owner", app.var_owner.get()))
        ttk.Entry(self, textvariable=self.v_owner, width=12).grid(row=7, column=1, sticky="w", **pad)
        self.v_info = tk.StringVar()
        ttk.Label(self, textvariable=self.v_info, wraplength=620, style="Err.TLabel").grid(
            row=8, column=0, columnspan=3, sticky="w", **pad)
        bar = ttk.Frame(self)
        bar.grid(row=9, column=0, columnspan=3, pady=8)
        ttk.Button(bar, text="Utwórz nowy zestaw", command=self.create).pack(side="left", padx=6)
        ttk.Button(bar, text="Anuluj", command=self.destroy).pack(side="left", padx=6)
        self.columnconfigure(1, weight=1)

        cur = app.cb_set.get().strip()
        if cur in sets:
            self.cb_set.set(cur)
        elif sets:
            self.cb_set.current(0)
        self.on_set(first=True)
        fit_window(self, 700, 560, 640, 480)
        self.grab_set()
        self.wait_window()

    def _side(self, parent, title, side):
        fr = ttk.Frame(parent)
        fr.pack(side="left", fill="both", expand=True, padx=6, pady=4)
        ttk.Label(fr, text=title).pack(anchor="w")
        f2, lb = make_list(fr, 4, 30)
        f2.pack(fill="both", expand=True)
        lb.configure(selectmode="browse")
        b = ttk.Frame(fr)
        b.pack(fill="x", pady=2)
        ttk.Button(b, text="+", width=3, command=lambda: self.add(side)).pack(side="left")
        ttk.Button(b, text="Zamień...", command=lambda: self.replace(side)).pack(side="left", padx=2)
        ttk.Button(b, text="Usuń", command=lambda: self.remove(side)).pack(side="left")
        return lb

    # ------------------------------------------------------------ dane wzorca
    def on_set(self, _=None, first=False):
        mats = self.db.std_set_materials(self.std, self.cb_set.get()) if self.cb_set.get() else []
        self.cb_mat["values"] = mats
        want = self.app.cur_pmat()
        if mats:
            self.cb_mat.set(want if want in mats else mats[0])
        else:
            self.cb_mat.set("")
        self.on_mat()

    def on_mat(self, _=None):
        std, key, mat = self.std, self.cb_set.get(), self.cb_mat.get()
        res = self.app.components_from_set(std, key, mat) if (key and mat) else None
        self.head, self.nut = res if res else ([], [])
        self.dia_vals = self.db.bolt_diameters(std, [mat]) if mat else []
        self.lb_dia.delete(0, "end")
        for d in self.dia_vals:
            self.lb_dia.insert("end", "Ø " + dia_text(d))
        self.lb_dia.selection_set(0, "end")
        self.refresh()

    def dias(self):
        return [self.dia_vals[i] for i in self.lb_dia.curselection()]

    def refresh(self):
        ds = self.dias()
        dia = ds[0] if ds else None
        miss = []
        for lb, items in ((self.lb_head, self.head), (self.lb_nut, self.nut)):
            lb.delete(0, "end")
            for i, c in enumerate(items, 1):
                bad = False
                if dia is not None:
                    bad = any(self.db.nut_item(c["std"], c["mat"], d) is None for d in ds)
                lb.insert("end", "%d. %s / %s%s" % (i, c["std"], c["mat"], T("   (brak w bazie)") if bad else ""))
                if bad:
                    lb.itemconfig("end", foreground="#b00000")
                    miss.append(c["std"] + "/" + c["mat"])
        self.v_info.set(T("Brak w bazie dla części średnic: ") + ", ".join(sorted(set(miss))) +
                        T(" - te średnice zostaną pominięte; użyj 'Zamień...'.") if miss else "")

    # ------------------------------------------------------------ edycja składu
    def lst(self, side):
        return self.head if side == "head" else self.nut

    def sel(self, side):
        lb = self.lb_head if side == "head" else self.lb_nut
        s = lb.curselection()
        return s[0] if s else None

    def pick(self, title, kind):
        ds = self.dias()
        return CompDialog(self, self.db, title, ds[0] if ds else None, kind).result

    def add(self, side):
        if len(self.head) + len(self.nut) >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS, parent=self)
            return
        r = self.pick(T("Dodaj element"), "nut" if (side == "nut" and self.nut) else "washer")
        if r:
            self.lst(side).append(r)
            self.refresh()

    def replace(self, side):
        i = self.sel(side)
        if i is None:
            messagebox.showinfo("Zamień", "Zaznacz element na liście.", parent=self)
            return
        r = self.pick(T("Zamień element"), "nut")
        if r:
            self.lst(side)[i] = r
            self.refresh()

    def remove(self, side):
        i = self.sel(side)
        if i is not None:
            del self.lst(side)[i]
            self.refresh()

    # ------------------------------------------------------------ zapis (używa podglądu i zapisu zakładki)
    def create(self):
        key, owner = self.v_key.get().strip(), self.v_owner.get().strip()
        errs = []
        if not self.cb_set.get() or not self.cb_mat.get():
            errs.append("Wybierz zestaw wzorcowy i klasę.")
        if not key or len(key) > 32:
            errs.append("Nowy klucz zestawu: wymagany, max 32 znaki.")
        elif key == self.cb_set.get():
            errs.append("Klucz nowego zestawu musi być inny niż wzorca.")
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: max 15 znaków, nie DSC/AUTODESK.")
        if not self.dias():
            errs.append("Zaznacz co najmniej jedną średnicę.")
        if not (self.head or self.nut):
            errs.append("Zestaw nie ma żadnych elementów.")
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(T(e) for e in errs), parent=self)
            return
        a = self.app
        mat = self.cb_mat.get()
        a.lb_mat.selection_clear(0, "end")
        if mat in a.mat_vals:
            a.lb_mat.selection_set(a.mat_vals.index(mat))
        a.refresh_diameters(reset=True)
        a.lb_dia.selection_clear(0, "end")
        for d in self.dias():
            if d in a.dia_vals:
                a.lb_dia.selection_set(a.dia_vals.index(d))
        a.refresh_pdia()
        a.head_items, a.nut_items = [dict(c) for c in self.head], [dict(c) for c in self.nut]
        a.cb_set.set(key)
        a.var_run.set(self.v_run.get().strip() or key)
        a.var_owner.set(owner)
        a.var_over.set(False)
        remember("owner", owner)
        a.on_pdia()
        self.destroy()
        a.save_set()
