# -*- coding: utf-8 -*-
"""Zakładka Kotwy: kopiuj kotwy / dodaj klasę."""
from as_editor.anchors_logic import plan_anchor_copy
from as_editor.common import clone_sql, fmt_dia, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER
from as_editor.i18n import T
from as_editor.ui.dialogs import ChoiceDialog
from as_editor.ui.widgets import make_list, make_tree, messagebox, tk, ttk


class AnchorsCopyMixin:
    # --- 2. kopiuj kotwy / dodaj klasę ---
    def build_anchor_copy(self):
        f = self.sub_ak
        left = ttk.Frame(f)
        left.pack(side="left", fill="y", padx=8, pady=6)
        g = ttk.Frame(left)
        g.pack(anchor="w")
        self.v_aknewstd, self.v_aknewrun = tk.StringVar(), tk.StringVar()
        self.v_akown = tk.StringVar(value=DEFAULT_OWNER)
        self.v_akfind, self.v_akrepl = tk.StringVar(), tk.StringVar()
        self.ak_dias, self.ak_pairs, self.ak_map = [], [], {}

        def row(r, text, widget):
            ttk.Label(g, text=text).grid(row=r, column=0, sticky="w", pady=3, padx=(0, 6))
            widget.grid(row=r, column=1, pady=3, sticky="w")
        self.cb_akstd = ttk.Combobox(g, width=38, state="readonly")
        self.cb_akstd.bind("<<ComboboxSelected>>", self.ak_on_std)
        row(0, "Norma źródłowa", self.cb_akstd)
        self.cb_akcl = ttk.Combobox(g, width=22, state="readonly")
        self.cb_akcl.bind("<<ComboboxSelected>>", self.ak_on_cl)
        row(1, "Klasa źródłowa", self.cb_akcl)
        row(2, "Nowa norma (kod; puste = ta sama)", ttk.Entry(g, textvariable=self.v_aknewstd, width=40))
        row(3, "Nazwa wyświetlana nowej normy", ttk.Entry(g, textvariable=self.v_aknewrun, width=40))
        self.cb_aknewcls = ttk.Combobox(g, width=38, state="readonly")
        row(4, "Nowa klasa", self.cb_aknewcls)
        row(5, "Właściciel (max 15)", ttk.Entry(g, textvariable=self.v_akown, width=20))
        row(6, "W numerach części zamień: znajdź", ttk.Entry(g, textvariable=self.v_akfind, width=40))
        row(7, "na", ttk.Entry(g, textvariable=self.v_akrepl, width=40))
        ttk.Label(left, text="Kopiowanie obejmuje kotwy, ich definicje długości i otwory. "
                             "Aby dodać klasę do tej samej normy: zostaw 'Nową normę' puste i wskaż nową klasę.",
                  wraplength=420, foreground="#444").pack(anchor="w", pady=8)
        ttk.Button(left, text="Kopiuj kotwy", command=self.ak_do).pack(anchor="w")
        mid = ttk.Frame(f)
        mid.pack(side="left", padx=8, pady=6, anchor="n")
        ttk.Label(mid, text="Średnice do skopiowania").pack(anchor="w")
        fr, self.lb_akdia = make_list(mid, 16, 16)
        fr.pack()
        right = ttk.Frame(f)
        right.pack(side="left", fill="both", expand=True, padx=8, pady=6)
        ttk.Label(right, text="Klasy nakrętek/podkładek w kopiowanych zestawach (dwuklik = zmień):").pack(anchor="w")
        fr, self.tr_akmap = make_tree(right, ("Element (norma)", "Klasa w źródle", "Klasa w kopii"), (200, 140, 200), 14, "browse")
        fr.pack(fill="both", expand=True)
        self.tr_akmap.bind("<Double-1>", self.ak_edit_map)

    @property
    def ALL_AK(self):
        return T("(wszystkie klasy)")

    def ak_std(self):
        i = self.cb_akstd.current()
        return self.an_std_rows[i][0] if 0 <= i < len(self.an_std_rows) else None

    def ak_mats(self):
        v = self.cb_akcl.get()
        return [] if (not v or v == self.ALL_AK) else [v]

    def ak_on_std(self, _=None):
        std = self.ak_std()
        if not std:
            return
        self.cb_akcl["values"] = [self.ALL_AK] + self.db.anchor_materials(std)
        self.cb_akcl.set(self.ALL_AK)
        self.ak_on_cl()

    def ak_on_cl(self, _=None):
        std = self.ak_std()
        if not std:
            return
        self.ak_dias = self.db.anchor_diameters(std, self.ak_mats() or None)
        self.lb_akdia.delete(0, "end")
        for d in self.ak_dias:
            self.lb_akdia.insert("end", "Ø " + fmt_dia(d))
            self.lb_akdia.selection_set("end")
        self.ak_pairs = self.db.anchor_component_pairs(std, self.ak_mats() or None)
        self.ak_map = {tuple(p): p[1] for p in self.ak_pairs}
        self.ak_map_refresh()

    def ak_map_refresh(self):
        t = self.tr_akmap
        t.delete(*t.get_children())
        for i, p in enumerate(self.ak_pairs):
            t.insert("", "end", iid=str(i), values=(p[0], p[1], self.ak_map[tuple(p)]))

    def ak_edit_map(self, event):
        iid = self.tr_akmap.identify_row(event.y)
        if not iid:
            return
        pair = tuple(self.ak_pairs[int(iid)])
        dlg = ChoiceDialog(self.root, "Klasa elementu", "Element %s: klasa w kopii (źródło: %s)" % (pair[0], pair[1]),
                           self.db.nut_materials(pair[0]), self.ak_map[pair])
        if dlg.result:
            self.ak_map[pair] = dlg.result
            self.ak_map_refresh()

    def ak_do(self):
        if not self.need_db():
            return
        std = self.ak_std()
        newstd, newrun, owner = self.v_aknewstd.get().strip(), self.v_aknewrun.get().strip(), self.v_akown.get().strip()
        j = self.cb_aknewcls.current()
        target_mat = self.cls_rows[j - 1][0] if j > 0 else None
        mats = self.ak_mats()
        dias = [self.ak_dias[i] for i in self.lb_akdia.curselection()]
        errs = []
        if not std:
            errs.append("Wybierz normę źródłową.")
        if not newstd and target_mat is None:
            errs.append("Podaj nową normę albo nową klasę.")
        if newstd and (len(newstd) > 64 or newstd in [r[0] for r in self.an_std_rows]):
            errs.append("Nowa norma: max 64 znaki i taki klucz nie może już istnieć.")
        if target_mat is not None and not mats:
            errs.append("Przy nowej klasie wybierz jedną klasę źródłową (nie 'wszystkie klasy').")
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        if not dias:
            errs.append("Zaznacz średnice.")
        names = self.db.anchor_names(std, mats or None, dias) if (std and dias) else []
        if std and dias and not names:
            errs.append("Nie znaleziono kotew do skopiowania.")
        ts = newstd or std
        conflicts = [n for n in names if self.db.anchor_exists(ts, target_mat or n["MaterialKey"], n["Diameter"], n["SetName"])]
        if conflicts:
            errs.append("%d kotew już istnieje w miejscu docelowym (np. Ø%s, klasa %s)." % (
                len(conflicts), fmt_dia(conflicts[0]["Diameter"]), target_mat or conflicts[0]["MaterialKey"]))
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return
        defs, holes = self.db.anchor_children([n["ID"] for n in names])
        ids = {"name": self.db.max_id("AnchorsName") + 1, "def": self.db.max_id("AnchorsDefinition") + 1,
               "hole": self.db.max_id("AnchorsHoleDefinition") + 1}
        mapping = {k: v for k, v in self.ak_map.items() if k[1] != v}
        new_n, new_d, new_h = plan_anchor_copy(names, defs, holes, ids, newstd or None, target_mat, owner, mapping,
                                               (self.v_akfind.get(), self.v_akrepl.get()))
        if not messagebox.askyesno("Potwierdź", "Skopiować kotwy?\n\nKotwy: %d\nDefinicje długości: %d\n"
                                   "Definicje otworów: %d%s" % (len(new_n), len(new_d), len(new_h),
                                                                    (T("\nNowa norma: %s") % newstd) if newstd else "")):
            return
        if not self.backup_before_write():
            return

        def fn(cur):
            if newstd:
                sql, p = clone_sql("AnchorsStandard", self.db.columns("AnchorsStandard"),
                                   {"Key": newstd, "RunName": (newrun or newstd)[:64], "OwnerText": owner[:15]},
                                   "[Key]=?", [std])
                cur.execute(sql, p)
            for r in new_n:
                cur.execute(*insert_sql("AnchorsName", r))
            for r in new_d:
                cur.execute(*insert_sql("AnchorsDefinition", r))
            for r in new_h:
                cur.execute(*insert_sql("AnchorsHoleDefinition", r))
        if self.write_or_report(fn):
            self.reload()
            messagebox.showinfo("Gotowe", "Skopiowano %d kotew. Odśwież dane w Advance Steel ('Update defaults') "
                                          "albo uruchom go ponownie." % len(new_n))
