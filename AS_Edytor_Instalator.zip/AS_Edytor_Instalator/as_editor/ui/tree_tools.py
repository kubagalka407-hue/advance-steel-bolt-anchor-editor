# -*- coding: utf-8 -*-
"""Sortowanie (klik w nagłówek: rosnąco / malejąco) i filtrowanie (tekst i liczby) tabel Treeview.

Użycie: make_tree(..., sort=True, filt=True). Moduł nie zmienia danych, tylko kolejność i widoczność wierszy
(ukryte wiersze są 'odpięte' od drzewa, ale zostają w rejestrze i wracają po wyczyszczeniu filtra).
Identyfikatory wierszy (iid) zostają bez zmian, więc kod wybierający po iid działa tak samo."""
import re

from as_editor.i18n import T

NUM = re.compile(r"\d+(?:[.,]\d+)?")
CHUNK = re.compile(r"(\d+(?:[.,]\d+)?)")
OPS = re.compile(r"^(>=|<=|>|<|=)(\d+(?:[.,]\d+)?)$")
RANGE = re.compile(r"^(\d+(?:[.,]\d+)?)(?:\.\.|–|—|-)(\d+(?:[.,]\d+)?)$")
INCH = re.compile(r'^\d+(?:-\d+/\d+|/\d+)?"\s*\((\d+(?:[.,]\d+)?)\)$')
ALL_COLS = "Wszystkie kolumny"
ARROWS = (" ▲", " ▼")


def fnum(s):
    return float(s.replace(",", "."))


def natural_key(v):
    """Klucz sortowania 'naturalnego': liczby jako liczby (M12 < M16 < M20, 8.8 < 10.9), tekst bez wielkości liter.
    Puste wartości na końcu przy sortowaniu rosnącym."""
    s = str(v).strip()
    m = INCH.match(s)
    if m:                                  # średnica calowa '1/2" (12.7)': sortuj i licz po mm
        s = m.group(1)
    if not s:
        return [(2, 0)]
    out = []
    for part in CHUNK.split(s):
        if not part:
            continue
        if CHUNK.fullmatch(part):
            out.append((1, fnum(part)))
        else:
            out.append((0, part.casefold()))
    return out


def parse_filter(text):
    """Zamienia tekst filtra na listę warunków (wszystkie muszą zachodzić): ('num', op, x), ('rng', a, b), ('txt', s)."""
    text = re.sub(r"(>=|<=|>|<|=)\s+", r"\1", (text or "").strip())
    conds = []
    for w in text.split():
        m = OPS.match(w)
        r = RANGE.match(w)
        if m:
            conds.append(("num", m.group(1), fnum(m.group(2))))
        elif r:
            a, b = sorted((fnum(r.group(1)), fnum(r.group(2))))
            conds.append(("rng", a, b))
        else:
            conds.append(("txt", w.casefold()))
    return conds


def cond_ok(cond, cells):
    kind = cond[0]
    if kind == "txt":
        return any(cond[1] in c.casefold() for c in cells)
    nums = [fnum(x) for c in cells for x in NUM.findall(INCH.sub(r"\1", c.strip()))]
    if kind == "rng":
        return any(cond[1] <= x <= cond[2] for x in nums)
    op, y = cond[1], cond[2]
    f = {">=": lambda x: x >= y, "<=": lambda x: x <= y, ">": lambda x: x > y, "<": lambda x: x < y,
         "=": lambda x: abs(x - y) < 1e-9}[op]
    return any(f(x) for x in nums)


class TreeTools:
    """Dokłada do Treeview sortowanie i (opcjonalnie) pasek filtra. Tworzy go make_tree."""

    def __init__(self, tree, frame, columns, sort=True, filt=False):
        from as_editor.ui.widgets import Tooltip, tk, ttk
        self.tree, self.columns = tree, list(columns)
        self.items, self.sort_col, self.sort_rev = [], None, False
        self.job = None
        self.active_filter = False
        self.v_text, self.v_col = tk.StringVar(), tk.StringVar(value=T(ALL_COLS))
        self.v_count = tk.StringVar()
        self.cb = None
        orig_insert, orig_delete = tree.insert, tree.delete
        orig_children = tree.get_children
        self._orig = (orig_insert, orig_delete, orig_children)

        def insert(parent, index, iid=None, **kw):
            r = orig_insert(parent, index, iid, **kw) if iid is not None else orig_insert(parent, index, **kw)
            if parent == "":
                self.items.append(r)
                self.dirty()
            return r

        def delete(*items):
            if items and set(items) >= set(orig_children()):      # czyszczenie całej tabeli: razem z ukrytymi
                orig_delete(*[i for i in self.items if tree.exists(i)])
                self.items = []
            else:
                orig_delete(*items)
                gone = set(items)
                self.items = [i for i in self.items if i not in gone]
            self.update_count()

        tree.insert, tree.delete = insert, delete
        if sort:
            for c in self.columns:
                tree.heading(c, command=lambda c=c: self.sort_by(c))
            self.base = {c: tree.heading(c, "text") for c in self.columns}
        if filt:
            bar = ttk.Frame(frame)
            bar.pack(side="top", fill="x", pady=(0, 4))
            ttk.Label(bar, text=T("Filtr")).pack(side="left")
            e = ttk.Entry(bar, textvariable=self.v_text, width=22)
            e.pack(side="left", padx=4)
            Tooltip(e, T("Tekst: fragment dowolnej nazwy. Liczby: >=20  <=30  >10  =16  albo zakres 10..20. "
                         "Kilka warunków oddziel spacją (muszą zachodzić wszystkie)."))
            self.cb = ttk.Combobox(bar, textvariable=self.v_col, state="readonly", width=18,
                                   values=[T(ALL_COLS)] + [T(str(c)) for c in self.columns])
            self.cb.pack(side="left")
            self.cb.bind("<<ComboboxSelected>>", lambda e: self.apply())
            ttk.Button(bar, text="✕", width=3, command=self.clear_filter).pack(side="left", padx=4)
            ttk.Label(bar, textvariable=self.v_count, style="Hint.TLabel").pack(side="left", padx=8)
            self.v_text.trace_add("write", lambda *a: self.schedule())
        self.has_filter = filt

    # ------------------------------------------------------------------ zdarzenia
    def dirty(self):
        if self.sort_col is not None or self.active_filter or self.has_filter:
            self.schedule()

    def schedule(self, delay=120):
        try:
            if self.job:
                self.tree.after_cancel(self.job)
            self.job = self.tree.after(delay, self.apply)
        except Exception:
            pass

    def clear_filter(self):
        self.v_text.set("")
        self.v_col.set(T(ALL_COLS))
        self.apply()

    def sort_by(self, col):
        self.sort_rev = (not self.sort_rev) if col == self.sort_col else False
        self.sort_col = col
        self.apply()

    # ------------------------------------------------------------------ logika
    def cells(self, iid):
        return [str(v) for v in self.tree.item(iid, "values")]

    def predicate(self):
        conds = parse_filter(self.v_text.get()) if self.has_filter else []
        self.active_filter = bool(conds)
        if not conds:
            return None
        pick = self.cb.current() if self.cb else 0
        idx = pick - 1 if pick > 0 else None

        def ok(cells):
            scope = cells if idx is None or idx >= len(cells) else [cells[idx]]
            return all(cond_ok(c, scope) for c in conds)
        return ok

    def apply(self):
        self.job = None
        tree = self.tree
        self.items = [i for i in self.items if tree.exists(i)]
        if self.sort_col is not None:
            k = self.columns.index(self.sort_col)
            self.items.sort(key=lambda i: natural_key((self.cells(i) + [""] * len(self.columns))[k]), reverse=self.sort_rev)
            for c in self.columns:
                tree.heading(c, text=self.base[c] + (ARROWS[self.sort_rev] if c == self.sort_col else ""))
        pred = self.predicate()
        for iid in self.items:
            if pred is None or pred(self.cells(iid)):
                tree.move(iid, "", "end")
            else:
                tree.detach(iid)
        self.update_count()

    def update_count(self):
        if not self.has_filter:
            return
        total, shown = len(self.items), len(self._orig[2]())
        self.v_count.set((T("Widoczne: %d z %d") % (shown, total)) if self.active_filter else (T("Wierszy: %d") % total))
