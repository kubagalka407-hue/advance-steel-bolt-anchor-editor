# -*- coding: utf-8 -*-
"""Bazowe okno kreatora (krok po kroku): nagłówek z krokami, treść, przyciski Wstecz / Dalej / Zapisz."""
from as_editor.i18n import T
from as_editor.ui.help_texts import show_help
from as_editor.ui.widgets import fit_window, messagebox, tk, ttk


class Wizard(tk.Toplevel):
    finish_text = "Zapisz"

    def __init__(self, app, title, size=(1280, 720)):
        super().__init__(app.root)
        self.app, self.db = app, app.db
        self.title(T(title))
        self.transient(app.root)
        fit_window(self, size[0], size[1], 860, 560)
        self.steps, self.cur = [], -1
        top = ttk.Frame(self)
        top.pack(fill="x", padx=24, pady=(16, 6))
        self.btn_help = ttk.Button(top, text="?", width=3, command=self.help, style="Toolbutton")
        self.btn_help.pack(side="right")
        ttk.Button(top, text=T("Zgłoś problem"), command=self.report, style="Toolbutton").pack(side="right", padx=(0, 4))
        self.var_progress = tk.StringVar()
        ttk.Label(top, textvariable=self.var_progress, style="Hint.TLabel").pack(side="right", padx=12)
        self.hdr = ttk.Frame(top)
        self.hdr.pack(side="left", fill="x", expand=True)
        ttk.Separator(self).pack(fill="x", padx=24)
        nav = ttk.Frame(self)
        nav.pack(side="bottom", fill="x", padx=24, pady=14)
        self.story = ttk.Frame(self, style="Card.TFrame", padding=(14, 10))
        self.var_story = tk.StringVar()
        ttk.Label(self.story, text=T("Co się stanie po zapisie"), style="Step.TLabel").pack(anchor="w")
        ttk.Label(self.story, textvariable=self.var_story, style="CardTitle.TLabel", wraplength=900, justify="left").pack(anchor="w", pady=(2, 0))
        self.bad = None
        self.mid = ttk.Frame(self)
        self.mid.pack(fill="both", expand=True, padx=24, pady=10)
        self.body = ttk.Frame(self.mid)
        self.body.pack(side="left", fill="both", expand=True)
        self.side = None
        ttk.Button(nav, text=T("Anuluj"), command=self.destroy).pack(side="left")
        self.btn_next = ttk.Button(nav, text=T("Dalej") + "  →", style="Accent.TButton", command=self.next)
        self.btn_next.pack(side="right")
        self.btn_back = ttk.Button(nav, text="←  " + T("Wstecz"), command=self.back)
        self.btn_back.pack(side="right", padx=8)
        self.var_err = tk.StringVar()
        ttk.Label(nav, textvariable=self.var_err, style="Err.TLabel", wraplength=520).pack(side="left", padx=16)
        self.step_labels, self.step_dots = [], []

    def make_side(self, title, width=400):
        """Stały panel podglądu po prawej stronie (widoczny w każdym kroku): rysunek kotwy lub śruby, który
        odzwierciedla bieżące wybory. Zwraca ramkę, do której kreator wstawia widżet podglądu."""
        self.side = ttk.LabelFrame(self.mid, text=T(title), padding=8)
        self.side.pack(side="right", fill="y", padx=(14, 0), before=self.body)
        self.side.configure(width=width)
        self.side.pack_propagate(False)
        return self.side

    def add_step(self, title, build, enter=None, leave=None, help=None):
        f = ttk.Frame(self.body)
        build(f)
        self.steps.append({"title": title, "frame": f, "enter": enter, "leave": leave, "help": help})

    def start(self):
        for i, s in enumerate(self.steps):
            if i:
                ttk.Separator(self.hdr, orient="horizontal").pack(side="left", padx=8, ipadx=14)
            dot = tk.Canvas(self.hdr, width=26, height=26, highlightthickness=0, bd=0,
                            bg=ttk.Style(self).lookup("TFrame", "background") or "#fafafa")
            dot.pack(side="left", padx=(0, 6))
            lb = ttk.Label(self.hdr, text=T(s["title"]), style="Step.TLabel")
            lb.pack(side="left")
            self.step_labels.append(lb)
            self.step_dots.append(dot)
        self.bind("<Return>", self.on_return)
        self.show(0)
        self.grab_set()
        self.focus_set()

    def show(self, i):
        for s in self.steps:
            s["frame"].pack_forget()
        self.cur = i
        s = self.steps[i]
        s["frame"].pack(fill="both", expand=True)
        for k, lb in enumerate(self.step_labels):
            title = T(self.steps[k]["title"])
            dot = self.step_dots[k]
            dot.delete("all")
            if k == i:
                lb.configure(style="StepOn.TLabel", text=title)
                dot.create_oval(2, 2, 24, 24, fill="#0b5cad", outline="#0b5cad")
                dot.create_text(13, 13, text=str(k + 1), fill="white", font=("TkDefaultFont", 10, "bold"))
            elif k < i:
                lb.configure(style="StepDone.TLabel", text=title)
                dot.create_oval(2, 2, 24, 24, fill="#0a7a3a", outline="#0a7a3a")
                dot.create_line(8, 13, 12, 17, 18, 9, fill="white", width=2)
            else:
                lb.configure(style="Step.TLabel", text=title)
                dot.create_oval(2, 2, 24, 24, fill="", outline="#9aa5b1", width=2)
                dot.create_text(13, 13, text=str(k + 1), fill="#6b7682", font=("TkDefaultFont", 10))
        last = i == len(self.steps) - 1
        self.story.pack_forget()
        if last:
            self.story.pack(side="bottom", fill="x", padx=24, pady=(0, 6), before=self.mid)
        self.btn_next.configure(text=T(self.finish_text) if last else T("Dalej") + "  →")
        self.btn_back.state(["disabled"] if i == 0 else ["!disabled"])
        self.var_err.set("")
        self.btn_help.state(["!disabled"] if s["help"] else ["disabled"])
        self.var_progress.set(T("Krok %d z %d") % (i + 1, len(self.steps)))
        if s["enter"]:
            s["enter"]()
        self.refresh_side()

    def refresh_side(self):
        """Odświeża panel podglądu po zmianie kroku (kreator z panelem nadpisuje tę metodę)."""

    def on_return(self, e):
        """Enter w polu tekstowym = Dalej (nie w listach, tabelach i przyciskach)."""
        if e.widget.winfo_class() in ("TEntry", "TCombobox", "Entry", "Toplevel"):
            self.next()

    def report(self):
        from as_editor.ui.report import open_report
        open_report(self.app, self)

    def help(self):
        h = self.steps[self.cur]["help"]
        if h:
            show_help(self, h)

    def back(self):
        if self.cur > 0:
            self.show(self.cur - 1)

    def mark_bad(self, widget):
        """Podświetla pole z błędem (stan 'invalid' motywu) i ustawia na nim fokus."""
        self.clear_bad()
        try:
            widget.state(["invalid"])
            widget.focus_set()
            self.bad = widget
            widget.bind("<Key>", lambda e: self.clear_bad(), add="+")
            widget.bind("<<ComboboxSelected>>", lambda e: self.clear_bad(), add="+")
        except Exception:
            pass

    def clear_bad(self):
        if self.bad is not None:
            try:
                self.bad.state(["!invalid"])
            except Exception:
                pass
            self.bad = None

    def next(self):
        s = self.steps[self.cur]
        self.clear_bad()
        err = s["leave"]() if s["leave"] else None
        if err:
            if isinstance(err, tuple):                       # (komunikat, pole)
                err, widget = err
                self.mark_bad(widget)
            self.var_err.set(T(err))
            return
        self.var_err.set("")
        if self.cur == len(self.steps) - 1:
            self.finish()
        else:
            self.show(self.cur + 1)

    def finish(self):
        raise NotImplementedError
