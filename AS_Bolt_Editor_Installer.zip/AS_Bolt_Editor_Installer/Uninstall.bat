@echo off
title Uninstall - Advance Steel Bolt and Anchor Editor
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
