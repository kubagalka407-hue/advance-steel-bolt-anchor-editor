# -*- coding: utf-8 -*-
"""Podpowiedzi (tooltip) przy etykietach: tekst etykiety -> wyjaśnienie z nazwą techniczną w bazie.
Dodanie wpisu wystarcza: hook w ui/hooks.py podpina podpowiedź do każdej etykiety o takim tekście."""

OWNER = ("Kolumna OwnerText. Wpisy z właścicielem DSC lub AUTODESK są fabryczne i program ich nie zmienia ani nie usuwa. "
         "Domyślnie MOJA; Management Tools zapisuje własne wpisy jako PL1.")
CODE = "Unikalny kod używany w bazie (kolumna Key / Standard). Nie zmieniaj go po utworzeniu normy."

TIPS = {
    "Właściciel wpisu (max 15 znaków)": OWNER,
    "Właściciel wpisu": OWNER,
    "Właściciel (max 15)": OWNER,
    "Kod nowej normy (max 32 znaki)": CODE,
    "Kod nowej normy (max 64 znaki)": CODE,
    "Nazwa normy na liście": "Kolumna RunName: nazwa pokazywana w Advance Steel i Management Tools.",
    "Nowa nazwa normy na liście": "Kolumna RunName: nazwa pokazywana w Advance Steel i Management Tools.",
    "Źródło / norma (max 15 znaków)": "Kolumna Source (tabela Sources): skrót normy lub producenta, max 15 znaków, np. EN 14399.",
    "Źródło / norma (max 15)": "Kolumna Source (tabela Sources): skrót normy lub producenta, max 15 znaków, np. HILTI.",
    "Domyślny zestaw normy": "Kolumna StandardSet: zestaw podkładek i nakrętek proponowany dla normy.",
    "Długość dobierana automatycznie": "Kolumna AutoLengthCalc: Advance Steel sam dobiera długość śruby do grubości pakietu.",
    "Możliwe rozbicie zestawu": "Kolumna Explodable: czy zestaw można rozbić na pojedyncze elementy w modelu.",
    "Podgląd wierszy do zapisu": "Wiersze, które trafią do tabeli SetOfBolts (zestawy śrub).",
    "Podgląd kotew do zapisu": "Wiersze, które trafią do tabeli AnchorsName (kotwy) i AnchorsDefinition (długości).",
    "Kod klasy:": "Kolumna Key (tabela StrengthClass): kod używany w bazie, np. 5.6 albo A4-70.",
    "Nazwa na liście:": "Kolumna RunName: nazwa pokazywana na liście klas.",
    "Nowa klasa / twardość": "Kolumna Material: klasa wytrzymałości lub twardość, np. 5.6, 8.8, A4-70, 200HV.",
    "Zestaw (lub wpisz nowy)": "Kolumna SetName: zestaw nakrętek i podkładek kotwy. Nowy zestaw powstanie przy zapisie.",
    "Klasa (lub wpisz nową)": "Kolumna MaterialKey: klasa materiału kotwy. Nową klasę możesz wpisać - powstanie przy zapisie.",
    "Zestaw:": "Kolumna SetName: zestaw nakrętek i podkładek kotwy.",
}
