# -*- coding: utf-8 -*-
"""Wspólne elementy tkinter: importy, kolory, make_tree, make_list, styl, fit_window, Tooltip."""
import sys
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, messagebox, simpledialog


COL_HEAD, COL_WASHER, COL_NUT, COL_PLATE, COL_SHANK, COL_MISSING = (
    "#4a4a4a", "#7fb2e5", "#e59a47", "#d4d4d4", "#a8a8a8", "#e05555")


def make_tree(parent, columns, widths, height=10, selectmode="extended"):
    frm = ttk.Frame(parent)
    tree = ttk.Treeview(frm, columns=columns, show="headings", height=height, selectmode=selectmode)
    vs = ttk.Scrollbar(frm, orient="vertical", command=tree.yview)
    hs = ttk.Scrollbar(frm, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
    for c, w in zip(columns, widths):
        tree.heading(c, text=c)
        tree.column(c, width=w, minwidth=40)
    vs.pack(side="right", fill="y")
    hs.pack(side="bottom", fill="x")
    tree.pack(fill="both", expand=True)
    return frm, tree


def make_list(parent, height=8, width=14):
    frm = ttk.Frame(parent)
    lb = tk.Listbox(frm, selectmode="extended", exportselection=False, height=height, width=width)
    sb = ttk.Scrollbar(frm, orient="vertical", command=lb.yview)
    lb.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    lb.pack(side="left", fill="both", expand=True)
    return frm, lb


def setup_style(root):
    """Jednolity wygląd: na Windows zostaje systemowa czcionka (Segoe UI), gdzie indziej DejaVu Sans (polskie znaki);
    nieco wyższe wiersze tabel i większe przyciski."""
    if sys.platform != "win32":
        for f in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
            try:
                tkfont.nametofont(f).configure(family="DejaVu Sans", size=9)
            except tk.TclError:
                pass
    st = ttk.Style(root)
    st.configure("Treeview", rowheight=22)
    st.configure("TButton", padding=(8, 3))
    st.configure("Hint.TLabel", foreground="#555555")
    st.configure("Ok.TLabel", foreground="#0a7a0a")
    st.configure("Err.TLabel", foreground="#b00000")
    st.configure("Err.TEntry", foreground="#b00000")
    st.configure("Err.TCombobox", foreground="#b00000")


def fit_window(win, width, height, minw=760, minh=520):
    """Ustawia rozmiar okna, ale nie większy niż 92% szerokości i 88% wysokości ekranu (laptop 1366x768), i wyśrodkowuje."""
    win.update_idletasks()
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    w, h = min(width, int(sw * 0.92)), min(height, int(sh * 0.88))
    x, y = max(0, (sw - w) // 2), max(0, (sh - h) // 3)
    win.geometry("%dx%d+%d+%d" % (w, h, x, y))
    win.minsize(min(minw, w), min(minh, h))


class Tooltip:
    """Podpowiedź przy najechaniu myszą (np. nazwa techniczna kolumny w bazie)."""

    def __init__(self, widget, text, delay=500):
        self.widget, self.text, self.delay = widget, text, delay
        self.tip, self.job = None, None
        widget.bind("<Enter>", self._enter, add="+")
        widget.bind("<Leave>", self._leave, add="+")
        widget.bind("<ButtonPress>", self._leave, add="+")

    def _enter(self, _=None):
        self._leave()
        self.job = self.widget.after(self.delay, self._show)

    def _show(self):
        if self.tip or not self.text:
            return
        x, y = self.widget.winfo_rootx() + 12, self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry("+%d+%d" % (x, y))
        tk.Label(self.tip, text=self.text, justify="left", background="#ffffe1", relief="solid", borderwidth=1,
                 wraplength=360, padx=6, pady=3).pack()

    def _leave(self, _=None):
        if self.job:
            try:
                self.widget.after_cancel(self.job)
            except tk.TclError:
                pass
            self.job = None
        if self.tip:
            self.tip.destroy()
            self.tip = None


def add_tip(widget, text):
    """Dodaje podpowiedź do widżetu (tekst przechodzi przez tłumaczenie T) i zwraca widżet."""
    from as_editor.i18n import T
    Tooltip(widget, T(text))
    return widget


def edit_cell(tree, iid, column, initial, commit):
    """Edycja wartości wprost w komórce tabeli (Enter = zatwierdź, Esc = anuluj, kliknięcie obok = zatwierdź).
    column: "#1".. lub nazwa kolumny; commit(tekst) może rzucić ValueError (wtedy pole zostaje otwarte)."""
    box = tree.bbox(iid, column)
    if not box:
        return None
    x, y, w, h = box
    e = ttk.Entry(tree)
    e.place(x=x, y=y, width=max(w, 60), height=h)
    e.insert(0, initial)
    e.select_range(0, "end")
    e.focus_set()
    state = {"done": False}

    def finish(ok):
        if state["done"]:
            return
        if ok:
            try:
                commit(e.get())
            except ValueError as ex:
                e.configure(style="Err.TEntry")
                messagebox.showwarning("Wartość", str(ex) or "Podaj liczbę.", parent=tree)
                e.focus_set()
                return
        state["done"] = True
        e.destroy()

    e.bind("<Return>", lambda ev: finish(True))
    e.bind("<KP_Enter>", lambda ev: finish(True))
    e.bind("<Escape>", lambda ev: finish(False))
    e.bind("<FocusOut>", lambda ev: finish(True))
    return e


def clean_paste(entry):
    """Wklejanie z Excela do pola jednowierszowego: nowe wiersze, tabulatory i średniki -> ", "."""
    def on_paste(ev):
        try:
            txt = entry.clipboard_get()
        except tk.TclError:
            return "break"
        txt = ", ".join(t for t in txt.replace("\t", "\n").replace(";", "\n").splitlines() if t.strip())
        try:
            if entry.selection_present():
                entry.delete("sel.first", "sel.last")
        except tk.TclError:
            pass
        entry.insert("insert", txt)
        return "break"
    entry.bind("<<Paste>>", on_paste)
    entry.bind("<Control-v>", on_paste)
    entry.bind("<Control-V>", on_paste)


def ask_range(parent):
    """Małe okno 'od - do - co ile'; zwraca tekst 'od-do/krok' albo None."""
    from as_editor.i18n import T
    win = tk.Toplevel(parent)
    win.title(T("Zakres długości"))
    win.transient(parent)
    res = {"v": None}
    vs = [tk.StringVar(value=v) for v in ("300", "1000", "100")]
    for i, lab in enumerate(("Od [mm]", "Do [mm]", "Co ile [mm]")):
        ttk.Label(win, text=lab).grid(row=i, column=0, sticky="w", padx=10, pady=4)
        ttk.Entry(win, textvariable=vs[i], width=10).grid(row=i, column=1, padx=10, pady=4)

    def ok():
        try:
            a, b, c = (float(v.get().replace(",", ".")) for v in vs)
            assert c > 0 and b >= a
        except (ValueError, AssertionError):
            messagebox.showwarning("Zakres", "Podaj liczby: od <= do, krok > 0.", parent=win)
            return
        g = lambda x: ("%g" % x)
        res["v"] = "%s-%s/%s" % (g(a), g(b), g(c))
        win.destroy()
    bar = ttk.Frame(win)
    bar.grid(row=3, column=0, columnspan=2, pady=8)
    ttk.Button(bar, text="OK", command=ok).pack(side="left", padx=4)
    ttk.Button(bar, text="Anuluj", command=win.destroy).pack(side="left", padx=4)
    win.grab_set()
    win.wait_window()
    return res["v"]


# ---------------------------------------------------------------- lista z filtrowaniem po wpisaniu tekstu
def make_filterable(cb):
    """Zwykły Combobox staje się listą z filtrem: wpisanie np. 'hilti' zawęża listę do pozycji z tym tekstem
    (kilka słów = wszystkie muszą wystąpić), Enter wybiera pierwszą pasującą. Wartości ustawiaj przez set_choices(),
    a wybraną pozycję odczytuj przez selected_index() (current() liczyłby indeks w liście zawężonej)."""
    cb._all, cb._last = [], -1
    cb.configure(state="normal")

    def matches(text):
        words = text.lower().split()
        return [v for v in cb._all if all(w in v.lower() for w in words)]

    def on_key(ev):
        if ev.keysym in ("Up", "Down", "Left", "Right", "Tab", "Escape", "Shift_L", "Shift_R", "Control_L", "Control_R",
                         "Return", "KP_Enter", "Home", "End", "ISO_Left_Tab", "Alt_L", "Alt_R"):
            return
        cb["values"] = matches(cb.get()) if cb.get().strip() else list(cb._all)

    def on_return(ev):
        m = matches(cb.get())
        if m:
            cb.set(m[0])
            cb["values"] = list(cb._all)
            cb.icursor("end")
            cb.event_generate("<<ComboboxSelected>>")
        return "break"

    def on_pick(ev):
        if cb.get() in cb._all:
            cb._last = cb._all.index(cb.get())
        cb["values"] = list(cb._all)                    # po wyborze lista znów pełna

    def on_focus(ev):
        cb.after(1, lambda: cb.select_range(0, "end"))  # kliknięcie zaznacza tekst: wpisanie zastępuje go

    cb.bind("<KeyRelease>", on_key, add="+")
    cb.bind("<Return>", on_return, add="+")
    cb.bind("<KP_Enter>", on_return, add="+")
    cb.bind("<<ComboboxSelected>>", on_pick, add="+")
    cb.bind("<FocusIn>", on_focus, add="+")
    return cb


def set_choices(cb, values):
    """Ustawia pełną listę pozycji filtrowanego Comboboxa."""
    cb._all = list(values)
    cb["values"] = list(values)


def selected_index(cb):
    """Indeks wybranej pozycji w PEŁNEJ liście (-1 = nic nie wybrano). Niedokończony wpis tekstu nie zmienia wyboru."""
    cur = cb.get()
    if cur in cb._all:
        cb._last = cb._all.index(cur)
    elif not cur.strip():
        cb._last = -1
    return cb._last
