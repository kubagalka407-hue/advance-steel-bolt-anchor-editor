# -*- coding: utf-8 -*-
"""Język interfejsu (PL / EN): T(), set_language(), check_i18n()."""
import os
import re
from as_editor.i18n_en import EN


LANG = "pl"


_PH_RE = re.compile(r"%\.?\d*[sdf]")


_TEMPLATES = []


def _build_templates():
    global _TEMPLATES
    items = []
    for pl, en in EN.items():
        if _PH_RE.search(pl):
            rx, pos = "", 0
            for m in _PH_RE.finditer(pl):
                rx += re.escape(pl[pos:m.start()])
                rx += r"(-?\d+)" if m.group().endswith("d") else (r"(-?[\d.]+)" if m.group().endswith("f") else "(.+?)")
                pos = m.end()
            rx += re.escape(pl[pos:])
            items.append((len(pl) - 2 * len(_PH_RE.findall(pl)), re.compile("^" + rx + "$", re.S), en))
    items.sort(key=lambda x: -x[0])
    _TEMPLATES = [(rx, en) for _, rx, en in items]


def _fill(en, groups):
    it = iter(groups)
    return _PH_RE.sub(lambda m: next(it, m.group()), en)


def T(s):
    """Tłumaczy tekst interfejsu na wybrany język (w trybie polskim zwraca go bez zmian)."""
    if LANG != "en" or not isinstance(s, str) or not s.strip():
        return s
    r = EN.get(s)
    if r is not None:
        return r
    for rx, en in _TEMPLATES:
        m = rx.match(s)
        if m:
            return _fill(en, m.groups())
    if "\n" in s:                        # komunikaty wielowierszowe: wiersz po wierszu
        return "\n".join(T(line) for line in s.split("\n"))
    st = s.strip()
    if st != s:                          # dodatkowe spacje na brzegach
        t = T(st)
        return s if t == st else s[:len(s) - len(s.lstrip())] + t + s[len(s.rstrip()):]
    return s


def check_i18n():
    """Kontrola pokrycia tłumaczeń: wypisuje teksty z polskimi znakami (poza SQL i docstringami), których nie ma w słowniku EN.
    Uruchomienie:  python advance_steel_bolt_editor.py --check-i18n"""
    import ast
    set_language("en")
    pkg = os.path.dirname(os.path.abspath(__file__))
    trees = []
    for root_dir, _dirs, files in os.walk(pkg):
        for fn in sorted(files):
            if fn.endswith(".py") and fn != "i18n_en.py":
                with open(os.path.join(root_dir, fn), "r", encoding="utf-8") as f:
                    trees.append(ast.parse(f.read()))
    docs = set()
    nodes = [n for tr in trees for n in ast.walk(tr)]
    for n in nodes:
        if isinstance(n, (ast.FunctionDef, ast.ClassDef, ast.Module)) and n.body and isinstance(n.body[0], ast.Expr) \
                and isinstance(getattr(n.body[0], "value", None), ast.Constant) and isinstance(n.body[0].value.value, str):
            docs.add(id(n.body[0].value))
    for n in nodes:                                   # wnętrze raportu zgłoszeń jest zawsze po polsku (czyta je Claude)
        if isinstance(n, ast.FunctionDef) and n.name in ("build_report", "dump_widgets", "describe_context", "describe_widget", "help_data"):
            docs.update(id(c) for c in ast.walk(n) if isinstance(c, ast.Constant))
    pl = re.compile("[ąćęłńóśźżĄĆĘŁŃÓŚŹŻ]")
    sql = re.compile(r"^\s*(SELECT|INSERT|DELETE|UPDATE|BACKUP|DRIVER=|\(SELECT|WITH)\b|FROM \[|WHERE \[", re.I)
    missing = []
    for n in nodes:
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and id(n) not in docs:
            v = n.value
            if pl.search(v) and not sql.search(v) and T(v) == v and v not in missing \
                    and not v.startswith(("[ąćę", "Teksty bez tłumaczenia")):
                missing.append(v)
    print("Teksty bez tłumaczenia: %d" % len(missing))
    for v in missing:
        print("  ", repr(v))
    return missing


def set_language(lang):
    global LANG
    LANG = lang if lang in ("pl", "en") else "pl"
    if LANG == "en" and not _TEMPLATES:
        _build_templates()


def get_language():
    return LANG
