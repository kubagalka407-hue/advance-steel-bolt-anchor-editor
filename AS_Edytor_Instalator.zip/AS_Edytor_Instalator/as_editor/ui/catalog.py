# -*- coding: utf-8 -*-
"""Katalog kotew i śrub (widok jak w Tekli): jedno okno - po lewej normy / rodziny, pośrodku tabela typów i rozmiarów,
po prawej rysunek wybranej pozycji; nad tabelą przyciski Nowa / Kopiuj / Zmień / Usuń.
Przyciski uruchamiają istniejące kreatory z już ustawionym wyborem (norma, zestaw, klasy, średnice) - zapis robią kreatory
(kopia zapasowa, dziennik, cofanie). Wpisów fabrycznych (DSC / AUTODESK) Katalog tylko pokazuje: nie zmienia ich ani nie usuwa."""
from as_editor.common import dia_text, fmt_dia, is_own
from as_editor.config import MAX_ITEMS
from as_editor.i18n import T
from as_editor.ui.widgets import Tooltip, make_tree, messagebox, style_listbox, tk, ttk


class CatalogView(ttk.Frame):
    """Wspólny szkielet: tytuł, pasek 'jak to działa', przyciski, lista norm, tabela, panel podglądu. Podklasy wypełniają dane."""
    title = ""
    intro = ""
    left_title = ""
    table_title = ""
    columns = ()
    widths = ()
    preview_title = ""

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app, self.rows, self.items, self.std_keys = app, [], [], []
        self.all_stds, self.counts, self.defs = [], {}, {}
        self.pack(fill="both", expand=True, padx=28, pady=(8, 12))
        head = ttk.Frame(self)
        head.pack(fill="x")
        ttk.Label(head, text=T(self.title), style="Title.TLabel").pack(side="left")
        ttk.Label(self, text=T(self.intro), style="Hint.TLabel", wraplength=1100, justify="left").pack(anchor="w", pady=(2, 6))
        steps = ttk.Frame(self)
        steps.pack(fill="x", pady=(0, 6))
        for n, txt in enumerate((T("Wybierz normę (rodzinę) po lewej"), T("Zaznacz pozycję w tabeli"),
                                 T("Użyj przycisku: Nowa, Kopiuj, Zmień albo Usuń")), 1):
            cell = ttk.Frame(steps)
            cell.pack(side="left", padx=(0, 20))
            dot = tk.Canvas(cell, width=22, height=22, highlightthickness=0, bd=0,
                            bg=ttk.Style(self).lookup("TFrame", "background") or "#fafafa")
            dot.create_oval(1, 1, 21, 21, fill="#0b5cad", outline="#0b5cad")
            dot.create_text(11, 11, text=str(n), fill="white", font=("TkDefaultFont", 9, "bold"))
            dot.pack(side="left", padx=(0, 6))
            ttk.Label(cell, text=txt, style="Body.TLabel").pack(side="left")
        self.bar = ttk.Frame(self)
        self.bar.pack(fill="x", pady=(2, 8))
        self.buttons = {}
        self.build_buttons()
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body, width=250)
        left.pack(side="left", fill="y", padx=(0, 12))
        left.pack_propagate(False)
        ttk.Label(left, text=T(self.left_title), style="CardTitle.TLabel").pack(anchor="w")
        self.build_left_filters(left)
        self.v_find = tk.StringVar()
        self.v_find.trace_add("write", lambda *a: self.fill_stds())
        ent = ttk.Entry(left, textvariable=self.v_find)
        ent.pack(fill="x", pady=(4, 4))
        Tooltip(ent, T("Wpisz fragment nazwy (np. hilti), aby zawęzić listę."))
        lf = ttk.Frame(left)
        lf.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(lf, orient="vertical")
        self.lb = tk.Listbox(lf, exportselection=False, activestyle="none", yscrollcommand=sb.set)
        sb.configure(command=self.lb.yview)
        sb.pack(side="right", fill="y")
        self.lb.pack(side="left", fill="both", expand=True)
        style_listbox(self.lb)
        self.lb.bind("<<ListboxSelect>>", lambda e: self.on_std())
        self.prev_box = ttk.LabelFrame(body, text=T(self.preview_title), padding=6, width=390)
        self.prev_box.pack(side="right", fill="y", padx=(12, 0))
        self.prev_box.pack_propagate(False)
        self.build_preview(self.prev_box)
        mid = ttk.Frame(body)
        mid.pack(side="left", fill="both", expand=True)
        ttk.Label(mid, text=T(self.table_title), style="CardTitle.TLabel").pack(anchor="w")
        fr, self.tree = make_tree(mid, self.columns, self.widths, 14, sort=True, filt=True)
        fr.pack(fill="both", expand=True, pady=(4, 0))
        self.tree.tag_configure("fact", foreground="#7a838d")
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.on_pick())
        self.var_status = tk.StringVar()
        ttk.Label(mid, textvariable=self.var_status, style="Hint.TLabel", wraplength=720, justify="left").pack(anchor="w", pady=(6, 0))
        ttk.Label(mid, text=T("Szare wiersze to pozycje fabryczne (DSC / AUTODESK): program ich nie zmienia ani nie usuwa - "
                              "użyj 'Kopiuj', aby zrobić własną wersję."), style="Hint.TLabel", wraplength=720,
                  justify="left").pack(anchor="w")

    # ------------------------------------------------------------ przyciski
    def add_button(self, key, text, command, tip, accent=False, side="left"):
        b = ttk.Button(self.bar, text=T(text), command=command, style="Accent.TButton" if accent else "TButton")
        b.pack(side=side, padx=(0, 6))
        Tooltip(b, T(tip))
        self.buttons[key] = b
        return b

    def set_enabled(self, **flags):
        for k, v in flags.items():
            b = self.buttons.get(k)
            if b is not None:
                b.state(["!disabled"] if v else ["disabled"])

    # ------------------------------------------------------------ lista norm
    def std_label(self, s):
        raise NotImplementedError

    def fill_stds(self):
        want = self.cur_std()
        f = self.v_find.get().strip().casefold()
        self.lb.delete(0, "end")
        self.std_keys = []
        for s in self.all_stds:
            lab = self.std_label(s)
            if (f and f not in lab.casefold()) or not self.std_ok(s):
                continue
            self.lb.insert("end", lab)
            self.std_keys.append(s[0])
        if want in self.std_keys:
            self.lb.selection_set(self.std_keys.index(want))

    def cur_std(self):
        sel = self.lb.curselection()
        return self.std_keys[sel[0]] if sel and sel[0] < len(self.std_keys) else None

    def select_std(self, key):
        """Zaznacza normę na liście (czyści filtr, jeśli ją ukrywa) i wczytuje jej pozycje."""
        if key not in self.std_keys:
            self.v_find.set("")
            self.fill_stds()
        if key in self.std_keys:
            self.lb.selection_clear(0, "end")
            self.lb.selection_set(self.std_keys.index(key))
            self.lb.see(self.std_keys.index(key))
            self.on_std()

    def on_std(self):
        self.load_items()
        self.on_pick()

    # ------------------------------------------------------------ tabela
    def picked(self):
        return [self.items[int(i)] for i in self.tree.selection() if int(i) < len(self.items)]

    def put_rows(self, rows):
        """rows: lista (wartości kolumn, czy_własna)."""
        self.tree.delete(*self.tree.get_children())
        for i, (vals, own) in enumerate(rows):
            self.tree.insert("", "end", iid=str(i), values=vals, tags=() if own else ("fact",))

    def refresh(self):
        """Odczyt normy z bazy od nowa (po powrocie na stronę, po zamknięciu kreatora, po usunięciu)."""
        if not self.app.db.conn:
            return
        keep = self.cur_std()
        self.all_stds = self.read_stds()
        self.fill_stds()
        if keep:
            self.select_std(keep)
        else:
            self.on_std()

    def watch(self, wizard):
        """Po zamknięciu kreatora odświeża katalog (nowo zapisane pozycje od razu widać w tabeli)."""
        if wizard is None:
            return
        def closed(e):
            if e.widget is wizard:
                try:
                    self.after(200, self.refresh)
                except Exception:
                    pass
        wizard.bind("<Destroy>", closed, add="+")

    def build_left_filters(self, left):
        """Podklasy mogą dołożyć filtry nad listą norm."""

    def std_ok(self, s):
        return True

    # ------------------------------------------------------------ do nadpisania
    def read_stds(self):
        raise NotImplementedError

    def build_buttons(self):
        raise NotImplementedError

    def build_preview(self, box):
        raise NotImplementedError

    def load_items(self):
        raise NotImplementedError

    def on_pick(self):
        raise NotImplementedError


# ====================================================================== kotwy
class AnchorCatalog(CatalogView):
    title = "Katalog kotew"
    intro = ("Tu widzisz wszystkie kotwy z bazy tak, jak je zobaczysz w Advance Steel: rodzina / producent (norma) po lewej, "
             "typy i rozmiary w tabeli, rysunek po prawej. Nową kotwę, kopię albo zmianę zestawu zrobisz przyciskami - "
             "program poprowadzi Cię przez kreator z już wybraną normą.")
    left_title = "Normy / rodziny kotew"
    table_title = "Kotwy w wybranej normie"
    columns = ("Typ", "Ø", "Klasa", "Zestaw", "Długości", "Źródło", "Status")
    widths = (90, 50, 60, 150, 100, 70, 80)
    preview_title = "Podgląd kotwy"

    def build_left_filters(self, left):
        """Typ kotwy i klasa materiału: zawężają listę norm i wiersze tabeli (kotwy innego typu / klasy znikają)."""
        self.cb_ftype = ttk.Combobox(left, state="readonly", values=[T("Wszystkie typy")])
        self.cb_fmat = ttk.Combobox(left, state="readonly", values=[T("Wszystkie klasy")])
        for cb, tip in ((self.cb_ftype, "Pokaż tylko normy i kotwy wybranego typu (np. z hakiem, z łbem)."),
                        (self.cb_fmat, "Pokaż tylko normy i kotwy wybranej klasy materiału (np. 5.8, 8.8).")):
            cb.current(0)
            cb.pack(fill="x", pady=(4, 0))
            cb.bind("<<ComboboxSelected>>", lambda e: self.on_filter())
            Tooltip(cb, T(tip))

    def f_type(self):
        i = self.cb_ftype.current()
        types = getattr(self.app, "an_type_rows", [])
        return types[i - 1][0] if 0 < i <= len(types) else None

    def f_mat(self):
        i = self.cb_fmat.current()
        return self.cb_fmat["values"][i] if i > 0 else None

    def std_ok(self, s):
        tid, mat = self.f_type(), self.f_mat()
        return ((tid is None or tid in getattr(self.app, "an_std_types", {}).get(s[0], ())) and
                (mat is None or mat in getattr(self.app, "an_std_mats", {}).get(s[0], ())))

    def on_filter(self):
        self.fill_stds()
        self.load_items()
        self.on_pick()

    def read_stds(self):
        types = getattr(self.app, "an_type_rows", [])
        keep_t = self.f_type()
        self.cb_ftype["values"] = [T("Wszystkie typy")] + ["%s   |   %s" % (x[0], T(x[1])) for x in types]
        self.cb_ftype.current(1 + [x[0] for x in types].index(keep_t) if keep_t in [x[0] for x in types] else 0)
        mats = sorted({m for ms in getattr(self.app, "an_std_mats", {}).values() for m in ms})
        keep = self.f_mat()
        self.cb_fmat["values"] = [T("Wszystkie klasy")] + mats
        self.cb_fmat.current(mats.index(keep) + 1 if keep in mats else 0)
        counts = dict(self.app.db.rows("SELECT [Standard], COUNT(*) FROM [AnchorsName] GROUP BY [Standard]"))
        self.counts = counts
        return list(self.app.db.anchor_standards())

    def std_label(self, s):
        return "%s%s   (%d)" % (s[0], "  [MOJA]" if is_own(s[2]) else "", self.counts.get(s[0], 0))

    def build_buttons(self):
        self.add_button("new", "+  Nowa kotwa", self.new_anchor,
                        "Kreator nowej kotwy w wybranej normie (typ, wymiary, długości, zestaw). Od zera albo na wzorcu.", accent=True)
        self.add_button("copy", "Kopiuj jako nową…", self.copy_anchor,
                        "Nowa kotwa na wzorcu zaznaczonej: dostaje jej typ, klasę, zestaw i wymiary; Ty wpisujesz nową średnicę i długości.")
        self.add_button("set", "Dodaj / zmień zestaw…", self.change_set,
                        "Nowy zestaw nakrętek i podkładek dla zaznaczonych kotew (albo zmiana zestawu w Twoich kotwach).")
        self.add_button("len", "Dopisz długości…", self.add_lengths,
                        "Dopisuje nowe długości do zaznaczonych kotew.")
        self.add_button("washer", "Nowa podkładka / nakrętka", self.new_washer,
                        "Brakuje elementu w zestawie? Dodaj nową podkładkę lub nakrętkę do katalogu (służy też śrubom).")
        self.add_button("del", "Usuń zaznaczone", self.delete, "Usuwa tylko Twoje kotwy (nie fabryczne); można cofnąć w 'Moje wpisy i cofanie'.", side="right")
        self.set_enabled(new=False, copy=False, set=False, len=False, **{"del": False})

    def build_preview(self, box):
        from as_editor.ui.wizard_anchor import ShapePreview, zone_of_anchor
        self.shape = ShapePreview(box, self.app, lambda: zone_of_anchor(self.shape.anchors[0]) if self.shape.anchors else
                                  {"top": [], "below": [], "end": []})
        self.shape.v_cap.set(T("Zaznacz kotwę w tabeli - zobaczysz jej rysunek ze składem zestawu."))
        self.shape.pack(fill="both", expand=True)

    def load_items(self):
        std = self.cur_std()
        self.items = []
        self.defs = {}
        if std:
            names = self.app.db.anchor_names(std)
            tid, mat = self.f_type(), self.f_mat()
            names = [n for n in names if (tid is None or n["ClassID"] == tid) and (mat is None or n["MaterialKey"] == mat)]
            self.items = sorted(names, key=lambda n: (n["ClassID"], float(n["Diameter"]), n["MaterialKey"], n["SetName"]))
            self.defs = self.app.db.anchor_children([n["ID"] for n in self.items])[0] if self.items else {}
        tn = {r[0]: r[1] for r in self.app.an_type_rows}
        rows = []
        for n in self.items:
            ls = sorted(r["Length"] for r in self.defs.get(n["ID"], []) if r.get("Length") is not None)
            rng = "%d:  %s - %s" % (len(ls), fmt_dia(ls[0]), fmt_dia(ls[-1])) if ls else "0"
            own = is_own(n.get("OwnerText"))
            rows.append(((T(tn.get(n["ClassID"], "?")), dia_text(float(n["Diameter"])), n["MaterialKey"], n["SetName"], rng,
                          n.get("Source") or "", T("własna") if own else T("fabryczna")), own))
        self.put_rows(rows)

    def on_pick(self):
        sel = self.picked()
        own = [n for n in sel if is_own(n.get("OwnerText"))]
        self.set_enabled(new=bool(self.cur_std()), copy=len(sel) == 1, set=bool(sel), len=bool(sel), **{"del": bool(own)})
        if sel:
            self.shape.set_anchors(sel[:1])
            self.shape.v_cap.set(T("Podgląd zaznaczonej kotwy (najdłuższa z jej długości)."))
            n = sel[0]
            self.var_status.set(T("Zaznaczono: %d.  Pierwsza: Ø%s, klasa %s, zestaw %s, źródło %s, właściciel %s.") % (
                len(sel), dia_text(float(n["Diameter"])), n["MaterialKey"], n["SetName"], n.get("Source") or "-", n.get("OwnerText") or "-"))
        else:
            self.shape.set_anchors([])
            self.shape.v_cap.set(T("Zaznacz kotwę w tabeli - zobaczysz jej rysunek ze składem zestawu."))
            std = self.cur_std()
            self.var_status.set(T("Kotew w tej normie: %d.") % len(self.items) if std else T("Wybierz normę po lewej."))

    # ------------------------------------------------------------ akcje
    def new_anchor(self):
        w = self.app.open_anchor_wizard("new")
        if w is not None:
            w.preset(self.cur_std())
            self.watch(w)

    def copy_anchor(self):
        sel = self.picked()
        if len(sel) != 1:
            return
        w = self.app.open_anchor_wizard("new")
        if w is not None:
            w.preset(self.cur_std(), sel[0]["ID"])
            self.watch(w)

    def _selection_args(self):
        sel = self.picked()
        sets = {n["SetName"] for n in sel}
        return dict(std=self.cur_std(), set_name=sets.pop() if len(sets) == 1 else None,
                    mats=sorted({n["MaterialKey"] for n in sel}), dias=sorted({float(n["Diameter"]) for n in sel}))

    def change_set(self):
        if not self.picked():
            return
        w = self.app.open_anchor_wizard("set")
        if w is not None:
            w.preselect(**self._selection_args())
            self.watch(w)

    def add_lengths(self):
        if not self.picked():
            return
        w = self.app.open_anchor_wizard("len")
        if w is not None:
            w.preselect(**self._selection_args())
            self.watch(w)

    def new_washer(self):
        self.app.open_tool(self.app.tab_new, "anchors")

    def delete(self):
        sel = self.picked()
        own = [n for n in sel if is_own(n.get("OwnerText"))]
        if not own:
            messagebox.showinfo("Usuń", "Zaznaczone kotwy są fabryczne - ich nie usuwamy.")
            return
        if len(own) < len(sel):
            messagebox.showinfo("Usuń", T("Fabryczne kotwy z zaznaczenia (%d) zostaną pominięte.") % (len(sel) - len(own)))
        if self.app.delete_anchors([n["ID"] for n in own]):
            self.refresh()


# ====================================================================== śruby
def set_components(row):
    """Skład zestawu z wiersza SetOfBolts -> (strona łba, strona nakrętki), od blachy na zewnątrz (jak components_from_set)."""
    comps = []
    for k in range(1, MAX_ITEMS + 1):
        din, pos, m = row.get("DIN%d" % k), row.get("Position%d" % k), row.get("Material%d" % k)
        if din not in (None, "", "-") and pos:
            comps.append((pos, {"std": din, "mat": m}))
    head = [c for p, c in sorted((x for x in comps if x[0] > 0), key=lambda t: t[0])]
    nut = [c for p, c in sorted((x for x in comps if x[0] < 0), key=lambda t: abs(t[0]))]
    return head, nut


def comp_text(head, nut):
    h = " + ".join(c["std"] for c in head) or "-"
    n = " + ".join(c["std"] for c in nut) or "-"
    return "%s: %s   %s: %s" % (T("łeb"), h, T("nakrętka"), n)


class BoltCatalog(CatalogView):
    title = "Katalog śrub"
    intro = ("Tu widzisz zestawy śrub (podkładki i nakrętki przypisane do śruby) tak, jak są w bazie: norma śruby po lewej, "
             "zestawy i klasy w tabeli, rysunek po prawej. Nowy zestaw, kopię albo zmianę własnego zestawu zrobisz przyciskami - "
             "kreator otworzy się z już wybraną normą, klasą i średnicami.")
    left_title = "Normy śrub"
    table_title = "Zestawy w wybranej normie"
    columns = ("Zestaw", "Klasa", "Średnice", "Skład", "Status")
    widths = (150, 70, 130, 360, 80)
    preview_title = "Podgląd śruby"

    def read_stds(self):
        self.counts = dict(self.app.db.rows("SELECT [Standard], COUNT(DISTINCT [Set]) FROM [SetOfBolts] GROUP BY [Standard]"))
        return list(self.app.db.standards())

    def std_label(self, s):
        return "%s%s   (%d)" % (s[0], "  [MOJA]" if is_own(s[4]) else "", self.counts.get(s[0], 0))

    def build_buttons(self):
        self.add_button("new", "+  Nowy zestaw", self.new_set,
                        "Kreator zestawu dla wybranej normy: klasy, średnice, podkładki i nakrętki.", accent=True)
        self.add_button("copy", "Kopiuj zestaw…", self.copy_set,
                        "Nowy zestaw na wzorcu zaznaczonego: dostaje jego skład, który możesz zmienić; oryginał zostaje bez zmian.")
        self.add_button("edit", "Zmień mój zestaw…", self.edit_set,
                        "Zmienia skład Twojego zestawu (nadpisuje go). Zestawów fabrycznych nie zmieniamy - użyj 'Kopiuj zestaw'.")
        self.add_button("cls", "Skopiuj klasę…", self.copy_class,
                        "Cała nowa klasa śrub (np. 5.6) z wymiarami i zestawami istniejącej klasy.")
        self.add_button("washer", "Nowa podkładka / nakrętka", self.new_washer,
                        "Brakuje elementu? Dodaj nową podkładkę lub nakrętkę do katalogu.")
        self.add_button("del", "Usuń zaznaczone", self.delete, "Usuwa tylko Twoje zestawy (nie fabryczne); można cofnąć w 'Moje wpisy i cofanie'.", side="right")
        self.set_enabled(new=False, copy=False, edit=False, cls=False, **{"del": False})

    def build_preview(self, box):
        from as_editor.ui.preview_panel import BoltPreview
        self.bolt = BoltPreview(box, self.app, self.bolt_state)
        self.bolt.pack(fill="both", expand=True)

    def load_items(self):
        std = self.cur_std()
        groups = {}
        if std:
            rows, cols = self.app.db.query("SELECT * FROM [SetOfBolts] WHERE [Standard]=? ORDER BY [Set],[Material],[Diameter]", (std,))
            for r in rows:
                d = dict(zip(cols, r))
                g = groups.setdefault((d["Set"], d["Material"]), {"set": d["Set"], "mat": d["Material"], "dias": [], "owner": d.get("OwnerText"),
                                                                 "rows": [], "first": d})
                g["dias"].append(float(d["Diameter"]))
                g["rows"].append((std, d["Set"], d["Material"], float(d["Diameter"]), d.get("OwnerText")))
        self.items = list(groups.values())
        rows_out = []
        for g in self.items:
            g["head"], g["nut"] = set_components(g["first"])
            ds = sorted(g["dias"])
            g["own"] = is_own(g["owner"])
            dtxt = "%s - %s  (%d)" % (dia_text(ds[0]), dia_text(ds[-1]), len(ds)) if len(ds) > 1 else dia_text(ds[0])
            rows_out.append(((g["set"], g["mat"], dtxt, comp_text(g["head"], g["nut"]), T("własny") if g["own"] else T("fabryczny")), g["own"]))
        self.put_rows(rows_out)

    def bolt_state(self):
        sel = self.picked()
        if not sel:
            return {"std": self.cur_std(), "caption": T("Zaznacz zestaw w tabeli - zobaczysz śrubę z jego podkładkami i nakrętkami.")}
        g = sel[0]
        return {"std": self.cur_std(), "mats": [g["mat"]], "dias": sorted(g["dias"]), "head": g["head"], "nut": g["nut"],
                "caption": T("Zestaw %s (klasa %s).") % (g["set"], g["mat"])}

    def on_pick(self):
        sel = self.picked()
        own = [g for g in sel if g["own"]]
        self.set_enabled(new=bool(self.cur_std()), copy=len(sel) == 1, edit=len(sel) == 1 and bool(own), cls=bool(self.cur_std()),
                         **{"del": bool(own)})
        if sel:
            g = sel[0]
            self.var_status.set(T("Zaznaczono: %d.  Pierwszy: zestaw %s, klasa %s, %d średnic, właściciel %s.") % (
                len(sel), g["set"], g["mat"], len(g["dias"]), g["owner"] or "-"))
        else:
            self.var_status.set(T("Zestawów w tej normie: %d.") % len(self.items) if self.cur_std() else T("Wybierz normę po lewej."))
        self.bolt.refresh()

    # ------------------------------------------------------------ akcje
    def new_set(self):
        w = self.app.open_bolt_set_wizard()
        if w is not None:
            w.preset(self.cur_std())
            self.watch(w)

    def copy_set(self):
        sel = self.picked()
        if len(sel) != 1:
            return
        g = sel[0]
        w = self.app.open_bolt_set_wizard()
        if w is not None:
            w.preset(self.cur_std(), mats=[g["mat"]], dias=sorted(g["dias"]), tpl=(g["set"], g["mat"]))
            self.watch(w)

    def edit_set(self):
        sel = self.picked()
        if len(sel) != 1 or not sel[0]["own"]:
            messagebox.showinfo("Zmień", "Zestawu fabrycznego nie zmieniamy - użyj 'Kopiuj zestaw', a potem zmień kopię.")
            return
        g = sel[0]
        run = next((s[1] for s in self.app.sets if s[0] == g["set"]), g["set"])
        w = self.app.open_bolt_set_wizard()
        if w is not None:
            w.preset(self.cur_std(), mats=[g["mat"]], dias=sorted(g["dias"]), tpl=(g["set"], g["mat"]), key=g["set"], run=run, overwrite=True)
            self.watch(w)

    def copy_class(self):
        w = self.app.open_class_copy_wizard()
        if w is None:
            return
        try:
            i = next(k for k, st in enumerate(self.app.stds) if st[0] == self.cur_std())
            w.cb_std.set(self.app.std_vals[i])
            w.cb_std._last = i
            w.on_std()
        except Exception:
            pass
        self.watch(w)

    def new_washer(self):
        self.app.open_tool(self.app.tab_new, "bolts")

    def delete(self):
        sel = self.picked()
        own = [g for g in sel if g["own"]]
        if not own:
            messagebox.showinfo("Usuń", "Zaznaczone zestawy są fabryczne - ich nie usuwamy.")
            return
        rows = [r for g in own for r in g["rows"]]
        if self.app.delete_bolt_sets(rows):
            self.refresh()


# ====================================================================== wpięcie w powłokę
class CatalogMixin:
    def build_page_cat_anchors(self, page):
        self.cat_anchors = AnchorCatalog(page, self)

    def build_page_cat_bolts(self, page):
        self.cat_bolts = BoltCatalog(page, self)

    def refresh_cat_page(self, name):
        view = {"cat_anchors": getattr(self, "cat_anchors", None), "cat_bolts": getattr(self, "cat_bolts", None)}.get(name)
        if view is not None:
            try:
                view.refresh()
            except Exception as e:
                self.say(T("Nie udało się odczytać katalogu: %s") % str(e).splitlines()[0][:120], "err")
