# -*- coding: utf-8 -*-
"""Małe okna dialogowe: wybór elementu zestawu, wczytanie zestawu, wybór z listy, wzorzec kotwy."""
from as_editor.common import fmt_dia
from as_editor.ui.widgets import tk, ttk


class CompDialog(tk.Toplevel):
    """Wybór elementu: typ (podkładka/nakrętka) -> norma -> klasa, z podglądem wymiarów."""

    def __init__(self, parent, db, title, dia, default_kind="washer"):
        super().__init__(parent)
        self.title(title)
        self.result = None
        self.db, self.dia = db, dia
        self.stds = []
        self.transient(parent)
        self.kind = tk.StringVar(value=default_kind)
        bar = ttk.Frame(self)
        bar.grid(row=0, column=0, columnspan=2, sticky="w", padx=8, pady=6)
        ttk.Label(bar, text="Typ elementu:").pack(side="left")
        for txt, val in (("Podkładka", "washer"), ("Nakrętka", "nut"), ("Wszystkie", "all")):
            ttk.Radiobutton(bar, text=txt, value=val, variable=self.kind,
                            command=self.fill_std).pack(side="left", padx=8)
        ttk.Label(self, text="Norma elementu:").grid(row=1, column=0, sticky="w", padx=8, pady=6)
        self.cb_std = ttk.Combobox(self, width=56, state="readonly")
        self.cb_std.grid(row=1, column=1, padx=8)
        self.cb_std.bind("<<ComboboxSelected>>", self.on_std)
        ttk.Label(self, text="Klasa / twardość:").grid(row=2, column=0, sticky="w", padx=8, pady=6)
        self.cb_mat = ttk.Combobox(self, width=24, state="readonly")
        self.cb_mat.grid(row=2, column=1, sticky="w", padx=8)
        self.cb_mat.bind("<<ComboboxSelected>>", lambda e: self.info_update())
        self.info = tk.StringVar()
        ttk.Label(self, textvariable=self.info, wraplength=520, foreground="#444").grid(
            row=3, column=0, columnspan=2, sticky="w", padx=8, pady=6)
        b2 = ttk.Frame(self)
        b2.grid(row=4, column=0, columnspan=2, pady=8)
        ttk.Button(b2, text="Dodaj", command=self.ok).pack(side="left", padx=6)
        ttk.Button(b2, text="Anuluj", command=self.destroy).pack(side="left")
        self.fill_std()
        self.grab_set()
        self.wait_window()

    def fill_std(self):
        k = self.kind.get()
        self.stds = self.db.nut_standards(None if k == "all" else k)
        self.cb_std["values"] = ["%s   |   %s" % (a, b) for a, b in self.stds]
        self.cb_std.set("")
        self.cb_mat.set("")
        self.cb_mat["values"] = []
        self.info.set("")

    def cur_std(self):
        i = self.cb_std.current()
        return self.stds[i][0] if i >= 0 else None

    def on_std(self, _=None):
        mats = self.db.nut_materials(self.cur_std())
        self.cb_mat["values"] = mats
        if mats:
            self.cb_mat.current(0)
        self.info_update()

    def info_update(self):
        s, m = self.cur_std(), self.cb_mat.get()
        if s and m and self.dia is not None:
            self.info.set("Ø%s:  %s" % (fmt_dia(self.dia), self.db.describe(s, m, self.dia)))

    def ok(self):
        if self.cur_std() and self.cb_mat.get():
            self.result = {"std": self.cur_std(), "mat": self.cb_mat.get()}
            self.destroy()


class LoadDialog(tk.Toplevel):
    """Wczytanie składu z istniejącego zestawu (jak 'Copy from...' w Management Tools)."""

    def __init__(self, parent, db, std):
        super().__init__(parent)
        self.title("Wczytaj skład z istniejącego zestawu")
        self.result = None
        self.db, self.std = db, std
        self.transient(parent)
        ttk.Label(self, text="Zestaw dla normy %s:" % std).grid(row=0, column=0, padx=8, pady=6, sticky="w")
        sets = [r[0] for r in db.rows("SELECT DISTINCT [Set] FROM [SetOfBolts] WHERE [Standard]=? ORDER BY 1", (std,))]
        self.cb_set = ttk.Combobox(self, values=sets, state="readonly", width=28)
        self.cb_set.grid(row=0, column=1, padx=8)
        self.cb_set.bind("<<ComboboxSelected>>", self.on_set)
        ttk.Label(self, text="Klasa:").grid(row=1, column=0, padx=8, pady=6, sticky="w")
        self.cb_mat = ttk.Combobox(self, state="readonly", width=28)
        self.cb_mat.grid(row=1, column=1, padx=8)
        bar = ttk.Frame(self)
        bar.grid(row=2, column=0, columnspan=2, pady=8)
        ttk.Button(bar, text="Wczytaj", command=self.ok).pack(side="left", padx=6)
        ttk.Button(bar, text="Anuluj", command=self.destroy).pack(side="left")
        self.grab_set()
        self.wait_window()

    def on_set(self, _=None):
        mats = [r[0] for r in self.db.rows(
            "SELECT DISTINCT [Material] FROM [SetOfBolts] WHERE [Standard]=? AND [Set]=? ORDER BY 1",
            (self.std, self.cb_set.get()))]
        self.cb_mat["values"] = mats
        if mats:
            self.cb_mat.current(0)

    def ok(self):
        if self.cb_set.get() and self.cb_mat.get():
            self.result = (self.cb_set.get(), self.cb_mat.get())
            self.destroy()


class ChoiceDialog(tk.Toplevel):
    """Wybór jednej wartości z listy."""

    def __init__(self, parent, title, prompt, values, initial=None):
        super().__init__(parent)
        self.title(title)
        self.result = None
        self.transient(parent)
        ttk.Label(self, text=prompt, wraplength=420).grid(row=0, column=0, padx=10, pady=8, sticky="w")
        self.cb = ttk.Combobox(self, values=list(values), state="readonly", width=34)
        self.cb.grid(row=1, column=0, padx=10)
        if initial in values:
            self.cb.set(initial)
        bar = ttk.Frame(self)
        bar.grid(row=2, column=0, pady=10)
        ttk.Button(bar, text="OK", command=self.ok).pack(side="left", padx=6)
        ttk.Button(bar, text="Anuluj", command=self.destroy).pack(side="left")
        self.grab_set()
        self.wait_window()

    def ok(self):
        if self.cb.get():
            self.result = self.cb.get()
            self.destroy()


class AnLoadDialog(tk.Toplevel):
    """Wybór istniejącej kotwy jako wzorca (norma + klasa + zestaw), jak 'Copy from...' w Management Tools."""

    def __init__(self, parent, db, std_rows):
        super().__init__(parent)
        self.title("Wczytaj wzorzec kotwy")
        self.result = None
        self.db, self.std_rows = db, std_rows
        self.transient(parent)
        ttk.Label(self, text="Norma kotwy:").grid(row=0, column=0, padx=8, pady=6, sticky="w")
        self.cb_std = ttk.Combobox(self, width=46, state="readonly",
                                   values=["%s   |   %s" % (r[0], r[1]) for r in std_rows])
        self.cb_std.grid(row=0, column=1, padx=8)
        self.cb_std.bind("<<ComboboxSelected>>", self.on_std)
        ttk.Label(self, text="Klasa:").grid(row=1, column=0, padx=8, pady=6, sticky="w")
        self.cb_mat = ttk.Combobox(self, width=24, state="readonly")
        self.cb_mat.grid(row=1, column=1, padx=8, sticky="w")
        self.cb_mat.bind("<<ComboboxSelected>>", self.on_mat)
        ttk.Label(self, text="Zestaw:").grid(row=2, column=0, padx=8, pady=6, sticky="w")
        self.cb_set = ttk.Combobox(self, width=34, state="readonly")
        self.cb_set.grid(row=2, column=1, padx=8, sticky="w")
        bar = ttk.Frame(self)
        bar.grid(row=3, column=0, columnspan=2, pady=10)
        ttk.Button(bar, text="Wczytaj", command=self.ok).pack(side="left", padx=6)
        ttk.Button(bar, text="Anuluj", command=self.destroy).pack(side="left")
        self.grab_set()
        self.wait_window()

    def cur_std(self):
        i = self.cb_std.current()
        return self.std_rows[i][0] if i >= 0 else None

    def on_std(self, _=None):
        mats = self.db.anchor_materials(self.cur_std())
        self.cb_mat["values"] = mats
        if mats:
            self.cb_mat.current(0)
        self.on_mat()

    def on_mat(self, _=None):
        sets = [r[0] for r in self.db.rows("SELECT DISTINCT [SetName] FROM [AnchorsName] WHERE [Standard]=? AND "
                                           "[MaterialKey]=? ORDER BY 1", (self.cur_std(), self.cb_mat.get()))]
        self.cb_set["values"] = sets
        if sets:
            self.cb_set.current(0)

    def ok(self):
        if self.cur_std() and self.cb_mat.get() and self.cb_set.get():
            self.result = (self.cur_std(), self.cb_mat.get(), self.cb_set.get())
            self.destroy()
