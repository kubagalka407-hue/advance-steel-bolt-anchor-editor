"""Moduły pakietu as_editor.tabs."""
