# -*- coding: utf-8 -*-
"""Okno '+ Długość': dopisanie nowych długości (i ich wymiarów) do ISTNIEJĄCEJ kotwy. Nic poza tym nie jest edytowalne:
typ, średnica, klasa, zestaw i skład zestawu zostają takie, jakie ma kotwa; dopisywane są tylko nowe wiersze definicji."""
from as_editor.anchors_logic import ANCHOR_DEF_COLS, ANCHOR_LABELS, ANCHOR_TIPS, anchor_weight, build_anchor_def_row, rename_part, zone_of
from as_editor.bolts_logic import parse_lengths
from as_editor.common import dia_text, fmt_dia, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER, MAX_ITEMS, recall, remember
from as_editor.i18n import T
from as_editor.ui.anchor_shape import DEFAULT_PLATE, check_dims, draw as shape_draw, num, resolve_items
from as_editor.ui.widgets import add_tip, ask_range, clean_paste, fit_window, make_tree, messagebox, tk, ttk

SKIP = ("Length", "Weight", "PartName")


class AddLengthsDialog(tk.Toplevel):
    def __init__(self, app, std_key, anchor_id, modal=True):
        super().__init__(app.root)
        self.app, self.db, self.std = app, app.db, std_key
        self.n = next((x for x in self.db.anchor_names(std_key) if x["ID"] == anchor_id), None)
        if self.n is None:
            self.destroy()
            return
        self.aid, self.tid, self.dia = anchor_id, self.n["ClassID"], float(self.n["Diameter"])
        defs, _ = self.db.anchor_children([anchor_id])
        self.defs = sorted(defs.get(anchor_id, []), key=lambda r: r.get("Length") or 0)
        self.have = {r.get("Length") for r in self.defs}
        self.factory = not is_own(self.n.get("OwnerText"))
        self.title(T("Dodaj długości do kotwy") + ": %s  Ø%s  %s  %s" % (
            std_key, dia_text(self.dia), self.n["MaterialKey"], self.n["SetName"]))
        fit_window(self, 1060, 700, 860, 540)
        self.transient(app.root)
        self.zone = {"top": [], "below": [], "end": []}
        comps = []
        for k in range(1, MAX_ITEMS + 1):
            din, pos, m = self.n.get("DIN%d" % k), self.n.get("Position%d" % k), self.n.get("Material%d" % k)
            if din not in (None, "", "-") and pos:
                comps.append((pos, {"std": din, "mat": m}))
        for pos, c in sorted(comps, key=lambda t: abs(t[0])):
            self.zone[zone_of(pos)].append(c)
        self.cols = [c for c in ANCHOR_DEF_COLS.get(self.tid, ANCHOR_DEF_COLS[3]) if c not in SKIP]
        self.pvars, self.focus_col, self.sel_len, self._job, self.plan = {}, None, None, None, None
        self.v_len, self.v_w, self.v_part = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.v_owner = tk.StringVar(value=recall("owner", DEFAULT_OWNER))
        self.v_plate = tk.StringVar(value=fmt_dia(DEFAULT_PLATE))
        self.v_grout = tk.StringVar(value="0")
        self.v_hint, self.v_shape, self.v_base = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self._build()
        self.use_base(len(self.defs) - 1)
        if modal:
            self.grab_set()
            self.wait_window()

    # ------------------------------------------------------------------ układ
    def _build(self):
        b = ttk.Frame(self)
        b.pack(side="bottom", fill="x", padx=10, pady=6)
        n = self.n
        lens = ", ".join(fmt_dia(x) for x in sorted(self.have) if x is not None) or "-"
        head = T("Kotwa: typ %s, Ø%s, klasa %s, zestaw %s. Istniejące długości: %s.") % (
            self.tid, dia_text(self.dia), n["MaterialKey"], n["SetName"], lens)
        ttk.Label(self, text=head, wraplength=1000, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10, pady=(8, 0))
        if self.factory:
            ttk.Label(self, text=T("To kotwa fabryczna. Jej dotychczasowe wiersze zostaną bez zmian - dopisane zostaną tylko "
                                   "nowe wiersze z Twoim właścicielem (można je potem usunąć)."),
                      wraplength=1000, foreground="#7a4b00").pack(anchor="w", padx=10)
        ttk.Label(self, text=T("Wpisz nowe długości i sprawdź wymiary. Typ, średnica, klasa i zestaw kotwy zostają bez zmian."),
                  wraplength=1000, foreground="#444").pack(anchor="w", padx=10, pady=(2, 4))
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, padx=10)
        left = ttk.Frame(body)
        left.pack(side="left", fill="both", expand=True)
        fl = ttk.LabelFrame(left, text="Nowe długości")
        fl.pack(fill="x")
        ttk.Label(fl, text="Długości [mm] (lista, zakresy np. 300-1000/100 albo kolumna wklejona z Excela)").grid(
            row=0, column=0, sticky="w", padx=6, pady=3)
        lf = ttk.Frame(fl)
        lf.grid(row=1, column=0, sticky="w", padx=6, pady=(0, 4))
        en = ttk.Entry(lf, textvariable=self.v_len, width=44)
        en.pack(side="left")
        clean_paste(en)
        ttk.Button(lf, text="Od-do co...", command=self.add_range).pack(side="left", padx=4)
        en.focus_set()
        ttk.Label(fl, text="Ciężar pierwszej nowej długości [kg] (puste = przeliczony)").grid(row=2, column=0, sticky="w", padx=6)
        ttk.Entry(fl, textvariable=self.v_w, width=12).grid(row=3, column=0, sticky="w", padx=6, pady=(0, 4))
        ttk.Label(fl, text="Numer części pierwszej nowej długości (puste = automatyczny)").grid(row=4, column=0, sticky="w", padx=6)
        ttk.Entry(fl, textvariable=self.v_part, width=44).grid(row=5, column=0, sticky="w", padx=6, pady=(0, 4))
        fp = ttk.LabelFrame(left, text="Wymiary nowych długości (zależne od typu)")
        fp.pack(fill="x", pady=6)
        rb = ttk.Frame(fp)
        rb.grid(row=0, column=0, columnspan=4, sticky="w", padx=8, pady=3)
        ttk.Label(rb, text="Weź wymiary z istniejącej długości:").pack(side="left")
        self.cb_base = ttk.Combobox(rb, width=10, state="readonly", textvariable=self.v_base,
                                    values=[fmt_dia(r["Length"]) for r in self.defs if r.get("Length") is not None])
        self.cb_base.pack(side="left", padx=4)
        self.cb_base.bind("<<ComboboxSelected>>", lambda e: self.use_base(self.cb_base.current()))
        for i, c in enumerate(self.cols):
            lab = ttk.Label(fp, text=T(ANCHOR_LABELS[c]) + (" [mm]" if c != "NumberOfHeadEdges" else ""))
            lab.grid(row=1 + i // 2, column=(i % 2) * 2, sticky="w", padx=(8, 4), pady=3)
            add_tip(lab, T(ANCHOR_TIPS[c]))
            v = tk.StringVar()
            v.trace_add("write", lambda *a: self.schedule_draw())
            self.pvars[c] = v
            e = ttk.Entry(fp, textvariable=v, width=9)
            e.grid(row=1 + i // 2, column=(i % 2) * 2 + 1, sticky="w", pady=3)
            e.bind("<FocusIn>", lambda ev, col=c: self.set_focus(col))
        ttk.Label(left, text="Podgląd do zapisu (kliknij wiersz, aby zobaczyć tę długość na schemacie):").pack(anchor="w")
        ttk.Label(left, textvariable=self.v_hint, foreground="#b00", wraplength=520).pack(anchor="w")
        fr, self.tr_prev = make_tree(left, ("Długość", "Nr części", "Ciężar", "Status"), (80, 240, 70, 170), 5, sort=True)
        fr.pack(fill="both", expand=True)
        self.tr_prev.bind("<<TreeviewSelect>>", self.on_prev_sel)

        right = ttk.LabelFrame(body, text="Kształt kotwy (schemat poglądowy)")
        right.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.cv = tk.Canvas(right, width=380, height=380, bg="white", highlightthickness=0)
        self.cv.pack(fill="both", expand=True, padx=4, pady=4)
        self.cv.bind("<Configure>", lambda e: self.draw())
        mb = ttk.Frame(right)
        mb.pack(fill="x", padx=4)
        ttk.Label(mb, text="Blacha [mm]:").grid(row=0, column=0, sticky="w")
        ttk.Entry(mb, textvariable=self.v_plate, width=7).grid(row=0, column=1, padx=2)
        ttk.Label(mb, text="Podlewka [mm]:").grid(row=1, column=0, sticky="w")
        ttk.Entry(mb, textvariable=self.v_grout, width=7).grid(row=1, column=1, padx=2)
        ttk.Label(right, textvariable=self.v_shape, wraplength=330, foreground="#444").pack(anchor="w", padx=4, pady=4)
        for v in (self.v_len, self.v_w, self.v_part, self.v_plate, self.v_grout):
            v.trace_add("write", lambda *a: self.schedule_draw())

        ttk.Label(b, text="Właściciel nowych wierszy:").pack(side="left")
        ttk.Entry(b, textvariable=self.v_owner, width=12).pack(side="left", padx=4)
        ttk.Button(b, text="Dopisz do kotwy", command=self.save).pack(side="right", padx=4)
        ttk.Button(b, text="Zamknij", command=self.destroy).pack(side="right", padx=4)

    # ------------------------------------------------------------------ dane
    def use_base(self, i):
        """Wypełnia pola wymiarów z istniejącej długości o numerze i."""
        if not (0 <= i < len(self.defs)):
            self.schedule_draw()
            return
        base = self.defs[i]
        self.v_base.set(fmt_dia(base["Length"]) if base.get("Length") is not None else "")
        for c, v in self.pvars.items():
            val = base.get(c)
            v.set("" if val is None else fmt_dia(val) if isinstance(val, float) else str(val))
        self.schedule_draw()

    def base_def(self):
        i = self.cb_base.current()
        return self.defs[i] if 0 <= i < len(self.defs) else (self.defs[-1] if self.defs else {})

    def add_range(self):
        r = ask_range(self)
        if r:
            cur = self.v_len.get().strip()
            self.v_len.set((cur + ", " if cur else "") + r)

    def set_focus(self, col):
        self.focus_col = col
        self.draw()

    def schedule_draw(self):
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(120, self.draw)

    def on_prev_sel(self, _=None):
        sel = self.tr_prev.selection()
        if sel:
            self.sel_len = num(self.tr_prev.item(sel[0], "values")[0])
            self.schedule_draw()

    def collect(self):
        errs, d = [], {}
        try:
            d["lens"] = parse_lengths(self.v_len.get())
            if not d["lens"]:
                raise ValueError(T("Podaj co najmniej jedną długość."))
        except ValueError as e:
            d["lens"] = []
            errs.append(str(e))
        params = {}
        for c, v in self.pvars.items():
            s = v.get().strip()
            try:
                params[c] = None if not s else (int(s) if c == "NumberOfHeadEdges" else float(s.replace(",", ".")))
            except ValueError:
                errs.append("%s: %s" % (T(ANCHOR_LABELS[c]), T("podaj liczbę.")))
        d["params"] = params
        try:
            d["w0"] = float(self.v_w.get().replace(",", ".")) if self.v_w.get().strip() else None
        except ValueError:
            d["w0"] = None
            errs.append(T("Ciężar: podaj liczbę."))
        d["owner"] = self.v_owner.get().strip()
        if not d["owner"] or len(d["owner"]) > 15 or not is_own(d["owner"]):
            errs.append(T("Właściciel: 1-15 znaków, nie DSC/AUTODESK."))
        return d, errs

    def build_defs(self, d):
        base = self.base_def()
        rows, l0 = [], d["lens"][0]
        for length in d["lens"]:
            r = dict(d["params"])
            r["Length"] = length
            if d["w0"]:
                r["Weight"] = anchor_weight(l0, d["w0"], self.dia, length)
            else:
                r["Weight"] = anchor_weight(base.get("Length"), base.get("Weight"), self.dia, length)
            r["PartName"] = rename_part(self.v_part.get().strip() or base.get("PartName"), l0 if self.v_part.get().strip() else base.get("Length"),
                                        length, self.dia, self.std)
            rows.append(r)
        return rows

    def preview(self, silent=False):
        d, errs = self.collect()
        self.tr_prev.delete(*self.tr_prev.get_children())
        if errs:
            if silent:
                self.v_hint.set(T("Do uzupełnienia: ") + " ".join(errs))
            else:
                messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            self.plan = None
            return None
        self.v_hint.set("")
        rows = self.build_defs(d)
        new = [r for r in rows if r["Length"] not in self.have]
        for i, r in enumerate(rows):
            st = T("już istnieje - pominięto") if r["Length"] in self.have else T("NOWA długość")
            self.tr_prev.insert("", "end", iid=str(i), values=(fmt_dia(r["Length"]), r["PartName"], r["Weight"], st))
        if rows:
            i = next((i for i, r in enumerate(rows) if r["Length"] == self.sel_len), 0)
            self.tr_prev.selection_set(str(i))
        self.plan = {"d": d, "defs": new}
        return self.plan

    def draw(self):
        self._job = None
        try:
            lens = parse_lengths(self.v_len.get())
        except ValueError:
            lens = []
        P = {c: num(v.get()) for c, v in self.pvars.items()}
        base_len = self.base_def().get("Length")
        L = (self.sel_len if self.sel_len in lens else lens[0]) if lens else base_len
        items = {z: resolve_items(self.db, self.zone[z], self.dia) for z in ("top", "below", "end")}
        info = shape_draw(self.cv, self.tid, P, self.dia, L, items, plate=num(self.v_plate.get(), 0.0),
                          grout=num(self.v_grout.get(), 0.0), focus=self.focus_col)
        warn = check_dims(self.tid, P, L)
        self.v_shape.set(info + ("  " + " ".join(warn) if warn else ""))
        try:
            self.preview(silent=True)
        except Exception as e:
            self.v_hint.set(T("Podgląd niedostępny: %s") % e)

    # ------------------------------------------------------------------ zapis
    def save(self):
        if not self.app.need_db():
            return
        p = self.preview()
        if p is None:
            return
        defs, d = p["defs"], p["d"]
        if not defs:
            messagebox.showinfo("Zapis", "Wszystkie podane długości już istnieją - nie ma nic do dopisania.")
            return
        msg = T("Dopisać %d długości do kotwy Ø%s (klasa %s, zestaw %s)?") % (
            len(defs), dia_text(self.dia), self.n["MaterialKey"], self.n["SetName"])
        if self.factory:
            msg += "\n" + T("To kotwa fabryczna: jej wiersze zostają bez zmian, dopisane będą tylko nowe z właścicielem %s.") % d["owner"]
        if not messagebox.askyesno("Potwierdź zapis", msg):
            return
        if not self.app.backup_before_write():
            return
        did = self.db.max_id("AnchorsDefinition")
        rows_d = []
        for vals in defs:
            did += 1
            rows_d.append(build_anchor_def_row(did, self.aid, vals, d["owner"]))

        def fn(cur):
            for r in rows_d:
                cur.execute(*insert_sql("AnchorsDefinition", r))
        if self.app.write_or_report(fn):
            remember("owner", d["owner"])
            self.app.an_last_std = self.std
            self.app.reload()
            messagebox.showinfo("Gotowe", T("Dopisano %d długości. Odśwież dane w Advance Steel (przycisk 'Update defaults') "
                                            "albo uruchom go ponownie.") % len(defs))
            self.destroy()
