# -*- coding: utf-8 -*-
"""Zgłaszanie problemów z programu: przycisk 'Zgłoś problem' (albo klawisz F8) zapisuje jeden plik ZIP z opisem użytkownika,
zrzutem ekranu okna, stanem wszystkich widocznych pól i tabel, ostatnimi kliknięciami i błędami programu. Plik wystarczy
dołączyć w rozmowie - nie trzeba nic opisywać dodatkowo. Nic nie jest wysyłane przez sieć: plik powstaje lokalnie."""
import collections
import datetime
import json
import os
import subprocess
import sys
import traceback
import zipfile

from as_editor import journal
from as_editor.config import APP_DIR
from as_editor.i18n import T, get_language
from as_editor.ui.widgets import tk, ttk

REPORT_DIR = os.path.join(APP_DIR, "reports")
CLICKS = collections.deque(maxlen=40)          # ostatnie kliknięcia: (czas, okno, opis elementu)
ERRORS = collections.deque(maxlen=10)          # ostatnie błędy programu: (czas, traceback)
MAX_TEXT = 24000


def build_stamp():
    """Znacznik wersji programu: data najnowszego pliku .py (nie ma osobnego numeru wersji)."""
    newest = 0.0
    pkg = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for root, _, files in os.walk(pkg):
        for f in files:
            if f.endswith(".py") and "vendor" not in root:
                newest = max(newest, os.path.getmtime(os.path.join(root, f)))
    return datetime.datetime.fromtimestamp(newest).strftime("%Y-%m-%d %H:%M") if newest else "?"


# ---------------------------------------------------------------------- rejestr kliknięć i błędów
def describe_widget(w):
    """Krótki opis klikniętego elementu: rodzaj + napis (przycisk, pole wyboru) albo nazwa kolumny/wiersza."""
    try:
        cls = w.winfo_class()
        if cls in ("TButton", "Button", "TCheckbutton", "Checkbutton", "TRadiobutton", "Radiobutton", "TLabel", "Label"):
            return "%s '%s'" % (cls, str(w.cget("text")).strip()[:60])
        if cls == "Treeview":
            return "tabela (%s)" % ", ".join(str(c) for c in w["columns"])[:80]
        if cls == "Listbox":
            return "lista (zaznaczone: %s)" % ", ".join(w.get(i) for i in w.curselection())[:80]
        if cls in ("TEntry", "Entry", "TCombobox"):
            return "%s [%s]" % (cls, nearby_label(w) or "?")
        return cls
    except Exception:
        return "?"


def install_logging(root):
    """Rejestruje kliknięcia i błędy z procedur obsługi tkinter (dotąd trafiały tylko do konsoli, której nie widać)."""
    def on_click(e):
        try:
            CLICKS.append((datetime.datetime.now().strftime("%H:%M:%S"), e.widget.winfo_toplevel().title()[:50], describe_widget(e.widget)))
        except Exception:
            pass
    root.bind_all("<ButtonRelease-1>", on_click, add="+")

    def on_error(exc, val, tb):
        txt = "".join(traceback.format_exception(exc, val, tb))
        ERRORS.append((datetime.datetime.now().strftime("%H:%M:%S"), txt))
        try:
            with open(os.path.join(APP_DIR, "errors.log"), "a", encoding="utf-8") as f:
                f.write("[%s]\n%s\n" % (datetime.datetime.now().isoformat(timespec="seconds"), txt))
        except OSError:
            pass
        traceback.print_exception(exc, val, tb)
    root.report_callback_exception = on_error
    root.bind_all("<F8>", lambda e: open_report(root._app, e.widget.winfo_toplevel()) if hasattr(root, "_app") else None, add="+")


# ---------------------------------------------------------------------- stan okna
def nearby_label(w):
    """Napis najbliższy polu: etykieta w tym samym wierszu po lewej (grid) albo poprzednia etykieta w tym samym kontenerze."""
    try:
        sibs = w.master.winfo_children()
        gi = w.grid_info()
        best = None
        if gi:
            for s in sibs:
                if s is w or s.winfo_class() not in ("TLabel", "Label"):
                    continue
                si = s.grid_info()
                if si and si.get("row") == gi.get("row") and int(si.get("column", 0)) < int(gi.get("column", 0)):
                    best = s
        else:
            for s in sibs[:sibs.index(w)]:
                if s.winfo_class() in ("TLabel", "Label") and str(s.cget("text")).strip():
                    best = s
        return str(best.cget("text")).strip()[:70] if best is not None else ""
    except Exception:
        return ""


def widget_value(w):
    try:
        v = w.get()
        return str(v)
    except Exception:
        return ""


def dump_widgets(top):
    """Tekstowy zrzut widocznych elementów okna: etykiety, pola, listy, tabele, przyciski, rysunki (teksty)."""
    out = []

    def add(s):
        out.append(s)

    def walk(w, depth=0):
        try:
            if not w.winfo_ismapped():
                return
        except Exception:
            return
        cls = w.winfo_class()
        try:
            if cls in ("TLabel", "Label"):
                t = str(w.cget("text")).strip()
                try:
                    if not t and w.cget("textvariable"):
                        t = str(w.getvar(str(w.cget("textvariable")))).strip()
                except Exception:
                    pass
                if t:
                    err = "Err" in str(w.cget("style")) if cls == "TLabel" else False
                    add("%s- %s%s" % ("  " * min(depth, 4), "[BŁĄD/UWAGA] " if err else "", t[:300].replace("\n", " ")))
            elif cls in ("TEntry", "Entry", "TCombobox", "TSpinbox"):
                st = ""
                try:
                    st = " (nieaktywne)" if "disabled" in w.state() else (" (BŁĘDNE)" if "invalid" in w.state() else "")
                except Exception:
                    pass
                add("%s- POLE [%s] = '%s'%s" % ("  " * min(depth, 4), nearby_label(w) or "?", widget_value(w)[:200], st))
            elif cls in ("TCheckbutton", "Checkbutton", "TRadiobutton", "Radiobutton"):
                var = str(w.cget("variable"))
                val = w.getvar(var) if var else ""
                if cls in ("TRadiobutton", "Radiobutton"):
                    on = str(val) == str(w.cget("value"))
                else:
                    on = str(val) in ("1", "True", "true")
                add("%s- [%s] %s" % ("  " * min(depth, 4), "x" if on else " ", str(w.cget("text")).strip()))
            elif cls in ("TButton", "Button"):
                dis = ""
                try:
                    dis = " (nieaktywny)" if "disabled" in w.state() else ""
                except Exception:
                    pass
                add("%s- PRZYCISK '%s'%s" % ("  " * min(depth, 4), str(w.cget("text")).strip(), dis))
            elif cls == "Listbox":
                items = [w.get(i) for i in range(w.size())]
                sel = [w.get(i) for i in w.curselection()]
                add("%s- LISTA (%d pozycji), zaznaczone: %s; pierwsze: %s" % ("  " * min(depth, 4), len(items), sel[:15], items[:8]))
            elif cls == "Treeview":
                cols = list(w["columns"])
                kids = w.get_children()
                tl = getattr(w, "tools", None)
                extra = ""
                if tl is not None:
                    extra = " | sortowanie: %s%s | filtr: '%s' (kolumna: %s) | %s" % (
                        tl.sort_col or "-", " malejąco" if tl.sort_rev and tl.sort_col else "", tl.v_text.get() if tl.has_filter else "-",
                        tl.v_col.get() if tl.has_filter else "-", tl.v_count.get() if tl.has_filter else "")
                add("%s- TABELA kolumny=%s, widocznych wierszy=%d%s" % ("  " * min(depth, 4), cols, len(kids), extra))
                sel = set(w.selection())
                for iid in kids[:12]:
                    vals = [str(v) for v in w.item(iid, "values")]
                    add("%s    %s%s" % ("  " * min(depth, 4), "> " if iid in sel else "  ", " | ".join(vals)[:240]))
                if len(kids) > 12:
                    add("%s    ... (+%d wierszy)" % ("  " * min(depth, 4), len(kids) - 12))
            elif cls == "Canvas":
                texts = [str(w.itemcget(i, "text")).strip() for i in w.find_all() if w.type(i) == "text"]
                add("%s- RYSUNEK: %d elementów; podpisy: %s" % ("  " * min(depth, 4), len(w.find_all()), [t for t in texts if t][:14]))
            elif cls == "TNotebook":
                add("%s- ZAKŁADKA: %s" % ("  " * min(depth, 4), w.tab(w.select(), "text") if w.tabs() else ""))
        except Exception as e:
            add("  (błąd odczytu %s: %s)" % (cls, e))
        for c in w.winfo_children():
            if c.winfo_class() == "Toplevel":
                continue
            walk(c, depth + 1)
    walk(top)
    txt = "\n".join(out)
    return txt if len(txt) <= MAX_TEXT else txt[:MAX_TEXT] + "\n... (obcięto)"


def describe_context(app, top):
    lines = ["Strona programu: %s" % getattr(app, "cur_page", "?"),
             "Język interfejsu: %s" % get_language(),
             "Połączenie z bazą: %s" % ("tak (%s, wersja krajowa %s)" % (getattr(app.db, "server", "?"), getattr(app.db, "lang", "?"))
                                        if getattr(app.db, "conn", None) else "NIE")]
    if hasattr(top, "steps") and getattr(top, "cur", -1) >= 0:
        s = top.steps[top.cur]
        lines.append("Okno: KREATOR '%s' (%s), krok %d z %d: %s" % (top.title(), top.__class__.__name__, top.cur + 1, len(top.steps), T(s["title"])))
        if top.var_err.get():
            lines.append("Komunikat błędu pod przyciskami: %s" % top.var_err.get())
        if top.cur == len(top.steps) - 1 and top.var_story.get():
            lines.append("Podsumowanie 'Co się stanie po zapisie': %s" % top.var_story.get())
    else:
        lines.append("Okno: %s (%s)" % (top.title(), top.__class__.__name__))
    return lines


# ---------------------------------------------------------------------- zrzut ekranu
def take_screenshot(win, path):
    """Zrzut obszaru okna do PNG. Kolejno: Pillow, PowerShell (Windows, bez dodatkowych pakietów), ImageMagick (Linux).
    Zwraca True, gdy plik powstał."""
    try:
        win.update_idletasks()
        x, y, w, h = win.winfo_rootx(), win.winfo_rooty(), win.winfo_width(), win.winfo_height()
    except Exception:
        return False
    bbox = (x, y, x + w, y + h)
    try:
        from PIL import ImageGrab
        ImageGrab.grab(bbox=bbox).save(path)
        return os.path.exists(path)
    except Exception:
        pass
    try:
        if sys.platform == "win32":
            ps = ("Add-Type -AssemblyName System.Drawing; $b=New-Object System.Drawing.Bitmap(%d,%d); "
                  "$g=[System.Drawing.Graphics]::FromImage($b); $g.CopyFromScreen(%d,%d,0,0,$b.Size); "
                  "$b.Save('%s',[System.Drawing.Imaging.ImageFormat]::Png)" % (w, h, x, y, path.replace("'", "''")))
            subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], timeout=20,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), capture_output=True)
        else:
            subprocess.run(["import", "-window", "root", "-crop", "%dx%d+%d+%d" % (w, h, x, y), "+repage", path], timeout=20,
                           capture_output=True)
        return os.path.exists(path)
    except Exception:
        return False


# ---------------------------------------------------------------------- raport
def build_report(app, top, kind, description, shot_path=None):
    """Tworzy ZIP w REPORT_DIR: zgloszenie.md, ekran.png (jeśli jest), errors.log (ogon), dziennik.json (3 ostatnie zapisy)."""
    os.makedirs(REPORT_DIR, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = os.path.join(REPORT_DIR, "zgloszenie_%s.zip" % stamp)
    md = ["# Zgłoszenie z programu Edytor śrub i kotew", "",
          "- Data: %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
          "- Wersja programu (data najnowszego pliku): %s" % build_stamp(),
          "- System: %s, Python %s" % (sys.platform, sys.version.split()[0]),
          "- Rodzaj zgłoszenia: %s" % kind, "", "## Opis użytkownika", "", description.strip() or "(brak opisu)", "",
          "## Gdzie byłem", ""] + ["- " + s for s in describe_context(app, top)] + ["", "## Co było na ekranie (widoczne elementy)", "",
          "```", dump_widgets(top), "```", "", "## Ostatnie kliknięcia (od najstarszego)", ""]
    md += ["- %s  [%s]  %s" % c for c in list(CLICKS)[-25:]] or ["(brak)"]
    md += ["", "## Błędy programu z tej sesji", ""]
    md += ["```\n[%s]\n%s\n```" % e for e in ERRORS] or ["(brak błędów)"]
    with zipfile.ZipFile(name, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("zgloszenie.md", "\n".join(md))
        if shot_path and os.path.exists(shot_path):
            z.write(shot_path, "ekran.png")
        try:
            with open(os.path.join(APP_DIR, "errors.log"), "r", encoding="utf-8", errors="replace") as f:
                z.writestr("errors.log", f.read()[-8000:])
        except OSError:
            pass
        try:
            z.writestr("dziennik.json", json.dumps(journal.load()[-3:], ensure_ascii=False, indent=1, default=str))
        except Exception:
            pass
    return name


KINDS = ("Coś nie działa (błąd)", "Coś jest niejasne lub niewygodne", "Pomysł / zmiana")


class ReportDialog(tk.Toplevel):
    is_report = True

    def __init__(self, app, top, shot):
        super().__init__(top)
        self.app, self.top_win, self.shot, self.result = app, top, shot, None
        self.title(T("Zgłoś problem lub uwagę"))
        self.transient(top)
        self.geometry("640x560")
        self.prev_grab = top.grab_current() if hasattr(top, "grab_current") else None
        self.bind("<Destroy>", self._restore_grab, add="+")
        f = ttk.Frame(self, padding=18)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text=T("Zgłoś problem lub uwagę"), style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(f, text=T("Program sam dołączy zrzut okna, to co wpisałeś w polach, ostatnie kliknięcia i błędy. "
                            "Opisz tylko, co chciałeś zrobić i co poszło nie tak."), style="Hint.TLabel", wraplength=590).pack(anchor="w", pady=(4, 10))
        self.v_kind = tk.StringVar(value=KINDS[0])
        for k in KINDS:
            ttk.Radiobutton(f, text=T(k), value=k, variable=self.v_kind).pack(anchor="w")
        ttk.Label(f, text=T("Co chciałeś zrobić, co się stało i czego oczekiwałeś?")).pack(anchor="w", pady=(10, 2))
        self.txt = tk.Text(f, height=9, wrap="word")
        self.txt.pack(fill="both", expand=True)
        self.txt.focus_set()
        try:
            self.grab_set()
        except Exception:
            pass
        self.v_shot = tk.BooleanVar(value=bool(shot))
        c = ttk.Checkbutton(f, text=T("Dołącz zrzut ekranu okna"), variable=self.v_shot)
        c.pack(anchor="w", pady=(8, 0))
        if not shot:
            c.state(["disabled"])
        self.var_res = tk.StringVar()
        ttk.Label(f, textvariable=self.var_res, style="Ok.TLabel", wraplength=590, justify="left").pack(anchor="w", pady=(8, 0))
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(10, 0))
        self.btn_save = ttk.Button(bar, text=T("Zapisz zgłoszenie"), style="Accent.TButton", command=self.save)
        self.btn_save.pack(side="right")
        self.btn_open = ttk.Button(bar, text=T("Otwórz folder"), command=self.open_folder)
        self.btn_copy = ttk.Button(bar, text=T("Kopiuj ścieżkę"), command=self.copy_path)
        ttk.Button(bar, text=T("Zamknij"), command=self.destroy).pack(side="left")

    def _restore_grab(self, e):
        if e.widget is self and self.prev_grab is not None:          # kreator pod spodem znów dostaje klawiaturę i mysz
            try:
                self.prev_grab.grab_set()
            except Exception:
                pass

    def save(self):
        try:
            self.result = build_report(self.app, self.top_win, self.v_kind.get(), self.txt.get("1.0", "end"),
                                       self.shot if self.v_shot.get() else None)
        except Exception as e:
            self.var_res.set(T("Nie udało się zapisać zgłoszenia: %s") % e)
            return
        self.var_res.set(T("Zgłoszenie zapisane:\n%s\nDołącz ten plik ZIP w rozmowie z Claude (przeciągnij go do okna rozmowy).") % self.result)
        self.btn_save.state(["disabled"])
        self.btn_open.pack(side="right", padx=6)
        self.btn_copy.pack(side="right")

    def open_folder(self):
        try:
            if sys.platform == "win32":
                subprocess.Popen(["explorer", "/select,", os.path.normpath(self.result)])
            else:
                subprocess.Popen(["xdg-open", os.path.dirname(self.result)])
        except Exception:
            pass

    def copy_path(self):
        self.clipboard_clear()
        self.clipboard_append(self.result)


def open_report(app, top=None):
    """Otwiera okno zgłoszenia dla okna 'top' (domyślnie aktywne). Zrzut robi PRZED otwarciem okna zgłoszenia."""
    try:
        if top is None:
            top = app.root
        if getattr(top, "is_report", False):
            return
        os.makedirs(REPORT_DIR, exist_ok=True)
        shot = os.path.join(REPORT_DIR, "_ekran.png")
        if os.path.exists(shot):
            os.remove(shot)
        ok = take_screenshot(top, shot)
        ReportDialog(app, top, shot if ok else None)
    except Exception as e:
        traceback.print_exc()
        from as_editor.ui.widgets import messagebox
        messagebox.showerror("Zgłoszenie", "Nie udało się otworzyć okna zgłoszenia: %s" % e)
