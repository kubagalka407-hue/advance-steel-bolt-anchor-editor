# -*- coding: utf-8 -*-
"""Zakładka Śruby -> Normy i klasy: usuń moje wpisy."""
from as_editor.common import is_own
from as_editor.i18n import T
from as_editor.ui.widgets import messagebox, tk, ttk


class NormsDeleteMixin:
    # --- 4. usuwanie moich wpisów ---
    def build_del_own(self):
        f = self.sub_del
        ttk.Label(f, text="Usuwa wyłącznie wpisy z właścicielem innym niż DSC (np. MOJA). Wpisy fabryczne są chronione. "
                          "Wybierz całą normę albo jedną klasę.", wraplength=900, foreground="#444").pack(anchor="w", padx=8, pady=8)
        row = ttk.Frame(f)
        row.pack(anchor="w", padx=8)
        ttk.Label(row, text="Norma:").pack(side="left")
        self.cb_dlstd = ttk.Combobox(row, width=46, state="readonly")
        self.cb_dlstd.pack(side="left", padx=6)
        self.cb_dlstd.bind("<<ComboboxSelected>>", self.dl_on_std)
        ttk.Label(row, text="Klasa:").pack(side="left", padx=(12, 2))
        self.cb_dlmat = ttk.Combobox(row, width=20, state="readonly")
        self.cb_dlmat.pack(side="left")
        self.cb_dlmat.bind("<<ComboboxSelected>>", lambda e: self.dl_count())
        ttk.Button(f, text="Usuń moje wpisy", command=self.dl_do).pack(anchor="w", padx=8, pady=10)
        self.var_dlinfo = tk.StringVar()
        ttk.Label(f, textvariable=self.var_dlinfo, wraplength=900).pack(anchor="w", padx=8)

    @property
    def ALL_CLASSES(self):
        return T("(wszystkie klasy)")

    OWN_COND = "ISNULL([OwnerText],'') NOT IN ('DSC','AUTODESK')"

    def dl_on_std(self, _=None):
        i = self.cb_dlstd.current()
        if i < 0:
            return
        std = self.stds[i][0]
        mats = sorted(set(self.db.bolt_materials(std)) | set(self.db.set_materials(std)))
        self.cb_dlmat["values"] = [self.ALL_CLASSES] + mats
        self.cb_dlmat.set(self.ALL_CLASSES)
        self.dl_count()

    def dl_where(self):
        i, mat = self.cb_dlstd.current(), self.cb_dlmat.get()
        if i < 0:
            return None
        std = self.stds[i][0]
        where, params = "[Standard]=? AND " + self.OWN_COND, [std]
        if mat and mat != self.ALL_CLASSES:
            where += " AND [Material]=?"
            params.append(mat)
        return std, where, params, (not mat or mat == self.ALL_CLASSES)

    def dl_count(self):
        w = self.dl_where()
        if not (self.db.conn and w):
            return None
        std, where, params, whole = w
        n_sets, n_bolts = self.db.count("SetOfBolts", where, params), self.db.count("SetBolts", where, params)
        self.var_dlinfo.set("Moje wiersze do usunięcia: zestawy śrub %d, wymiary śrub %d." % (n_sets, n_bolts))
        return n_sets, n_bolts

    def dl_do(self):
        if not self.need_db():
            return
        w = self.dl_where()
        if not w:
            messagebox.showinfo("Usuń", "Wybierz normę.")
            return
        std, where, params, whole = w
        n = self.dl_count()
        std_row = [x for x in self.stds if x[0] == std][0]
        std_own = whole and is_own(std_row[4])
        if not n or (n[0] + n[1] == 0 and not std_own):
            messagebox.showinfo("Usuń", "Nie ma tu moich wpisów do usunięcia.")
            return
        if not messagebox.askyesno("Potwierdź", "Usunąć zestawy śrub: %d i wymiary śrub: %d wierszy%s?" % (
                n[0], n[1], " oraz (jeśli nic nie zostanie) wpis normy" if std_own else "")):
            return
        if not self.backup_before_write():
            return

        def fn(cur):
            cur.execute("DELETE FROM [SetOfBolts] WHERE " + where, params)
            cur.execute("DELETE FROM [SetBolts] WHERE " + where, params)
            if std_own:
                cur.execute("SELECT (SELECT COUNT(*) FROM [SetBolts] WHERE [Standard]=?) + "
                            "(SELECT COUNT(*) FROM [SetOfBolts] WHERE [Standard]=?)", (std, std))
                if cur.fetchone()[0] == 0:
                    cur.execute("DELETE FROM [Standard] WHERE [Key]=?", (std,))
        if self.write_or_report(fn):
            self.reload()
            self.cb_dlmat.set("")
            self.var_dlinfo.set("Usunięto.")
