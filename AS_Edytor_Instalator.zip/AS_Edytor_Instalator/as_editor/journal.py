# -*- coding: utf-8 -*-
"""Dziennik zapisów i cofanie ostatniego zapisu.
Każdy zapis do bazy (DB.write) przechodzi przez `JournalCursor`, który zapamiętuje, co zmienił:
  INSERT  -> klucz nowego wiersza (cofnięcie = DELETE),
  DELETE  -> stare wiersze (cofnięcie = ponowny INSERT),
  UPDATE  -> stare wartości wierszy (cofnięcie = UPDATE po kluczu).
Cofnąć można tylko OSTATNI zapis (kolejność LIFO), więc nic nie koliduje. Zapis, którego nie da się odwrócić
(nieznana tabela), jest w dzienniku oznaczony i nie można go cofnąć."""
import json
import re
import time

from as_editor import config

PK = {
    "AnchorsName": ["ID"], "AnchorsDefinition": ["ID"], "AnchorsHoleDefinition": ["AnchorNameID", "ID"],
    "AnchorsStandard": ["Key"], "Sets": ["Key"], "Sources": ["Short"], "StrengthClass": ["Key"], "BoltsDiameters": ["Key"],
    "SetOfBolts": ["Diameter", "Material", "Set", "Standard"], "SetBolts": ["Diameter", "Length", "Material", "Standard"],
    "SetNutsBolts": ["Diameter", "Material", "Standard"], "Standard": ["Key"], "StandardNuts": ["ID"],
}
IDENT = r"\[((?:[^\]]|\]\])+)\]"
MAX_ENTRIES = 50


def q(n):
    return "[" + n.replace("]", "]]") + "]"


def _plain(v):
    if v is None or isinstance(v, (int, float, str, bool)):
        return v
    try:
        return float(v)
    except Exception:
        return str(v)


def journal_path():
    return config.JOURNAL_FILE


def load():
    try:
        with open(journal_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def save(entries):
    try:
        with open(journal_path(), "w", encoding="utf-8") as f:
            json.dump(entries[-MAX_ENTRIES:], f, ensure_ascii=False, indent=1)
    except OSError:
        pass


def last_entry():
    e = load()
    return e[-1] if e else None


class JournalCursor:
    """Opakowanie kursora: wykonuje polecenia normalnie i zapisuje ślad do cofnięcia w self.ops."""

    def __init__(self, cur):
        self.cur = cur
        self.ops = []
        self.undoable = True

    def __getattr__(self, name):                  # fetchone, fetchall, rowcount...
        return getattr(self.cur, name)

    def _keys(self, table):
        pk = PK.get(table)
        if not pk:
            return None
        self.cur.execute("SELECT %s FROM %s" % (",".join(q(c) for c in pk), q(table)))
        return {tuple(_plain(v) for v in r) for r in self.cur.fetchall()}

    def execute(self, sql, params=()):
        params = list(params) if isinstance(params, (list, tuple)) else [params]
        s = sql.strip()
        m = re.match(r"INSERT\s+INTO\s+" + IDENT + r"\s*\((.*?)\)\s*(VALUES|SELECT)\b", s, re.I | re.S)
        if m:
            table, cols_txt, kind = m.group(1), m.group(2), m.group(3).upper()
            pk = PK.get(table)
            if kind == "VALUES" and pk:
                cols = [c.replace("]]", "]") for c in re.findall(IDENT, cols_txt)]
                row = dict(zip(cols, params))
                if all(c in row for c in pk):
                    self.ops.append({"op": "insert", "table": table, "key": [_plain(row[c]) for c in pk]})
                else:
                    self.undoable = False
                return self.cur.execute(sql, params)
            if kind == "SELECT" and pk:
                before = self._keys(table)
                res = self.cur.execute(sql, params)
                for k in sorted(self._keys(table) - before, key=str):
                    self.ops.append({"op": "insert", "table": table, "key": list(k)})
                return res
            self.undoable = False
            return self.cur.execute(sql, params)
        m = re.match(r"(UPDATE\s+" + IDENT + r"\s+SET\b.*?|DELETE\s+FROM\s+" + IDENT + r")\s+WHERE\s+(.*)$", s, re.I | re.S)
        if m:
            kind = "update" if s[:6].upper() == "UPDATE" else "delete"
            table, where = (m.group(2) if kind == "update" else m.group(3)), m.group(4)
            n = where.count("?")
            wparams = params[len(params) - n:] if n else []
            pk = PK.get(table)
            if pk is None or (kind == "update" and not pk):
                self.undoable = False
                return self.cur.execute(sql, params)
            self.cur.execute("SELECT * FROM %s WHERE %s" % (q(table), where), wparams)
            cols = [d[0] for d in self.cur.description]
            rows = [[_plain(v) for v in r] for r in self.cur.fetchall()]
            if rows:
                self.ops.append({"op": kind, "table": table, "cols": cols, "rows": rows})
            return self.cur.execute(sql, params)
        if re.match(r"(INSERT|UPDATE|DELETE|MERGE|TRUNCATE|DROP|ALTER)\b", s, re.I):
            self.undoable = False
        return self.cur.execute(sql, params)

    def entry(self, label):
        if not self.ops and self.undoable:
            return None
        return {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "label": label or "", "undoable": self.undoable,
                "ops": self.ops, "n": len(self.ops)}


def undo_entry(cur, entry):
    """Odwraca zapis (operacje od końca). cur: zwykły kursor w transakcji. Zwraca liczbę cofniętych operacji."""
    if not entry.get("undoable"):
        raise ValueError("Tego zapisu nie da się cofnąć automatycznie.")
    n = 0
    for op in reversed(entry["ops"]):
        t, pk = op["table"], PK[op["table"]]
        if op["op"] == "insert":
            cur.execute("DELETE FROM %s WHERE %s" % (q(t), " AND ".join("%s=?" % q(c) for c in pk)), op["key"])
        elif op["op"] == "delete":
            cols = op["cols"]
            for r in op["rows"]:
                cur.execute("INSERT INTO %s (%s) VALUES (%s)" % (q(t), ",".join(q(c) for c in cols), ",".join("?" * len(cols))), r)
        else:
            cols = op["cols"]
            for r in op["rows"]:
                row = dict(zip(cols, r))
                sets = [c for c in cols if c not in pk]
                cur.execute("UPDATE %s SET %s WHERE %s" % (q(t), ",".join("%s=?" % q(c) for c in sets),
                                                         " AND ".join("%s=?" % q(c) for c in pk)),
                            [row[c] for c in sets] + [row[c] for c in pk])
        n += 1
    return n


def describe(entry):
    kinds = {}
    for op in entry.get("ops", []):
        kinds.setdefault((op["op"], op["table"]), 0)
        kinds[(op["op"], op["table"])] += len(op["rows"]) if "rows" in op else 1
    return kinds
