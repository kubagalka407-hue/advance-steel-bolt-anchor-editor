# -*- coding: utf-8 -*-
"""Zakładka Śruby -> Normy i klasy: dodaj klasę do normy."""
from as_editor.bolts_logic import remap_set_row
from as_editor.common import clone_sql, dia_text, fmt_dia, in_clause, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER, MAX_ITEMS
from as_editor.ui.dialogs import ChoiceDialog
from as_editor.ui.widgets import make_list, make_tree, messagebox, tk, ttk


class NormsAddClassMixin:
    # --- 3. dodaj klasę do normy ---
    def build_add_class(self):
        f = self.sub_add
        left = ttk.Frame(f)
        left.pack(side="left", fill="y", padx=8, pady=6)
        ttk.Label(left, text="Norma śruby").pack(anchor="w")
        self.cb_acstd = ttk.Combobox(left, width=46, state="readonly")
        self.cb_acstd.pack(anchor="w")
        self.cb_acstd.bind("<<ComboboxSelected>>", self.ac_on_std)
        ttk.Label(left, text="Klasa źródłowa (z niej kopiuję średnice, długości i zestawy)").pack(anchor="w", pady=(6, 0))
        self.cb_acsrc = ttk.Combobox(left, width=24, state="readonly")
        self.cb_acsrc.pack(anchor="w")
        self.cb_acsrc.bind("<<ComboboxSelected>>", self.ac_on_src)
        ttk.Label(left, text="Nowa klasa (ze słownika klas - zakładka 1)").pack(anchor="w", pady=(6, 0))
        self.cb_accls = ttk.Combobox(left, width=36, state="readonly")
        self.cb_accls.pack(anchor="w")
        self.v_acown = tk.StringVar(value=DEFAULT_OWNER)
        ttk.Label(left, text="Właściciel wpisu (max 15 znaków)").pack(anchor="w", pady=(6, 0))
        ttk.Entry(left, textvariable=self.v_acown, width=20).pack(anchor="w")
        self.v_acname, self.v_acsets = tk.BooleanVar(value=True), tk.BooleanVar(value=True)
        ttk.Checkbutton(left, text="Zamień klasę w nazwach śrub", variable=self.v_acname).pack(anchor="w", pady=(8, 0))
        ttk.Checkbutton(left, text="Kopiuj też zestawy śrub", variable=self.v_acsets).pack(anchor="w")
        ttk.Button(left, text="Dodaj klasę do normy", command=self.ac_save).pack(anchor="w", pady=10)
        mid = ttk.Frame(f)
        mid.pack(side="left", padx=8, pady=6, anchor="n")
        ttk.Label(mid, text="Średnice do skopiowania").pack(anchor="w")
        fr, self.lb_acdia = make_list(mid, 16, 16)
        fr.pack()
        right = ttk.Frame(f)
        right.pack(side="left", fill="both", expand=True, padx=8, pady=6)
        ttk.Label(right, text="Klasy nakrętek/podkładek w zestawach nowej klasy (dwuklik = zmień). Np. dla śruby 5.6 "
                              "nakrętka klasy 5 zamiast 8.", wraplength=560).pack(anchor="w")
        fr, self.tr_acmap = make_tree(right, ("Element (norma)", "Klasa w źródle", "Klasa w nowych zestawach"),
                                      (200, 140, 200), 14, "browse")
        fr.pack(fill="both", expand=True)
        self.tr_acmap.bind("<Double-1>", self.ac_edit_map)

    def ac_on_std(self, _=None):
        i = self.cb_acstd.current()
        if i < 0:
            return
        mats = self.db.bolt_materials(self.stds[i][0])
        self.cb_acsrc["values"] = mats
        if mats:
            self.cb_acsrc.current(0)
        self.ac_on_src()

    def ac_on_src(self, _=None):
        i, src = self.cb_acstd.current(), self.cb_acsrc.get()
        if i < 0 or not src:
            return
        std = self.stds[i][0]
        self.ac_dias = self.db.bolt_diameters(std, [src])
        self.lb_acdia.delete(0, "end")
        for d in self.ac_dias:
            self.lb_acdia.insert("end", "Ø " + dia_text(d))
            self.lb_acdia.selection_set("end")
        self.ac_pairs = self.db.set_component_pairs(std, src)
        self.ac_map = {tuple(p): p[1] for p in self.ac_pairs}
        self.ac_map_refresh()

    def ac_map_refresh(self):
        t = self.tr_acmap
        t.delete(*t.get_children())
        for i, p in enumerate(self.ac_pairs):
            t.insert("", "end", iid=str(i), values=(p[0], p[1], self.ac_map[tuple(p)]))

    def ac_edit_map(self, event):
        iid = self.tr_acmap.identify_row(event.y)
        if not iid:
            return
        pair = tuple(self.ac_pairs[int(iid)])
        mats = self.db.nut_materials(pair[0])
        dlg = ChoiceDialog(self.root, "Klasa elementu", "Element %s: klasa w nowych zestawach (źródło: %s)" % (pair[0], pair[1]),
                           mats, self.ac_map[pair])
        if dlg.result:
            self.ac_map[pair] = dlg.result
            self.ac_map_refresh()

    def ac_save(self):
        if not self.need_db():
            return False
        si, src, ci = self.cb_acstd.current(), self.cb_acsrc.get(), self.cb_accls.current()
        owner = self.v_acown.get().strip()
        dias = [self.ac_dias[i] for i in self.lb_acdia.curselection()]
        errs = []
        if si < 0 or not src:
            errs.append("Wybierz normę i klasę źródłową.")
        if ci < 0:
            errs.append("Wybierz nową klasę ze słownika (dodaj ją w zakładce 1, jeśli jej brakuje).")
        if not dias:
            errs.append("Zaznacz średnice.")
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        if not errs:
            std, newcls = self.stds[si][0], self.cls_rows[ci][0]
            if newcls == src:
                errs.append("Nowa klasa musi się różnić od źródłowej.")
            if self.db.count("SetBolts", "[Standard]=? AND [Material]=?", (std, newcls)) or \
                    self.db.count("SetOfBolts", "[Standard]=? AND [Material]=?", (std, newcls)):
                errs.append("Norma %s ma już wiersze dla klasy %s." % (std, newcls))
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return False
        cm, pm = in_clause("Diameter", dias)
        where = "[Standard]=? AND [Material]=? AND " + cm
        wparams = [std, src] + pm
        n_bolts = self.db.count("SetBolts", where, wparams)
        new_sets, skipped = [], 0
        if self.v_acsets.get():
            rows, cols = self.db.set_rows(std, src, dias)
            for r in rows:
                nr = remap_set_row(dict(zip(cols, r)), std, newcls, owner, self.ac_map)
                ok = True
                for k in range(1, MAX_ITEMS + 1):
                    din, m, pos = nr.get("DIN%d" % k), nr.get("Material%d" % k), nr.get("Position%d" % k)
                    if pos and din not in (None, "", "-") and self.db.nut_item(din, m, nr["Diameter"]) is None:
                        ok = False
                if ok:
                    new_sets.append(nr)
                else:
                    skipped += 1
        msg = "Dodać klasę %s do normy %s (kopia z %s)?\n\nWymiary śrub: %d wierszy\nZestawy śrub: %d wierszy" % (
            newcls, std, src, n_bolts, len(new_sets))
        if skipped:
            msg += "\n\nUWAGA: %d zestawów pominięto, bo brakuje w bazie elementów o wybranej klasie " \
                   "dla danej średnicy." % skipped
        if not messagebox.askyesno("Potwierdź", msg):
            return False
        if not self.backup_before_write():
            return False
        repl = {"Name": (src, newcls)} if self.v_acname.get() else None

        def fn(cur):
            sql, p = clone_sql("SetBolts", self.db.columns("SetBolts"), {"Material": newcls, "OwnerText": owner[:15]},
                               where, wparams, repl)
            cur.execute(sql, p)
            for r in new_sets:
                cur.execute(*insert_sql("SetOfBolts", r))
        if self.write_or_report(fn):
            self.reload()
            messagebox.showinfo("Gotowe", "Dodano klasę %s do normy %s.\nUruchom ponownie Advance Steel / "
                                          "Management Tools." % (newcls, std))
            return True
        return False
