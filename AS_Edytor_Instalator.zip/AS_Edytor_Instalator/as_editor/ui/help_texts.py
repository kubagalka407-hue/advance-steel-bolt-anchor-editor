# -*- coding: utf-8 -*-
"""Teksty pomocy dla przycisków '?' (kreatory i strony). Klucz -> (tytuł, treść); tłumaczenia w i18n_en.py."""
from as_editor.i18n import T
from as_editor.ui.widgets import tk, ttk

HELP = {
    "home": ("Jak zacząć",
             "Wybierz, czego dotyczy zmiana: Kotwy albo Śruby. Program poprowadzi Cię krok po kroku (kreator): wybierasz, co "
             "zmienić, sprawdzasz podsumowanie i dopiero na końcu zapisujesz.\n\nZapis zawsze poprzedza kopia zapasowa bazy. "
             "Wpisów fabrycznych (DSC / AUTODESK) program nigdy nie zmienia - powstają nowe wpisy z Twoim właścicielem.\n\n"
             "Podgląd: po prawej stronie każdego kreatora widzisz rysunek kotwy lub śruby - zmienia się razem z Twoimi wyborami, więc od razu widać, co powstanie.\n\n"
             "Tabele: kliknij nagłówek kolumny, aby posortować (od najmniejszej do największej, drugie kliknięcie = odwrotnie). Pole 'Filtr' zawęża wiersze: wpisz tekst albo liczby (>=20, <=30, 10..20) i wybierz kolumnę. Przycisk 'Ø ▲/▼' przy liście średnic zmienia ich kolejność."),
    "bolts": ("Śruby - co wybrać?",
              "Dodaj zestaw do śruby: masz śrubę (norma + klasa + średnice) i chcesz dla niej nowy zestaw podkładek i nakrętek.\n\n"
              "Skopiuj całą klasę śrub: chcesz mieć nową klasę (np. 5.6) ze wszystkimi wymiarami i zestawami istniejącej "
              "klasy - zmieniasz tylko klasy elementów.\n\n"
              "Nowa podkładka / nakrętka: brakuje elementu w katalogu - dodajesz go z typowymi wymiarami."),
    "anchors": ("Kotwy - co wybrać?",
                "Dodaj set do kotew: kotwy (norma + zestaw + klasy + średnice) dostają nowy zestaw nakrętek i podkładek albo "
                "zmieniasz zestaw w swoich kotwach.\n\nDodaj długości do kotew: dopisujesz nowe długości do wielu kotew naraz.\n\n"
                "Nowa kotwa: tworzysz kotwę od zera albo na wzorcu istniejącej - wybierz wzorzec w kroku 2 i zmień średnicę, "
                "klasę lub nazwę zestawu (nowa średnica, nowa klasa, kopia)."),
    "cat_anchors": ("Katalog kotew - jak z niego korzystać?",
                    "To widok jak w katalogach typu Tekla: wszystko w jednym oknie.\n\n1. Po lewej wybierz normę (rodzinę / producenta kotew).\n"
                    "2. W tabeli zaznacz kotwę (Ctrl / Shift = kilka). Po prawej zobaczysz jej rysunek.\n"
                    "3. Użyj przycisku:\n  + Nowa kotwa - kreator nowej kotwy w tej normie.\n  Kopiuj jako nową - nowa średnica, klasa albo wariant na wzorcu zaznaczonej.\n"
                    "  Dodaj / zmień zestaw - zestaw nakrętek i podkładek dla zaznaczonych kotew.\n  Dopisz długości - nowe długości do zaznaczonych kotew.\n"
                    "  Usuń zaznaczone - tylko Twoje kotwy.\n\nSzare wiersze to dane fabryczne: program ich nie zmienia. Każdy zapis robi kopię zapasową i można go cofnąć."),
    "cat_bolts": ("Katalog śrub - jak z niego korzystać?",
                  "To widok jak w katalogach typu Tekla: wszystko w jednym oknie.\n\n1. Po lewej wybierz normę śruby.\n"
                  "2. W tabeli zaznacz zestaw (podkładki i nakrętki dla danej klasy). Po prawej zobaczysz śrubę z tym zestawem.\n"
                  "3. Użyj przycisku:\n  + Nowy zestaw - kreator zestawu dla tej normy.\n  Kopiuj zestaw - nowy zestaw na wzorcu zaznaczonego.\n"
                  "  Zmień mój zestaw - zmiana składu Twojego zestawu.\n  Skopiuj klasę - nowa klasa śrub (np. 5.6) z całą zawartością istniejącej.\n"
                  "  Usuń zaznaczone - tylko Twoje zestawy.\n\nSzare wiersze to dane fabryczne: program ich nie zmienia. Każdy zapis robi kopię zapasową i można go cofnąć."),
    "mine": ("Moje wpisy i cofanie",
             "Tu są wszystkie kotwy i zestawy śrub, które dodałeś (właściciel inny niż DSC / AUTODESK). Możesz je usunąć.\n\n"
             "Zakładka 'Ostatnie zapisy i cofanie' pokazuje dziennik zapisów. 'Cofnij ostatni zapis' usuwa dokładnie to, co "
             "dodał ostatni zapis (albo przywraca to, co zmienił). Cofać można po kolei - zawsze ostatni."),
    "bolt_set.1": ("Krok 1: śruba, klasy, średnice",
                   "Wskaż, dla jakich śrub powstanie zestaw: normę, jedną lub kilka klas i średnic (Ctrl / Shift zaznacza kilka). "
                   "Zestaw zostanie zapisany dla wszystkich zaznaczonych kombinacji. Po prawej widzisz zestawy, które już istnieją "
                   "dla tego wyboru - nowy zestaw ich nie zmienia."),
    "bolt_set.2": ("Krok 2: skład zestawu",
                   "Ułóż podkładki i nakrętki od łba do końca śruby. Możesz zacząć od istniejącego zestawu (lista pokazuje tylko "
                   "zestawy z Twojego wyboru; pole 'Pokaż wszystkie' rozszerza listę) i go zmienić. Czerwone elementy nie istnieją "
                   "w bazie dla jakiejś średnicy - zamień je. Rysunek po prawej pokazuje efekt."),
    "bolt_set.3": ("Krok 3: nazwa i zapis",
                   "Nadaj zestawowi klucz i nazwę oraz wpisz właściciela (nie DSC/AUTODESK). Podsumowanie pokazuje, co zostanie "
                   "zapisane dla każdej klasy i średnicy. Zapis robi kopię zapasową bazy."),
    "class_copy.1": ("Krok 1: norma i klasa źródłowa",
                     "Wybierz normę i klasę, którą chcesz skopiować, oraz średnice. Nowa klasa dostanie te same wymiary śrub i te "
                     "same zestawy."),
    "class_copy.2": ("Krok 2: nowa klasa",
                     "Podaj nazwę nowej klasy (np. 5.6). Jeśli nie ma jej w słowniku, możesz ją tu dodać. Potem wskaż, jak mają się "
                     "zmienić klasy elementów (np. nakrętka klasy 8 -> 5)."),
    "class_copy.3": ("Krok 3: podsumowanie",
                     "Sprawdź, ile wierszy zostanie skopiowanych. Zapis robi kopię zapasową i działa w jednej transakcji - przy "
                     "błędzie nic się nie zmienia."),
    "anchor_set.1": ("Krok 1: które kotwy",
                     "Wybierz normę kotwy i zestaw-wzór, potem klasy materiałowe i średnice. Tabela po prawej pokazuje dokładnie "
                     "te kotwy, których dotyczy operacja. Szare wiersze to kotwy fabryczne - program ich nie zmienia."),
    "anchor_set.2": ("Krok 2: nowy set",
                     "Wybierz tryb: 'Nowy zestaw' tworzy kopie wybranych kotew z nowym zestawem (z tymi samymi długościami), "
                     "'Zmień zestaw w tych kotwach' nadpisuje skład zestawu w Twoich kotwach (fabrycznych nie rusza).\n\n"
                     "Skład układasz w strefach: nad blachą, pod blachą, koniec kotwy. Nad blachą wiersz 1 jest najdalej od blachy, "
                     "pod blachą wiersz 1 leży przy blasze. Schemat po prawej pokazuje efekt."),
    "anchor_set.3": ("Krok 3: podsumowanie",
                     "Każda kotwa ma status: NOWA / NADPISANIE albo powód pominięcia (np. element zestawu nie istnieje w bazie "
                     "dla tej średnicy, kotwa fabryczna). Możesz zapisać bez brakujących elementów."),
    "anchor_len.1": ("Krok 1: które kotwy",
                     "Wskaż normę i zestaw, potem klasy materiałowe i średnice. Nowe długości dostaną wszystkie kotwy z tabeli "
                     "po prawej."),
    "anchor_len.2": ("Krok 2: nowe długości",
                     "Wpisz długości [mm]: listę (300, 400), zakres (300-1000/100) albo wklej kolumnę z Excela. Wymiary, ciężar "
                     "i numer części każdej długości są liczone z najbliższej istniejącej długości tej kotwy. Długości, które "
                     "kotwa już ma, są pomijane."),
    "anchor_len.3": ("Krok 3: podsumowanie",
                     "Lista wierszy do dopisania i status każdego. Dotychczasowe wiersze (także fabryczne) nie są zmieniane - "
                     "dopisywane są tylko nowe z Twoim właścicielem."),
    "anchor_new.1": ("Krok 1: norma kotwy",
                     "Wybierz istniejącą normę kotwy (np. producenta) albo załóż nową, wpisując jej nazwę.\n\n"
                     "Chcesz nową średnicę, klasę albo kopię istniejącej kotwy? Wybierz jej normę, a w kroku 2 wybierz wzorzec "
                     "i zmień średnicę lub klasę."),
    "anchor_new.2": ("Krok 2: typ, wymiary, długości",
                     "Najszybciej wybierz wzorzec - wypełni typ, klasę, zestaw, źródło i wymiary; potem wpisz średnicę "
                     "i długości. Wzorzec możesz wziąć z dowolnej normy (także gdy tworzysz nową normę) - najpierw wybierz 'Norma wzorca'. "
                     "Pola z gwiazdką są wymagane. Wymiary zależą od typu kotwy (najedź na nazwę pola, aby zobaczyć opis)."),
    "anchor_new.3": ("Krok 3: zestaw nakrętek i podkładek",
                     "Dodaj elementy w trzech strefach: nad blachą, pod blachą, koniec kotwy. Nad blachą wiersz 1 jest najdalej od blachy, pod blachą przy blasze. "
                     "Czerwone '(brak)' oznacza element, którego nie ma w bazie dla tej średnicy. Schemat pokazuje efekt."),
    "anchor_new.4": ("Krok 4: podsumowanie",
                     "Sprawdź długości, numery części i ciężary. Jeśli kotwa o tej średnicy, klasie i zestawie już istnieje, "
                     "zapis jest zablokowany - zmień jedną z tych wartości."),
}


GLOSSARY = [
    ("Norma", "Nazwa grupy w katalogu: dla śrub np. DIN 933, dla kotew np. rodzina producenta (Hilti HST). Zawiera śruby / kotwy o różnych średnicach i klasach."),
    ("Klasa (materiałowa)", "Klasa wytrzymałości lub materiału, np. 5.8, 8.8, A4. Nie myl z typem kotwy."),
    ("Typ kotwy", "Kształt kotwy: zwykła, młoteczkowa, gwintowana, fajkowa (L), J. Od typu zależą wymiary, które trzeba podać."),
    ("Zestaw (set)", "Komplet elementów dodawanych do śruby lub kotwy: podkładki i nakrętki w ustalonej kolejności."),
    ("Strefy zestawu kotwy", "Nad blachą, pod blachą i koniec kotwy. Nad blachą wiersz 1 jest najdalej od blachy, pod blachą wiersz 1 leży przy blasze, kolejne niżej."),
    ("Źródło", "Skrót (max 15 znaków) wskazujący pochodzenie danych, np. HILTI. Widać go w katalogu."),
    ("Właściciel", "Nazwa, którą program wpisuje przy Twoich wierszach (np. MOJA). Wpisy fabryczne mają DSC / AUTODESK i nie są zmieniane."),
    ("Kopia zapasowa", "Przed pierwszym zapisem w sesji program robi kopię bazy (folder backups). Dodatkowo każdy zapis można cofnąć w 'Moje wpisy'."),
]


def show_glossary(parent):
    win = tk.Toplevel(parent)
    win.title(T("Słowniczek pojęć"))
    win.transient(parent.winfo_toplevel())
    ttk.Label(win, text=T("Słowniczek pojęć"), style="CardTitle.TLabel").pack(anchor="w", padx=20, pady=(16, 6))
    for term, text in GLOSSARY:
        row = ttk.Frame(win)
        row.pack(anchor="w", padx=20, pady=3, fill="x")
        ttk.Label(row, text=T(term), style="Step.TLabel", width=22).pack(side="left", anchor="n")
        ttk.Label(row, text=T(text), wraplength=420, justify="left").pack(side="left")
    ttk.Button(win, text=T("Zamknij"), command=win.destroy, style="Accent.TButton").pack(anchor="e", padx=20, pady=16)
    win.bind("<Escape>", lambda e: win.destroy())
    win.focus_set()


def show_help(parent, key):
    title, text = HELP[key]
    win = tk.Toplevel(parent)
    win.title(T(title))
    win.transient(parent.winfo_toplevel())
    ttk.Label(win, text=T(title), style="CardTitle.TLabel").pack(anchor="w", padx=20, pady=(16, 6))
    ttk.Label(win, text="\n".join(T(x) for x in text.split("\n")), wraplength=460, justify="left").pack(anchor="w", padx=20)
    bar = ttk.Frame(win)
    bar.pack(fill="x", padx=20, pady=16)
    ttk.Button(bar, text=T("Słowniczek pojęć"), command=lambda: show_glossary(win)).pack(side="left")
    ttk.Button(bar, text=T("Zamknij"), command=win.destroy, style="Accent.TButton").pack(side="right")
    win.update_idletasks()
    x = parent.winfo_toplevel().winfo_rootx() + 80
    y = parent.winfo_toplevel().winfo_rooty() + 60
    win.geometry("+%d+%d" % (x, y))
    win.bind("<Escape>", lambda e: win.destroy())
    win.focus_set()


def help_button(parent, key):
    return ttk.Button(parent, text="?", width=3, command=lambda: show_help(parent, key))


WELCOME = [
    ("1  Wybierz", "Na ekranie startowym wybierz, czego dotyczy zmiana: Kotwy albo Śruby."),
    ("2  Sprawdź", "Kreator prowadzi krok po kroku. Po prawej widzisz podgląd, a na końcu zdanie 'Co się stanie po zapisie'."),
    ("3  Zapisz", "Zapis robi kopię zapasową bazy i nigdy nie zmienia wpisów fabrycznych. Pomyłkę cofniesz w 'Moje wpisy i cofanie'."),
]


def show_welcome(parent):
    win = tk.Toplevel(parent)
    win.title(T("Witaj"))
    win.transient(parent.winfo_toplevel())
    ttk.Label(win, text=T("Jak to działa"), style="Title.TLabel").pack(anchor="w", padx=24, pady=(18, 8))
    for head, text in WELCOME:
        row = ttk.Frame(win, style="Card.TFrame", padding=12)
        row.pack(fill="x", padx=24, pady=4)
        ttk.Label(row, text=T(head), style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(row, text=T(text), wraplength=440, justify="left").pack(anchor="w", pady=(2, 0))
    ttk.Label(win, text=T("Przycisk '?' w każdym kroku wyjaśnia, co robisz."), style="Hint.TLabel").pack(anchor="w", padx=24, pady=(8, 0))
    ttk.Button(win, text=T("Zaczynamy"), style="Accent.TButton", command=win.destroy).pack(anchor="e", padx=24, pady=16)
    win.update_idletasks()
    x = parent.winfo_toplevel().winfo_rootx() + 120
    y = parent.winfo_toplevel().winfo_rooty() + 80
    win.geometry("+%d+%d" % (x, y))
    win.bind("<Escape>", lambda e: win.destroy())
    win.focus_set()
