# -*- coding: utf-8 -*-
"""
Sondaż kotew Advance Steel (tylko odczyt) + migawki "przed/po" do wykrywania zmian w bazie.

Użycie:
  python as_anchor_probe.py                       -> sondaż kotew  -> anchor_probe.txt
  python as_anchor_probe.py snapshot przed        -> migawka tabel AstorBase i AstorAddIn -> snapshot_przed.json
  python as_anchor_probe.py diff przed            -> porównanie bazy z migawką            -> diff_przed.txt
Opcje (na końcu polecenia):  --lang POL   --server "(LocalDB)\\AdvanceSteel2026"
Skrypt wykonuje wyłącznie SELECT-y. Nic nie zmienia w bazie.
"""
import os
import re
import sys
import json
import hashlib
import subprocess
from collections import Counter

try:
    import pyodbc
except ImportError:
    sys.exit("Brak pyodbc:  pip install pyodbc")

APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
ANCH_TABLES = ["AnchorsClass", "AnchorsStandard", "AnchorsName", "AnchorsDefinition", "AnchorsHoleDefinition",
               "AnchorsOrientation", "Sources", "BoltsDiameters", "ScrewHoleType", "ScrewHoleLocation",
               "StrengthClass", "BoltsCoating"]
SMALL = 30   # tabele o tylu wierszach lub mniej zrzucamy w całości


# ---------------------------------------------------------------- narzędzia
def instances():
    try:
        out = subprocess.run(["sqllocaldb", "i"], capture_output=True, text=True, timeout=20).stdout
        return [l.strip() for l in out.splitlines() if l.strip()]
    except Exception:
        return []


def pick_driver():
    d = [x for x in pyodbc.drivers() if "SQL Server" in x]
    d.sort(key=lambda x: ("18" in x, "17" in x), reverse=True)
    if not d:
        sys.exit("Brak sterownika ODBC dla SQL Server (zainstaluj ODBC Driver 17/18).")
    return d[0]


def cs(drv, server, db):
    return ("DRIVER={%s};SERVER=%s;DATABASE={%s};Trusted_Connection=yes;TrustServerCertificate=yes;Encrypt=no;"
            % (drv, server, db))


def find_dbs(drv, server, lang):
    con = pyodbc.connect(cs(drv, server, "master"), timeout=15)
    cur = con.cursor()
    cur.execute("SELECT d.name, mf.physical_name FROM sys.master_files mf "
                "JOIN sys.databases d ON d.database_id=mf.database_id WHERE mf.type=0 AND d.database_id>4")
    rows = [(r[0], r[1]) for r in cur.fetchall()]
    con.close()
    res = {}
    for name, phys in rows:
        base = os.path.basename(phys or "").lower()
        m = re.search(r"\\([A-Za-z]{3})\\(?:Steel|User2)\\Data\\", phys or "")
        if m and m.group(1).upper() == lang and base in ("astorbase.mdf", "astoraddin.mdf"):
            res[base] = name
    return res


def fetch(cur, sql, params=()):
    cur.execute(sql, list(params))
    cols = [d[0] for d in cur.description]
    return cols, [tuple(r) for r in cur.fetchall()]


def fmt(v):
    if v is None:
        return "NULL"
    s = str(v)
    return s if len(s) <= 40 else s[:40] + "..."


def show(out, cols, rows, indent="  "):
    for r in rows:
        out(indent + " | ".join("%s=%s" % (c, fmt(v)) for c, v in zip(cols, r)))


def ranges(ids):
    ids = sorted(set(i for i in ids if isinstance(i, int)))
    res, s, p = [], None, None
    for i in ids:
        if s is None:
            s = p = i
        elif i == p + 1:
            p = i
        else:
            res.append((s, p))
            s = p = i
    if s is not None:
        res.append((s, p))
    return res


def ranges_text(ids, limit=60):
    rs = ranges(ids)
    txt = ", ".join(("%d" % a) if a == b else ("%d-%d" % (a, b)) for a, b in rs[:limit])
    return txt + (" ... (+%d zakresów)" % (len(rs) - limit) if len(rs) > limit else "")


def safe(out, title, fn):
    out("\n### " + title)
    try:
        fn()
    except Exception as e:
        out("  (błąd: %s)" % str(e)[:200])


# ---------------------------------------------------------------- sondaż kotew
def probe(cur, out):
    tables = {r[0] for r in fetch(cur, "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES")[1]}

    def counts():
        for t in ANCH_TABLES:
            if t not in tables:
                out("  %-24s (brak tabeli)" % t)
                continue
            n = fetch(cur, "SELECT COUNT(*) FROM [%s]" % t)[1][0][0]
            pk = [r[0] for r in fetch(cur, "SELECT k.COLUMN_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS c JOIN "
                                           "INFORMATION_SCHEMA.KEY_COLUMN_USAGE k ON c.CONSTRAINT_NAME=k.CONSTRAINT_NAME "
                                           "WHERE c.CONSTRAINT_TYPE='PRIMARY KEY' AND c.TABLE_NAME=?", (t,))[1]]
            out("  %-24s wierszy=%d  klucz główny=%s" % (t, n, ",".join(pk) or "(brak)"))
    safe(out, "1. Tabele: liczba wierszy i klucze główne", counts)

    def lookups():
        for t in ("AnchorsClass", "AnchorsOrientation", "ScrewHoleType", "ScrewHoleLocation", "AnchorsHoleDefinition",
                  "Sources", "BoltsDiameters"):
            if t not in tables:
                continue
            cols, rows = fetch(cur, "SELECT TOP %d * FROM [%s]" % (SMALL if t != "BoltsDiameters" else 12, t))
            out("  -- %s (kolumny: %s)" % (t, ", ".join(cols)))
            show(out, cols, rows, "    ")
    safe(out, "2. Słowniki i tabele pomocnicze", lookups)

    def owners():
        for t in ("AnchorsStandard", "AnchorsName", "AnchorsDefinition", "AnchorsHoleDefinition", "StrengthClass"):
            if t not in tables:
                continue
            col = next((c for c in ("OwnerText", "Owner") if c in fetch(cur, "SELECT TOP 0 * FROM [%s]" % t)[0]), None)
            if col:
                rows = fetch(cur, "SELECT [%s], COUNT(*) FROM [%s] GROUP BY [%s] ORDER BY 2 DESC" % (col, t, col))[1]
                out("  %-22s %s" % (t, ", ".join("%s=%d" % (r[0], r[1]) for r in rows)))
    safe(out, "3. Właściciele wpisów (OwnerText)", owners)

    def per_class():
        cols, rows = fetch(cur, "SELECT ClassID, COUNT(*) n, MIN(ID) min_id, MAX(ID) max_id, COUNT(DISTINCT Standard) normy "
                                "FROM [AnchorsName] GROUP BY ClassID ORDER BY ClassID")
        show(out, cols, rows)
    safe(out, "4. AnchorsName: liczba wierszy i zakresy ID per typ kotwy (ClassID)", per_class)

    def samples():
        for cid in range(0, 5):
            out("  ===== ClassID = %d =====" % cid)
            cols, rows = fetch(cur, "SELECT TOP 2 * FROM [AnchorsName] WHERE ClassID=? ORDER BY ID", (cid,))
            if not rows:
                out("    (brak wierszy)")
                continue
            for r in rows:
                out("    [AnchorsName]")
                show(out, cols, [r], "      ")
                dc, dr = fetch(cur, "SELECT TOP 3 * FROM [AnchorsDefinition] WHERE AnchorID=? ORDER BY ID", (r[0],))
                out("    [AnchorsDefinition dla AnchorID=%s]" % r[0])
                show(out, dc, dr, "      ")
            neg = " OR ".join("ISNULL(Position%d,0)<0" % k for k in range(1, 7))
            cols, rows = fetch(cur, "SELECT TOP 1 * FROM [AnchorsName] WHERE ClassID=? AND (%s) ORDER BY ID" % neg, (cid,))
            out("    [przykład z elementami po stronie dolnej (pozycja < 0)]")
            show(out, cols, rows, "      ") if rows else out("      (brak takich wierszy)")
    safe(out, "5. Przykładowe wiersze każdego typu kotwy (AnchorsName + AnchorsDefinition)", samples)

    def patterns():
        comp = "CONCAT(" + ",' ',".join("DIN%d,'/',Position%d" % (k, k) for k in range(1, 7)) + ")"
        cols, rows = fetch(cur, "SELECT TOP 80 ClassID, SetName, NumItems, comp, COUNT(*) n FROM (SELECT ClassID, SetName, "
                                "NumItems, %s AS comp FROM [AnchorsName]) t GROUP BY ClassID, SetName, NumItems, comp "
                                "ORDER BY ClassID, COUNT(*) DESC" % comp)
        show(out, cols, rows)
    safe(out, "6. Wzorce składu zestawu (DIN/pozycja) per typ kotwy", patterns)

    def ids():
        for t, col in (("AnchorsName", "ID"), ("AnchorsDefinition", "ID"), ("AnchorsHoleDefinition", "ID"),
                       ("AnchorsOrientation", "Key")):
            vals = [r[0] for r in fetch(cur, "SELECT [%s] FROM [%s]" % (col, t))[1]]
            out("  %s.%s: min=%s max=%s liczba=%d" % (t, col, min(vals, default=None), max(vals, default=None), len(vals)))
            out("     zakresy: " + ranges_text(vals))
        q1 = {
            "definicje bez kotwy (AnchorID nie istnieje w AnchorsName)":
                "SELECT COUNT(*) FROM [AnchorsDefinition] d LEFT JOIN [AnchorsName] n ON n.ID=d.AnchorID WHERE n.ID IS NULL",
            "kotwy bez żadnej definicji":
                "SELECT COUNT(*) FROM [AnchorsName] n LEFT JOIN [AnchorsDefinition] d ON d.AnchorID=n.ID WHERE d.ID IS NULL",
            "otwory (HoleDefinition) bez kotwy":
                "SELECT COUNT(*) FROM [AnchorsHoleDefinition] h LEFT JOIN [AnchorsName] n ON n.ID=h.AnchorNameID WHERE n.ID IS NULL",
            "kotwy z normą spoza AnchorsStandard":
                "SELECT COUNT(*) FROM [AnchorsName] n LEFT JOIN [AnchorsStandard] s ON s.[Key]=n.Standard WHERE s.[Key] IS NULL",
            "kotwy z klasą spoza StrengthClass":
                "SELECT COUNT(*) FROM [AnchorsName] n LEFT JOIN [StrengthClass] c ON c.[Key]=n.MaterialKey WHERE c.[Key] IS NULL",
            "kotwy z ClassID spoza AnchorsClass":
                "SELECT COUNT(*) FROM [AnchorsName] n LEFT JOIN [AnchorsClass] c ON c.ID=n.ClassID WHERE c.ID IS NULL",
            "kotwy z zestawem (SetName) spoza Sets":
                "SELECT COUNT(*) FROM [AnchorsName] n LEFT JOIN [Sets] s ON s.[Key]=n.SetName WHERE s.[Key] IS NULL",
            "duplikaty (Standard, MaterialKey, Diameter, SetName)":
                "SELECT COUNT(*) FROM (SELECT 1 x FROM [AnchorsName] GROUP BY Standard, MaterialKey, Diameter, SetName "
                "HAVING COUNT(*)>1) t",
        }
        for label, sql in q1.items():
            try:
                out("  %-62s %s" % (label, fetch(cur, sql)[1][0][0]))
            except Exception as e:
                out("  %-62s (błąd: %s)" % (label, str(e)[:80]))
        cols, rows = fetch(cur, "SELECT TOP 40 Standard, COUNT(*) kotwy, MIN(ID) min_id, MAX(ID) max_id FROM [AnchorsName] "
                                "GROUP BY Standard ORDER BY MIN(ID)")
        out("  -- zakresy ID kotew per norma (pierwsze 40):")
        show(out, cols, rows, "    ")
    safe(out, "7. Identyfikatory i spójność powiązań", ids)

    def sources():
        cols, rows = fetch(cur, "SELECT TOP 40 Source, COUNT(*) n FROM [AnchorsName] GROUP BY Source ORDER BY n DESC")
        out("  -- najczęstsze wartości AnchorsName.Source:")
        show(out, cols, rows, "    ")
        cols, rows = fetch(cur, "SELECT TOP 15 * FROM [AnchorsName] WHERE ISNULL(OwnerText,'') NOT IN ('DSC','AUTODESK') ORDER BY ID")
        out("  -- wlasne (nie fabryczne) kotwy w bazie:")
        show(out, cols, rows, "    ") if rows else out("    (brak)")
    safe(out, "8. Źródła (Source) i własne wpisy", sources)

    def constraints():
        cols, rows = fetch(cur, "SELECT fk.name, OBJECT_NAME(fkc.parent_object_id) tbl, COL_NAME(fkc.parent_object_id, fkc.parent_column_id) col, "
                                "OBJECT_NAME(fkc.referenced_object_id) ref_tbl, COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) ref_col "
                                "FROM sys.foreign_keys fk JOIN sys.foreign_key_columns fkc ON fk.object_id=fkc.constraint_object_id")
        out("  klucze obce w całej bazie: %d" % len(rows))
        mine = [r for r in rows if any(k in (r[1] or "") + (r[3] or "") for k in ("Anchor", "SetBolts", "SetOfBolts", "SetNutsBolts", "Standard", "Sets", "StrengthClass", "Sources"))]
        show(out, cols, mine[:80])
        cols, rows = fetch(cur, "SELECT OBJECT_NAME(parent_object_id) tbl, name, definition FROM sys.check_constraints")
        out("  ograniczenia CHECK: %d" % len(rows))
        show(out, cols, rows[:40])
        cols, rows = fetch(cur, "SELECT name, OBJECT_NAME(parent_id) tbl FROM sys.triggers")
        out("  wyzwalacze (triggers): %d" % len(rows))
        show(out, cols, rows[:40])
    safe(out, "9. Klucze obce, ograniczenia i wyzwalacze", constraints)


# ---------------------------------------------------------------- migawki
def row_hash(row):
    return hashlib.md5(repr(tuple(row)).encode("utf-8", "replace")).hexdigest()[:12]


def base_tables(cur):
    return [r[0] for r in fetch(cur, "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY 1")[1]]


def snapshot(drv, server, dbs, path, out):
    data = {}
    for base, name in dbs.items():
        con = pyodbc.connect(cs(drv, server, name), timeout=30)
        cur = con.cursor()
        for t in base_tables(cur):
            cur.execute("SELECT * FROM [%s]" % t)
            data["%s.%s" % (base, t)] = [row_hash(r) for r in cur.fetchall()]
        con.close()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f)
    out("Zapisano migawkę: %s  (tabel: %d, wierszy: %d)" % (path, len(data), sum(len(v) for v in data.values())))


def diff(drv, server, dbs, path, out):
    with open(path, "r", encoding="utf-8") as f:
        old = json.load(f)
    changed = 0
    for base, name in dbs.items():
        con = pyodbc.connect(cs(drv, server, name), timeout=30)
        cur = con.cursor()
        for t in base_tables(cur):
            key = "%s.%s" % (base, t)
            if key not in old:
                out("\n[%s] NOWA TABELA" % key)
                continue
            cur.execute("SELECT * FROM [%s]" % t)
            cols = [d[0] for d in cur.description]
            rows = [tuple(r) for r in cur.fetchall()]
            was, now = Counter(old[key]), Counter(row_hash(r) for r in rows)
            added = [r for r in rows if was.get(row_hash(r), 0) == 0]
            removed = sum((was - now).values())
            if not added and not removed:
                continue
            changed += 1
            out("\n[%s]  dodane/zmienione wiersze: %d   usunięte/zastąpione: %d" % (key, len(added), removed))
            for r in added[:40]:
                out("   + " + " | ".join("%s=%s" % (c, fmt(v)) for c, v in zip(cols, r)))
            if len(added) > 40:
                out("   ... (+%d)" % (len(added) - 40))
        con.close()
    out("\nTabel ze zmianami: %d" % changed)


# ---------------------------------------------------------------- main
def main():
    args = sys.argv[1:]
    opts = {"--lang": "INT", "--server": None}
    for k in list(opts):
        if k in args:
            i = args.index(k)
            opts[k] = args[i + 1]
            del args[i:i + 2]
    lang = opts["--lang"].upper()
    drv = pick_driver()
    server = opts["--server"]
    if not server:
        cand = [i for i in instances() if i.lower().startswith("advancesteel")]
        server = "(LocalDB)\\" + (cand[0] if cand else "AdvanceSteel2026")
    dbs = find_dbs(drv, server, lang)
    if "astorbase.mdf" not in dbs:
        sys.exit("Nie znaleziono podłączonej bazy AstorBase dla wersji %s na %s. Uruchom Advance Steel / Management "
                 "Tools w tej wersji i spróbuj ponownie." % (lang, server))
    mode = args[0] if args else "probe"
    tag = args[1] if len(args) > 1 else "migawka"
    if mode == "probe":
        path = os.path.join(APP_DIR, "anchor_probe.txt")
    elif mode == "snapshot":
        path = os.path.join(APP_DIR, "snapshot_%s.json" % tag)
    elif mode == "diff":
        path = os.path.join(APP_DIR, "diff_%s.txt" % tag)
    else:
        sys.exit("Nieznany tryb: %s (probe | snapshot NAZWA | diff NAZWA)" % mode)

    with open(path, "w", encoding="utf-8") if mode != "snapshot" else open(os.devnull, "w") as fh:
        def out(s=""):
            print(s)
            fh.write(s + "\n")
        out("Serwer: %s   Wersja: %s   Bazy: %s" % (server, lang, ", ".join(dbs.values())))
        if mode == "probe":
            con = pyodbc.connect(cs(drv, server, dbs["astorbase.mdf"]), timeout=30)
            probe(con.cursor(), out)
            con.close()
        elif mode == "snapshot":
            snapshot(drv, server, dbs, path, out)
        else:
            snap = os.path.join(APP_DIR, "snapshot_%s.json" % tag)
            if not os.path.exists(snap):
                sys.exit("Brak migawki: %s - najpierw uruchom 'snapshot %s'." % (snap, tag))
            diff(drv, server, dbs, snap, out)
    print("\nGotowe. Plik: %s" % path)


if __name__ == "__main__":
    main()
