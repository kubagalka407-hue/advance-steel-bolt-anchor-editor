# -*- coding: utf-8 -*-
"""Kreator 'Dodaj zestaw do śruby': 1) norma, klasy i średnice, 2) skład (podkładki, nakrętki), 3) nazwa i zapis."""
from as_editor.common import dia_text, fmt_dia, is_own
from as_editor.config import recall, remember
from as_editor.i18n import T
from as_editor.ui.comp_editor import CompEditor
from as_editor.ui.preview_panel import BoltPreview
from as_editor.ui.widgets import order_button, make_filterable, make_list, make_tree, selected_index, set_choices, tk, ttk
from as_editor.ui.wizard import Wizard


class BoltSetWizard(Wizard):
    finish_text = "Zapisz zestaw"

    def __init__(self, app):
        super().__init__(app, "Dodaj zestaw do śruby")
        self.mats, self.dias = [], []
        self.loaded_for = None
        self.job = None
        self.pv = BoltPreview(self.make_side("Podgląd śruby", 390), app, self.pv_state)
        self.pv.pack(fill="both", expand=True)
        self.add_step("Śruba, klasy i średnice", self.build1, self.enter1, self.leave1, help="bolt_set.1")
        self.add_step("Skład zestawu", self.build2, self.enter2, self.leave2, help="bolt_set.2")
        self.add_step("Nazwa i zapis", self.build3, self.enter3, self.leave3, help="bolt_set.3")
        self.start()

    # ------------------------------------------------------------ krok 1
    def build1(self, f):
        ttk.Label(f, text="Dla których śrub ma powstać zestaw? Zaznacz normę, klasy i średnice (Ctrl / Shift = kilka).",
                  style="Sub.TLabel").pack(anchor="w", pady=(0, 10))
        ttk.Label(f, text="Norma śruby (wpisz tekst, np. DIN, aby zawęzić listę)").pack(anchor="w")
        self.cb_std = make_filterable(ttk.Combobox(f, width=60))
        self.cb_std.pack(anchor="w", pady=(2, 12))
        set_choices(self.cb_std, self.app.std_vals)
        self.cb_std.bind("<<ComboboxSelected>>", lambda e: (self.on_std(), self.redraw()))
        cols = ttk.Frame(f)
        cols.pack(anchor="w", fill="y", expand=True)
        c1 = ttk.Frame(cols)
        c1.pack(side="left", padx=(0, 24), fill="y")
        ttk.Label(c1, text="Klasy śruby").pack(anchor="w")
        fr, self.lb_mat = make_list(c1, 12, 16)
        fr.pack(fill="y", expand=True)
        self.lb_mat.bind("<<ListboxSelect>>", lambda e: (self.on_mats(), self.redraw()))
        c2 = ttk.Frame(cols)
        c2.pack(side="left", fill="y")
        ttk.Label(c2, text="Średnice").pack(anchor="w")
        fr, self.lb_dia = make_list(c2, 12, 16)
        fr.pack(fill="y", expand=True)
        self.lb_dia.bind("<<ListboxSelect>>", lambda e: (self.fill_have(), self.redraw()))
        b = ttk.Frame(c2)
        b.pack(anchor="w", pady=(6, 0))
        ttk.Button(b, text=T("Wszystkie"), command=lambda: (self.lb_dia.selection_set(0, "end"), self.fill_have())).pack(side="left", padx=(0, 6))
        ttk.Button(b, text=T("Żadna"), command=lambda: (self.lb_dia.selection_clear(0, "end"), self.fill_have())).pack(side="left", padx=(0, 6))
        order_button(b, self, self.on_mats).pack(side="left")
        c3 = ttk.Frame(cols)
        c3.pack(side="left", fill="both", expand=True, padx=(24, 0))
        ttk.Label(c3, text=T("Zestawy, które już istnieją dla tego wyboru"), style="CardTitle.TLabel").pack(anchor="w")
        fr, self.tr_have = make_tree(c3, ("Zestaw", "Klasa"), (180, 90), 10, sort=True, filt=True)
        fr.pack(fill="both", expand=True)
        ttk.Label(c3, text=T("Nowy zestaw nie zmienia tych zestawów - powstaje obok."), style="Hint.TLabel").pack(anchor="w")
        self.var_hint1 = tk.StringVar()
        ttk.Label(f, textvariable=self.var_hint1, style="Hint.TLabel", wraplength=700).pack(anchor="w", pady=(10, 0))

    def enter1(self):
        if selected_index(self.cb_std) < 0:
            cur = self.app.cur_std() or recall("last_bolt_std")
            for i, st in enumerate(self.app.stds):
                if st[0] == cur:
                    self.cb_std.set(self.app.std_vals[i])
                    self.cb_std._last = i
                    self.on_std()
                    break

    def preset(self, std, mats=None, dias=None, tpl=None, key=None, run=None, overwrite=False):
        """Wstępny wybór (z Katalogu): norma, klasy, średnice; tpl = (zestaw, klasa) jako wzorzec składu;
        key/run/overwrite = zmiana własnego zestawu (nadpisanie)."""
        i = next((k for k, st in enumerate(self.app.stds) if st[0] == std), -1)
        if i < 0:
            return False
        self.cb_std.set(self.app.std_vals[i])
        self.cb_std._last = i
        self.on_std()
        if mats:
            self.lb_mat.selection_clear(0, "end")
            for k, m in enumerate(self.mats):
                if m in mats:
                    self.lb_mat.selection_set(k)
            self.on_mats()
        if dias:
            self.lb_dia.selection_clear(0, "end")
            for k, d in enumerate(self.dias):
                if any(abs(d - float(x)) < 1e-6 for x in dias):
                    self.lb_dia.selection_set(k)
            self.fill_have()
        self.want_tpl, self.want_key = tpl, (key, run, overwrite) if key else None
        self.redraw()
        return True

    def std_key(self):
        i = selected_index(self.cb_std)
        return self.app.stds[i][0] if 0 <= i < len(self.app.stds) else None

    def on_std(self):
        std = self.std_key()
        self.mats = self.db.bolt_materials(std) if std else []
        self.lb_mat.delete(0, "end")
        for m in self.mats:
            self.lb_mat.insert("end", m)
        if self.mats:
            self.lb_mat.selection_set(0)
        self.on_mats()
        self.var_hint1.set("" if self.mats else T("Ta norma nie ma śrub w bazie - nie da się dla niej zbudować zestawu."))

    def on_mats(self):
        old = [self.dias[i] for i in self.lb_dia.curselection()] if self.dias else []
        sel = self.sel_mats()
        self.dias = sorted(self.db.bolt_diameters(self.std_key(), sel), reverse=self.dia_desc) if sel else []
        self.lb_dia.delete(0, "end")
        for d in self.dias:
            self.lb_dia.insert("end", "Ø " + dia_text(d))
        keep = [i for i, d in enumerate(self.dias) if d in old]
        for i in (keep or range(len(self.dias))):
            self.lb_dia.selection_set(i)
        self.fill_have()

    def fill_have(self):
        self.tr_have.delete(*self.tr_have.get_children())
        if self.std_key() and self.sel_mats() and self.sel_dias():
            for a, b in self.db.std_set_pairs(self.std_key(), self.sel_mats(), self.sel_dias()):
                self.tr_have.insert("", "end", values=(a, b))

    def sel_mats(self):
        return [self.mats[i] for i in self.lb_mat.curselection()]

    def sel_dias(self):
        return [self.dias[i] for i in self.lb_dia.curselection()]

    def leave1(self):
        if not self.std_key():
            return "Wybierz normę śruby."
        if not self.sel_mats():
            return "Zaznacz co najmniej jedną klasę śruby."
        if not self.sel_dias():
            return "Zaznacz co najmniej jedną średnicę."

    # ------------------------------------------------------------ krok 2
    def build2(self, f):
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        ttk.Label(f, text="Ułóż podkładki i nakrętki. Skład obowiązuje dla wszystkich zaznaczonych klas i średnic.",
                  style="Sub.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        left = ttk.Frame(f)
        left.grid(row=1, column=0, sticky="nsew")
        row = ttk.Frame(left)
        row.pack(fill="x", pady=(0, 8))
        ttk.Label(row, text="Zacznij od istniejącego zestawu:").pack(side="left")
        self.cb_tpl = ttk.Combobox(row, state="readonly", width=26)
        self.cb_tpl.pack(side="left", padx=8)
        self.cb_tpl.bind("<<ComboboxSelected>>", lambda e: self.on_tpl())
        self.var_all_tpl = tk.BooleanVar(value=False)
        ttk.Checkbutton(row, text="Pokaż wszystkie zestawy normy", variable=self.var_all_tpl,
                        command=self.fill_tpl).pack(side="left")
        self.tpl_rows = []
        self.editor = CompEditor(left, self.app, self.sel_dias, self.redraw)
        self.editor.pack(fill="both", expand=True)

    def enter2(self):
        key = (self.std_key(), tuple(self.sel_mats()))
        if self.loaded_for != key:                      # inna norma/klasy niż poprzednio: wczytaj wzór od nowa
            self.loaded_for = key
            self.fill_tpl()
        self.redraw()

    def refresh_side(self):
        self.redraw()

    def fill_tpl(self):
        """Lista wzorców: domyślnie tylko zestawy istniejące dla wybranej normy, klas i średnic; opcja 'wszystkie'."""
        std = self.std_key()
        rows = []
        if not self.var_all_tpl.get():
            rows = self.db.std_set_pairs(std, self.sel_mats(), self.sel_dias())
        if not rows:                                     # brak dopasowań albo wybrano 'wszystkie'
            rows = [(s[0], m) for s in self.db.std_sets(std) for m in self.db.std_set_materials(std, s[0])]
        self.tpl_rows = rows
        self.cb_tpl["values"] = ["%s  |  %s" % (a, b) for a, b in self.tpl_rows]
        self.pick_default_tpl()

    def pick_default_tpl(self):
        std, mats = self.std_key(), self.sel_mats()
        default = next((s[3] for s in self.app.stds if s[0] == std), None)
        want = getattr(self, "want_tpl", None)
        if want and tuple(want) in [tuple(r) for r in self.tpl_rows]:
            self.cb_tpl.current([tuple(r) for r in self.tpl_rows].index(tuple(want)))
            self.on_tpl()
            return
        best = None
        for i, (sk, m) in enumerate(self.tpl_rows):
            score = (m in mats) * 2 + (sk.lower() == (default or "").lower())
            if best is None or score > best[0]:
                best = (score, i)
        if best:
            self.cb_tpl.current(best[1])
            self.on_tpl()
        else:
            self.cb_tpl.set("")
            self.editor.set_items([], [])

    def on_tpl(self):
        i = self.cb_tpl.current()
        if 0 <= i < len(self.tpl_rows):
            sk, m = self.tpl_rows[i]
            res = self.app.components_from_set(self.std_key(), sk, m)
            self.editor.set_items(*(res if res else ([], [])))

    def pv_state(self):
        """Stan dla panelu podglądu: wybór z kroku 1 i skład z kroku 2 (w kroku 1 jeszcze pusty)."""
        step = max(self.cur, 0)
        cap = {0: T("Skład zestawu (podkładki, nakrętki) dobierzesz w kroku 2 - na razie widzisz samą śrubę."),
               1: T("Rysunek pokazuje skład, który układasz po lewej. Zmieniasz go - rysunek odświeża się sam."),
               2: T("Tak będzie wyglądał nowy zestaw. Zapis nic nie zmienia w istniejących zestawach.")}[min(step, 2)]
        ed = getattr(self, "editor", None)
        return {"std": self.std_key() if hasattr(self, "cb_std") else None, "mats": self.sel_mats() if hasattr(self, "lb_mat") else [],
                "dias": self.sel_dias() if hasattr(self, "lb_dia") else [],
                "head": ed.head if ed else [], "nut": ed.nut if ed else [], "caption": cap}

    def redraw(self):
        self.pv.refresh()

    def leave2(self):
        if not (self.editor.head or self.editor.nut):
            return "Dodaj co najmniej jeden element zestawu."

    # ------------------------------------------------------------ krok 3
    def build3(self, f):
        f.columnconfigure(1, weight=1)
        ttk.Label(f, text="Nadaj zestawowi nazwę. Zobaczysz, co zostanie zapisane, zanim cokolwiek trafi do bazy.",
                  style="Sub.TLabel").grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 10))
        self.entries = {}
        self.v_key, self.v_run = tk.StringVar(), tk.StringVar()
        self.v_owner = tk.StringVar(value=recall("owner", self.app.var_owner.get()))
        self.v_over = tk.BooleanVar(value=False)
        for r, (lab, var, w) in enumerate((("Klucz zestawu (kod w bazie, max 32 znaki)", self.v_key, 26),
                                           ("Nazwa na liście", self.v_run, 36), ("Właściciel wpisu", self.v_owner, 14)), 1):
            ttk.Label(f, text=lab).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 16))
            en = ttk.Entry(f, textvariable=var, width=w)
            en.grid(row=r, column=1, sticky="w", pady=4)
            self.entries[r] = en
            var.trace_add("write", lambda *a: self.schedule())
        ttk.Checkbutton(f, text="Nadpisz istniejące MOJE wpisy o tym kluczu", variable=self.v_over,
                        command=self.schedule).grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 8))
        fr, self.tr = make_tree(f, ("Klasa", "Ø", "Skład", "Status"), (80, 60, 360, 260), 8, sort=True, filt=True)
        fr.grid(row=5, column=0, columnspan=3, sticky="nsew")
        self.tr.tag_configure("ok", foreground="#0a6a0a")
        self.tr.tag_configure("skip", foreground="#b36b00")
        f.rowconfigure(5, weight=1)
        self.var_sum = tk.StringVar()
        ttk.Label(f, textvariable=self.var_sum, style="Hint.TLabel", wraplength=900).grid(
            row=6, column=0, columnspan=3, sticky="w", pady=(6, 0))
        self.var_hint = tk.StringVar()
        ttk.Label(f, textvariable=self.var_hint, style="Err.TLabel", wraplength=900).grid(
            row=7, column=0, columnspan=3, sticky="w")

    def enter3(self):
        wk = getattr(self, "want_key", None)
        if wk and not self.v_key.get().strip():              # zmiana własnego zestawu: klucz i nazwa z katalogu, nadpisanie włączone
            self.v_key.set(wk[0])
            self.v_run.set(wk[1] or wk[0])
            self.v_over.set(bool(wk[2]))
        self.refresh_summary()

    def schedule(self):
        if self.job:
            self.after_cancel(self.job)
        self.job = self.after(250, self.refresh_summary)

    def apply_to_app(self):
        """Przenosi wybór do (ukrytej) zakładki 'Zestawy śrub', której podgląd i zapis są już sprawdzone."""
        a = self.app
        std = self.std_key()
        i = next(k for k, s in enumerate(a.stds) if s[0] == std)
        a.cb_std.set(a.std_vals[i])
        a.cb_std._last = i
        a.on_std()
        a.lb_mat.selection_clear(0, "end")
        for m in self.sel_mats():
            if m in a.mat_vals:
                a.lb_mat.selection_set(a.mat_vals.index(m))
        a.refresh_diameters(reset=True)
        a.lb_dia.selection_clear(0, "end")
        for d in self.sel_dias():
            if d in a.dia_vals:
                a.lb_dia.selection_set(a.dia_vals.index(d))
        a.refresh_pdia()
        a.head_items, a.nut_items = [dict(c) for c in self.editor.head], [dict(c) for c in self.editor.nut]
        key = self.v_key.get().strip()
        a.cb_set.set(key)
        a.var_run.set(self.v_run.get().strip() or key)
        a.var_owner.set(self.v_owner.get().strip())
        a.var_over.set(self.v_over.get())
        a.on_pdia()

    def refresh_summary(self):
        self.job = None
        self.tr.delete(*self.tr.get_children())
        key = self.v_key.get().strip()
        if not key:
            self.var_sum.set("")
            self.var_story.set(T("Wpisz klucz zestawu, aby zobaczyć, co zostanie zapisane."))
            self.var_hint.set(T("Wpisz klucz zestawu."))
            return
        self.apply_to_app()
        rows = self.app.preview(silent=True)
        codes_by_row = [c for c, _ in (rows or [])]
        for k, iid in enumerate(self.app.tr_prev.get_children()):
            v = self.app.tr_prev.item(iid, "values")
            c = codes_by_row[k] if k < len(codes_by_row) else ""
            self.tr.insert("", "end", tags=("ok" if c in ("new", "over") else "skip",), values=(v[2], v[3], v[4], v[5]))
        self.var_sum.set(self.app.var_prevsum.get())
        self.var_hint.set(self.app.var_prevhint.get())
        codes = [c for c, _ in (rows or [])]
        n_new, n_over = codes.count("new"), codes.count("over")
        self.var_story.set(T("Powstanie zestaw '%s' dla %d kombinacji klasa × średnica (norma %s)%s. Istniejące zestawy i wpisy fabryczne "
                             "zostają bez zmian.") % (key, n_new + n_over, self.std_key(),
                                                      T(", w tym %d nadpisanych Twoich wpisów") % n_over if n_over else "")
                           if n_new + n_over else T("Nic nie zostanie zapisane - zobacz kolumnę Status."))

    def leave3(self):
        key, owner = self.v_key.get().strip(), self.v_owner.get().strip()
        if not key or len(key) > 32:
            return "Klucz zestawu: wymagany, max 32 znaki.", self.entries[1]
        if not owner or len(owner) > 15 or not is_own(owner):
            return "Właściciel: max 15 znaków, nie DSC/AUTODESK.", self.entries[3]
        self.apply_to_app()
        rows = self.app.preview(silent=True)
        if not rows or not any(c in ("new", "over") for c, _ in rows):
            return "Nic nie zostanie zapisane - zobacz kolumnę Status."

    def finish(self):
        remember("owner", self.v_owner.get().strip())
        self.apply_to_app()
        if self.app.save_set():
            self.destroy()
