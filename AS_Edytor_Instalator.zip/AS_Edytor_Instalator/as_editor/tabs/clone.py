# -*- coding: utf-8 -*-
"""Zakładka Śruby -> Kopia normy (szybka)."""
from as_editor.common import clone_sql, fmt_dia, in_clause, is_own
from as_editor.config import DEFAULT_OWNER
from as_editor.ui.widgets import make_list, messagebox, tk, ttk


class CloneMixin:
    # ------------------------------------------------------------------ kopia normy
    def build_clone(self):
        f = self.tab_clone
        left = ttk.Frame(f)
        left.pack(side="left", fill="y", padx=8, pady=6)
        ttk.Label(left, text="Norma źródłowa").pack(anchor="w")
        self.cb_src = ttk.Combobox(left, width=44, state="readonly")
        self.cb_src.pack(anchor="w")
        self.cb_src.bind("<<ComboboxSelected>>", self.on_src)
        self.v_newkey, self.v_newrun = tk.StringVar(), tk.StringVar()
        self.v_cowner = tk.StringVar(value=DEFAULT_OWNER)
        self.v_find, self.v_repl = tk.StringVar(), tk.StringVar()
        for lab, var in (("Kod nowej normy (max 64 znaki)", self.v_newkey),
                         ("Nowa nazwa normy na liście", self.v_newrun),
                         ("Właściciel wpisu (max 15 znaków)", self.v_cowner),
                         ("W nazwach śrub zamień: znajdź", self.v_find),
                         ("                                    na", self.v_repl)):
            ttk.Label(left, text=lab).pack(anchor="w", pady=(6, 0))
            ttk.Entry(left, textvariable=var, width=46).pack(anchor="w")
        self.v_copysets = tk.BooleanVar(value=True)
        ttk.Checkbutton(left, text="Kopiuj też zestawy śrub z normy źródłowej",
                        variable=self.v_copysets).pack(anchor="w", pady=8)
        ttk.Button(left, text="Klonuj normę", command=self.do_clone).pack(anchor="w")
        mid = ttk.Frame(f)
        mid.pack(side="left", padx=10, pady=6, anchor="n")
        ttk.Label(mid, text="Klasy do skopiowania").pack(anchor="w")
        fr, self.lb_cmat = make_list(mid, 8, 18)
        fr.pack()
        right = ttk.Frame(f)
        right.pack(side="left", padx=10, pady=6, anchor="n")
        ttk.Label(right, text="Średnice do skopiowania").pack(anchor="w")
        fr, self.lb_cdia = make_list(right, 14, 18)
        fr.pack()
        self.cmat_vals, self.cdia_vals = [], []
        self.lb_cmat.bind("<<ListboxSelect>>", lambda e: self.refresh_cdia())

    def on_src(self, _=None):
        i = self.cb_src.current()
        if i < 0:
            return
        std = self.stds[i][0]
        self.cmat_vals = self.db.bolt_materials(std)
        self.lb_cmat.delete(0, "end")
        for m in self.cmat_vals:
            self.lb_cmat.insert("end", m)
            self.lb_cmat.selection_set("end")
        self.refresh_cdia(reset=True)
        self.v_newkey.set(std + "-MOJA")
        self.v_newrun.set((self.stds[i][1] or std) + " (moja)")

    def refresh_cdia(self, reset=False):
        i = self.cb_src.current()
        if i < 0:
            return
        mats = [self.cmat_vals[k] for k in self.lb_cmat.curselection()]
        old = [] if reset else [self.cdia_vals[k] for k in self.lb_cdia.curselection()]
        self.cdia_vals = self.db.bolt_diameters(self.stds[i][0], mats)
        self.lb_cdia.delete(0, "end")
        for d in self.cdia_vals:
            self.lb_cdia.insert("end", "Ø " + fmt_dia(d))
        sel = [k for k, d in enumerate(self.cdia_vals) if d in old]
        for k in (sel or range(len(self.cdia_vals))):
            self.lb_cdia.selection_set(k)

    def do_clone(self):
        if not self.need_db():
            return
        i = self.cb_src.current()
        newkey, newrun, owner = self.v_newkey.get().strip(), self.v_newrun.get().strip(), self.v_cowner.get().strip()
        mats = [self.cmat_vals[k] for k in self.lb_cmat.curselection()]
        dias = [self.cdia_vals[k] for k in self.lb_cdia.curselection()]
        errs = []
        if i < 0:
            errs.append("Wybierz normę źródłową.")
        if not newkey or len(newkey) > 64:
            errs.append("Nowy klucz: wymagany, max 64 znaki.")
        if newkey in [s[0] for s in self.stds]:
            errs.append("Norma o kluczu '%s' już istnieje." % newkey)
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        if not mats or not dias:
            errs.append("Zaznacz klasy i średnice.")
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return
        src = self.stds[i][0]
        cm, pm = in_clause("Material", mats)
        cd, pd = in_clause("Diameter", dias)
        where = "[Standard]=? AND %s AND %s" % (cm, cd)
        wparams = [src] + pm + pd
        n_bolts = self.db.rows("SELECT COUNT(*) FROM [SetBolts] WHERE " + where, wparams)[0][0]
        n_sets = self.db.rows("SELECT COUNT(*) FROM [SetOfBolts] WHERE " + where, wparams)[0][0] if self.v_copysets.get() else 0
        if not messagebox.askyesno("Potwierdź", "Utworzyć normę '%s' jako kopię '%s'?\n\nWymiary śrub: %d wierszy\nZestawy śrub: %d wierszy"
                                   % (newkey, src, n_bolts, n_sets)):
            return
        if not self.backup_before_write():
            return
        find, repl = self.v_find.get(), self.v_repl.get()

        def fn(cur):
            c = self.db.columns("Standard")
            sql, p = clone_sql("Standard", c, {"Key": newkey, "RunName": (newrun or newkey)[:64], "OwnerText": owner},
                               "[Key]=?", [src])
            cur.execute(sql, p)
            c = self.db.columns("SetBolts")
            sql, p = clone_sql("SetBolts", c, {"Standard": newkey, "OwnerText": owner}, where, wparams,
                               {"Name": (find, repl)} if find else None)
            cur.execute(sql, p)
            if self.v_copysets.get():
                c = self.db.columns("SetOfBolts")
                sql, p = clone_sql("SetOfBolts", c, {"Standard": newkey, "OwnerText": owner}, where, wparams)
                cur.execute(sql, p)
        try:
            self.db.write(fn)
        except Exception as e:
            messagebox.showerror("Błąd zapisu (zmiany wycofane)", str(e))
            return
        self.reload()
        self.reload_browsers()
        messagebox.showinfo("Gotowe", "Utworzono normę '%s'.\nUruchom ponownie Advance Steel / Management Tools." % newkey)
