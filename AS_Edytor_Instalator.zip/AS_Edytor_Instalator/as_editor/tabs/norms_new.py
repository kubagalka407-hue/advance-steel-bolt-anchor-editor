# -*- coding: utf-8 -*-
"""Zakładka Śruby -> Normy i klasy: nowa norma śruby."""
from as_editor.bolts_logic import bolt_weight, compress_lengths, parse_lengths, remap_set_row
from as_editor.common import clone_sql, fmt_dia, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER
from as_editor.ui.widgets import make_list, make_tree, messagebox, simpledialog, tk, ttk


class NormsNewMixin:
    # --- 2. nowa norma śruby ---
    def build_new_norm(self):
        f = self.sub_new
        left = ttk.Frame(f)
        left.pack(side="left", fill="y", padx=8, pady=6)
        ttk.Label(left, text="Wzorzec - norma śruby (stąd wymiary łba i długości)").pack(anchor="w")
        self.cb_nbstd = ttk.Combobox(left, width=46, state="readonly")
        self.cb_nbstd.pack(anchor="w")
        self.cb_nbstd.bind("<<ComboboxSelected>>", self.nb_on_std)
        ttk.Label(left, text="Wzorzec - klasa").pack(anchor="w", pady=(6, 0))
        self.cb_nbmat = ttk.Combobox(left, width=22, state="readonly")
        self.cb_nbmat.pack(anchor="w")
        ttk.Button(left, text="Wczytaj wzorzec do tabeli", command=self.nb_load).pack(anchor="w", pady=6)
        self.v_nbkey, self.v_nbrun, self.v_nbsrc = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.v_nbown = tk.StringVar(value=DEFAULT_OWNER)
        for lab, var in (("Kod nowej normy (max 64 znaki)", self.v_nbkey),
                         ("Nazwa normy na liście", self.v_nbrun),
                         ("Źródło / norma (max 15 znaków)", self.v_nbsrc),
                         ("Właściciel wpisu (max 15 znaków)", self.v_nbown)):
            ttk.Label(left, text=lab).pack(anchor="w", pady=(6, 0))
            ttk.Entry(left, textvariable=var, width=48).pack(anchor="w")
        right = ttk.Frame(f)
        right.pack(side="left", fill="both", expand=True, padx=8, pady=6)
        ttk.Label(right, text="Wymiary dla każdej średnicy (dwuklik w komórkę = edycja). Długości: lista lub "
                              "zakresy, np.  40-100/5, 120, 140-200/20").pack(anchor="w")
        fr, self.tr_nb = make_tree(right, ("Ø", "Ø łba", "Wys. łba", "Kr.", "Długości"), (60, 80, 80, 50, 520), 13)
        fr.pack(fill="both", expand=True)
        self.tr_nb.bind("<Double-1>", self.nb_edit)
        bottom = ttk.Frame(right)
        bottom.pack(fill="x", pady=6)
        c1 = ttk.Frame(bottom)
        c1.pack(side="left", padx=(0, 14))
        ttk.Label(c1, text="Klasy nowej normy (wielokrotny wybór)").pack(anchor="w")
        fr, self.lb_nbcls = make_list(c1, 7, 30)
        fr.pack(anchor="w")
        c2 = ttk.Frame(bottom)
        c2.pack(side="left", fill="x", expand=True)
        self.cb_nbset = ttk.Combobox(c2, width=30)
        self.v_nbname = tk.StringVar(value="{run} M{d} x {L} - {class}")
        self.v_nbauto, self.v_nbsets = tk.BooleanVar(value=True), tk.BooleanVar(value=True)
        ttk.Label(c2, text="Domyślny zestaw normy").pack(anchor="w")
        self.cb_nbset.pack(anchor="w")
        ttk.Label(c2, text="Wzór nazwy śruby ({run} {d} {L} {class})").pack(anchor="w", pady=(6, 0))
        ttk.Entry(c2, textvariable=self.v_nbname, width=44).pack(anchor="w")
        ttk.Checkbutton(c2, text="Długość dobierana automatycznie",
                        variable=self.v_nbauto).pack(anchor="w", pady=(6, 0))
        ttk.Checkbutton(c2, text="Utwórz od razu zestawy skopiowane ze wzorca",
                        variable=self.v_nbsets).pack(anchor="w")
        ttk.Button(c2, text="Utwórz normę", command=self.nb_save).pack(anchor="e", pady=6)

    def nb_on_std(self, _=None):
        i = self.cb_nbstd.current()
        if i < 0:
            return
        std = self.stds[i][0]
        mats = self.db.bolt_materials(std)
        self.cb_nbmat["values"] = mats
        if mats:
            self.cb_nbmat.current(0)
        if self.stds[i][3] and not self.cb_nbset.get():
            self.cb_nbset.set(self.stds[i][3])
        if not self.v_nbkey.get():
            self.v_nbkey.set(std + "-MOJA")
            self.v_nbrun.set((self.stds[i][1] or std) + " (moja)")
        if not self.v_nbsrc.get():
            self.v_nbsrc.set(std[:15])

    def nb_load(self):
        if not self.need_db():
            return
        i, mat = self.cb_nbstd.current(), self.cb_nbmat.get()
        if i < 0 or not mat:
            messagebox.showinfo("Wzorzec", "Wybierz normę i klasę wzorca.")
            return
        rows, cols = self.db.bolt_rows(self.stds[i][0], mat)
        by = {}
        for r in rows:
            d = dict(zip(cols, r))
            by.setdefault(float(d["Diameter"]), []).append(d)
        self.nb_rows = []
        for dia in sorted(by):
            lst = by[dia]
            first = lst[0]
            self.nb_rows.append({
                "dia": dia, "tpl": first,
                "head_od": first.get("ScrewHeadOuterDiameter") or 0.0, "head_h": first.get("HeadHeight") or 0.0,
                "corners": first.get("NumberOfCorners") or 0,
                "lens": compress_lengths([float(x["Length"]) for x in lst]),
                "pts": [(float(x["Length"]), x.get("Weight")) for x in lst]})
        self.nb_refresh()

    def nb_refresh(self):
        self.tr_nb.delete(*self.tr_nb.get_children())
        for i, r in enumerate(self.nb_rows):
            self.tr_nb.insert("", "end", iid=str(i), values=(
                fmt_dia(r["dia"]), r["head_od"], r["head_h"], r["corners"], r["lens"]))

    def nb_edit(self, event):
        iid = self.tr_nb.identify_row(event.y)
        col = self.tr_nb.identify_column(event.x)
        if not iid or col not in ("#2", "#3", "#4", "#5"):
            return
        r = self.nb_rows[int(iid)]
        key = {"#2": "head_od", "#3": "head_h", "#4": "corners", "#5": "lens"}[col]
        val = simpledialog.askstring("Edycja", "Nowa wartość:", initialvalue=str(r[key]), parent=self.root)
        if val is None:
            return
        try:
            if key == "lens":
                parse_lengths(val)
                r[key] = val
            elif key == "corners":
                r[key] = int(val)
            else:
                r[key] = float(val.replace(",", "."))
        except ValueError as e:
            messagebox.showwarning("Wartość", str(e) or "Podaj liczbę.")
            return
        self.nb_refresh()

    def nb_save(self):
        if not self.need_db():
            return
        ti, tmat = self.cb_nbstd.current(), self.cb_nbmat.get()
        key, run = self.v_nbkey.get().strip(), self.v_nbrun.get().strip()
        src, owner = self.v_nbsrc.get().strip(), self.v_nbown.get().strip()
        setkey = self.cb_nbset.get().strip()
        classes = [self.cls_rows[i][0] for i in self.lb_nbcls.curselection()]
        cls_run = {r[0]: (r[1] or r[0]) for r in self.cls_rows}
        sel = [int(i) for i in self.tr_nb.selection()] or list(range(len(self.nb_rows)))
        errs = []
        if ti < 0 or not self.nb_rows:
            errs.append("Wybierz wzorzec i kliknij 'Wczytaj wzorzec do tabeli'.")
        if not key or len(key) > 64:
            errs.append("Klucz normy: wymagany, max 64 znaki.")
        if key.lower() in [x[0].lower() for x in self.stds]:
            errs.append("Norma o kluczu '%s' już istnieje." % key)
        if len(src) > 15:
            errs.append("Źródło: max 15 znaków.")
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        if not classes:
            errs.append("Zaznacz co najmniej jedną klasę nowej normy.")
        bolts = []
        if not errs:
            pattern = self.v_nbname.get() or "{run} M{d} x {L} - {class}"
            try:
                for idx in sel:
                    rr = self.nb_rows[idx]
                    for cls in classes:
                        for L in parse_lengths(rr["lens"]):
                            row = dict(rr["tpl"])
                            name = (pattern.replace("{run}", run or key).replace("{d}", fmt_dia(rr["dia"]))
                                    .replace("{L}", fmt_dia(L)).replace("{class}", cls_run.get(cls, cls)))
                            row.update({"Standard": key, "Material": cls, "Diameter": rr["dia"], "Length": L,
                                        "ScrewHeadOuterDiameter": rr["head_od"], "HeadHeight": rr["head_h"],
                                        "NumberOfCorners": rr["corners"], "Name": name[:255],
                                        "Weight": bolt_weight(rr["pts"], rr["dia"], L),
                                        "OwnerText": owner[:15], "Source": src[:15]})
                            bolts.append(row)
            except ValueError as e:
                errs.append(str(e))
            if not errs and not bolts:
                errs.append("Brak długości do utworzenia.")
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return
        tpl_std = self.stds[ti][0]
        dias = [self.nb_rows[i]["dia"] for i in sel]
        set_new = []
        if self.v_nbsets.get():
            rows, cols = self.db.set_rows(tpl_std, tmat, dias)
            for r in rows:
                d = dict(zip(cols, r))
                for cls in classes:
                    nr = remap_set_row(d, key, cls, owner, {})
                    if src:
                        nr["Source"] = src[:15]
                    set_new.append(nr)
        if not messagebox.askyesno("Potwierdź", "Utworzyć normę '%s' (wzorzec %s / %s)?\n\nWymiary śrub: %d wierszy\n"
                                   "Zestawy śrub: %d wierszy\nKlasy: %s" % (key, tpl_std, tmat, len(bolts),
                                                                            len(set_new), ", ".join(classes))):
            return
        if not self.backup_before_write():
            return
        ov = {"Key": key, "RunName": (run or key)[:64], "OwnerText": owner,
              "AutoLengthCalc": 1 if self.v_nbauto.get() else 0}
        if setkey:
            ov["StandardSet"] = setkey[:64]

        def fn(cur):
            sql, p = clone_sql("Standard", self.db.columns("Standard"), ov, "[Key]=?", [tpl_std])
            cur.execute(sql, p)
            for r in bolts:
                cur.execute(*insert_sql("SetBolts", r))
            for r in set_new:
                cur.execute(*insert_sql("SetOfBolts", r))
        if self.write_or_report(fn):
            self.reload()
            messagebox.showinfo("Gotowe", "Utworzono normę '%s'.\nZestawy dopracujesz w zakładce 'Zestaw śrub'. "
                                          "Uruchom ponownie Advance Steel / Management Tools." % key)
