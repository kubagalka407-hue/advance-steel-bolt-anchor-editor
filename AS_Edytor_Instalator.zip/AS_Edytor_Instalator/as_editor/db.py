# -*- coding: utf-8 -*-
"""Dostęp do bazy AstorBase (SQL Server LocalDB): połączenie, kopie zapasowe, zapytania, zapis w transakcji."""
import datetime
import os
import re
import subprocess
from as_editor.common import fmt_dia, in_clause, q
from as_editor.config import BACKUP_DIR, MAX_ITEMS, pyodbc
from as_editor.i18n import T


class DB:
    def __init__(self):
        self.conn = None
        self.server = None
        self.dbname = None
        self.lang = None
        self.drv = None
        self.backed_up = False
        self.cache = {}
        self.on_write = None      # wywoływane po udanym zapisie (pasek stanu w oknie głównym)

    @staticmethod
    def instances():
        try:
            out = subprocess.run(["sqllocaldb", "i"], capture_output=True, text=True, timeout=20).stdout
            return [l.strip() for l in out.splitlines() if l.strip()]
        except Exception:
            return []

    def _driver(self):
        if pyodbc is None:
            raise RuntimeError("Brak modułu pyodbc  ->  pip install pyodbc")
        d = [x for x in pyodbc.drivers() if "SQL Server" in x]
        d.sort(key=lambda x: ("18" in x, "17" in x), reverse=True)
        if not d:
            raise RuntimeError("Brak sterownika ODBC dla SQL Server (zainstaluj ODBC Driver 17/18).")
        return d[0]

    def _cs(self, server, database):
        return ("DRIVER={%s};SERVER=%s;DATABASE={%s};Trusted_Connection=yes;"
                "TrustServerCertificate=yes;Encrypt=no;" % (self.drv, server, database))

    def _astorbases(self, server):
        self.drv = self._driver()
        con = pyodbc.connect(self._cs(server, "master"), timeout=15)
        cur = con.cursor()
        cur.execute("SELECT d.name, mf.physical_name FROM sys.master_files mf "
                    "JOIN sys.databases d ON d.database_id=mf.database_id "
                    "WHERE mf.type=0 AND d.database_id>4")
        rows = [(r[0], r[1]) for r in cur.fetchall()]
        con.close()
        out = []
        for name, phys in rows:
            if os.path.basename(phys or "").lower() == "astorbase.mdf":
                m = re.search(r"\\([A-Za-z]{3})\\Steel\\Data\\", phys)
                out.append((m.group(1).upper() if m else "?", name, phys))
        return out

    def languages(self, server):
        return sorted(set(l for l, _, _ in self._astorbases(server)))

    def connect(self, server, lang):
        found = [(n, p) for l, n, p in self._astorbases(server) if l == lang]
        if not found:
            raise RuntimeError("Nie znaleziono podłączonej bazy AstorBase dla wersji %s.\n"
                               "Uruchom Advance Steel (lub Management Tools) w tej wersji i spróbuj ponownie." % lang)
        self.close()
        self.server, self.lang, self.dbname = server, lang, found[0][0]
        self.conn = pyodbc.connect(self._cs(server, self.dbname), autocommit=True, timeout=15)
        self.backed_up = False
        self.cache = {}

    def close(self):
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
        self.conn = None

    # --- odczyt ---
    def query(self, sql, params=()):
        cur = self.conn.cursor()
        cur.execute(sql, list(params))
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = [tuple(r) for r in cur.fetchall()] if cur.description else []
        return rows, cols

    def rows(self, sql, params=()):
        return self.query(sql, params)[0]

    def columns(self, table):
        return [r[0] for r in self.rows(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=? ORDER BY ORDINAL_POSITION",
            (table,))]

    def pk_columns(self, table):
        return [r[0] for r in self.rows(
            "SELECT k.COLUMN_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS c "
            "JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k ON c.CONSTRAINT_NAME=k.CONSTRAINT_NAME "
            "WHERE c.CONSTRAINT_TYPE='PRIMARY KEY' AND c.TABLE_NAME=? ORDER BY k.ORDINAL_POSITION", (table,))]

    def tables(self):
        return [r[0] for r in self.rows(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY 1")]

    def standards(self):
        return self.rows("SELECT [Key],[RunName],[AutoLengthCalc],[StandardSet],[OwnerText] "
                         "FROM [Standard] ORDER BY [Key]")

    def sets(self):
        return self.rows("SELECT [Key],[RunName],[OwnerText] FROM [Sets] ORDER BY [Key]")

    def bolt_materials(self, std):
        return [r[0] for r in self.rows(
            "SELECT DISTINCT [Material] FROM [SetBolts] WHERE [Standard]=? ORDER BY 1", (std,))]

    def bolt_diameters(self, std, mats=None):
        sql, params = "SELECT DISTINCT [Diameter] FROM [SetBolts] WHERE [Standard]=?", [std]
        if mats:
            c, p = in_clause("Material", mats)
            sql += " AND " + c
            params += p
        return [r[0] for r in self.rows(sql + " ORDER BY 1", params)]

    def bolt_exists(self, std, mat, dia):
        k = ("bolt", std, mat, round(dia, 4))
        if k not in self.cache:
            self.cache[k] = bool(self.rows(
                "SELECT TOP 1 1 FROM [SetBolts] WHERE [Standard]=? AND [Material]=? AND ABS([Diameter]-?)<0.0001",
                (std, mat, dia)))
        return self.cache[k]

    def bolt_head(self, std, mat, dia):
        """(średnica łba, wysokość łba) z SetBolts albo None."""
        k = ("head", std, mat, round(dia, 4))
        if k not in self.cache:
            r = self.rows("SELECT TOP 1 [ScrewHeadOuterDiameter],[HeadHeight] FROM [SetBolts] "
                          "WHERE [Standard]=? AND [Material]=? AND ABS([Diameter]-?)<0.0001 ORDER BY [Length]",
                          (std, mat, dia))
            self.cache[k] = r[0] if r else None
        return self.cache[k]

    def bolt_lengths(self, std, mat, dia):
        k = ("lens", std, mat, round(dia, 4))
        if k not in self.cache:
            self.cache[k] = [r[0] for r in self.rows(
                "SELECT DISTINCT [Length] FROM [SetBolts] WHERE [Standard]=? AND [Material]=? "
                "AND ABS([Diameter]-?)<0.0001 ORDER BY 1", (std, mat, dia))]
        return self.cache[k]

    def nut_standards(self, kind=None):
        where = ""
        if kind == "washer":
            where = "WHERE ISNULL(n.[NumberOfCorners],0)=0 "
        elif kind == "nut":
            where = "WHERE ISNULL(n.[NumberOfCorners],0)>0 "
        return self.rows("SELECT DISTINCT n.[Standard], ISNULL(s.[RunName], n.[Standard]) "
                         "FROM [SetNutsBolts] n LEFT JOIN [StandardNuts] s ON s.[ID]=n.[Standard] "
                         + where + "ORDER BY 1")

    def nut_materials(self, std):
        return [r[0] for r in self.rows(
            "SELECT DISTINCT [Material] FROM [SetNutsBolts] WHERE [Standard]=? ORDER BY 1", (std,))]

    def nut_rows(self, std, mat):
        return self.query("SELECT * FROM [SetNutsBolts] WHERE [Standard]=? AND [Material]=? ORDER BY [Diameter]",
                          (std, mat))

    def nut_item(self, std, mat, dia):
        k = ("nut", std, mat, round(dia, 4))
        if k not in self.cache:
            r = self.rows("SELECT TOP 1 [Height],[NumberOfCorners],[OutsideDiameter],[Name],[Type],[Weight] "
                          "FROM [SetNutsBolts] WHERE [Standard]=? AND [Material]=? AND ABS([Diameter]-?)<0.0001",
                          (std, mat, dia))
            self.cache[k] = r[0] if r else None
        return self.cache[k]

    def classes(self):
        return self.rows("SELECT [Key],[RunName],[OwnerText] FROM [StrengthClass] ORDER BY [Key]")

    def bolt_rows(self, std, mat):
        return self.query("SELECT * FROM [SetBolts] WHERE [Standard]=? AND [Material]=? "
                          "ORDER BY [Diameter],[Length]", (std, mat))

    def set_rows(self, std, mat, dias=None):
        sql, params = "SELECT * FROM [SetOfBolts] WHERE [Standard]=? AND [Material]=?", [std, mat]
        if dias:
            c, p = in_clause("Diameter", dias)
            sql += " AND " + c
            params += p
        return self.query(sql + " ORDER BY [Set],[Diameter]", params)

    def set_component_pairs(self, std, mat):
        """Unikalne elementy (norma, klasa) używane w zestawach danej normy i klasy śruby."""
        parts = ["SELECT [DIN%d] d,[Material%d] m,[Position%d] p FROM [SetOfBolts] WHERE [Standard]=? AND [Material]=?"
                 % (k, k, k) for k in range(1, MAX_ITEMS + 1)]
        sql = ("SELECT DISTINCT d,m FROM (" + " UNION ALL ".join(parts) + ") t "
               "WHERE ISNULL(p,0)<>0 AND d IS NOT NULL AND d NOT IN ('-','') ORDER BY d,m")
        return self.rows(sql, [std, mat] * MAX_ITEMS)

    def count(self, table, where, params=()):
        return self.rows("SELECT COUNT(*) FROM %s WHERE %s" % (q(table), where), params)[0][0]

    def set_materials(self, std):
        return [r[0] for r in self.rows("SELECT DISTINCT [Material] FROM [SetOfBolts] WHERE [Standard]=? ORDER BY 1", (std,))]

    # --- kotwy ---
    def anchor_standards(self):
        return self.rows("SELECT [Key],[RunName],[OwnerText] FROM [AnchorsStandard] ORDER BY [Key]")

    def anchor_std_types(self):
        """{norma kotwy: zbiór typów (ClassID) kotew, które w niej są} - do filtrowania listy norm po typie."""
        out = {}
        for std, cid in self.rows("SELECT DISTINCT [Standard],[ClassID] FROM [AnchorsName]"):
            out.setdefault(std, set()).add(cid)
        return out

    def anchor_std_mats(self):
        """{norma kotwy: zbiór klas materiału (MaterialKey)} - do filtrowania listy norm po klasie."""
        out = {}
        for std, mat in self.rows("SELECT DISTINCT [Standard],[MaterialKey] FROM [AnchorsName]"):
            out.setdefault(std, set()).add(mat)
        return out

    def anchor_types(self):
        return self.rows("SELECT [ID],[RunName] FROM [AnchorsClass] ORDER BY [ID]")

    def sources(self):
        return self.rows("SELECT [Short],[Long] FROM [Sources] ORDER BY [Short]")

    def all_diameters(self):
        return self.rows("SELECT [Key],[RunName] FROM [BoltsDiameters] ORDER BY [Key]")

    def max_id(self, table, col="ID"):
        return self.rows("SELECT ISNULL(MAX(%s),0) FROM %s" % (q(col), q(table)))[0][0]

    def anchor_materials(self, std):
        return [r[0] for r in self.rows("SELECT DISTINCT [MaterialKey] FROM [AnchorsName] WHERE [Standard]=? ORDER BY 1", (std,))]

    def anchor_set_names(self, std):
        """Zestawy (SetName, RunName) faktycznie używane przez kotwy danej normy."""
        return self.rows("SELECT DISTINCT n.[SetName], ISNULL(s.[RunName], n.[SetName]) FROM [AnchorsName] n "
                         "LEFT JOIN [Sets] s ON s.[Key]=n.[SetName] WHERE n.[Standard]=? ORDER BY 1", (std,))

    def anchor_diameters(self, std, mats=None):
        sql, params = "SELECT DISTINCT [Diameter] FROM [AnchorsName] WHERE [Standard]=?", [std]
        if mats:
            c, p = in_clause("MaterialKey", mats)
            sql += " AND " + c
            params += p
        return [r[0] for r in self.rows(sql + " ORDER BY 1", params)]

    def anchor_names(self, std, mats=None, dias=None, set_name=None):
        sql, params = "SELECT * FROM [AnchorsName] WHERE [Standard]=?", [std]
        if mats:
            c, p = in_clause("MaterialKey", mats)
            sql += " AND " + c
            params += p
        if dias:
            c, p = in_clause("Diameter", dias)
            sql += " AND " + c
            params += p
        if set_name:
            sql += " AND [SetName]=?"
            params.append(set_name)
        rows, cols = self.query(sql + " ORDER BY [Diameter],[MaterialKey],[ID]", params)
        return [dict(zip(cols, r)) for r in rows]

    def anchor_children(self, ids):
        """Definicje i otwory kotew o podanych ID -> ({id: [definicje]}, {id: otwór})."""
        defs, holes = {}, {}
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            c, p = in_clause("AnchorID", chunk)
            rows, cols = self.query("SELECT * FROM [AnchorsDefinition] WHERE " + c + " ORDER BY [AnchorID],[Length],[ID]", p)
            for r in rows:
                d = dict(zip(cols, r))
                defs.setdefault(d["AnchorID"], []).append(d)
            c, p = in_clause("AnchorNameID", chunk)
            rows, cols = self.query("SELECT * FROM [AnchorsHoleDefinition] WHERE " + c, p)
            for r in rows:
                d = dict(zip(cols, r))
                holes[d["AnchorNameID"]] = d
        return defs, holes

    def anchor_exists(self, std, mat, dia, set_name):
        r = self.rows("SELECT TOP 1 [ID],[OwnerText] FROM [AnchorsName] WHERE [Standard]=? AND [MaterialKey]=? "
                      "AND ABS([Diameter]-?)<0.0001 AND [SetName]=?", (std, mat, dia, set_name))
        return (r[0][0], r[0][1]) if r else None

    def anchor_component_pairs(self, std, mats=None):
        parts, params = [], []
        for k in range(1, MAX_ITEMS + 1):
            sql = ("SELECT [DIN%d] d,[Material%d] m,[Position%d] p FROM [AnchorsName] WHERE [Standard]=?" % (k, k, k))
            params.append(std)
            if mats:
                c, p = in_clause("MaterialKey", mats)
                sql += " AND " + c
                params += p
            parts.append(sql)
        sql = ("SELECT DISTINCT d,m FROM (" + " UNION ALL ".join(parts) + ") t "
               "WHERE ISNULL(p,0)<>0 AND d IS NOT NULL AND d NOT IN ('-','') ORDER BY d,m")
        return self.rows(sql, params)

    def nut_diameters(self, std, mat):
        k = ("nutdias", std, mat)
        if k not in self.cache:
            self.cache[k] = [float(r[0]) for r in self.rows(
                "SELECT DISTINCT [Diameter] FROM [SetNutsBolts] WHERE [Standard]=? AND [Material]=?", (std, mat))]
        return self.cache[k]

    def std_sets(self, std):
        """Zestawy (Set, RunName) faktycznie przypisane do normy śruby w SetOfBolts."""
        return self.rows("SELECT DISTINCT o.[Set], ISNULL(s.[RunName], o.[Set]) FROM [SetOfBolts] o "
                         "LEFT JOIN [Sets] s ON s.[Key]=o.[Set] WHERE o.[Standard]=? ORDER BY 1", (std,))

    def std_set_pairs(self, std, mats, dias):
        """Pary (Set, Material) istniejące w SetOfBolts dla normy, zaznaczonych klas i średnic (dokładnie te zestawy)."""
        if not mats or not dias:
            return []
        qm = ",".join("?" * len(mats))
        qd = ",".join("?" * len(dias))
        return [(r[0], r[1]) for r in self.rows(
            "SELECT DISTINCT [Set],[Material] FROM [SetOfBolts] WHERE [Standard]=? AND [Material] IN (%s) "
            "AND [Diameter] IN (%s) ORDER BY 1,2" % (qm, qd), (std, *mats, *dias))]

    def std_set_materials(self, std, set_key):
        return [r[0] for r in self.rows(
            "SELECT DISTINCT [Material] FROM [SetOfBolts] WHERE [Standard]=? AND [Set]=? ORDER BY 1", (std, set_key))]

    def nut_catalog(self, dia, kind):
        """Podkładki ('washer') lub nakrętki ('nut') dostępne dla średnicy dia."""
        k = ("cat", round(dia, 4), kind)
        if k not in self.cache:
            cond = "=0" if kind == "washer" else ">0"
            self.cache[k] = self.rows(
                "SELECT [Standard],[Material],[Height],[OutsideDiameter],[Name],[NumberOfCorners] FROM [SetNutsBolts] "
                "WHERE ABS([Diameter]-?)<0.0001 AND ISNULL([NumberOfCorners],0)" + cond +
                " ORDER BY [Standard],[Material]", (dia,))
        return self.cache[k]

    def describe(self, std, mat, dia):
        it = self.nut_item(std, mat, dia)
        if not it:
            return T("BRAK w bazie dla Ø%s") % fmt_dia(dia)
        kind = T("podkładka") if not it[1] else T("nakrętka (%s kr.)") % it[1]
        return T("%s: %s, wys. %s, Ø zewn. %s") % (kind, it[3], it[0], it[2])

    def nutstd_exists(self, key):
        return bool(self.rows("SELECT TOP 1 1 FROM [StandardNuts] WHERE [ID]=?", (key,)))

    def nutset_exists(self, std, mat):
        return bool(self.rows("SELECT TOP 1 1 FROM [SetNutsBolts] WHERE [Standard]=? AND [Material]=?", (std, mat)))

    def template(self, std):
        r = self.rows("SELECT TOP 1 [BindingLength],[Source] FROM [SetOfBolts] WHERE [Standard]=? ORDER BY [Diameter]", (std,))
        if r:
            return r[0][0], r[0][1]
        return 0.0, std

    def set_owner(self, std, set_key, mat, dia):
        r = self.rows("SELECT [OwnerText] FROM [SetOfBolts] WHERE [Standard]=? AND [Set]=? AND [Material]=? "
                      "AND ABS([Diameter]-?)<0.0001", (std, set_key, mat, dia))
        return (True, r[0][0]) if r else (False, None)

    # --- zapis ---
    def backup(self):
        os.makedirs(BACKUP_DIR, exist_ok=True)
        fn = os.path.join(BACKUP_DIR, "AstorBase_%s_%s.bak" % (
            self.lang, datetime.datetime.now().strftime("%Y%m%d_%H%M%S")))
        c = pyodbc.connect(self._cs(self.server, "master"), autocommit=True, timeout=30)
        cur = c.cursor()
        cur.execute("BACKUP DATABASE %s TO DISK = N'%s' WITH INIT, COPY_ONLY" % (q(self.dbname), fn.replace("'", "''")))
        while cur.nextset():
            pass
        c.close()
        return fn

    def ensure_backup(self):
        if self.backed_up:
            return None
        fn = self.backup()
        self.backed_up = True
        return fn

    def undo_last(self):
        """Cofa ostatni zapis z dziennika (tylko jeśli dało się go odwrócić). Zwraca opis albo rzuca wyjątek."""
        from as_editor import journal as J
        entries = J.load()
        if not entries:
            raise ValueError("Dziennik zapisów jest pusty.")
        e = entries[-1]
        self.write(lambda cur: J.undo_entry(cur, e), journal=False)
        J.save(entries[:-1])
        return e

    def write(self, fn, label=None, journal=True):
        """Jedyna droga zapisu: transakcja + dziennik zmian (journal.py) do cofania ostatniego zapisu."""
        from as_editor import journal as J
        self.conn.autocommit = False
        try:
            cur = self.conn.cursor()
            jc = J.JournalCursor(cur) if journal else cur
            fn(jc)
            self.conn.commit()
            if journal:
                e = jc.entry(label)
                if e:
                    J.save(J.load() + [e])
        except Exception:
            self.conn.rollback()
            raise
        finally:
            self.conn.autocommit = True
        self.cache = {}
        if self.on_write:
            try:
                self.on_write()
            except Exception:
                pass
