# -*- coding: utf-8 -*-
"""Numer kompilacji: widoczny w tytule okna i w Ustawieniach - po nim widać, czy działa najnowsza kopia programu.
Podbijaj przy każdej dostarczonej zmianie."""
BUILD = "8.6 (2026-11-05: angielski instalator, ikona kotwy)"
