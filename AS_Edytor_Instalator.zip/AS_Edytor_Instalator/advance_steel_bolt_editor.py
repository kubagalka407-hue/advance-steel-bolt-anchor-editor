# -*- coding: utf-8 -*-
"""Edytor śrub i kotew Advance Steel - punkt startowy.
Cały kod jest w pakiecie as_editor/ (patrz MODULY.md). Uruchomienie: python advance_steel_bolt_editor.py
(lub uruchom_edytor_srub.bat). Kontrola tłumaczeń: python advance_steel_bolt_editor.py --check-i18n"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from as_editor.main import main  # noqa: E402

if __name__ == "__main__":
    main()
