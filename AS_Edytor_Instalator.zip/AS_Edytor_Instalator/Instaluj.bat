@echo off
chcp 65001 >nul
title Instalator - Edytor srub i kotew Advance Steel
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalator.ps1"
