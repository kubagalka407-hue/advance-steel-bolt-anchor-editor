@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist "%~dp0advance_steel_bolt_editor.py" (
  echo File advance_steel_bolt_editor.py is missing from this folder.
  pause
  exit /b 1
)

set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY (
  echo Python not found - installing it with winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo Close this window and run this file again ^(Windows has to refresh its paths^).
  pause
  exit /b 0
)

%PY% -m pip install --quiet --upgrade pyodbc
if errorlevel 1 (
  echo Could not install pyodbc. Check your internet connection.
  pause
  exit /b 1
)

powershell -NoProfile -Command "if (Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) { exit 0 } else { exit 1 }"
if errorlevel 1 (
  echo ODBC Driver 17/18 not found - installing it with winget...
  winget install -e --id Microsoft.msodbcsql.18 --accept-package-agreements --accept-source-agreements
)

%PY% "%~dp0advance_steel_bolt_editor.py"
if errorlevel 1 (
  echo.
  echo The program ended with an error - please copy the message above.
  pause
)
