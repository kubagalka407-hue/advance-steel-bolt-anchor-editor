# -*- coding: utf-8 -*-
"""
Zrzut schematu baz Advance Steel (tylko odczyt - wykonuje wyłącznie SELECT).

Wymagania: Windows, pip install pyodbc, sterownik "ODBC Driver 17/18 for SQL Server".
Uruchomienie:   python as_schema_dump.py
Opcjonalnie:    python as_schema_dump.py "(LocalDB)\\ADVANCESTEEL2025"   (ręcznie podana instancja)
Wynik:          plik schemat_as.txt obok skryptu - wklej jego zawartość do rozmowy.
Zamknij najlepiej Advance Steel / Management Tools na czas zrzutu.
"""
import os
import sys
import glob
import re
import subprocess

try:
    import pyodbc
except ImportError:
    sys.exit("Brak pyodbc:  pip install pyodbc")

OUT = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "schemat_as.txt")
KEYWORDS = ("bolt", "set", "nut", "washer", "standard", "strength", "autolength",
            "anchor", "stud", "diameter", "length", "hole")
ROWS = 6          # ile przykładowych wierszy z każdej tabeli
MAXW = 60         # ucięcie długich wartości


def log(f, s=""):
    print(s)
    f.write(s + "\n")


def drivers():
    d = [x for x in pyodbc.drivers() if "SQL Server" in x]
    d.sort(key=lambda x: ("18" in x, "17" in x), reverse=True)
    return d


def instances():
    try:
        out = subprocess.run(["sqllocaldb", "i"], capture_output=True, text=True, timeout=20).stdout
        return [l.strip() for l in out.splitlines() if l.strip()]
    except Exception:
        return []


def connect(server, drv, db="master"):
    cs = ("DRIVER={%s};SERVER=%s;DATABASE={%s};Trusted_Connection=yes;"
          "TrustServerCertificate=yes;Encrypt=no;" % (drv, server, db))
    return pyodbc.connect(cs, timeout=15)


def short(v):
    s = repr(v) if not isinstance(v, str) else v
    return s if len(s) <= MAXW else s[:MAXW] + "..."


def dump_db(f, server, drv, dbname):
    log(f, "\n" + "=" * 90)
    log(f, "BAZA: %s   (serwer %s)" % (dbname, server))
    log(f, "=" * 90)
    con = connect(server, drv, dbname)
    cur = con.cursor()
    cur.execute("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY 1")
    tables = [r[0] for r in cur.fetchall()]
    log(f, "Liczba tabel: %d" % len(tables))
    log(f, "WSZYSTKIE TABELE: " + ", ".join(tables))
    for t in tables:
        if not any(k in t.lower() for k in KEYWORDS):
            continue
        log(f, "\n--- TABELA [%s] ---" % t)
        cur.execute("SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE, "
                    "COLUMNPROPERTY(OBJECT_ID(TABLE_SCHEMA+'.'+TABLE_NAME), COLUMN_NAME, 'IsIdentity') "
                    "FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=? ORDER BY ORDINAL_POSITION", t)
        cols = cur.fetchall()
        for c in cols:
            log(f, "  %-28s %-12s len=%s null=%s identity=%s" % (c[0], c[1], c[2], c[3], c[4]))
        cur.execute("""SELECT k.COLUMN_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS c
                       JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k ON c.CONSTRAINT_NAME=k.CONSTRAINT_NAME
                       WHERE c.CONSTRAINT_TYPE='PRIMARY KEY' AND c.TABLE_NAME=?""", t)
        log(f, "  KLUCZ GŁÓWNY: " + (", ".join(r[0] for r in cur.fetchall()) or "(brak)"))
        cur.execute("SELECT COUNT(*) FROM [%s]" % t)
        log(f, "  LICZBA WIERSZY: %d" % cur.fetchone()[0])
        names = [c[0] for c in cols]
        queries = [("pierwsze wiersze", "SELECT TOP %d * FROM [%s]" % (ROWS, t), [])]
        if "Set" in names:   # przykładowy zestaw NaW (nakrętka + podkładka) i MuS
            queries.append(("wiersze dla Set='NaW'", "SELECT TOP %d * FROM [%s] WHERE [Set]=?" % (ROWS, t), ["NaW"]))
        if "Standard" in names and t.lower() == "setofbolts":
            queries.append(("wiersze dla Standard='4014'", "SELECT TOP %d * FROM [%s] WHERE [Standard]=?" % (ROWS, t), ["4014"]))
        for title, q, p in queries:
            try:
                cur.execute(q, p)
                rows = cur.fetchall()
            except Exception as e:
                log(f, "  (%s: błąd %s)" % (title, e))
                continue
            log(f, "  [%s]  (%d)" % (title, len(rows)))
            hdr = [d[0] for d in cur.description]
            for r in rows:
                log(f, "   " + " | ".join("%s=%s" % (h, short(v)) for h, v in zip(hdr, r)))
    con.close()


def lang_of(phys):
    m = re.search(r"\\([A-Za-z]{3})\\(?:Steel|User2)\\Data\\", phys or "")
    return m.group(1).upper() if m else "?"


def scan_custom(f, srv, drv, name, lang):
    """Liczy wlasne (nie-AUTODESK) wpisy w Sets i SetOfBolts danej wersji krajowej."""
    total = 0
    try:
        con = connect(srv, drv, name)
        cur = con.cursor()
        for t in ("Sets", "SetOfBolts"):
            try:
                cur.execute("SELECT COUNT(*) FROM [%s] WHERE ISNULL(OwnerText,'')<>'AUTODESK'" % t)
                c = cur.fetchone()[0]
                total += c
                log(f, "  [%s] %s: wlasne wpisy (OwnerText inny niz AUTODESK) = %d" % (lang, t, c))
                if t == "Sets" and c:
                    cur.execute("SELECT TOP 20 [Key],[RunName],[OwnerText] FROM [Sets] "
                                "WHERE ISNULL(OwnerText,'')<>'AUTODESK'")
                    for r in cur.fetchall():
                        log(f, "      Sets: %s | %s | %s" % tuple(r))
            except Exception as e:
                log(f, "  [%s] %s: nie mozna odczytac (%s)" % (lang, t, str(e)[:80]))
        con.close()
    except Exception as e:
        log(f, "  [%s] blad polaczenia: %s" % (lang, str(e)[:100]))
    return total


def main():
    drvs = drivers()
    if not drvs:
        sys.exit("Brak sterownika ODBC dla SQL Server (zainstaluj 'ODBC Driver 17 for SQL Server').")
    drv = drvs[0]
    # argumenty (opcjonalne):  [instancja]  [kod_jezyka]   np.  "(LocalDB)\\AdvanceSteel2026" GBR
    server_arg = sys.argv[1] if len(sys.argv) > 1 else None
    lang_arg = sys.argv[2].upper() if len(sys.argv) > 2 else None  # domyslnie INT
    WANTED = ("astorbase.mdf", "astoraddin.mdf")
    with open(OUT, "w", encoding="utf-8") as f:
        log(f, "Sterownik: %s" % drv)
        inst = instances()
        log(f, "Instancje LocalDB: %s" % (inst or "(nie wykryto)"))
        xmls = glob.glob(r"C:\ProgramData\Autodesk\Advance Steel*\**\DatabaseConfiguration.xml", recursive=True)
        for p in xmls[:1]:
            log(f, "\n### %s" % p)
            try:
                log(f, open(p, encoding="utf-8", errors="replace").read()[:1500])
            except Exception as e:
                log(f, "(nie da sie odczytac: %s)" % e)

        servers = [server_arg] if server_arg else ["(LocalDB)\\%s" % i for i in inst if i.lower().startswith("advancesteel")]
        if not servers:
            servers = ["(LocalDB)\\MSSQLLocalDB"]
        done = False
        for srv in servers:
            log(f, "\n##### Serwer: %s" % srv)
            try:
                con = connect(srv, drv)
            except Exception as e:
                log(f, "Nie mozna polaczyc: %s" % e)
                continue
            cur = con.cursor()
            cur.execute("SELECT d.name, mf.physical_name FROM sys.master_files mf "
                        "JOIN sys.databases d ON d.database_id = mf.database_id "
                        "WHERE mf.type = 0 AND d.database_id > 4")
            dbs = [(r[0], r[1]) for r in cur.fetchall()]
            con.close()
            for name, phys in dbs:
                log(f, "Baza: %s  ->  %s" % (name, phys))

            # --- przeglad wersji krajowych: gdzie sa Twoje wlasne wpisy? ---
            log(f, "\n=== PRZEGLAD WERSJI KRAJOWYCH (AstorBase) ===")
            counts = {}
            for name, phys in dbs:
                if os.path.basename(phys or "").lower() == "astorbase.mdf":
                    lg = lang_of(phys)
                    counts[lg] = scan_custom(f, srv, drv, name, lg)
            pref = ["POL", "INT", "GBR", "DEU", "USA", "AUS"]
            lang = lang_arg or "INT"   # domyslnie wersja INT (mozna podac inny kod jako 2. argument)
            log(f, "\n>>> Wybrana wersja krajowa do pelnego zrzutu: %s  (liczba wlasnych wpisow: %s)" % (lang, counts))

            chosen = [(n, p) for n, p in dbs
                      if os.path.basename(p or "").lower() in WANTED and lang_of(p) == lang]
            for name, phys in chosen:
                try:
                    dump_db(f, srv, drv, name)
                    done = True
                except Exception as e:
                    log(f, "Blad zrzutu %s: %s" % (name, e))
        if not done:
            log(f, "\nNie udalo sie zrzucic AstorBase. Uruchom Advance Steel (lub Management Tools) "
                   "i sprobuj ponownie.")
    print("\nGotowe. Plik: %s" % OUT)


if __name__ == "__main__":
    main()
