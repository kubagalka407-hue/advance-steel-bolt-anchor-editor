@echo off
title Install - Advance Steel Bolt and Anchor Editor
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
