# -*- coding: utf-8 -*-
"""Przeglądarka tabel bazy (filtr, edycja i usuwanie własnych wierszy)."""
from as_editor.common import is_own, q
from as_editor.ui.widgets import make_tree, messagebox, tk, ttk


class TableBrowser:
    """Przeglądarka tabel bazy: podgląd, filtr i usuwanie własnych wierszy (osobna instancja dla Śrub i dla Kotew)."""

    def __init__(self, app, parent, default_table):
        self.app, self.default = app, default_table
        self.tr, self.cols, self.rows = None, [], []
        bar = ttk.Frame(parent)
        bar.pack(fill="x", pady=6, padx=6)
        ttk.Label(bar, text="Tabela:").pack(side="left")
        self.cb = ttk.Combobox(bar, width=34, state="readonly")
        self.cb.pack(side="left", padx=4)
        self.cb.bind("<<ComboboxSelected>>", lambda e: self.load())
        ttk.Label(bar, text="Filtr:").pack(side="left", padx=(10, 2))
        self.v_filter = tk.StringVar()
        self.v_filter.trace_add("write", lambda *a: self.fill())
        ttk.Entry(bar, textvariable=self.v_filter, width=26).pack(side="left")
        ttk.Button(bar, text="Odśwież", command=self.load).pack(side="left", padx=6)
        ttk.Button(bar, text="Usuń zaznaczone MOJE wiersze", command=self.delete_own).pack(side="left", padx=6)
        self.lbl = tk.StringVar()
        ttk.Label(bar, textvariable=self.lbl).pack(side="left", padx=10)
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True, padx=6)

    def refresh_tables(self):
        names = self.app.db.tables()
        self.cb["values"] = names
        if not self.cb.get() and self.default in names:
            self.cb.set(self.default)
            self.load()

    def reload(self):
        if self.cb.get():
            self.load()

    def load(self):
        if not self.app.need_db():
            return
        t = self.cb.get()
        if not t:
            return
        try:
            rows, cols = self.app.db.query("SELECT TOP 5000 * FROM %s" % q(t))
        except Exception as e:
            messagebox.showerror("Błąd", str(e))
            return
        self.cols, self.rows = cols, rows
        for w in self.frame.winfo_children():
            w.destroy()
        fr, self.tr = make_tree(self.frame, cols, [110] * len(cols), 20)
        fr.pack(fill="both", expand=True)
        self.fill()

    def fill(self):
        if self.tr is None:
            return
        self.tr.delete(*self.tr.get_children())
        qs = self.v_filter.get().lower()
        n = 0
        for i, r in enumerate(self.rows):
            if qs and not any(qs in str(v).lower() for v in r):
                continue
            self.tr.insert("", "end", iid=str(i), values=["" if v is None else v for v in r])
            n += 1
        self.lbl.set("%d wierszy (pokazano %d; limit odczytu 5000)" % (len(self.rows), n))

    def delete_own(self):
        app = self.app
        if not app.need_db() or self.tr is None:
            return
        t = self.cb.get()
        sel = self.tr.selection()
        owner_col = next((c for c in self.cols if c.lower() in ("ownertext", "owner")), None)
        pk = app.db.pk_columns(t)
        if not sel or not owner_col or not pk:
            messagebox.showinfo("Usuń", "Zaznacz wiersze w tabeli z kolumną OwnerText i kluczem głównym.")
            return
        rows = [dict(zip(self.cols, self.rows[int(i)])) for i in sel]
        own = [r for r in rows if is_own(r[owner_col])]
        if not own:
            messagebox.showinfo("Usuń", "Zaznaczone wiersze są fabryczne (DSC) - program ich nie usuwa.")
            return
        if not messagebox.askyesno("Potwierdź", "Usunąć %d wierszy (pominięto fabrycznych: %d)?" % (len(own), len(rows) - len(own))):
            return
        if not app.backup_before_write():
            return

        def fn(cur):
            for r in own:
                cur.execute("DELETE FROM %s WHERE %s" % (q(t), " AND ".join("%s=?" % q(c) for c in pk)), [r[c] for c in pk])
                if cur.rowcount != 1:
                    raise RuntimeError("Usunięcie dotknęłoby %d wierszy - anulowano." % cur.rowcount)
        if app.write_or_report(fn, "Błąd (zmiany wycofane)"):
            app.reload()
            app.reload_browsers()
