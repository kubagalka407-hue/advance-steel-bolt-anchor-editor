# -*- coding: utf-8 -*-
"""Panel podglądu śruby (stały, po prawej stronie kreatorów śrub): rysunek śruby z podkładkami i nakrętkami
w skali wymiarów z bazy. Rysuje App.draw_assembly (ten sam rysunek co w widoku Tekla)."""
from as_editor.common import dia_text, fmt_dia
from as_editor.i18n import T
from as_editor.ui.widgets import tk, ttk


class BoltPreview(ttk.Frame):
    """get_state() -> dict(std, mats, dias, head, nut, caption): bieżący stan kreatora (puste = brak wyboru).
    head / nut: listy {'std','mat'} od blachy na zewnątrz; caption: zdanie pod rysunkiem."""

    def __init__(self, parent, app, get_state):
        super().__init__(parent)
        self.app, self.get_state, self._job = app, get_state, None
        self.dias, self.mats = [], []
        r = ttk.Frame(self)
        r.pack(fill="x")
        ttk.Label(r, text="Klasa").pack(side="left")
        self.cb_mat = ttk.Combobox(r, state="readonly", width=7)
        self.cb_mat.pack(side="left", padx=(4, 8))
        self.cb_mat.bind("<<ComboboxSelected>>", lambda e: self.schedule())
        ttk.Label(r, text="Ø").pack(side="left")
        self.cb_dia = ttk.Combobox(r, state="readonly", width=6)
        self.cb_dia.pack(side="left", padx=(4, 8))
        self.cb_dia.bind("<<ComboboxSelected>>", lambda e: self.schedule())
        r2 = ttk.Frame(self)
        r2.pack(fill="x", pady=(4, 0))
        ttk.Label(r2, text="Pakiet blach [mm]").pack(side="left")
        self.var_grip = tk.StringVar(value="20")
        self.var_grip.trace_add("write", lambda *a: self.schedule())
        ttk.Entry(r2, textvariable=self.var_grip, width=6).pack(side="left", padx=6)
        self.cv = tk.Canvas(self, width=360, height=360, bg="white", highlightthickness=1, highlightbackground="#cccccc")
        self.cv.pack(fill="both", expand=True, pady=8)
        self.cv.bind("<Configure>", lambda e: self.schedule())
        self.var_cap = tk.StringVar()
        ttk.Label(self, textvariable=self.var_cap, style="Hint.TLabel", wraplength=350, justify="left").pack(anchor="w")
        self.var_info = tk.StringVar()
        ttk.Label(self, textvariable=self.var_info, style="Hint.TLabel", wraplength=350, justify="left").pack(anchor="w", pady=(4, 0))

    def grip(self):
        try:
            return max(1.0, float(self.var_grip.get().replace(",", ".")))
        except ValueError:
            return 20.0

    def schedule(self):
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
        self._job = self.after(80, self.draw)

    refresh = schedule

    def _sync(self, cb, values, cur):
        if list(cb["values"]) != values:
            cb["values"] = values
        if cur in values:
            cb.current(values.index(cur))
        elif values:
            cb.current(0)
        else:
            cb.set("")

    def draw(self):
        self._job = None
        cv = self.cv
        W, H = max(cv.winfo_width(), 200), max(cv.winfo_height(), 200)
        try:
            st = self.get_state() or {}
            mats, dias = list(st.get("mats") or []), list(st.get("dias") or [])
            self.var_cap.set(st.get("caption", ""))
            self._sync(self.cb_mat, mats, self.cb_mat.get())
            self._sync(self.cb_dia, [dia_text(d) for d in dias], self.cb_dia.get())
            std = st.get("std")
            i = self.cb_dia.current()
            if not (std and mats and dias and 0 <= i < len(dias)) or not self.app.db.conn:
                from as_editor.ui.icons import placeholder
                placeholder(cv, "bolt", T("Wybierz normę śruby, klasę i średnicę - tu zobaczysz śrubę."), W, H)
                self.var_info.set("")
                return
            mat = mats[self.cb_mat.current()] if self.cb_mat.current() >= 0 else mats[0]
            self.var_info.set(self.app.draw_assembly(cv, std, mat, dias[i], st.get("head") or [], st.get("nut") or [],
                                                     self.grip(), W, H))
        except Exception as e:
            cv.delete("all")
            self.var_info.set(T("Podgląd niedostępny: %s") % str(e).splitlines()[0][:100])
