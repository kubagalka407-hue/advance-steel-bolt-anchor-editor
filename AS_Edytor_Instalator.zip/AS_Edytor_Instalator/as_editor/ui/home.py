# -*- coding: utf-8 -*-
"""Powłoka okna: nagłówek ze statusem, ekran języka, ekran startowy (Kotwy / Śruby), podmenu i strona 'Zaawansowane'.
Cały dawny interfejs (zakładki) mieści się na stronie 'adv'."""
from as_editor.i18n import T, get_language
from as_editor.ui.theme import FONT
from as_editor.ui.widgets import Tooltip, messagebox, tk, ttk


class HomeMixin:
    PAGES = ("lang", "home", "bolts", "anchors", "cat_anchors", "cat_bolts", "mine", "settings", "adv")

    # ------------------------------------------------------------------ szkielet
    def build_shell(self, start):
        root = self.root
        self.header = ttk.Frame(root)
        self.header.pack(side="top", fill="x", padx=14, pady=(8, 0))
        self.btn_menu = ttk.Button(self.header, text="← " + T("Menu główne"), command=lambda: self.show_page("home"))
        self.var_crumb = tk.StringVar()
        self.lbl_crumb = ttk.Label(self.header, textvariable=self.var_crumb, style="Crumb.TLabel")
        self.lbl_dot = tk.Label(self.header, text="●", foreground="#b00000", font=("TkDefaultFont", 13))
        self.status = tk.StringVar(value=T("Brak połączenia"))
        self.lbl_status = ttk.Label(self.header, textvariable=self.status, style="Hint.TLabel")
        self.btn_lang = ttk.Button(self.header, text="English" if get_language() == "pl" else "Polski",
                                   command=self.switch_language, style="Toolbutton")
        self.btn_help = ttk.Button(self.header, text="?  " + T("Pomoc"), command=self.page_help, style="Toolbutton")
        self.btn_report = ttk.Button(self.header, text=T("Zgłoś problem"), command=self.report_problem, style="Toolbutton")
        self.btn_lang.pack(side="right")
        Tooltip(self.btn_report, T("Coś nie działa albo jest niejasne? Opisz to - program dołączy zrzut okna i stan pól (klawisz F8)."))
        self.btn_report.pack(side="right", padx=(0, 10))
        self.lbl_status.pack(side="right", padx=(0, 10))
        self.lbl_dot.pack(side="right")
        self.stage = ttk.Frame(root)
        self.stage.pack(fill="both", expand=True)
        self.pages = {n: ttk.Frame(self.stage) for n in self.PAGES}
        self.cur_page = None
        self.build_page_lang(self.pages["lang"])
        self.build_page_home(self.pages["home"])
        self.build_page_bolts(self.pages["bolts"])
        self.build_page_anchors(self.pages["anchors"])
        self.build_page_cat_anchors(self.pages["cat_anchors"])
        self.build_page_cat_bolts(self.pages["cat_bolts"])
        self.build_page_mine(self.pages["mine"])
        self.build_page_settings(self.pages["settings"])
        self.show_page(start)

    def show_page(self, name):
        for n, f in self.pages.items():
            f.pack_forget()
        self.pages[name].pack(fill="both", expand=True)
        self.cur_page = name
        crumbs = {"bolts": "Śruby", "anchors": "Kotwy", "cat_anchors": "Katalog kotew", "cat_bolts": "Katalog śrub", "mine": "Moje wpisy i cofanie", "settings": "Ustawienia",
                  "adv": "Tryb ekspercki"}
        self.lbl_crumb.pack_forget()
        if name in ("lang", "home"):
            self.btn_menu.pack_forget()
        else:
            self.btn_menu.pack(side="left")
            self.var_crumb.set(T(crumbs.get(name, "")))
            self.lbl_crumb.pack(side="left", padx=(14, 0))
        self.btn_help.pack_forget()
        if name in ("home", "bolts", "anchors", "mine", "cat_anchors", "cat_bolts"):
            self.btn_help.pack(side="right", padx=(0, 10), before=self.btn_report)
        if name in ("cat_anchors", "cat_bolts"):
            self.refresh_cat_page(name)
        if name == "mine":
            try:
                self.refresh_mine()
            except Exception as e:
                self.say(T("Nie udało się odczytać listy: %s") % str(e).splitlines()[0][:120], "err")
        self.update_notice()

    # ------------------------------------------------------------------ elementy
    def page_help(self):
        from as_editor.ui.help_texts import show_help
        if self.cur_page in ("home", "bolts", "anchors", "mine", "cat_anchors", "cat_bolts"):
            show_help(self.root, self.cur_page)

    def report_problem(self):
        from as_editor.ui.report import open_report
        open_report(self, self.root)

    def centered(self, page):
        box = ttk.Frame(page)
        box.place(relx=0.5, rely=0.46, anchor="center")
        return box

    def clickable(self, frame, command, hover=None):
        """Cała karta reaguje na kliknięcie (kursor 'ręka'); hover = widżet-tytuł podświetlany po najechaniu."""
        def walk(w):
            yield w
            for ch in w.winfo_children():
                yield from walk(ch)
        for w in walk(frame):
            if isinstance(w, ttk.Button):
                continue
            w.bind("<Button-1>", lambda e: command(), add="+")
            try:
                w.configure(cursor="hand2")
            except Exception:
                pass
            if hover is not None:
                w.bind("<Enter>", lambda e: hover.configure(style="CardTitleOn.TLabel"), add="+")
                w.bind("<Leave>", lambda e: hover.configure(style="CardTitle.TLabel"), add="+")

    def card(self, parent, title, text, command, col, accent=False, icon_name=None, grid_row=0):
        from as_editor.ui.icons import icon
        c = ttk.Frame(parent, style="Card.TFrame", padding=22)
        c.grid(row=grid_row, column=col, padx=14, pady=10, sticky="nsew")
        if icon_name:
            icon(c, icon_name, 72).pack(anchor="w", pady=(0, 12))
        lt = ttk.Label(c, text=title, style="CardTitle.TLabel")
        lt.pack(anchor="w")
        ttk.Label(c, text=text, wraplength=230, justify="left", style="Hint.TLabel").pack(anchor="w", pady=(8, 16))
        b = ttk.Button(c, text=T("Wybierz") + "  →", command=command, style="Accent.TButton" if accent else "TButton")
        b.pack(anchor="w", side="bottom")
        self.clickable(c, command, lt)
        return c

    def big_card(self, parent, col, icon_name, title, bullets, command):
        """Duża karta ekranu startowego: ilustracja, tytuł, lista tego, co można zrobić, przycisk."""
        from as_editor.ui.icons import icon
        c = ttk.Frame(parent, style="Card.TFrame", padding=(26, 22))
        c.grid(row=0, column=col, padx=14, pady=8, sticky="nsew")
        top = ttk.Frame(c)
        top.pack(fill="x")
        icon(top, icon_name, 96).pack(side="left", padx=(0, 18))
        lt = ttk.Label(top, text=title, style="BigTitle.TLabel")
        lt.pack(side="left", anchor="w")
        body = ttk.Frame(c)
        body.pack(fill="x", pady=(14, 14))
        for b in bullets:
            ttk.Label(body, text="•  " + T(b), style="Body.TLabel", wraplength=400, justify="left").pack(anchor="w", pady=2)
        ttk.Button(c, text=T("Otwórz") + "  →", command=command, style="Accent.TButton").pack(anchor="w")
        self.clickable(c, command, lt)
        return c

    def tile(self, parent, col, icon_name, title, text, command):
        """Mała karta (rzadziej używane strony): ikona, tytuł i jedno zdanie."""
        from as_editor.ui.icons import icon
        c = ttk.Frame(parent, style="Card.TFrame", padding=(16, 12))
        c.grid(row=0, column=col, padx=14, pady=6, sticky="nsew")
        icon(c, icon_name, 44).pack(side="left", padx=(0, 14))
        col_ = ttk.Frame(c)
        col_.pack(side="left", fill="x", expand=True)
        lt = ttk.Label(col_, text=title, style="TileTitle.TLabel")
        lt.pack(anchor="w")
        ttk.Label(col_, text=text, style="Hint.TLabel", wraplength=300, justify="left").pack(anchor="w")
        ttk.Label(c, text="›", style="Chevron.TLabel").pack(side="right", padx=(10, 0))
        self.clickable(c, command, lt)
        return c

    def cards_row(self, page, title, sub, cards):
        box = self.centered(page)
        ttk.Label(box, text=title, style="Title.TLabel").pack(pady=(0, 4))
        if sub:
            ttk.Label(box, text=sub, style="Sub.TLabel").pack(pady=(0, 14))
        row = ttk.Frame(box)
        row.pack()
        n = len(cards)
        per = n if n <= 3 else 2 if n == 4 else 3                  # więcej kart niż się mieści: kolejny rząd (okno nie wychodzi poza ekran)
        for i, cd in enumerate(cards):
            t, d, cmd = cd[:3]
            self.card(row, t, d, cmd, i % per, accent=(i == 0), icon_name=cd[3] if len(cd) > 3 else None, grid_row=i // per)
        for c in range(per):
            row.columnconfigure(c, weight=1, uniform="c")
        return box

    # ------------------------------------------------------------------ strony
    def build_page_lang(self, page):
        box = self.centered(page)
        ttk.Label(box, text="Edytor śrub i kotew", style="Title.TLabel").pack()
        ttk.Label(box, text="Advance Steel", style="Sub.TLabel").pack(pady=(0, 18))
        ttk.Label(box, text="Wybierz język  /  Choose language", style="Sub.TLabel").pack(pady=(0, 10))
        row = ttk.Frame(box)
        row.pack()
        cur = get_language()
        for code, name in (("pl", "Polski"), ("en", "English")):
            ttk.Button(row, text=name, width=14, style="Accent.TButton" if code == cur else "TButton",
                       command=lambda c=code: self.choose_language(c)).pack(side="left", padx=8, ipady=6)

    def build_page_home(self, page):
        box = self.centered(page)
        ttk.Label(box, text=T("Co chcesz zrobić?"), style="Title.TLabel").pack(pady=(0, 4))
        ttk.Label(box, text=T("Wybierz, a program poprowadzi Cię krok po kroku."), style="Sub.TLabel").pack(pady=(0, 16))
        row = ttk.Frame(box)
        row.pack()
        self.big_card(row, 0, "anchor", T("Kotwy"), [
            "Przeglądaj katalog kotew z rysunkiem", "Dodaj set nakrętek i podkładek do kotew", "Dopisz nowe długości do kotew",
            "Utwórz nową kotwę, średnicę lub klasę"], lambda: self.go("anchors"))
        self.big_card(row, 1, "bolt", T("Śruby"), [
            "Przeglądaj katalog zestawów śrub", "Dodaj zestaw (podkładki i nakrętki) do śruby", "Skopiuj całą klasę śrub (np. 5.6)",
            "Dodaj nową podkładkę lub nakrętkę"], lambda: self.go("bolts"))
        for i in (0, 1):
            row.columnconfigure(i, weight=1, uniform="big")
        row2 = ttk.Frame(box)
        row2.pack(fill="x", pady=(6, 0))
        self.tile(row2, 0, "mine", T("Moje wpisy i cofanie"), T("Zobacz i usuń to, co dodałeś, oraz cofnij ostatni zapis."),
                  lambda: self.go("mine"))
        self.tile(row2, 1, "settings", T("Ustawienia"),
                  T("Połączenie z bazą, właściciel wpisów, kopie zapasowe, tryb ekspercki."), lambda: self.show_page("settings"))
        for i in (0, 1):
            row2.columnconfigure(i, weight=1, uniform="tile")
        self.var_notice = tk.StringVar()
        self.lbl_notice = ttk.Label(box, textvariable=self.var_notice, style="Err.TLabel", wraplength=600, justify="center")
        self.lbl_notice.pack(pady=(8, 0))
        self.btn_retry = ttk.Button(box, text=T("Połącz ponownie"), style="Accent.TButton", command=lambda: self.connect(silent=False))
        self.btn_adv = ttk.Button(box, text=T("Ustawienia połączenia"), command=lambda: self.show_page("settings"))

    def build_page_bolts(self, page):
        self.cards_row(page, T("Śruby"), T("Co chcesz zrobić?"), [
            (T("Katalog śrub"),
             T("Przeglądaj zestawy śrub jak w Tekli: norma, klasa, skład i rysunek w jednym oknie; stąd też dodasz, skopiujesz, zmienisz albo usuniesz zestaw."),
             lambda: self.go("cat_bolts"), "catalog_bolt"),
            (T("Dodaj zestaw do śruby"),
             T("Wybierz normę, klasy i średnice, ułóż podkładki i nakrętki i zapisz nowy zestaw."),
             self.open_bolt_set_wizard, "bolt"),
            (T("Skopiuj całą klasę śrub"),
             T("Nowa klasa (np. 5.6) z tymi samymi wymiarami i zestawami co istniejąca; zmieniasz tylko klasy elementów."),
             self.open_class_copy_wizard, "copy"),
            (T("Nowa podkładka / nakrętka"),
             T("Dodaj do katalogu nowy element z typowymi wymiarami (otwiera narzędzie w trybie eksperckim)."),
             lambda: self.open_tool(self.tab_new, "bolts"), "washer"),
        ])

    def build_page_anchors(self, page):
        self.cards_row(page, T("Kotwy"), T("Co chcesz zrobić?"), [
            (T("Katalog kotew"),
             T("Przeglądaj kotwy jak w Tekli: rodzina, typ, rozmiar i rysunek w jednym oknie; stąd też dodasz nową kotwę, skopiujesz ją, zmienisz zestaw albo usuniesz własną."),
             lambda: self.go("cat_anchors"), "catalog"),
            (T("Dodaj set do kotew"),
             T("Wybierz kotwy (norma, zestaw, klasy, średnice) i nadaj im nowy zestaw nakrętek i podkładek."),
             lambda: self.open_anchor_wizard("set"), "set"),
            (T("Dodaj długości do kotew"),
             T("Dopisz nowe długości do kotew z danym zestawem i klasami materiałów (wiele kotew naraz)."),
             lambda: self.open_anchor_wizard("len"), "length"),
            (T("Nowa kotwa"),
             T("Od zera albo na wzorcu istniejącej (nowa średnica, nowa klasa, kopia): typ, wymiary, długości i zestaw."),
             lambda: self.open_anchor_wizard("new"), "newanchor"),
            (T("Nowa podkładka / nakrętka"),
             T("Dodaj do katalogu nowy element z typowymi wymiarami, żeby użyć go w zestawie kotwy (te same elementy służą śrubom i kotwom)."),
             lambda: self.open_tool(self.tab_new, "anchors"), "washer"),
        ])

    # ------------------------------------------------------------------ nawigacja
    def go(self, name):
        if not self.db.conn and not self.connect(silent=True):
            self.update_notice()
            messagebox.showwarning("Brak połączenia",
                                   "Nie udało się połączyć z bazą. Uruchom Advance Steel (lub Management Tools) i kliknij "
                                   "'Połącz ponownie'. Instancję i wersję zmienisz w 'Zaawansowane'.")
            return
        self.show_page(name)

    def update_notice(self):
        if not hasattr(self, "var_notice"):
            return
        if self.db.conn:
            self.var_notice.set("")
            self.btn_retry.pack_forget()
            self.btn_adv.pack_forget()
        else:
            self.var_notice.set(T("Brak połączenia z bazą Advance Steel. Uruchom Advance Steel i kliknij 'Połącz ponownie'."))
            self.btn_retry.pack(pady=(6, 0))
            self.btn_adv.pack(pady=(8, 0))

    def choose_language(self, code):
        from as_editor.i18n import set_language
        if code == get_language():
            self.show_page("home")
        else:
            self.switch_language(page="home")
        from as_editor.config import recall
        if not recall("welcome_seen"):
            self.root.after(400, self.welcome)
