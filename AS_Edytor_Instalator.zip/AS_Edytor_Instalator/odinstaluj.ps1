﻿# Odinstalowanie: Edytor srub i kotew Advance Steel (usuwa program i skroty; baza Advance Steel nie jest zmieniana)
$ErrorActionPreference = 'Continue'
$dest  = Join-Path $env:LOCALAPPDATA 'AS_Edytor_Srub'
$title = 'Edytor srub i kotew Advance Steel'
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $lnk = Join-Path $folder ($title + '.lnk')
    if (Test-Path $lnk) { Remove-Item $lnk -Force }
}
if (Test-Path $dest) {
    $keep = Join-Path $dest 'backups'
    $hasBackups = (Test-Path $keep) -and (Get-ChildItem $keep -ErrorAction SilentlyContinue)
    if ($hasBackups) {
        $a = Read-Host 'W folderze programu sa kopie zapasowe bazy (backups). Usunac je tez? (T/N)'
        if ($a -notmatch '^[TtYy]') {
            Get-ChildItem $dest -Exclude 'backups' | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host ('Program usuniety. Kopie zapasowe zostaly w: ' + $keep)
            Read-Host 'Nacisnij Enter, aby zamknac'
            exit 0
        }
    }
    Set-Location $env:LOCALAPPDATA
    Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host 'Program i skroty zostaly usuniete.'
Read-Host 'Nacisnij Enter, aby zamknac'
