# -*- coding: utf-8 -*-
"""Logika kotew bez GUI i bazy: kolumny definicji, pozycje zestawu, wiersze AnchorsName/Definition."""
import math
from as_editor.common import fmt_dia
from as_editor.config import MAX_ITEMS, RHO


# --- kotwy: kolumny definicji widoczne w Management Tools dla poszczególnych typów (ClassID) ---
ANCHOR_DEF_COLS = {
    0: ["Length", "ThreadLength", "TopDistance", "HeadHeight", "HeadDiameter", "NumberOfHeadEdges", "Weight", "PartName"],
    1: ["Length", "ThreadLength", "TopDistance", "HeadHeight", "HeadDiameter", "NumberOfHeadEdges", "Weight", "PartName"],
    2: ["Length", "ThreadLength", "TopDistance", "BottomDistance", "HeadHeight", "HeadDiameter",
        "NumberOfHeadEdges", "Weight", "PartName"],
    3: ["Length", "ThreadLength", "TopDistance", "DistanceF", "DistanceE", "DistanceA", "DistanceO", "HookRadius",
        "Weight", "PartName"],
    4: ["Length", "ThreadLength", "TopDistance", "DistanceF", "DistanceE", "DistanceA", "DistanceO", "DistanceC",
        "HookRadius", "Weight", "PartName"],
}


ANCHOR_LABELS = {
    "Length": "Długość", "ThreadLength": "Gwint od czubka", "TopDistance": "Ponad blachę",
    "BottomDistance": "Od dołu kotwy", "DistanceF": "Hak F", "DistanceE": "Hak E", "DistanceA": "Hak A",
    "DistanceO": "Hak O", "DistanceC": "Hak C", "HeadHeight": "Wys. główki", "HeadDiameter": "Ø główki",
    "NumberOfHeadEdges": "Boki główki", "HookRadius": "Promień gięcia",
    "Weight": "Ciężar", "PartName": "Nr części"}


# --- znaczenie wymiarów wg zrzutów Management Tools i opisu użytkownika (2026-10) ---
ANCHOR_TIPS = {
    "Length": "Długość całkowita kotwy. Dla haków mierzona od czubka do spodu haka.",
    "ThreadLength": "Długość gwintu liczona OD CZUBKA kotwy w dół.",
    "TopDistance": "Ile kotwy wystaje ponad płaszczyznę przyłożenia, czyli ponad górną powierzchnię blachy.",
    "BottomDistance": "Odległość mierzona OD DOŁU kotwy w górę. Od niej układane są nakrętki i podkładki "
                      "ze strefy 'koniec kotwy'.",
    "HeadHeight": "Wysokość główki na DOLNYM końcu kotwy.",
    "HeadDiameter": "Średnica okręgu OPISANEGO na główce - główka to wielobok wpisany w ten okrąg.",
    "NumberOfHeadEdges": "Liczba boków główki, np. 6 = sześciokąt wpisany w okrąg o podanej średnicy.",
    "DistanceF": "Hak: wysokość odcinka ukośnego (mierzona w pionie).",
    "DistanceE": "Hak: wysokość prostego odcinka pod ukosem, do spodu haka.",
    "DistanceO": "Hak: przesunięcie poziome, o jakie ukos odsuwa dolną część kotwy od górnej.",
    "DistanceA": "Hak: szerokość - od zewnętrznej krawędzi dolnego odcinka pionowego do końca ramienia poziomego.",
    "DistanceC": "Hak J: wysokość powrotu zagiętego do góry na końcu ramienia.",
    "HookRadius": "Promień gięcia haka.",
    "Weight": "Ciężar jednej sztuki w kg.",
    "PartName": "Nazwa / numer części widoczny w Advance Steel."}


ANCHOR_DEF_FIELDS = ["Length", "ThreadLength", "TopDistance", "DistanceF", "DistanceE", "DistanceA", "DistanceO",
                     "DistanceC", "BottomDistance", "HeadHeight", "HeadDiameter", "NumberOfHeadEdges", "HookRadius",
                     "PartName", "Weight"]


def anchor_positions(top, below, end):
    """Pozycje elementów zestawu kotwy: góra +1.., pod blachą -1.., koniec kotwy -101...
    Listy są w kolejności jak w Management Tools i czyta się je od góry do dołu: nad blachą wiersz 1 (+1) jest
    NAJDALEJ od blachy, a ostatni przylega do blachy; pod blachą wiersz 1 (-1) PRZYLEGA do blachy, kolejne są coraz niżej
    (potwierdzone zrzutem zakładki Set, wpisami fabrycznymi i modelem Advance Steel: podkładka -1 przy blasze, nakrętka -2 pod nią)."""
    items = []
    for i, c in enumerate(top, 1):
        items.append((c["std"], c["mat"], i))
    for i, c in enumerate(below, 1):
        items.append((c["std"], c["mat"], -i))
    for i, c in enumerate(end, 1):
        items.append((c["std"], c["mat"], -(100 + i)))
    return items


def zone_of(position):
    return "top" if position > 0 else ("below" if position > -100 else "end")


def pick_dia(avail, dia, tol=0.15):
    """Średnica elementu najbliższa średnicy kotwy (dokładna, a w razie braku w granicach tolerancji)."""
    if not avail:
        return None
    best = min(avail, key=lambda x: abs(x - dia))
    return best if abs(best - dia) <= tol * dia else None


def build_anchor_name_row(id_, std, class_id, mat, dia, source, set_name, owner, explodable, items):
    """items: [(din, klasa, pozycja, średnica_elementu)]."""
    row = {"ID": id_, "Standard": std[:64], "ClassID": class_id, "MaterialKey": mat[:64],
           "Explodable": 1 if explodable else 0, "Source": source[:15], "Diameter": dia,
           "SetName": set_name[:64], "OwnerText": owner[:15], "NumItems": len(items)}
    for i in range(1, MAX_ITEMS + 1):
        if i <= len(items):
            din, m, pos, cd = items[i - 1]
            row.update({"DIN%d" % i: din, "Diameter%d" % i: cd, "Material%d" % i: m, "Position%d" % i: pos})
        else:
            row.update({"DIN%d" % i: "-", "Diameter%d" % i: 0.0, "Material%d" % i: "-", "Position%d" % i: 0})
    return row


def build_anchor_def_row(id_, anchor_id, vals, owner):
    row = {"ID": id_, "AnchorID": anchor_id}
    for f in ANCHOR_DEF_FIELDS:
        row[f] = vals.get(f)
    if row["PartName"] is not None:
        row["PartName"] = str(row["PartName"])[:64]
    row["OwnerText"] = owner[:15]
    return row


def empty_hole_row(id_, name_id):
    """Management Tools zakłada dla każdej nowej kotwy pusty wiersz otworu (potwierdzone porównaniem baz)."""
    return {"ID": id_, "AnchorNameID": name_id, "Location": None, "HoleType": None, "HoleTolerance": None,
            "Depth": None, "Angle": None, "HeadDiameter": None}


def rename_part(base_name, base_len, new_len, dia, fallback):
    if base_name and base_len is not None and fmt_dia(base_len) in base_name:
        return base_name.replace(fmt_dia(base_len), fmt_dia(new_len), 1)[:64]
    return ("%s M%sx%s" % (fallback, fmt_dia(dia), fmt_dia(new_len)))[:64]


def anchor_weight(base_len, base_w, d, length):
    """Waga [kg] kotwy dla innej długości: z wagi wzorca albo z objętości pręta."""
    if base_w and base_len:
        return round(max(0.0, base_w + RHO * math.pi / 4.0 * d * d * (length - base_len)), 4)
    return round(RHO * math.pi / 4.0 * d * d * length, 4)


def plan_anchor_copy(names, defs, holes, ids, std=None, mat=None, owner="MOJA", mapping=None, repl=None):
    """Kopiowanie kotew z nowymi identyfikatorami.
    names: [dict AnchorsName]; defs: {id_kotwy: [dict]}; holes: {id_kotwy: dict}; ids: {'name','def','hole'} = następne ID."""
    out_n, out_d, out_h = [], [], []
    for n in names:
        nid = ids["name"]
        ids["name"] += 1
        nn = dict(n)
        nn["ID"], nn["OwnerText"] = nid, owner[:15]
        if std:
            nn["Standard"] = std
        if mat:
            nn["MaterialKey"] = mat
        for k in range(1, MAX_ITEMS + 1):
            key = (nn.get("DIN%d" % k), nn.get("Material%d" % k))
            if mapping and key in mapping:
                nn["Material%d" % k] = mapping[key]
        out_n.append(nn)
        for d in defs.get(n["ID"], []):
            nd = dict(d)
            nd["ID"], nd["AnchorID"], nd["OwnerText"] = ids["def"], nid, owner[:15]
            ids["def"] += 1
            if repl and repl[0] and nd.get("PartName"):
                nd["PartName"] = nd["PartName"].replace(repl[0], repl[1])[:64]
            out_d.append(nd)
        h = holes.get(n["ID"])
        nh = dict(h) if h else empty_hole_row(None, None)
        nh["ID"], nh["AnchorNameID"] = ids["hole"], nid
        ids["hole"] += 1
        out_h.append(nh)
    return out_n, out_d, out_h
