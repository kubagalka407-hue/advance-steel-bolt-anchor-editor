# -*- coding: utf-8 -*-
"""Punkt wejścia: start programu i kontrola tłumaczeń (--check-i18n)."""
import sys
from as_editor.app import App
from as_editor.config import load_settings, pyodbc
from as_editor.i18n import check_i18n, set_language
from as_editor.ui.hooks import install_translation_hooks
from as_editor.ui.widgets import messagebox, setup_style, tk


def main():
    if "--check-i18n" in sys.argv:
        check_i18n()
        return
    install_translation_hooks()
    set_language(load_settings().get("lang", "pl"))
    if pyodbc is None:
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror("Brak pyodbc", "Zainstaluj moduł:  pip install pyodbc")
        return
    root = tk.Tk()
    setup_style(root)
    try:
        App(root)
        root.mainloop()
    except Exception:                                   # start bez konsoli (skrót): błąd trafia do pliku i okienka
        import os
        import traceback
        from as_editor.config import APP_DIR
        txt = traceback.format_exc()
        try:
            with open(os.path.join(APP_DIR, "blad.log"), "w", encoding="utf-8") as f:
                f.write(txt)
        except OSError:
            pass
        messagebox.showerror("Błąd programu", txt[-1500:] + "\n\n(zapisano w pliku blad.log)")
