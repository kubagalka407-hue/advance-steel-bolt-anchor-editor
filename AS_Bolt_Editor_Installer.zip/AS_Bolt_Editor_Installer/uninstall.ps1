# Uninstall: Advance Steel Bolt and Anchor Editor (removes the program and shortcuts; the Advance Steel database is not changed)
$ErrorActionPreference = 'Continue'
$dest  = Join-Path $env:LOCALAPPDATA 'AS_Bolt_Editor'
$title = 'Advance Steel Bolt and Anchor Editor'
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    foreach ($n in @(($title + '.lnk'), ('Uninstall ' + $title + '.lnk'))) {
        $lnk = Join-Path $folder $n
        if (Test-Path $lnk) { Remove-Item $lnk -Force -ErrorAction SilentlyContinue }
    }
}
if (Test-Path $dest) {
    $keep = Join-Path $dest 'backups'
    $hasBackups = (Test-Path $keep) -and (Get-ChildItem $keep -ErrorAction SilentlyContinue)
    if ($hasBackups) {
        $a = Read-Host 'The program folder contains database backups (backups). Delete them too? (Y/N)'
        if ($a -notmatch '^[Yy]') {
            Set-Location $env:LOCALAPPDATA
            Get-ChildItem $dest -Exclude 'backups' | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host ('Program removed. The backups were kept in: ' + $keep)
            Read-Host 'Press Enter to close'
            exit 0
        }
    }
    Set-Location $env:LOCALAPPDATA
    Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host 'The program and its shortcuts were removed.'
Read-Host 'Press Enter to close'
