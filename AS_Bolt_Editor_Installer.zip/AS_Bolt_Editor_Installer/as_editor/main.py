# -*- coding: utf-8 -*-
"""Punkt wejścia: start programu i kontrola tłumaczeń (--check-i18n)."""
import os
import sys
from as_editor.app import App
from as_editor.config import load_settings, pyodbc
from as_editor.i18n import check_i18n, set_language
from as_editor.ui.hooks import install_translation_hooks
from as_editor.ui.widgets import messagebox, setup_style, tk


def default_language():
    """Pierwszy start bez zapisanego wyboru: polski tylko na polskim Windows, w pozostałych przypadkach angielski."""
    try:
        import ctypes
        return "pl" if (ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0xFF) == 0x15 else "en"
    except Exception:                                   # nie Windows (testy, Linux)
        return "pl"


def set_app_icon(root):
    """Ikona kotwy w oknach programu i na pasku zadań (osobna grupa, nie ikona Pythona)."""
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("AdvanceSteel.BoltAnchorEditor")
    except Exception:
        pass
    assets = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    try:
        root.iconbitmap(default=os.path.join(assets, "anchor.ico"))
    except Exception:
        try:
            root.iconphoto(True, tk.PhotoImage(file=os.path.join(assets, "anchor_256.png")))
        except Exception:
            pass


def main():
    if "--check-i18n" in sys.argv:
        check_i18n()
        return
    install_translation_hooks()
    set_language(load_settings().get("lang", default_language()))
    if pyodbc is None:
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror("Brak pyodbc", "Zainstaluj moduł:  pip install pyodbc")
        return
    root = tk.Tk()
    set_app_icon(root)
    setup_style(root)
    try:
        App(root)
        root.mainloop()
    except Exception:                                   # start bez konsoli (skrót): błąd trafia do pliku i okienka
        import os
        import traceback
        from as_editor.config import APP_DIR
        txt = traceback.format_exc()
        try:
            with open(os.path.join(APP_DIR, "crash.log"), "w", encoding="utf-8") as f:
                f.write(txt)
        except OSError:
            pass
        messagebox.showerror("Błąd programu", txt[-1500:] + "\n\n(zapisano w pliku crash.log)")
