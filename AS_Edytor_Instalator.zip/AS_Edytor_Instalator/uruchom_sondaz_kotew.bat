@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist "%~dp0as_anchor_probe.py" (
  echo Brak pliku as_anchor_probe.py w tym samym folderze.
  pause
  exit /b 1
)

set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY (
  echo Nie znaleziono Pythona - instaluje przez winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo Zamknij to okno i uruchom plik ponownie ^(Windows musi odswiezyc sciezki^).
  pause
  exit /b 0
)
%PY% -m pip install --quiet --upgrade pyodbc
if errorlevel 1 (
  echo Nie udalo sie zainstalowac pyodbc. Sprawdz polaczenie z internetem.
  pause
  exit /b 1
)
powershell -NoProfile -Command "if (Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) { exit 0 } else { exit 1 }"
if errorlevel 1 (
  echo Brak sterownika ODBC 17/18 - instaluje przez winget...
  winget install -e --id Microsoft.msodbcsql.18 --accept-package-agreements --accept-source-agreements
)

echo ==============================================
echo   Sondaz kotew / porownanie zmian w bazie
echo   ^(tylko odczyt - nic nie zmienia w bazie^)
echo ==============================================
echo.
echo   1 - Sondaz kotew ^(wynik do pliku i schowka^)
echo   2 - Migawka PRZED zmiana w Management Tools
echo   3 - Porownaj baze z migawka ^(PO zmianie^)
echo.
set OPT=
set /p OPT=Wybierz 1, 2 lub 3: 
set LANGV=INT
set /p LANGV=Wersja krajowa bazy [INT / POL ...] - Enter = INT: 

if "%OPT%"=="1" goto probe
if "%OPT%"=="2" goto snap
if "%OPT%"=="3" goto diff
echo Nieprawidlowy wybor.
pause
exit /b 1

:probe
%PY% "%~dp0as_anchor_probe.py" --lang %LANGV%
set OUTF=%~dp0anchor_probe.txt
goto done

:snap
%PY% "%~dp0as_anchor_probe.py" snapshot przed --lang %LANGV%
echo.
echo Migawka zapisana. Teraz w Management Tools wykonaj JEDNA czynnosc, np. utworz nowa kotwe
echo i kliknij Zastosuj. Potem uruchom ten plik ponownie i wybierz 3.
pause
exit /b 0

:diff
%PY% "%~dp0as_anchor_probe.py" diff przed --lang %LANGV%
set OUTF=%~dp0diff_przed.txt

:done
if not exist "%OUTF%" goto end
type "%OUTF%" | clip
echo.
echo Wynik skopiowany do schowka - wklej go w rozmowie (Ctrl+V).
start "" notepad "%OUTF%"

:end
pause
