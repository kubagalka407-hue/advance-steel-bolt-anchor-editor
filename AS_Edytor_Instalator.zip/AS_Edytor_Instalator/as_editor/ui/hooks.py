# -*- coding: utf-8 -*-
"""Podpięcie T() pod tworzenie widżetów tkinter (zmiana języka całego interfejsu)."""
from as_editor.i18n import T
from as_editor.ui.tips import TIPS
from as_editor.ui.widgets import Tooltip
from as_editor.ui.widgets import messagebox, simpledialog, tk, ttk


def install_translation_hooks():
    """Podpina T() pod wspólne miejsca tworzenia tekstów w tkinter: etykiety, przyciski, nagłówki tabel, zakładki,
    zmienne tekstowe (StringVar), napisy na płótnie, tytuły okien i komunikaty. Dzięki temu cały interfejs zmienia język."""
    def wrap_init(cls):
        orig = cls.__init__

        def init(self, master=None, **kw):
            raw = kw.get("text")
            if isinstance(raw, str):
                kw["text"] = T(raw)
            orig(self, master, **kw)
            if isinstance(raw, str) and raw in TIPS:
                Tooltip(self, T(TIPS[raw]))
        cls.__init__ = init
    for name in ("Label", "Button", "Checkbutton", "Radiobutton", "LabelFrame"):
        wrap_init(getattr(ttk, name))

    orig_add = ttk.Notebook.add

    def nb_add(self, child, **kw):
        if isinstance(kw.get("text"), str):
            kw["text"] = T(kw["text"])
        return orig_add(self, child, **kw)
    ttk.Notebook.add = nb_add

    orig_heading = ttk.Treeview.heading

    def heading(self, column, option=None, **kw):
        if isinstance(kw.get("text"), str):
            kw["text"] = T(kw["text"])
        return orig_heading(self, column, option, **kw)
    ttk.Treeview.heading = heading

    orig_ct = tk.Canvas.create_text

    def create_text(self, *a, **kw):
        if isinstance(kw.get("text"), str):
            kw["text"] = T(kw["text"])
        return orig_ct(self, *a, **kw)
    tk.Canvas.create_text = create_text

    orig_set = tk.StringVar.set

    def sv_set(self, value):
        return orig_set(self, T(value) if isinstance(value, str) else value)
    tk.StringVar.set = sv_set

    def make_mb(orig):
        def f(title=None, message=None, **kw):
            return orig(T(title) if isinstance(title, str) else title,
                        T(message) if isinstance(message, str) else message, **kw)
        return f
    for name in ("showinfo", "showwarning", "showerror", "askyesno"):
        setattr(messagebox, name, make_mb(getattr(messagebox, name)))

    orig_ask = simpledialog.askstring

    def askstring(title, prompt, **kw):
        return orig_ask(T(title), T(prompt), **kw)
    simpledialog.askstring = askstring

    orig_title = tk.Wm.wm_title

    def wm_title(self, string=None):
        return orig_title(self, T(string) if isinstance(string, str) else string)
    tk.Wm.wm_title = wm_title
    tk.Wm.title = wm_title
