# -*- coding: utf-8 -*-
"""Kreator 'Skopiuj całą klasę śrub': 1) norma, klasa źródłowa, średnice, 2) nowa klasa i klasy elementów, 3) zapis.
Zachowuje wszystkie wymiary i zestawy źródła; zapis wykonuje sprawdzona logika zakładki 'Dodaj klasę do normy'."""
from as_editor.common import dia_text, fmt_dia, in_clause, insert_sql, is_own
from as_editor.config import MAX_ITEMS, recall, remember
from as_editor.i18n import T
from as_editor.ui.dialogs import ChoiceDialog
from as_editor.ui.preview_panel import BoltPreview
from as_editor.ui.widgets import order_button, make_filterable, make_list, make_tree, messagebox, selected_index, set_choices, tk, ttk
from as_editor.ui.wizard import Wizard


class ClassCopyWizard(Wizard):
    finish_text = "Skopiuj klasę"

    def __init__(self, app):
        super().__init__(app, "Skopiuj całą klasę śrub")
        self.dias, self.pairs, self.map = [], [], {}
        self.map_for = None
        self._comp = {}
        self.pv = BoltPreview(self.make_side("Podgląd śruby", 390), app, self.pv_state)
        self.pv.pack(fill="both", expand=True)
        self.add_step("Norma i klasa źródłowa", self.build1, self.enter1, self.leave1, help="class_copy.1")
        self.add_step("Nowa klasa", self.build2, self.enter2, self.leave2, help="class_copy.2")
        self.add_step("Podsumowanie i zapis", self.build3, self.enter3, self.leave3, help="class_copy.3")
        self.start()

    # ------------------------------------------------------------ krok 1
    def build1(self, f):
        ttk.Label(f, text="Którą klasę chcesz skopiować? Zostaną skopiowane wszystkie jej wymiary i zestawy.",
                  style="Sub.TLabel").pack(anchor="w", pady=(0, 10))
        ttk.Label(f, text="Norma śruby (wpisz tekst, np. DIN, aby zawęzić listę)").pack(anchor="w")
        self.cb_std = make_filterable(ttk.Combobox(f, width=60))
        self.cb_std.pack(anchor="w", pady=(2, 12))
        set_choices(self.cb_std, self.app.std_vals)
        self.cb_std.bind("<<ComboboxSelected>>", lambda e: (self.on_std(), self.pv.refresh()))
        row = ttk.Frame(f)
        row.pack(anchor="w", fill="y", expand=True)
        c1 = ttk.Frame(row)
        c1.pack(side="left", padx=(0, 24), fill="y", anchor="n")
        ttk.Label(c1, text="Klasa źródłowa").pack(anchor="w")
        self.cb_src = ttk.Combobox(c1, state="readonly", width=18)
        self.cb_src.pack(anchor="w", pady=(2, 0))
        self.cb_src.bind("<<ComboboxSelected>>", lambda e: (self.on_src(), self.pv.refresh()))
        c2 = ttk.Frame(row)
        c2.pack(side="left", fill="y")
        ttk.Label(c2, text="Średnice do skopiowania (Ctrl / Shift = kilka)").pack(anchor="w")
        fr, self.lb_dia = make_list(c2, 12, 18)
        fr.pack(fill="y", expand=True)
        b = ttk.Frame(c2)
        b.pack(anchor="w", pady=(6, 0))
        ttk.Button(b, text=T("Wszystkie"), command=lambda: self.lb_dia.selection_set(0, "end")).pack(side="left", padx=(0, 6))
        ttk.Button(b, text=T("Żadna"), command=lambda: self.lb_dia.selection_clear(0, "end")).pack(side="left", padx=(0, 6))
        order_button(b, self, self.on_src_keep).pack(side="left")

    def enter1(self):
        if selected_index(self.cb_std) < 0:
            cur = self.app.cur_std() or recall("last_bolt_std")
            for i, st in enumerate(self.app.stds):
                if st[0] == cur:
                    self.cb_std.set(self.app.std_vals[i])
                    self.cb_std._last = i
                    self.on_std()
                    break

    def std_index(self):
        return selected_index(self.cb_std)

    def std_key(self):
        i = self.std_index()
        return self.app.stds[i][0] if 0 <= i < len(self.app.stds) else None

    def on_std(self):
        mats = self.db.bolt_materials(self.std_key()) if self.std_key() else []
        self.cb_src["values"] = mats
        if mats:
            self.cb_src.current(0)
        else:
            self.cb_src.set("")
        self.on_src()

    def on_src(self, keep=None):
        src = self.cb_src.get()
        self.dias = sorted(self.db.bolt_diameters(self.std_key(), [src]), reverse=self.dia_desc) if src else []
        self.lb_dia.delete(0, "end")
        for d in self.dias:
            self.lb_dia.insert("end", "Ø " + dia_text(d))
        for i, d in enumerate(self.dias):
            if keep is None or d in keep:
                self.lb_dia.selection_set(i)

    def on_src_keep(self):
        self.on_src(keep=self.sel_dias())

    def sel_dias(self):
        return [self.dias[i] for i in self.lb_dia.curselection()]

    def source_items(self):
        """Skład pierwszego zestawu klasy źródłowej (do rysunku): (łeb, nakrętka) albo ([], [])."""
        std, src = self.std_key(), self.cb_src.get()
        if not (std and src):
            return [], []
        if (std, src) not in self._comp:
            res = None
            try:
                for s in self.db.std_sets(std):
                    if src in self.db.std_set_materials(std, s[0]):
                        res = self.app.components_from_set(std, s[0], src)
                        if res:
                            break
            except Exception:
                res = None
            self._comp[(std, src)] = res or ([], [])
        return self._comp[(std, src)]

    def pv_state(self):
        if not hasattr(self, "cb_src"):
            return {}
        head, nut = self.source_items()
        new = self.new_class() if hasattr(self, "cb_new") and self.cur >= 1 else None
        if new:                                           # krok 2/3: elementy z klasami po zmianie
            mp = lambda c: {"std": c["std"], "mat": self.map.get((c["std"], c["mat"]), c["mat"])}
            head, nut = [mp(c) for c in head], [mp(c) for c in nut]
            cap = T("Podgląd: wymiary jak w klasie %s, elementy zestawu z klasami po zmianie (klasa śruby %s).") % (self.cb_src.get(), new)
        else:
            cap = T("Podgląd: klasa źródłowa %s i skład jej pierwszego zestawu. Zostaną skopiowane wszystkie jej średnice i zestawy.") % (self.cb_src.get() or "-")
        return {"std": self.std_key(), "mats": [self.cb_src.get()] if self.cb_src.get() else [],
                "dias": self.sel_dias(), "head": head, "nut": nut, "caption": cap}

    def refresh_side(self):
        self.pv.refresh()

    def leave1(self):
        if not self.std_key() or not self.cb_src.get():
            return "Wybierz normę i klasę źródłową."
        if not self.sel_dias():
            return "Zaznacz średnice."

    # ------------------------------------------------------------ krok 2
    def build2(self, f):
        f.columnconfigure(1, weight=1)
        f.rowconfigure(3, weight=1)
        ttk.Label(f, text="Wybierz nową klasę. Nie ma jej na liście? Dodaj ją do słownika poniżej.",
                  style="Sub.TLabel").grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 10))
        ttk.Label(f, text="Nowa klasa").grid(row=1, column=0, sticky="w", padx=(0, 16))
        self.cb_new = ttk.Combobox(f, state="readonly", width=34)
        self.cb_new.grid(row=1, column=1, sticky="w")
        self.cb_new.bind("<<ComboboxSelected>>", lambda e: self.pv.refresh())
        add = ttk.Frame(f)
        add.grid(row=2, column=0, columnspan=3, sticky="w", pady=(8, 8))
        self.v_nkey, self.v_nrun = tk.StringVar(), tk.StringVar()
        ttk.Label(add, text="Brak klasy? Kod:").pack(side="left")
        ttk.Entry(add, textvariable=self.v_nkey, width=12).pack(side="left", padx=6)
        ttk.Label(add, text="Nazwa:").pack(side="left")
        ttk.Entry(add, textvariable=self.v_nrun, width=16).pack(side="left", padx=6)
        ttk.Button(add, text=T("Dodaj do słownika"), command=self.add_class).pack(side="left", padx=6)
        box = ttk.Frame(f)
        box.grid(row=3, column=0, columnspan=3, sticky="nsew")
        ttk.Label(box, text="Klasy podkładek i nakrętek w zestawach nowej klasy (dwuklik = zmień). Np. dla śruby 5.6 "
                            "nakrętka klasy 5 zamiast 8.", wraplength=900, style="Hint.TLabel").pack(anchor="w")
        fr, self.tr_map = make_tree(box, ("Element (norma)", "Klasa w źródle", "Klasa w nowych zestawach"),
                                    (260, 200, 260), 7, "browse")
        fr.pack(fill="both", expand=True, pady=(4, 6))
        self.tr_map.bind("<Double-1>", self.edit_map)
        self.v_name, self.v_sets = tk.BooleanVar(value=True), tk.BooleanVar(value=True)
        ttk.Checkbutton(box, text="Zamień klasę w nazwach śrub", variable=self.v_name).pack(anchor="w")
        ttk.Checkbutton(box, text="Kopiuj też zestawy śrub", variable=self.v_sets).pack(anchor="w", pady=(2, 0))

    def fill_classes(self, select=None):
        rows = self.app.cls_rows
        self.cb_new["values"] = ["%s   |   %s" % (r[0], r[1] or r[0]) for r in rows]
        if select:
            for i, r in enumerate(rows):
                if r[0] == select:
                    self.cb_new.current(i)

    def enter2(self):
        self.fill_classes()
        key = (self.std_key(), self.cb_src.get())
        if self.map_for != key:
            self.map_for = key
            self.pairs = [tuple(p) for p in self.db.set_component_pairs(*key)]
            self.map = {p: p[1] for p in self.pairs}
        self.refresh_map()

    def refresh_map(self):
        t = self.tr_map
        t.delete(*t.get_children())
        for i, p in enumerate(self.pairs):
            t.insert("", "end", iid=str(i), values=(p[0], p[1], self.map[p]))

    def edit_map(self, event):
        iid = self.tr_map.identify_row(event.y)
        if not iid:
            return
        pair = self.pairs[int(iid)]
        dlg = ChoiceDialog(self, T("Klasa elementu"), T("Element %s: klasa w nowych zestawach (źródło: %s)") % (pair[0], pair[1]),
                           self.db.nut_materials(pair[0]), self.map[pair])
        if dlg.result:
            self.map[pair] = dlg.result
            self.refresh_map()
            self.pv.refresh()

    def add_class(self):
        key, run = self.v_nkey.get().strip(), self.v_nrun.get().strip()
        owner = recall("owner", self.app.var_owner.get())
        if not key or len(key) > 64:
            self.var_err.set(T("Kod klasy: wymagany, max 64 znaki."))
            return
        if key.lower() in [r[0].lower() for r in self.app.cls_rows]:
            self.var_err.set(T("Klasa '%s' już istnieje w słowniku.") % key)
            return
        if not is_own(owner):
            owner = "MOJA"
        if not self.app.backup_before_write():
            return

        def fn(cur):
            sql, p = insert_sql("StrengthClass", {"Key": key, "RunName": (run or key)[:64], "OwnerText": owner[:15]})
            cur.execute(sql, p)
        if self.app.write_or_report(fn):
            self.app.cls_refresh()
            self.fill_classes(select=key)
            self.v_nkey.set("")
            self.v_nrun.set("")
            self.var_err.set("")

    def new_class(self):
        i = self.cb_new.current()
        return self.app.cls_rows[i][0] if 0 <= i < len(self.app.cls_rows) else None

    def leave2(self):
        if not self.new_class():
            return "Wybierz nową klasę ze słownika (albo dodaj ją)."
        if self.new_class() == self.cb_src.get():
            return "Nowa klasa musi się różnić od źródłowej."
        std, nc = self.std_key(), self.new_class()
        if self.db.count("SetBolts", "[Standard]=? AND [Material]=?", (std, nc)) or \
                self.db.count("SetOfBolts", "[Standard]=? AND [Material]=?", (std, nc)):
            return T("Norma %s ma już wiersze dla klasy %s.") % (std, nc)

    # ------------------------------------------------------------ krok 3
    def build3(self, f):
        ttk.Label(f, text="Sprawdź podsumowanie. Przed zapisem program jeszcze raz poprosi o potwierdzenie i zrobi kopię "
                          "zapasową bazy.", style="Sub.TLabel", wraplength=900).pack(anchor="w", pady=(0, 14))
        self.v_owner = tk.StringVar(value=recall("owner", self.app.var_owner.get()))
        row = ttk.Frame(f)
        row.pack(anchor="w", pady=(0, 14))
        ttk.Label(row, text="Właściciel wpisu (max 15 znaków)").pack(side="left", padx=(0, 12))
        self.en_owner = ttk.Entry(row, textvariable=self.v_owner, width=14)
        self.en_owner.pack(side="left")
        self.var_sum = tk.StringVar()
        ttk.Label(f, textvariable=self.var_sum, wraplength=900, justify="left").pack(anchor="w")

    def enter3(self):
        std, src, nc = self.std_key(), self.cb_src.get(), self.new_class()
        dias = self.sel_dias()
        c, p = in_clause("Diameter", dias)
        n_b = self.db.count("SetBolts", "[Standard]=? AND [Material]=? AND " + c, [std, src] + p)
        n_s = len(self.db.set_rows(std, src, dias)[0]) if self.v_sets.get() else 0
        txt = [T("Norma: %s") % std, T("Skopiowana klasa: %s  →  nowa klasa: %s") % (src, nc),
               T("Średnice: %s") % ", ".join(dia_text(d) for d in dias),
               "", T("Wymiary śrub do skopiowania: %d wierszy") % n_b,
               T("Zestawy śrub do skopiowania: %d wierszy") % n_s]
        ch = [(a[0], a[1], self.map[a]) for a in self.pairs if self.map[a] != a[1]]
        if ch:
            txt += ["", T("Zmienione klasy elementów:")] + ["   %s: %s → %s" % x for x in ch]
        self.var_sum.set("\n".join(txt))
        self.var_story.set(T("Powstanie nowa klasa '%s' w normie %s: skopiuję %d wierszy wymiarów śrub i %d wierszy zestawów z klasy '%s'. "
                             "Klasa źródłowa i wpisy fabryczne zostają bez zmian.") % (nc, std, n_b, n_s, src))

    def leave3(self):
        o = self.v_owner.get().strip()
        if not o or len(o) > 15 or not is_own(o):
            return "Właściciel: max 15 znaków, nie DSC/AUTODESK.", self.en_owner

    def finish(self):
        a = self.app
        i = self.std_index()
        a.cb_acstd.current(i)
        a.ac_on_std()
        a.cb_acsrc.set(self.cb_src.get())
        a.ac_on_src()
        a.lb_acdia.selection_clear(0, "end")
        for d in self.sel_dias():
            if d in a.ac_dias:
                a.lb_acdia.selection_set(a.ac_dias.index(d))
        a.cb_accls.current(next(k for k, r in enumerate(a.cls_rows) if r[0] == self.new_class()))
        for p in a.ac_pairs:
            if tuple(p) in self.map:
                a.ac_map[tuple(p)] = self.map[tuple(p)]
        a.v_acown.set(self.v_owner.get().strip())
        a.v_acname.set(self.v_name.get())
        a.v_acsets.set(self.v_sets.get())
        remember("owner", self.v_owner.get().strip())
        if a.ac_save():
            self.destroy()
