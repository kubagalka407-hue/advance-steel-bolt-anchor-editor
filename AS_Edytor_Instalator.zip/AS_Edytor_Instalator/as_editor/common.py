# -*- coding: utf-8 -*-
"""Małe funkcje pomocnicze: cytowanie nazw SQL, budowa INSERT/kopii, właściciel wpisu, format średnic."""
from as_editor.config import FACTORY


def q(name):
    return "[" + name.replace("]", "]]") + "]"


def is_own(owner):
    return (owner or "") not in FACTORY


def fmt_dia(d):
    return ("%g" % d)


def insert_sql(table, row):
    cols = list(row.keys())
    return ("INSERT INTO %s (%s) VALUES (%s)" % (q(table), ",".join(q(c) for c in cols),
                                                  ",".join("?" * len(cols))),
            [row[c] for c in cols])


def clone_sql(table, cols, overrides, where, wparams, replaces=None):
    """INSERT ... SELECT kopiujący wiersze tej samej tabeli z podmianą wybranych kolumn."""
    sel, params = [], []
    for c in cols:
        if c in overrides:
            sel.append("?")
            params.append(overrides[c])
        elif replaces and c in replaces and replaces[c][0]:
            sel.append("REPLACE(%s,?,?)" % q(c))
            params += list(replaces[c])
        else:
            sel.append(q(c))
    sql = "INSERT INTO %s (%s) SELECT %s FROM %s WHERE %s" % (
        q(table), ",".join(q(c) for c in cols), ",".join(sel), q(table), where)
    return sql, params + list(wparams)


def in_clause(col, values):
    return "%s IN (%s)" % (q(col), ",".join("?" * len(values))), list(values)
