# -*- coding: utf-8 -*-
"""Nowoczesny motyw (Sun Valley / sv-ttk, licencja MIT, dołączony w as_editor/vendor). Brak motywu nie psuje programu."""
import sys

from as_editor.ui.widgets import ttk

FONT = "Segoe UI" if sys.platform == "win32" else "DejaVu Sans"


def apply_theme(root):
    """Włącza jasny motyw Sun Valley; zwraca True, gdy się udało (inaczej zostaje domyślny wygląd ttk)."""
    try:
        from as_editor.vendor import sv_ttk
        sv_ttk.set_theme("light", root)
        root.update_idletasks()
        root.tk.eval("configure_colors")          # kolory bazowe motywu (bez czekania na zdarzenie ThemeChanged)
        root.configure(background="#fafafa")
        return True
    except Exception:
        return False


def setup_fonts_and_styles(root, themed):
    st = ttk.Style(root)
    st.configure("Treeview", rowheight=26 if themed else 22)
    st.configure("Hint.TLabel", foreground="#666666")
    st.configure("Ok.TLabel", foreground="#0a7a0a")
    st.configure("Err.TLabel", foreground="#b00000")
    st.configure("Title.TLabel", font=(FONT, 22, "bold"))
    st.configure("Sub.TLabel", font=(FONT, 11), foreground="#666666")
    st.configure("CardTitle.TLabel", font=(FONT, 15, "bold"))
    st.configure("Step.TLabel", font=(FONT, 10), foreground="#888888")
    st.configure("StepOn.TLabel", font=(FONT, 10, "bold"), foreground="#0b5cad")
    st.configure("StepDone.TLabel", font=(FONT, 10), foreground="#0a6a0a")
    st.configure("BigTitle.TLabel", font=(FONT, 20, "bold"))
    st.configure("TileTitle.TLabel", font=(FONT, 12, "bold"))
    st.configure("CardTitleOn.TLabel", font=(FONT, 15, "bold"), foreground="#0b5cad")
    st.configure("HelpDot.TLabel", font=(FONT, 9, "bold"), foreground="#ffffff", background="#0b5cad", padding=(5, 0))
    st.configure("Body.TLabel", font=(FONT, 11))
    st.configure("Chevron.TLabel", font=(FONT, 20), foreground="#8a96a3")
    st.configure("Crumb.TLabel", font=(FONT, 12, "bold"))
    st.configure("Big.TButton", font=(FONT, 11), padding=(14, 8))
