# -*- coding: utf-8 -*-
"""Małe funkcje pomocnicze: cytowanie nazw SQL, budowa INSERT/kopii, właściciel wpisu, format średnic."""
from as_editor.config import FACTORY


def q(name):
    return "[" + name.replace("]", "]]") + "]"


def is_own(owner):
    return (owner or "") not in FACTORY


def fmt_dia(d):
    return ("%g" % d)


def inch_name(d):
    """Średnica w calach ('1/2"', '1-1/4"') dla wymiarów calowych (wielokrotności 1/16", np. 12.7, 15.875, 19.05); inaczej ''.
    Liczby całkowite w mm (M12, M24, M27...) są zawsze metryczne."""
    try:
        d = float(d)
    except (TypeError, ValueError):
        return ""
    if d < 6 or abs(d - round(d)) < 1e-9:
        return ""
    n = round(d / 25.4 * 16)
    if n < 4 or abs(d - n * 25.4 / 16) > 0.011:
        return ""
    whole, rest = divmod(n, 16)
    if rest == 0:
        return '%d"' % whole
    g = 1
    for k in (8, 4, 2):
        if rest % k == 0:
            g = k
            break
    frac = "%d/%d" % (rest // g, 16 // g)
    return ('%d-%s"' % (whole, frac)) if whole else '%s"' % frac


def dia_text(d):
    """Średnica do wyświetlenia: dla calowych '1/2" (12.7)', dla metrycznych '12'. Tylko do pokazywania (nie do wpisywania w pola)."""
    name = inch_name(d)
    return ("%s (%s)" % (name, fmt_dia(d))) if name else fmt_dia(d)


def insert_sql(table, row):
    cols = list(row.keys())
    return ("INSERT INTO %s (%s) VALUES (%s)" % (q(table), ",".join(q(c) for c in cols),
                                                  ",".join("?" * len(cols))),
            [row[c] for c in cols])


def clone_sql(table, cols, overrides, where, wparams, replaces=None):
    """INSERT ... SELECT kopiujący wiersze tej samej tabeli z podmianą wybranych kolumn."""
    sel, params = [], []
    for c in cols:
        if c in overrides:
            sel.append("?")
            params.append(overrides[c])
        elif replaces and c in replaces and replaces[c][0]:
            sel.append("REPLACE(%s,?,?)" % q(c))
            params += list(replaces[c])
        else:
            sel.append(q(c))
    sql = "INSERT INTO %s (%s) SELECT %s FROM %s WHERE %s" % (
        q(table), ",".join(q(c) for c in cols), ",".join(sel), q(table), where)
    return sql, params + list(wparams)


def in_clause(col, values):
    return "%s IN (%s)" % (q(col), ",".join("?" * len(values))), list(values)
