# -*- coding: utf-8 -*-
"""Okno 'Dodaj kotwę do normy': formularz jednej kotwy w istniejącej normie."""
from as_editor.anchors_logic import ANCHOR_DEF_COLS, ANCHOR_LABELS, ANCHOR_TIPS, anchor_positions, anchor_weight, build_anchor_def_row, build_anchor_name_row, empty_hole_row, pick_dia, rename_part, zone_of
from as_editor.bolts_logic import parse_lengths
from as_editor.common import fmt_dia, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER, MAX_ITEMS, recall, remember
from as_editor.i18n import T
from as_editor.ui.anchor_shape import DEFAULT_PLATE, check_dims, draw as shape_draw, num, resolve_items
from as_editor.ui.dialogs import CompDialog
from as_editor.ui.widgets import add_tip, ask_range, clean_paste, fit_window, make_tree, messagebox, tk, ttk


class SingleAnchorDialog(tk.Toplevel):
    """Dodanie JEDNEJ kotwy do istniejącej normy (zestawu kotew): jeden formularz z wszystkimi parametrami.
    Typ, klasa, zestaw i źródło podpowiadane są z kotew tej normy; wymiary zależą od typu kotwy."""

    SKIP = ("Length", "Weight", "PartName")      # pola z osobnymi kontrolkami (długości, ciężar, nr części)

    def __init__(self, app, std_key, template_id=None, modal=True, mode=None):
        """mode: None (zwykły formularz) | 'length' (dopisz długości) | 'dia' (nowa średnica) | 'class' (nowa klasa)."""
        super().__init__(app.root)
        self.app, self.db, self.std = app, app.db, std_key
        self.title("Dodaj kotwę do normy: %s" % std_key)
        fit_window(self, 1200, 740, 960, 560)
        self.transient(app.root)
        self.names = self.db.anchor_names(std_key)
        self.tpl_shown = []
        self.tpl_names = self.names                      # kotwy, z których wczytywany jest wzorzec (domyślnie ta sama norma)
        self.zone = {"top": [], "below": [], "end": []}
        self.pvars, self.tpl_defs = {}, {}
        self.type_rows = app.an_type_rows
        self.v_dia, self.v_len, self.v_w, self.v_part = (tk.StringVar() for _ in range(4))
        self.v_owner = tk.StringVar(value=recall("owner", DEFAULT_OWNER))
        self.v_plate = tk.StringVar(value=fmt_dia(DEFAULT_PLATE))
        self.v_grout = tk.StringVar(value="0")
        self.v_shape = tk.StringVar()
        self.v_prevhint = tk.StringVar()
        self.v_expl = tk.BooleanVar(value=True)
        self.v_over = tk.BooleanVar(value=False)
        self.v_skipmiss = tk.BooleanVar(value=False)
        self.miss = []
        self.v_hint = tk.StringVar()
        self.items, self.tpl = [], None
        self.mode, self.append_id, self.exist_lens = mode, None, set()
        self.lockable = []
        self._build()
        used = sorted({n["ClassID"] for n in self.names})
        tpl = next((n for n in self.names if n["ID"] == template_id), None) or (self.names[0] if self.names else None)
        if tpl:
            self.load_template(tpl["ID"])
        elif self.type_rows:
            self.cb_type.current(0)
            self.rebuild_params()
        self.v_hint.set("Norma ma kotew: %d, typów: %d. Wzorzec podpowiada typ, klasę, zestaw, wymiary i skład - "
                        "popraw to, co się różni, wpisz średnicę i długości." % (len(self.names), len(used)))
        if tpl and mode:
            self.apply_mode(tpl)
        if modal:
            self.grab_set()
            self.wait_window()

    # ------------------------------------------------------------------ układ
    def _build(self):
        b = ttk.Frame(self)
        b.pack(side="bottom", fill="x", padx=10, pady=6)      # przyciski najpierw: nie znikają w małym oknie
        ttk.Label(self, textvariable=self.v_hint, wraplength=1010, foreground="#444").pack(anchor="w", padx=10, pady=(8, 2))
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, padx=10, pady=4)
        left = ttk.LabelFrame(body, text="Kotwa")
        left.pack(side="left", fill="y", padx=(0, 8))
        g = ttk.Frame(left)
        g.pack(padx=8, pady=6)

        def row(r, text, w):
            ttk.Label(g, text=text).grid(row=r, column=0, sticky="w", pady=3, padx=(0, 6))
            w.grid(row=r, column=1, sticky="w", pady=3)
        row(0, "Norma kotwy", ttk.Label(g, text=self.std, font=("Segoe UI", 9, "bold")))
        self.cb_tstd = ttk.Combobox(g, width=34, state="readonly",
                                    values=["%s   |   %s" % (r[0], r[1]) for r in self.app.an_std_rows])
        keys = [r[0] for r in self.app.an_std_rows]
        if self.std in keys:
            self.cb_tstd.current(keys.index(self.std))
        self.cb_tstd.bind("<<ComboboxSelected>>", self.on_tstd)
        self.lockable.append(self.cb_tstd)
        row(1, "Norma wzorca (np. inna norma Hilti)", self.cb_tstd)
        tf = ttk.Frame(g)
        self.cb_tpl = ttk.Combobox(tf, width=24, state="readonly")
        self.cb_tpl.bind("<<ComboboxSelected>>", self.on_tpl)
        self.cb_ttype = ttk.Combobox(tf, width=11, state="readonly", values=[T("Wszystkie typy")] + [
            "%s | %s" % (r[0], r[1]) for r in self.app.an_type_rows])
        self.cb_ttype.current(0)
        self.cb_ttype.bind("<<ComboboxSelected>>", self.on_ttype)
        self.cb_tpl.pack(side="left")
        self.cb_ttype.pack(side="left", padx=(4, 0))
        self.fill_tpl_list()
        row(2, "Wzorzec (kotwa z tej normy; z prawej filtr typu)", tf)
        self.lockable += [self.cb_tpl, self.cb_ttype]
        self.cb_type = ttk.Combobox(g, width=34, state="readonly",
                                    values=["%s   |   %s" % (r[0], r[1]) for r in self.type_rows])
        self.cb_type.bind("<<ComboboxSelected>>", lambda e: self.rebuild_params())
        row(3, "Typ kotwy", self.cb_type)
        self.lockable.append(self.cb_type)
        self.cb_dia = ttk.Combobox(g, width=12, textvariable=self.v_dia,
                                   values=[fmt_dia(float(r[0])) for r in self.app.an_dia_rows])
        row(4, "Średnica Ø [mm]", self.cb_dia)
        self.lockable.append(self.cb_dia)
        cls_map = {r[0]: (r[1] or r[0]) for r in self.app.cls_rows}
        mats = self.db.anchor_materials(self.std)
        self.cb_cls = ttk.Combobox(g, width=34, values=["%s   |   %s" % (m, cls_map.get(m, m)) for m in mats])
        self.cb_cls.bind("<<ComboboxSelected>>", lambda e: self.cb_cls.set(self.cb_cls.get().split("   |   ")[0]))
        row(5, "Klasa (lub wpisz nową)", self.cb_cls)
        self.lockable.append(self.cb_cls)
        self.cb_set = ttk.Combobox(g, width=34, values=[r[0] for r in self.db.anchor_set_names(self.std)])
        row(6, "Zestaw (lub wpisz nowy)", self.cb_set)
        self.lockable.append(self.cb_set)
        self.cb_src = ttk.Combobox(g, width=34, values=[r[0] for r in self.app.an_src_rows])
        row(7, "Źródło / norma (max 15)", self.cb_src)
        self.lockable.append(self.cb_src)
        row(8, "Właściciel (max 15)", ttk.Entry(g, textvariable=self.v_owner, width=18))
        ttk.Checkbutton(g, text="Możliwe rozbicie zestawu", variable=self.v_expl).grid(row=9, column=1, sticky="w")
        ttk.Label(left, text="Skład zestawu: nakrętki i podkładki").pack(anchor="w", padx=8, pady=(8, 0))
        fr, self.tr_comp = make_tree(left, ("Strefa", "Nr", "Norma elementu", "Klasa"), (104, 28, 126, 70), 6, "browse")
        fr.pack(fill="x", padx=8)
        bar = ttk.Frame(left)
        bar.pack(fill="x", padx=8, pady=4)
        for txt, cmd in (("+ Nad blachą", lambda: self.add_comp("top")), ("+ Pod blachą", lambda: self.add_comp("below")),
                         ("+ Koniec kotwy", lambda: self.add_comp("end"))):
            bt = ttk.Button(bar, text=txt, command=cmd)
            bt.pack(side="left", padx=2)
            self.lockable.append(bt)
        bar2 = ttk.Frame(left)
        bar2.pack(fill="x", padx=8, pady=(0, 4))
        for txt, cmd in (("▲", lambda: self.move_comp(-1)), ("▼", lambda: self.move_comp(1)),
                         ("Zamień...", self.replace_comp), ("Usuń", self.del_comp)):
            bt = ttk.Button(bar2, text=txt, command=cmd, width=9 if txt == "Zamień..." else 6 if txt == "Usuń" else 3)
            bt.pack(side="left", padx=2)
            self.lockable.append(bt)
        ttk.Label(left, text="Wiersz 1 jest najdalej od blachy, ostatni przy blasze.",
                  foreground="#666", wraplength=330).pack(anchor="w", padx=8)

        right = ttk.Frame(body)
        right.pack(side="left", fill="both", expand=True)
        top = ttk.Frame(right)
        top.pack(fill="x")
        self.fr_par = ttk.LabelFrame(top, text="Wymiary kotwy (zależne od typu)")
        self.fr_par.pack(side="left", fill="y")
        fs = ttk.LabelFrame(top, text="Kształt kotwy (schemat poglądowy)")
        fs.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self.cv = tk.Canvas(fs, width=420, height=330, bg="white", highlightthickness=0)
        self.cv.pack(fill="both", expand=True, padx=4, pady=4)
        self.cv.bind("<Configure>", lambda e: self.draw())
        mb = ttk.Frame(fs)
        mb.pack(fill="x", padx=4, pady=(0, 2))
        ttk.Label(mb, text="Blacha [mm]:").grid(row=0, column=0, sticky="w")
        ttk.Entry(mb, textvariable=self.v_plate, width=7).grid(row=0, column=1, sticky="w", padx=2)
        ttk.Label(mb, text="Podlewka [mm]:").grid(row=1, column=0, sticky="w")
        ttk.Entry(mb, textvariable=self.v_grout, width=7).grid(row=1, column=1, sticky="w", padx=2)
        ttk.Label(fs, textvariable=self.v_shape, wraplength=300, foreground="#444").pack(anchor="w", padx=4, pady=(0, 4))
        self.focus_col = None
        self.sel_len = None                                  # długość pokazywana na schemacie
        self._draw_job = None
        for v in (self.v_dia, self.v_len, self.v_plate, self.v_grout):
            v.trace_add("write", lambda *a: self.schedule_draw())
        fl = ttk.LabelFrame(right, text="Długości, ciężar, numer części")
        fl.pack(fill="x", pady=6)
        ttk.Label(fl, text="Długości [mm] (lista, zakresy np. 300-1000/100 albo kolumna wklejona z Excela)").grid(row=0, column=0, sticky="w", padx=6, pady=3)
        lf = ttk.Frame(fl)
        lf.grid(row=0, column=1, sticky="w")
        self.en_len = ttk.Entry(lf, textvariable=self.v_len, width=34)
        self.en_len.pack(side="left")
        clean_paste(self.en_len)                          # wklejanie kolumny z Excela
        self.btn_range = ttk.Button(lf, text="Od-do co...", command=self.add_range)
        self.btn_range.pack(side="left", padx=4)
        self.lockable_len = [self.en_len, self.btn_range]
        ttk.Label(fl, text="Ciężar pierwszej długości [kg] (puste = przeliczony ze wzorca)").grid(row=1, column=0, sticky="w", padx=6, pady=3)
        ttk.Entry(fl, textvariable=self.v_w, width=14).grid(row=1, column=1, sticky="w")
        ttk.Label(fl, text="Numer części pierwszej długości (puste = automatyczny)").grid(row=2, column=0, sticky="w", padx=6, pady=3)
        ttk.Entry(fl, textvariable=self.v_part, width=34).grid(row=2, column=1, sticky="w")
        ttk.Label(right, text="Podgląd do zapisu (aktualizuje się sam; kliknij wiersz, aby zobaczyć tę długość "
                              "na schemacie):").pack(anchor="w")
        ttk.Label(right, textvariable=self.v_prevhint, foreground="#b00", wraplength=700).pack(anchor="w")
        fr, self.tr_prev = make_tree(right, ("Długość", "Nr części", "Ciężar", "Status"), (80, 300, 80, 280), 5)
        fr.pack(fill="both", expand=True)
        self.tr_prev.bind("<<TreeviewSelect>>", self.on_prev_sel)
        ttk.Checkbutton(b, text="Nadpisz istniejącą MOJĄ kotwę (ta sama średnica, klasa, zestaw)",
                        variable=self.v_over).pack(side="left")
        ttk.Checkbutton(b, text="Zapisz bez brakujących elementów", variable=self.v_skipmiss,
                        command=self.schedule_draw).pack(side="left", padx=12)
        ttk.Button(b, text="Zapisz do bazy", command=self.save).pack(side="right", padx=4)
        ttk.Button(b, text="Podgląd", command=self.preview).pack(side="right", padx=4)
        ttk.Button(b, text="Zamknij", command=self.destroy).pack(side="right", padx=4)

    # ------------------------------------------------------------------ dane
    def type_id(self):
        i = self.cb_type.current()
        return self.type_rows[i][0] if 0 <= i < len(self.type_rows) else None

    def cols(self):
        return [c for c in ANCHOR_DEF_COLS.get(self.type_id(), ANCHOR_DEF_COLS[3]) if c not in self.SKIP]

    def rebuild_params(self):
        keep = {k: v.get() for k, v in self.pvars.items()}
        for w in self.fr_par.winfo_children():
            w.destroy()
        self.pvars = {}
        for i, c in enumerate(self.cols()):
            lab = ttk.Label(self.fr_par, text=T(ANCHOR_LABELS[c]) + (" [mm]" if c != "NumberOfHeadEdges" else ""))
            lab.grid(row=i // 2, column=(i % 2) * 2, sticky="w", padx=(8, 4), pady=3)
            add_tip(lab, T(ANCHOR_TIPS[c]))
            v = tk.StringVar(value=keep.get(c, ""))
            v.trace_add("write", lambda *a: self.schedule_draw())
            self.pvars[c] = v
            e = ttk.Entry(self.fr_par, textvariable=v, width=9)
            e.grid(row=i // 2, column=(i % 2) * 2 + 1, sticky="w", pady=3)
            e.bind("<FocusIn>", lambda ev, col=c: self.set_focus(col))
        self.schedule_draw()

    def load_template(self, anchor_id):
        n = next((x for x in self.tpl_names if x["ID"] == anchor_id), None)
        if not n:
            return
        defs, _ = self.db.anchor_children([anchor_id])
        rows = defs.get(anchor_id, [])
        ti = [i for i, r in enumerate(self.type_rows) if r[0] == n["ClassID"]]
        if ti:
            self.cb_type.current(ti[0])
        if anchor_id not in [x["ID"] for x in self.tpl_shown]:      # wzorzec spoza filtra typu: zdejmij filtr
            self.cb_ttype.current(0)
            self.fill_tpl_list()
        self.cb_tpl.current([x["ID"] for x in self.tpl_shown].index(anchor_id))
        self.rebuild_params()
        self.cb_cls.set(n["MaterialKey"])
        self.cb_set.set(n["SetName"])
        self.cb_src.set(n.get("Source") or "")
        self.v_expl.set(bool(n.get("Explodable")))
        first = rows[0] if rows else {}
        for c, v in self.pvars.items():
            val = first.get(c)
            v.set("" if val is None else fmt_dia(val) if isinstance(val, float) else str(val))
        self.v_len.set("%s" % ", ".join(fmt_dia(r["Length"]) for r in rows if r.get("Length") is not None))
        self.v_w.set("")
        self.v_part.set("")
        self.tpl = (float(n["Diameter"]), first.get("Length"), first.get("Weight"))      # do skalowania ciężaru
        self.zone = {"top": [], "below": [], "end": []}
        comps = []
        for k in range(1, MAX_ITEMS + 1):
            din, pos, m = n.get("DIN%d" % k), n.get("Position%d" % k), n.get("Material%d" % k)
            if din not in (None, "", "-") and pos:
                comps.append((pos, {"std": din, "mat": m}))
        for pos, c in sorted(comps, key=lambda t: abs(t[0])):
            self.zone[zone_of(pos)].append(c)
        self.refresh_comps()

    def on_tpl(self, _=None):
        i = self.cb_tpl.current()
        if 0 <= i < len(self.tpl_shown):
            self.load_template(self.tpl_shown[i]["ID"])

    def on_ttype(self, _=None):
        """Filtr typu na liście wzorców: pokazuje tylko kotwy wybranego typu."""
        self.fill_tpl_list()
        self.cb_tpl.set("")
        if self.tpl_shown:
            self.load_template(self.tpl_shown[0]["ID"])
        else:
            messagebox.showinfo("Wzorzec", "Brak kotew tego typu w wybranej normie.")

    def fill_tpl_list(self):
        i = self.cb_ttype.current()
        tid = self.type_rows[i - 1][0] if 1 <= i <= len(self.type_rows) else None
        self.tpl_shown = [n for n in self.tpl_names if tid is None or n["ClassID"] == tid]
        self.cb_tpl["values"] = ["%s | Ø%s | %s | %s" % (n["ID"], fmt_dia(float(n["Diameter"])), n["MaterialKey"], n["SetName"])
                                 for n in self.tpl_shown]

    def on_tstd(self, _=None):
        """Wzorzec z innej normy: wczytuje listę jej kotew i pierwszą z nich (norma docelowa zostaje bez zmian)."""
        i = self.cb_tstd.current()
        if i < 0:
            return
        self.tpl_names = self.db.anchor_names(self.app.an_std_rows[i][0])
        self.fill_tpl_list()
        self.cb_tpl.set("")
        if self.tpl_names:
            self.load_template((self.tpl_shown or self.tpl_names)[0]["ID"])
        else:
            messagebox.showinfo("Wzorzec", "Ta norma nie ma kotew.")

    def refresh_comps(self):
        t = self.tr_comp
        t.delete(*t.get_children())
        names = {"top": T("nad blachą"), "below": T("pod blachą"), "end": T("koniec kotwy")}
        self.comp_map = {}
        t.tag_configure("miss", foreground="#b00")
        for z in ("top", "below", "end"):
            for i, c in enumerate(self.zone[z]):
                iid = "%s%d" % (z[0], i)
                t.insert("", "end", iid=iid, values=(names[z], i + 1, c["std"], c["mat"]))
                self.comp_map[iid] = (z, i)
        try:
            self.mark_missing()
        except Exception:
            pass
        self.schedule_draw()

    def add_comp(self, zone):
        if sum(len(v) for v in self.zone.values()) >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS)
            return
        try:
            dia = float(self.v_dia.get().replace(",", "."))
        except ValueError:
            dia = None
        title = {"top": T("nad blachą"), "below": T("pod blachą"), "end": T("koniec kotwy")}[zone]
        default = "washer" if (zone != "end" and not self.zone[zone]) else "nut"
        dlg = CompDialog(self, self.db, T("Dodaj element - ") + title, dia, default)
        if dlg.result:
            self.zone[zone].append(dlg.result)
            self.refresh_comps()

    def move_comp(self, direction):
        sel = self.tr_comp.selection()
        if not (sel and sel[0] in self.comp_map):
            return
        z, i = self.comp_map[sel[0]]
        j = i + direction
        lst = self.zone[z]
        if 0 <= j < len(lst):
            lst[i], lst[j] = lst[j], lst[i]
            self.refresh_comps()
            self.tr_comp.selection_set("%s%d" % (z[0], j))

    def del_comp(self):
        sel = self.tr_comp.selection()
        if sel and sel[0] in self.comp_map:
            z, i = self.comp_map[sel[0]]
            del self.zone[z][i]
            self.refresh_comps()

    def add_range(self):
        """Kreator zakresu: dopisuje 'od-do/krok' do pola długości."""
        r = ask_range(self)
        if r:
            cur = self.v_len.get().strip()
            self.v_len.set((cur + ", " if cur else "") + r)

    def replace_comp(self):
        """Zamienia zaznaczony element zestawu na inny (np. gdy w bazie nie ma go dla tej średnicy)."""
        sel = self.tr_comp.selection()
        if not (sel and sel[0] in self.comp_map):
            messagebox.showinfo("Zamień", "Zaznacz element zestawu na liście.")
            return
        z, i = self.comp_map[sel[0]]
        dia = num(self.v_dia.get())
        title = {"top": T("nad blachą"), "below": T("pod blachą"), "end": T("koniec kotwy")}[z]
        dlg = CompDialog(self, self.db, T("Zamień element - ") + title, dia, "nut")
        if dlg.result:
            self.zone[z][i] = dlg.result
            self.refresh_comps()
            self.tr_comp.selection_set(sel[0])

    def mark_missing(self):
        """Elementy zestawu, których nie ma w bazie dla bieżącej średnicy, są oznaczone na czerwono."""
        dia = num(self.v_dia.get())
        for iid, (z, i) in self.comp_map.items():
            c = self.zone[z][i]
            bad = bool(dia) and pick_dia(self.db.nut_diameters(c["std"], c["mat"]), dia) is None
            vals = list(self.tr_comp.item(iid, "values"))
            vals[2] = (T("(brak) ") if bad else "") + str(c["std"])
            self.tr_comp.item(iid, values=vals, tags=("miss",) if bad else ())

    def apply_mode(self, tpl):
        """Przygotowuje formularz do szybkiej akcji: + długość / + średnica / + klasa (wzorzec = zaznaczona kotwa)."""
        dia0 = fmt_dia(float(tpl["Diameter"]))
        own = is_own(tpl.get("OwnerText"))
        lens = self.v_len.get()
        if self.mode == "dia":
            self.v_dia.set("")
            self.cb_dia.focus_set()
            self.v_hint.set(T("Nowa średnica: wpisz średnicę i długości. Klasa, zestaw i wymiary są ze wzorca (Ø%s) - "
                              "popraw to, co się różni.") % dia0)
        elif self.mode == "class":
            self.v_dia.set(dia0)
            self.cb_cls.set("")
            self.cb_cls.focus_set()
            self.v_hint.set(T("Nowa klasa: wpisz klasę (lub wybierz z listy). Średnica Ø%s, zestaw i wymiary są "
                              "ze wzorca. Jeśli zestaw ma inne nakrętki w tej klasie, zmień je w składzie.") % dia0)
        elif self.mode == "length":
            self.v_dia.set(dia0)
            self.exist_lens = {num(x) for x in lens.replace(" ", "").split(",") if num(x) is not None}
            if own:
                self.append_id = tpl["ID"]
                self.v_len.set("")
                for w in self.lockable:
                    w.state(["disabled"])
                self.v_hint.set(T("Nowa długość: wpisz długości (lista lub zakresy). Zostaną dopisane do Twojej kotwy "
                                  "Ø%s (klasa %s, zestaw %s). Już istniejące długości: %s.") % (
                    dia0, tpl["MaterialKey"], tpl["SetName"], lens or "-"))
            else:
                self.cb_set.set(("%s_%s" % (tpl["SetName"], self.v_owner.get().strip()))[:64])
                self.v_hint.set(T("To kotwa fabryczna - nie zmieniam jej. Zapiszę Twoją kopię z nową nazwą zestawu "
                                  "(zmień ją, jeśli chcesz) i dopiszesz w niej nowe długości (są już wpisane: %s).") % (lens or "-"))
        self.schedule_draw()

    # ------------------------------------------------------------------ schemat kształtu
    def on_prev_sel(self, _=None):
        """Schemat pokazuje długość zaznaczoną w podglądzie zapisu."""
        sel = self.tr_prev.selection()
        if sel:
            self.sel_len = num(self.tr_prev.item(sel[0], "values")[0])
            self.schedule_draw()

    def set_focus(self, col):
        self.focus_col = col
        self.draw()

    def schedule_draw(self):
        if self._draw_job:
            self.after_cancel(self._draw_job)
        self._draw_job = self.after(120, self.draw)

    def draw(self):
        """Schemat kotwy rysowany na żywo z wpisanych wymiarów i składu zestawu."""
        self._draw_job = None
        try:
            lens = parse_lengths(self.v_len.get())
        except ValueError:
            lens = []
        P = {c: num(v.get()) for c, v in self.pvars.items()}
        L = (self.sel_len if self.sel_len in lens else lens[0]) if lens else None
        dia = num(self.v_dia.get())
        items = {z: resolve_items(self.db, self.zone[z], dia) for z in ("top", "below", "end")}
        info = shape_draw(self.cv, self.type_id(), P, dia, L, items,
                          plate=num(self.v_plate.get(), 0.0), grout=num(self.v_grout.get(), 0.0), focus=self.focus_col)
        try:
            self.mark_missing()
        except Exception:
            pass
        warn = check_dims(self.type_id(), P, L)
        self.v_shape.set(info + ("  " + " ".join(warn) if warn else ""))
        try:
            self.preview(silent=True)
        except Exception as e:                               # brak bazy / nietypowe dane: podgląd zostaje pusty
            self.v_prevhint.set(T("Podgląd niedostępny: %s") % e)

    def collect(self):
        """Zwraca (dane, błędy)."""
        errs, d = [], {}
        d["tid"] = self.type_id()
        if d["tid"] is None:
            errs.append("Wybierz typ kotwy.")
        try:
            d["dia"] = float(self.v_dia.get().replace(",", "."))
            assert d["dia"] > 0
        except (ValueError, AssertionError):
            d["dia"] = None
            errs.append("Średnica: podaj dodatnią liczbę (mm).")
        d["mat"] = self.cb_cls.get().split("   |   ")[0].strip()
        d["set"], d["src"] = self.cb_set.get().split("   |   ")[0].strip(), self.cb_src.get().strip()
        d["owner"] = self.v_owner.get().strip()
        if not d["mat"] or len(d["mat"]) > 64:
            errs.append("Klasa: wybierz z listy albo wpisz nową (max 64 znaki).")
        if not d["set"] or len(d["set"]) > 64:
            errs.append("Zestaw: wymagany, max 64 znaki.")
        if not d["src"] or len(d["src"]) > 15:
            errs.append("Źródło: wymagane, max 15 znaków.")
        if not d["owner"] or len(d["owner"]) > 15 or not is_own(d["owner"]):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        try:
            d["lens"] = parse_lengths(self.v_len.get())
            if not d["lens"]:
                raise ValueError("Podaj co najmniej jedną długość.")
        except ValueError as e:
            d["lens"] = []
            errs.append(str(e))
        params = {}
        for c, v in self.pvars.items():
            s = v.get().strip()
            try:
                params[c] = None if not s else (int(s) if c == "NumberOfHeadEdges" else float(s.replace(",", ".")))
            except ValueError:
                errs.append("%s: podaj liczbę." % T(ANCHOR_LABELS[c]))
        d["params"] = params
        try:
            d["w0"] = float(self.v_w.get().replace(",", ".")) if self.v_w.get().strip() else None
        except ValueError:
            d["w0"] = None
            errs.append("Ciężar: podaj liczbę.")
        return d, errs

    def build_defs(self, d):
        rows, l0 = [], d["lens"][0]
        for length in d["lens"]:
            r = dict(d["params"])
            r["Length"] = length
            if d["w0"]:
                r["Weight"] = anchor_weight(l0, d["w0"], d["dia"], length)
            elif self.tpl and self.tpl[2] and self.tpl[1] and self.tpl[0]:
                r["Weight"] = anchor_weight(self.tpl[1], self.tpl[2] * (d["dia"] / self.tpl[0]) ** 2, d["dia"], length)
            else:
                r["Weight"] = anchor_weight(None, None, d["dia"], length)
            r["PartName"] = rename_part(self.v_part.get().strip() or None, l0, length, d["dia"], self.std)
            rows.append(r)
        return rows

    def preview(self, silent=False):
        """Wypełnia tabelę 'Podgląd do zapisu'. silent=True: odświeżanie na bieżąco, bez okienek z błędami."""
        d, errs = self.collect()
        if errs:
            if not silent:
                messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            else:
                self.tr_prev.delete(*self.tr_prev.get_children())
                self.v_prevhint.set(T("Do uzupełnienia: ") + " ".join(errs))
            return None
        self.v_prevhint.set("")
        if self.append_id:
            return self.preview_append(d)
        self.items, miss = [], []
        for din, m, pos in anchor_positions(self.zone["top"], self.zone["below"], self.zone["end"]):
            cd = pick_dia(self.db.nut_diameters(din, m), d["dia"])
            if cd is None:
                miss.append("%s/%s" % (din, m))
            else:
                self.items.append((din, m, pos, cd))
        ex = self.db.anchor_exists(self.std, d["mat"], d["dia"], d["set"])
        self.miss = miss
        if miss and not self.v_skipmiss.get():
            status, code = T("pominięto: brak w bazie ") + ", ".join(miss), "skip"
        elif not ex:
            status, code = T("NOWA"), "new"
            if miss:
                status += T(" (bez: ") + ", ".join(miss) + ")"
        elif is_own(ex[1]) and self.v_over.get():
            status, code = T("istnieje (moja) - zostanie nadpisana"), "over"
        elif is_own(ex[1]):
            status, code = T("istnieje (moja) - pominięto (zaznacz nadpisywanie)"), "skip"
        else:
            status, code = T("istnieje (fabryczna) - pominięto"), "skip"
        defs = self.build_defs(d)
        self.tr_prev.delete(*self.tr_prev.get_children())
        for i, r in enumerate(defs):
            self.tr_prev.insert("", "end", iid=str(i), values=(fmt_dia(r["Length"]), r["PartName"], r["Weight"], status))
        if defs:                                             # zaznacz długość pokazywaną na schemacie
            i = next((i for i, r in enumerate(defs) if r["Length"] == self.sel_len), 0)
            self.tr_prev.selection_set(str(i))
        self.plan = {"d": d, "defs": defs, "code": code, "exist": ex[0] if ex else None}
        return self.plan

    def preview_append(self, d):
        """Tryb '+ długość': nowe długości dopisywane do istniejącej własnej kotwy (istniejące długości są pomijane)."""
        defs_all = self.build_defs(d)
        defs = [r for r in defs_all if r["Length"] not in self.exist_lens]
        self.tr_prev.delete(*self.tr_prev.get_children())
        for i, r in enumerate(defs_all):
            st = T("już istnieje - pominięto") if r["Length"] in self.exist_lens else T("NOWA długość")
            self.tr_prev.insert("", "end", iid=str(i), values=(fmt_dia(r["Length"]), r["PartName"], r["Weight"], st))
        if defs_all:
            i = next((i for i, r in enumerate(defs_all) if r["Length"] == self.sel_len), 0)
            self.tr_prev.selection_set(str(i))
        self.miss = []
        self.plan = {"d": d, "defs": defs, "code": "append" if defs else "skip", "exist": self.append_id}
        return self.plan

    def save_append(self, p):
        d, defs, aid = p["d"], p["defs"], self.append_id
        if not messagebox.askyesno("Potwierdź zapis", T("Dopisać %d długości do Twojej kotwy Ø%s (klasa %s, zestaw %s)?") % (
                len(defs), fmt_dia(d["dia"]), d["mat"], d["set"])):
            return
        if not self.app.backup_before_write():
            return
        did = self.db.max_id("AnchorsDefinition")
        rows_d = []
        for vals in defs:
            did += 1
            rows_d.append(build_anchor_def_row(did, aid, vals, d["owner"]))

        def fn(cur):
            for r in rows_d:
                cur.execute(*insert_sql("AnchorsDefinition", r))
        if self.app.write_or_report(fn):
            self.app.an_last_std = self.std
            self.app.reload()
            messagebox.showinfo("Gotowe", T("Dopisano %d długości. Odśwież dane w Advance Steel (przycisk 'Update defaults') "
                                            "albo uruchom go ponownie.") % len(defs))
            self.destroy()

    def save(self):
        if not self.app.need_db():
            return
        p = self.preview()
        if p is None:
            return
        if p["code"] == "append":
            self.save_append(p)
            return
        if p["code"] not in ("new", "over"):
            if self.miss and not self.v_skipmiss.get():
                messagebox.showinfo("Zapis", T("W bazie nie ma elementów zestawu: %s (dla tej średnicy).\n"
                                               "Zamień je na istniejące w składzie zestawu, dodaj je w zakładce "
                                               "'Nowa podkładka / nakrętka' albo zaznacz "
                                               "'Zapisz bez brakujących elementów'.") % ", ".join(self.miss))
            else:
                messagebox.showinfo("Zapis", "Brak kotwy do zapisu (zobacz kolumnę Status).")
            return
        d, defs = p["d"], p["defs"]
        std, dia, mat, set_name, src, owner = self.std, d["dia"], d["mat"], d["set"], d["src"], d["owner"]
        new_dia = not any(abs(dia - float(r[0])) < 1e-6 for r in self.app.an_dia_rows)
        new_src = src not in [r[0] for r in self.app.an_src_rows]
        new_set = set_name not in [x[0] for x in self.app.sets]
        new_cls = mat.lower() not in [r[0].lower() for r in self.app.cls_rows]
        msg = "Zapisać kotwę Ø%s klasa %s zestaw %s (norma %s) z %d definicjami długości?" % (
            fmt_dia(dia), mat, set_name, std, len(defs))
        for flag, text in ((new_dia, T("nową średnicę %s mm") % fmt_dia(dia)), (new_src, T("nowe źródło '%s'") % src),
                           (new_set, T("nowy zestaw '%s'") % set_name), (new_cls, T("nową klasę '%s'") % mat)):
            if flag:
                msg += T("\nZostanie dodane: %s.") % text
        if not messagebox.askyesno("Potwierdź zapis", msg):
            return
        if not self.app.backup_before_write():
            return
        nid = self.db.max_id("AnchorsName") + 1
        did = self.db.max_id("AnchorsDefinition")
        hid = self.db.max_id("AnchorsHoleDefinition") + 1
        row_n = build_anchor_name_row(nid, std, d["tid"], mat, dia, src, set_name, owner, self.v_expl.get(), self.items)
        rows_d = []
        for vals in defs:
            did += 1
            rows_d.append(build_anchor_def_row(did, nid, vals, owner))
        old = p["exist"] if p["code"] == "over" else None

        def fn(cur):
            if new_dia:
                cur.execute(*insert_sql("BoltsDiameters", {"Key": dia, "RunName": "%g mm" % dia, "Description": None}))
            if new_src:
                cur.execute(*insert_sql("Sources", {"Short": src, "Long": src}))
            if new_set:
                cur.execute(*insert_sql("Sets", {"Key": set_name[:64], "RunName": set_name[:64], "OwnerText": owner[:15]}))
            if new_cls:
                cur.execute(*insert_sql("StrengthClass", {"Key": mat[:64], "RunName": mat[:64], "OwnerText": owner[:15]}))
            if old:
                cur.execute("DELETE FROM [AnchorsDefinition] WHERE [AnchorID]=?", (old,))
                cur.execute("DELETE FROM [AnchorsHoleDefinition] WHERE [AnchorNameID]=?", (old,))
                cur.execute("DELETE FROM [AnchorsName] WHERE [ID]=?", (old,))
            cur.execute(*insert_sql("AnchorsName", row_n))
            for r in rows_d:
                cur.execute(*insert_sql("AnchorsDefinition", r))
            cur.execute(*insert_sql("AnchorsHoleDefinition", empty_hole_row(hid, nid)))
        if self.app.write_or_report(fn):
            remember("owner", owner)
            self.app.an_last_std = std
            self.app.reload()
            messagebox.showinfo("Gotowe", "Zapisano kotwę Ø%s z %d długościami. Odśwież dane w Advance Steel (przycisk "
                                          "'Update defaults') albo uruchom go ponownie." % (fmt_dia(dia), len(defs)))
            self.destroy()
