"""Edytor śrub i kotew Advance Steel."""
