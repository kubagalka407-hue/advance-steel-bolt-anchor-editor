# -*- coding: utf-8 -*-
"""Okno kotwy: dodanie wymiaru z wzorca, edycja własnej kotwy, nowa norma."""
from as_editor.anchors_logic import ANCHOR_DEF_FIELDS, zone_of
from as_editor.common import fmt_dia
from as_editor.config import MAX_ITEMS
from as_editor.ui.anchor_editor import AnchorEditorMixin
from as_editor.ui.widgets import fit_window, tk, ttk


class AnchorDialog(AnchorEditorMixin, tk.Toplevel):
    """Okno kotwy: pełna konfiguracja jednej kotwy (parametry, wymiary i długości, zestaw, schemat).
    Metody edytora (an_*) pochodzą z AnchorEditorMixin, a brakujące atrybuty (baza, słowniki,
    funkcje zapisu) pochodzą z aplikacji przez __getattr__. Stan edytora jest osobny dla każdego okna."""

    def __init__(self, app, std_key=None, template_id=None, edit_id=None):
        super().__init__(app.root)
        self.app = app
        self.root = self          # okna podrzędne (CompDialog, simpledialog) mają rodzica w tym oknie
        self.an_edit_id, self.an_tpl = None, None
        self.an_cols, self.an_prev = [], []
        self.an_class_choices, self.an_set_choices = [], []
        self.an_defs, self.an_comp_map = {}, {}
        self.an_zone = {"top": [], "below": [], "end": []}
        self.an_cur = None
        self.tr_andef = None
        self.title("Edytuj kotwę" if edit_id else "Dodaj kotwy (kilka średnic)")
        fit_window(self, 1340, 790, 1000, 600)
        self.transient(app.root)
        ttk.Label(self, wraplength=1290, foreground="#444", text=(
            "Wybierz średnicę na liście po lewej (można kilka). Tabela po prawej to wszystkie długości i wymiary kotwy: "
            "dwuklik w komórkę = edycja, 'Generuj długości...' dodaje wiele długości naraz, 'Wypełnij kolumnę...' ustawia "
            "wartość parametru dla wszystkich wierszy. Zestaw (nakrętki, podkładki) układasz niżej.")).pack(
            anchor="w", padx=10, pady=(8, 0))
        self.sub_ad = ttk.Frame(self)
        self.sub_ad.pack(fill="both", expand=True)
        self.build_anchor_def()
        self.an_fill_lists()
        if edit_id or template_id:
            self.an_prefill(edit_id or template_id, bool(edit_id))
        elif std_key:
            self.cb_anstd.set(std_key)
            self.an_std_changed()
        self.an_refresh_dias()
        self.grab_set()
        self.wait_window()

    def __getattr__(self, name):
        if name == "app":
            raise AttributeError(name)
        return getattr(self.app, name)

    def close_after_save(self):
        self.destroy()

    def an_prefill(self, anchor_id, edit):
        """Wypełnia okno danymi istniejącej kotwy: edycja (własna) albo wzorzec do dodania nowego wymiaru."""
        rows, cols = self.db.query("SELECT * FROM [AnchorsName] WHERE [ID]=?", (anchor_id,))
        if not rows:
            return
        n = dict(zip(cols, rows[0]))
        defs, holes = self.db.anchor_children([anchor_id])
        dia = float(n["Diameter"])
        key = next((v for v in self.an_dia_vals if abs(v - dia) < 1e-6), dia)
        self.cb_anstd.set(n["Standard"])
        self.an_refresh_choices()
        ti = [i for i, r in enumerate(self.an_type_rows) if r[0] == n["ClassID"]]
        if ti:
            self.cb_antype.current(ti[0])
        self.cb_ancls.set(n["MaterialKey"])
        self.cb_ansrc.set(n.get("Source") or "")
        self.cb_anset.set(n["SetName"])
        self.v_anexpl.set(bool(n.get("Explodable")))
        self.an_zone = {"top": [], "below": [], "end": []}
        comps = []
        for k in range(1, MAX_ITEMS + 1):
            din, pos, m = n.get("DIN%d" % k), n.get("Position%d" % k), n.get("Material%d" % k)
            if din not in (None, "", "-") and pos:
                comps.append((pos, {"std": din, "mat": m}))
        for pos, c in sorted(comps, key=lambda t: abs(t[0])):
            self.an_zone[zone_of(pos)].append(c)
        drows = [{f: r.get(f) for f in ANCHOR_DEF_FIELDS} for r in defs.get(anchor_id, [])]
        self.lb_andia.selection_clear(0, "end")
        self.an_cur = None
        if edit:
            self.an_edit_id = anchor_id
            self.an_defs = {key: drows}
            if key in self.an_dia_vals:
                self.lb_andia.selection_set(self.an_dia_vals.index(key))
            self.var_anhint.set("Edycja kotwy (ID %s). Zapis zastąpi jej dotychczasowe wiersze." % anchor_id)
        else:
            self.an_defs = {}
            self.an_tpl = (key, drows)
            self.var_anhint.set("Wzorzec: %s, klasa %s, Ø%s. Wybierz NOWĄ średnicę na liście - długości i wymiary skopiują się "
                                "z wzorca i przeskalują (popraw je w tabeli)." % (n["Standard"], n["MaterialKey"], fmt_dia(dia)))
        self.an_on_type()
