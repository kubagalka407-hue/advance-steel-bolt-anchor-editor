# -*- coding: utf-8 -*-
"""Zakładka Śruby -> Zestaw śrub (widok Tekla)."""
from as_editor.bolts_logic import assembly_layout, build_set_row, items_label, pitch_for, positions_for
from as_editor.common import dia_text, fmt_dia, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER, MAX_ITEMS, recall, remember
from as_editor.i18n import T
from as_editor.ui.theme import FONT
from as_editor.ui.dialogs import CompDialog, LoadDialog
from as_editor.ui.quick_set import QuickSetDialog
from as_editor.ui.widgets import COL_HEAD, COL_MISSING, COL_NUT, COL_PLATE, COL_SHANK, COL_WASHER, make_filterable, make_list, make_tree, messagebox, selected_index, tk, ttk


class BuilderMixin:
    # ------------------------------------------------------------------ widok zestawu (Tekla)
    def build_builder(self):
        """Ekran zestawu śruby: kroki od lewej do prawej. 1-2 wybór (norma, zestaw, klasy, średnice), 3 skład zestawu,
        po prawej rysunek oraz 4 podgląd i zapis."""
        f = self.tab_build
        f.columnconfigure(0, weight=0, minsize=330)
        f.columnconfigure(1, weight=3, minsize=420)
        f.columnconfigure(2, weight=3, minsize=380)
        f.rowconfigure(0, weight=1)
        # ---------------- kolumna 1: norma, zestaw, klasy, średnice ----------------
        col1 = ttk.Frame(f)
        col1.grid(row=0, column=0, sticky="ns", padx=(8, 4), pady=6)
        ttk.Button(col1, text="★ Szybko: nowy zestaw z wzoru...", command=self.quick_set).pack(anchor="w", fill="x", pady=(0, 8))
        ttk.Label(col1, text="1. Norma śruby (wpisz tekst, np. DIN, aby zawęzić listę)", font=(FONT, 9, "bold")).pack(anchor="w")
        self.cb_std = make_filterable(ttk.Combobox(col1, width=38))
        self.cb_std.pack(anchor="w", fill="x")
        self.cb_std.bind("<<ComboboxSelected>>", self.on_std)
        ttk.Label(col1, text="2. Zestaw (wybierz istniejący albo wpisz nowy kod)", font=(FONT, 9, "bold")).pack(
            anchor="w", pady=(10, 0))
        self.cb_set = ttk.Combobox(col1, width=38)
        self.cb_set.pack(anchor="w", fill="x")
        self.cb_set.bind("<<ComboboxSelected>>", self.on_set_selected)
        self.cb_set.bind("<FocusOut>", self.on_set)
        self.cb_set.bind("<Return>", self.on_set)
        self.var_allsets = tk.BooleanVar(value=False)
        ttk.Checkbutton(col1, text="pokaż wszystkie zestawy (także nieprzypisane do normy)",
                        variable=self.var_allsets, command=self.refresh_set_choices).pack(anchor="w")
        self.var_setinfo = tk.StringVar()
        ttk.Label(col1, textvariable=self.var_setinfo, wraplength=320, style="Hint.TLabel").pack(anchor="w")
        self.set_choices = []
        ttk.Label(col1, text="Nazwa zestawu na liście (dla nowego zestawu)").pack(anchor="w", pady=(6, 0))
        self.var_run = tk.StringVar()
        ttk.Entry(col1, textvariable=self.var_run, width=40).pack(anchor="w", fill="x")
        ttk.Label(col1, text="3. Klasy i średnice, dla których zapisać zestaw", font=(FONT, 9, "bold")).pack(
            anchor="w", pady=(12, 0))
        lists = ttk.Frame(col1)
        lists.pack(anchor="w", fill="both", expand=True)
        c1 = ttk.Frame(lists)
        c1.pack(side="left", padx=(0, 10), fill="y")
        ttk.Label(c1, text="Klasy śruby").pack(anchor="w")
        fr, self.lb_mat = make_list(c1, 10, 12)
        fr.pack(fill="both", expand=True)
        self.lb_mat.bind("<<ListboxSelect>>", lambda e: self.refresh_diameters())
        c2 = ttk.Frame(lists)
        c2.pack(side="left", fill="y")
        ttk.Label(c2, text="Średnice").pack(anchor="w")
        fr, self.lb_dia = make_list(c2, 10, 12)
        fr.pack(fill="both", expand=True)
        self.lb_dia.bind("<<ListboxSelect>>", lambda e: self.refresh_pdia())
        ttk.Label(col1, text="Zaznacz kilka (Ctrl / Shift) albo wszystkie - zestaw powstanie dla każdej pary klasa + średnica.",
                  wraplength=320, style="Hint.TLabel").pack(anchor="w", pady=(4, 0))

        # ---------------- kolumna 2: skład zestawu ----------------
        col2 = ttk.Frame(f)
        col2.grid(row=0, column=1, sticky="nsew", padx=4, pady=6)
        ttk.Label(col2, text="4. Skład zestawu - fizycznie od łba w dół (zaznacz wiersz, aby edytować)",
                  font=(FONT, 9, "bold")).pack(anchor="w")
        fr, self.tr_stack = make_tree(col2, ("Element", "Norma", "Klasa", "Wymiary (dla podglądu Ø)"),
                                      (150, 100, 70, 200), 8, "browse")
        fr.pack(fill="x")
        self.tr_stack.tag_configure("fixed", foreground="#666", background="#f0f0f0")
        self.tr_stack.tag_configure("washer", background="#e3effa")
        self.tr_stack.tag_configure("nut", background="#fbe9d6")
        self.tr_stack.tag_configure("missing", background="#f8d6d6")
        bar = ttk.Frame(col2)
        bar.pack(fill="x", pady=(4, 0))
        for txt, cmd in (("+ po stronie łba", lambda: self.add_comp("head")),
                         ("+ po stronie nakrętki", lambda: self.add_comp("nut"))):
            ttk.Button(bar, text=txt, command=cmd).pack(side="left", padx=2)
        bar_b = ttk.Frame(col2)
        bar_b.pack(fill="x", pady=(2, 4))
        for txt, cmd in (("▲", lambda: self.move_comp(-1)), ("▼", lambda: self.move_comp(1)),
                         ("Zamień...", self.replace_comp), ("Usuń", self.del_comp),
                         ("Domyślny skład normy", lambda: self.auto_default(True)),
                         ("Skopiuj istniejący zestaw...", self.load_existing)):
            ttk.Button(bar_b, text=txt, command=cmd).pack(side="left", padx=2)
        cat = ttk.LabelFrame(col2, text="Dostępne podkładki i nakrętki dla podglądu Ø  (dwuklik = dodaj po stronie nakrętki)")
        cat.pack(fill="both", expand=True, pady=(6, 0))
        cb = ttk.Frame(cat)
        cb.pack(fill="x", padx=4, pady=2)
        self.var_cat_kind = tk.StringVar(value="washer")
        for txt, val in (("Podkładki", "washer"), ("Nakrętki", "nut")):
            ttk.Radiobutton(cb, text=txt, value=val, variable=self.var_cat_kind,
                            command=self.refresh_catalog).pack(side="left", padx=6)
        ttk.Label(cb, text="Filtr:").pack(side="left", padx=(12, 2))
        self.var_cat_filter = tk.StringVar()
        self.var_cat_filter.trace_add("write", lambda *a: self.fill_catalog())
        ttk.Entry(cb, textvariable=self.var_cat_filter, width=14).pack(side="left")
        cb2 = ttk.Frame(cat)
        cb2.pack(fill="x", padx=4)
        ttk.Button(cb2, text="→ po stronie łba", command=lambda: self.add_from_catalog("head")).pack(side="left", padx=2)
        ttk.Button(cb2, text="→ po stronie nakrętki", command=lambda: self.add_from_catalog("nut")).pack(side="left", padx=2)
        fr, self.tr_cat = make_tree(cat, ("Norma", "Klasa", "Wysokość", "Ø zewn.", "Nazwa"),
                                    (100, 70, 65, 65, 200), 6, sort=True)
        fr.pack(fill="both", expand=True)
        self.tr_cat.bind("<Double-1>", lambda e: self.add_from_catalog("nut"))
        self.cat_rows = []

        # ---------------- kolumna 3: rysunek + podgląd i zapis ----------------
        col3 = ttk.Frame(f)
        col3.grid(row=0, column=2, sticky="nsew", padx=(4, 8), pady=6)
        ttk.Label(col3, text="Widok zestawu (od łba do końca śruby)", font=(FONT, 9, "bold")).pack(anchor="w")
        row = ttk.Frame(col3)
        row.pack(side="top", fill="x")
        ttk.Label(row, text="Podgląd dla Ø:").pack(side="left")
        self.cb_pdia = ttk.Combobox(row, width=8, state="readonly")
        self.cb_pdia.pack(side="left", padx=4)
        self.cb_pdia.bind("<<ComboboxSelected>>", lambda e: self.on_pdia())
        ttk.Label(row, text="Grubość pakietu blach [mm]:").pack(side="left", padx=(14, 2))
        self.var_grip = tk.StringVar(value="20")
        self.var_grip.trace_add("write", lambda *a: self.on_pdia())
        ttk.Entry(row, textvariable=self.var_grip, width=7).pack(side="left")
        self.canvas = tk.Canvas(col3, width=380, height=300, bg="white", highlightthickness=1,
                                highlightbackground="#999")
        self.canvas.pack(fill="both", expand=True, pady=4)
        self.canvas.bind("<Configure>", lambda e: self.draw())
        self.var_info = tk.StringVar()
        ttk.Label(col3, textvariable=self.var_info, wraplength=400, style="Hint.TLabel").pack(anchor="w")
        ttk.Label(col3, text="5. Podgląd zapisu (aktualizuje się sam) i zapis", font=(FONT, 9, "bold")).pack(
            anchor="w", pady=(8, 0))
        fr, self.tr_prev = make_tree(col3, ("Standard", "Set", "Klasa", "Ø", "Skład (pozycja norma/klasa)", "Status"),
                                     (70, 60, 50, 40, 220, 200), 6)
        fr.pack(fill="both", expand=True)
        self.var_prevhint = tk.StringVar()
        ttk.Label(col3, textvariable=self.var_prevhint, wraplength=400, style="Err.TLabel").pack(anchor="w")
        self.var_prevsum = tk.StringVar()
        ttk.Label(col3, textvariable=self.var_prevsum, wraplength=400, style="Hint.TLabel").pack(anchor="w")
        bar2 = ttk.Frame(col3)
        bar2.pack(fill="x", pady=4)
        ttk.Label(bar2, text="Właściciel wpisu (max 15 znaków)").pack(side="left")
        self.var_owner = tk.StringVar(value=DEFAULT_OWNER)
        self.var_owner.trace_add("write", lambda *a: self.schedule_preview())
        ttk.Entry(bar2, textvariable=self.var_owner, width=10).pack(side="left", padx=4)
        bar3 = ttk.Frame(col3)
        bar3.pack(fill="x", pady=(0, 4))
        self.var_over = tk.BooleanVar(value=False)
        self.var_over.trace_add("write", lambda *a: self.schedule_preview())
        ttk.Checkbutton(bar3, text="Nadpisz istniejące MOJE wpisy", variable=self.var_over).pack(side="left")
        ttk.Button(bar3, text="Zapisz zestaw do bazy...", command=self.save_set).pack(side="right", padx=4)
        self._prev_job = None

    def quick_set(self):
        """Prosty tryb: wzór (zestaw + klasa) -> nowy klucz -> zapis; reszta z normy i wzoru."""
        if not self.need_db():
            return
        std = self.cur_std()
        if not std:
            messagebox.showinfo("Norma", "Najpierw wybierz normę śruby.")
            return
        if not self.db.std_sets(std):
            messagebox.showinfo("Wzór", "Ta norma nie ma jeszcze żadnego zestawu, który mógłby być wzorem.")
            return
        QuickSetDialog(self, std)

    def schedule_preview(self):
        """Podgląd zapisu odświeża się sam (po 250 ms od ostatniej zmiany), bez okienek i bez osobnego przycisku."""
        if not getattr(self.db, "conn", None) or not hasattr(self, "tr_prev"):
            return
        if self._prev_job:
            try:
                self.root.after_cancel(self._prev_job)
            except tk.TclError:
                pass
        self._prev_job = self.root.after(250, lambda: self.preview(silent=True))

    def cur_std(self):
        i = selected_index(self.cb_std)
        return self.stds[i][0] if 0 <= i < len(self.stds) else None

    def cur_pdia(self):
        i = self.cb_pdia.current()
        return self.pdia_vals[i] if 0 <= i < len(self.pdia_vals) else None

    def cur_pmat(self):
        sel = self.lb_mat.curselection()
        if sel:
            return self.mat_vals[sel[0]]
        return self.mat_vals[0] if self.mat_vals else None

    def on_std(self, _=None):
        std = self.cur_std()
        if not std:
            return
        remember("last_bolt_std", std)
        self.mat_vals = self.db.bolt_materials(std)
        self.lb_mat.delete(0, "end")
        for m in self.mat_vals:
            self.lb_mat.insert("end", m)
        if self.mat_vals:
            self.lb_mat.selection_set(0)
        self.refresh_diameters(reset=True)
        d = [s for s in self.stds if s[0] == std][0]
        assigned = [r[0] for r in self.db.std_sets(std)]
        global_keys = [x[0] for x in self.sets]
        cur = self.cb_set.get().strip()
        if cur and cur in global_keys and cur not in assigned:      # klucz z poprzedniej normy - nie pasuje
            cur = ""
            self.cb_set.set("")
            self.var_run.set("")
        if not cur:
            by_lower = {k.lower(): k for k in assigned}
            default = by_lower.get((d[3] or "").lower()) or (assigned[0] if assigned else "")
            if default:
                self.cb_set.set(default)
                self.on_set()
        self.refresh_set_choices()
        self.auto_default()

    def refresh_set_choices(self):
        """Lista kluczy zestawu: tylko przypisane do wybranej normy (albo wszystkie po zaznaczeniu opcji)."""
        std = self.cur_std()
        assigned = self.db.std_sets(std) if (self.db.conn and std) else []
        if self.var_allsets.get() or not (self.db.conn and std):
            self.set_choices = [(x[0], x[1] or x[0]) for x in self.sets]
        else:
            self.set_choices = [(r[0], r[1]) for r in assigned]
        self.cb_set["values"] = ["%s   |   %s" % (k, run) for k, run in self.set_choices]
        if not (self.db.conn and std):
            self.var_setinfo.set("")
        elif not self.mat_vals:
            self.var_setinfo.set("Ta norma nie ma śrub w SetBolts (brak klas i średnic) - nie da się dla niej "
                                 "zbudować zestawu. Użyj 'Kopia normy (szybka)'.")
        elif not assigned:
            self.var_setinfo.set("Ta norma nie ma jeszcze żadnych zestawów w bazie. Wpisz nowy klucz zestawu albo "
                                 "zaznacz 'pokaż wszystkie klucze'.")
        else:
            self.var_setinfo.set("Zestawy przypisane do tej normy: %d." % len(assigned))

    def on_set_selected(self, _=None):
        """Wybór klucza z listy: ustawia klucz i nazwę oraz wczytuje skład tego zestawu."""
        i = self.cb_set.current()
        if 0 <= i < len(self.set_choices):
            self.cb_set.set(self.set_choices[i][0])
            self.var_run.set(self.set_choices[i][1] or "")
        self.load_set_composition()

    def load_set_composition(self):
        std, key = self.cur_std(), self.cb_set.get().strip()
        if not (self.db.conn and std and key):
            return
        have = self.db.std_set_materials(std, key)
        if not have:
            self.var_setinfo.set("Zestaw '%s' nie jest przypisany do normy %s - skład nie został wczytany, "
                                 "ułóż go ręcznie." % (key, std))
            return
        sel = [self.mat_vals[i] for i in self.lb_mat.curselection()]
        order = [m for m in sel if m in have] + [m for m in have if m not in sel]
        for m in order:
            res = self.components_from_set(std, key, m)
            if res and (res[0] or res[1]):
                self.head_items, self.nut_items = res
                self.var_setinfo.set("Wczytano skład zestawu '%s' (klasa %s). Klasy z tym zestawem: %s." % (
                    key, m, ", ".join(have)))
                self.on_pdia()
                return
        self.var_setinfo.set("Zestaw '%s' nie ma elementów w bazie dla tej normy." % key)

    def on_set(self, _=None):
        k = self.cb_set.get().strip()
        for s in self.sets:
            if s[0] == k:
                self.var_run.set(s[1] or "")
                break
        self.schedule_preview()

    def refresh_diameters(self, reset=False):
        std = self.cur_std()
        if not std:
            return
        mats = [self.mat_vals[i] for i in self.lb_mat.curselection()]
        old = [] if reset else [self.dia_vals[i] for i in self.lb_dia.curselection()]
        self.dia_vals = self.db.bolt_diameters(std, mats)
        self.lb_dia.delete(0, "end")
        for d in self.dia_vals:
            self.lb_dia.insert("end", "Ø " + dia_text(d))
        sel = [i for i, d in enumerate(self.dia_vals) if d in old]
        for i in (sel or range(len(self.dia_vals))):
            self.lb_dia.selection_set(i)
        self.refresh_pdia()

    def refresh_pdia(self):
        cur = self.cur_pdia()
        self.pdia_vals = [self.dia_vals[i] for i in self.lb_dia.curselection()]
        self.cb_pdia["values"] = ["Ø " + dia_text(d) for d in self.pdia_vals]
        if self.pdia_vals:
            self.cb_pdia.current(self.pdia_vals.index(cur) if cur in self.pdia_vals else 0)
        else:
            self.cb_pdia.set("")
        self.on_pdia()
        self.refresh_catalog()

    def on_pdia(self):
        self.refresh_stack()
        self.draw()
        self.schedule_preview()

    def grip(self):
        try:
            return max(1.0, float(self.var_grip.get().replace(",", ".")))
        except ValueError:
            return 20.0

    # --- skład: stos elementów ---
    def item_dims(self, comp, dia):
        """(wysokość, średnica zewn., rodzaj, opis, istnieje) elementu dla danej średnicy."""
        it = self.db.nut_item(comp["std"], comp["mat"], dia) if self.db.conn and dia is not None else None
        if not it:
            return 3.0, 1.8 * (dia or 10), "missing", "BRAK dla Ø%s" % (fmt_dia(dia) if dia else "?"), False
        h = it[0] or 3.0
        od = it[2] or 1.8 * dia
        kind = "washer" if not it[1] else "nut"
        return h, od, kind, T("h=%s  Ø zewn.=%s") % (fmt_dia(h), fmt_dia(od)), True

    def refresh_stack(self):
        t = self.tr_stack
        t.delete(*t.get_children())
        self.stack_map = {}
        std = self.cur_std() or "-"
        mat = self.cur_pmat() or "-"
        dia = self.cur_pdia()
        hd = self.db.bolt_head(std, mat, dia) if (self.db.conn and self.cur_std() and dia is not None) else None
        head_dims = (T("Ø łba=%s  h=%s") % (fmt_dia(hd[0]), fmt_dia(hd[1]))) if hd and hd[0] else ""

        def put(iid, vals, tag, ref):
            t.insert("", "end", iid=iid, values=vals, tags=(tag,))
            self.stack_map[iid] = ref

        put("fixed_head", (T("ŁEB ŚRUBY"), std, mat, head_dims), "fixed", ("fixed", "head"))
        if not self.head_items:
            put("empty_head", (T("   (pusto - dodaj podkładkę lub nakrętkę po stronie łba)"), "", "", ""),
                "fixed", ("empty", "head"))
        for i in range(len(self.head_items) - 1, -1, -1):          # fizycznie: od łba do blachy
            self._put_comp(put, "h", i, self.head_items[i], dia)
        put("fixed_plate", (T("PAKIET BLACH"), "", "", "t = %s mm" % fmt_dia(self.grip())), "fixed", ("fixed", "plate"))
        for i, c in enumerate(self.nut_items):                       # fizycznie: od blachy do końca
            self._put_comp(put, "n", i, c, dia)
        if not self.nut_items:
            put("empty_nut", (T("   (pusto - dodaj podkładkę lub nakrętkę po stronie nakrętki)"), "", "", ""),
                "fixed", ("empty", "nut"))
        put("fixed_tip", (T("KONIEC ŚRUBY"), "", "", ""), "fixed", ("fixed", "tip"))

    def _put_comp(self, put, side, i, c, dia):
        h, od, kind, desc, ok = self.item_dims(c, dia)
        name = {"washer": T("podkładka"), "nut": T("nakrętka"), "missing": T("BRAK elementu")}[kind]
        put("%s%d" % (side, i), ("   " + name, c["std"], c["mat"], desc), kind,
            ("head" if side == "h" else "nut", i))

    def add_comp(self, side):
        if not self.need_db():
            return
        if len(self.head_items) + len(self.nut_items) >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS)
            return
        lst = self.head_items if side == "head" else self.nut_items
        default = "nut" if (side == "nut" and lst) else "washer"   # po podkładce zwykle nakrętka
        dlg = CompDialog(self.root, self.db, T("Dodaj element - ") + T("strona łba" if side == "head" else "strona nakrętki"),
                         self.cur_pdia(), default)
        if dlg.result:
            lst.append(dlg.result)
            self.on_pdia()

    def selected_comp(self):
        sel = self.tr_stack.selection()
        if not sel:
            return None
        ref = self.stack_map.get(sel[0])
        return ref if ref and ref[0] in ("head", "nut") else None

    def del_comp(self):
        ref = self.selected_comp()
        if not ref:
            return
        del (self.head_items if ref[0] == "head" else self.nut_items)[ref[1]]
        self.on_pdia()

    def move_comp(self, direction):
        """direction: -1 = fizycznie w górę (ekranu), +1 = w dół."""
        ref = self.selected_comp()
        if not ref:
            return
        side, i = ref
        lst = self.head_items if side == "head" else self.nut_items
        # strona łba: indeks 0 = przy blasze (na dole), więc "w górę" = indeks+1
        j = i + (-direction if side == "head" else direction)
        if 0 <= j < len(lst):
            lst[i], lst[j] = lst[j], lst[i]
            self.on_pdia()
            self.tr_stack.selection_set("%s%d" % ("h" if side == "head" else "n", j))

    def replace_comp(self):
        """Zamienia zaznaczony element zestawu na inny (np. gdy w bazie nie ma go dla wybranych średnic)."""
        if not self.need_db():
            return
        ref = self.selected_comp()
        if not ref:
            messagebox.showinfo("Zamień", "Zaznacz element zestawu (podkładkę lub nakrętkę) w tabeli składu.")
            return
        side, i = ref
        lst = self.head_items if side == "head" else self.nut_items
        dlg = CompDialog(self.root, self.db, T("Zamień element - ") + T("strona łba" if side == "head" else "strona nakrętki"),
                         self.cur_pdia(), "nut")
        if dlg.result:
            lst[i] = dlg.result
            self.on_pdia()
            self.tr_stack.selection_set("%s%d" % ("h" if side == "head" else "n", i))

    def load_existing(self):
        if not self.need_db():
            return
        std = self.cur_std()
        if not std:
            messagebox.showinfo("Norma", "Najpierw wybierz normę śruby.")
            return
        dlg = LoadDialog(self.root, self.db, std)
        if not dlg.result:
            return
        set_key, mat = dlg.result
        res = self.components_from_set(std, set_key, mat)
        if not res:
            return
        self.head_items, self.nut_items = res
        self.cb_set.set(set_key)
        self.on_set()
        self.on_pdia()

    def components_from_set(self, std, set_key, mat):
        """Skład istniejącego zestawu -> (strona łba, strona nakrętki), od blachy na zewnątrz."""
        rows, cols = self.db.query("SELECT TOP 1 * FROM [SetOfBolts] WHERE [Standard]=? AND [Set]=? AND [Material]=? "
                                   "ORDER BY [Diameter]", (std, set_key, mat))
        if not rows:
            return None
        r = dict(zip(cols, rows[0]))
        comps = []
        for k in range(1, MAX_ITEMS + 1):
            din, pos, m = r.get("DIN%d" % k), r.get("Position%d" % k), r.get("Material%d" % k)
            if din not in (None, "", "-") and pos:
                comps.append((pos, {"std": din, "mat": m}))
        head = [c for p, c in sorted((x for x in comps if x[0] > 0), key=lambda t: t[0])]
        nut = [c for p, c in sorted((x for x in comps if x[0] < 0), key=lambda t: abs(t[0]))]
        return head, nut

    def auto_default(self, force=False):
        """Wczytuje domyślny skład normy (StandardSet z tabeli Standard), jeśli zestaw jest jeszcze pusty."""
        if not self.db.conn or ((self.head_items or self.nut_items) and not force):
            return
        std = self.cur_std()
        if not std:
            return
        mats = [self.mat_vals[i] for i in self.lb_mat.curselection()] or self.mat_vals
        d = [x for x in self.stds if x[0] == std]
        cands = []
        if d and d[0][3]:
            cands += [(d[0][3], m) for m in mats]
        cands += [(r[0], r[1]) for r in self.db.rows(
            "SELECT DISTINCT [Set],[Material] FROM [SetOfBolts] WHERE [Standard]=? ORDER BY 1,2", (std,))]
        for sk, m in cands:
            res = self.components_from_set(std, sk, m)
            if res and (res[0] or res[1]):
                self.head_items, self.nut_items = res
                if not self.cb_set.get():
                    self.cb_set.set(sk)
                    self.on_set()
                self.on_pdia()
                return
        if force:
            messagebox.showinfo("Skład", "Dla tej normy nie znaleziono żadnego zestawu w bazie.")

    # --- katalog podkładek / nakrętek w oknie głównym ---
    def refresh_catalog(self):
        dia = self.cur_pdia()
        self.cat_rows = self.db.nut_catalog(dia, self.var_cat_kind.get()) if (self.db.conn and dia is not None) else []
        self.fill_catalog()

    def fill_catalog(self):
        t = self.tr_cat
        t.delete(*t.get_children())
        f = self.var_cat_filter.get().lower()
        for i, r in enumerate(self.cat_rows):
            if f and not any(f in str(v).lower() for v in (r[0], r[1], r[4])):
                continue
            t.insert("", "end", iid=str(i), values=(r[0], r[1], r[2], r[3], r[4]))

    def add_from_catalog(self, side):
        sel = self.tr_cat.selection()
        if not sel:
            messagebox.showinfo("Dodaj", "Zaznacz podkładkę lub nakrętkę na liście.")
            return
        lst = self.head_items if side == "head" else self.nut_items
        for iid in sel:
            if len(self.head_items) + len(self.nut_items) >= MAX_ITEMS:
                messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS)
                break
            r = self.cat_rows[int(iid)]
            lst.append({"std": r[0], "mat": r[1]})
        self.on_pdia()

    # --- rysunek ---
    def draw(self):
        c = self.canvas
        c.delete("all")
        W, H = max(c.winfo_width(), 200), max(c.winfo_height(), 200)
        if not self.db.conn:
            c.create_text(W / 2, H / 2, text="Połącz się z bazą (przycisk 'Połącz' u góry)", fill="#888")
            self.var_info.set("")
            return
        std, mat, dia = self.cur_std(), self.cur_pmat(), self.cur_pdia()
        if not (std and mat and dia is not None):
            c.create_text(W / 2, H / 2, text="Wybierz normę śruby, klasę i średnicę", fill="#888")
            self.var_info.set("")
            return
        self.var_info.set(self.draw_assembly(c, std, mat, dia, self.head_items, self.nut_items, self.grip()))

    def draw_assembly(self, c, std, mat, dia, head_items, nut_items, grip, W=None, H=None):
        """Rysuje śrubę z zestawem na canvasie c (używane przez widok Tekla i kreatory); zwraca opis długości."""
        c.delete("all")
        W = W or max(c.winfo_width(), 200)
        H = H or max(c.winfo_height(), 200)
        d = dia
        hd = self.db.bolt_head(std, mat, dia)
        hw = hd[0] if hd and hd[0] else 1.7 * d
        hh = hd[1] if hd and hd[1] else 0.65 * d

        def make(comp):
            h, od, kind, desc, ok = self.item_dims(comp, dia)
            name = {"washer": T("podkładka"), "nut": T("nakrętka"), "missing": T("BRAK")}[kind]
            return {"kind": kind, "label": "%s %s / %s   h=%s" % (name, comp["std"], comp["mat"], fmt_dia(h)),
                    "w": od, "h": h}

        head_phys = [make(cc) for cc in reversed(head_items)]
        nut_phys = [make(cc) for cc in nut_items]
        prot = 2.0 * pitch_for(d)
        lay = assembly_layout(d, hw, hh, head_phys, grip, nut_phys, prot)
        scale = min((H - 30) / lay["total_h"], (W * (0.5 if W >= 520 else 0.42)) / lay["max_w"])   # wąski panel: miejsce na podpisy
        cx = 16 + lay["max_w"] * scale / 2.0
        x_lab = 16 + lay["max_w"] * scale + 14
        y0 = 12
        colors = {"head": COL_HEAD, "washer": COL_WASHER, "nut": COL_NUT, "plate": COL_PLATE,
                  "missing": COL_MISSING}

        def rect(el):
            x0, x1 = cx - el["w"] * scale / 2, cx + el["w"] * scale / 2
            ya, yb = y0 + el["y"] * scale, y0 + (el["y"] + el["h"]) * scale
            c.create_rectangle(x0, ya, x1, yb, fill=colors[el["kind"]], outline="#222")
            return (ya + yb) / 2

        els = lay["elements"]
        for el in els:                       # 1) pakiet blach
            if el["kind"] == "plate":
                ym = rect(el)
                c.create_text(x_lab, ym, anchor="w", font=(FONT, 9),
                              text="pakiet blach  t=%s mm" % fmt_dia(grip))
        c.create_rectangle(cx - d * scale / 2, y0 + lay["shank_y0"] * scale,       # 2) trzon
                           cx + d * scale / 2, y0 + lay["shank_y1"] * scale, fill=COL_SHANK, outline="#222")
        for el in els:                       # 3) łeb, podkładki, nakrętki
            if el["kind"] == "plate":
                continue
            ym = rect(el)
            txt = el["label"] or "łeb  %s / %s  Ø%s" % (std, mat, dia_text(d))
            c.create_text(x_lab, ym, anchor="w", font=(FONT, 9), text=txt)
        # wymagana długość
        lens = self.db.bolt_lengths(std, mat, dia)
        need = lay["req_len"]
        avail = next((L for L in lens if L >= need - 1e-6), None)
        return (
            "Wymagana długość śruby ≈ %.1f mm (pakiet %s + elementy + wystawanie %.1f mm). "
            "Najbliższa dostępna w bazie: %s. Rysunek w skali wymiarów z bazy; Advance Steel dobiera długość "
            "sam (AutoLengthCalc)." % (need, fmt_dia(grip), prot,
                                       ("%s mm" % fmt_dia(avail)) if avail is not None else "brak dłuższej"))

    # --- zbieranie i zapis ---
    def components(self):
        return ([dict(side="head", **c) for c in self.head_items] +
                [dict(side="nut", **c) for c in self.nut_items])

    def collect(self):
        std = self.cur_std()
        set_key = self.cb_set.get().strip()
        owner = self.var_owner.get().strip()
        mats = [self.mat_vals[i] for i in self.lb_mat.curselection()]
        dias = [self.dia_vals[i] for i in self.lb_dia.curselection()]
        errs = []
        if not std:
            errs.append("Wybierz normę śruby.")
        if not set_key or len(set_key) > 32:
            errs.append("Klucz zestawu: wymagany, max 32 znaki.")
        if not owner or len(owner) > 15:
            errs.append("Właściciel: wymagany, max 15 znaków.")
        if owner and not is_own(owner):
            errs.append("Właściciel nie może być fabryczny (DSC/AUTODESK).")
        if not mats:
            errs.append("Zaznacz co najmniej jedną klasę śruby.")
        if not dias:
            errs.append("Zaznacz co najmniej jedną średnicę.")
        if not (self.head_items or self.nut_items):
            errs.append("Dodaj co najmniej jeden element zestawu.")
        return std, set_key, owner, mats, dias, errs

    def preview(self, silent=False):
        """Buduje podgląd wierszy do zapisu. silent=True: bez okienek (podgląd na żywo); błędy w polu pod tabelą."""
        self._prev_job = None
        if not self.db.conn:
            if not silent:
                self.need_db()
            return None
        std, set_key, owner, mats, dias, errs = self.collect()
        if errs:
            self.var_prevsum.set("")
            if silent:
                self.tr_prev.delete(*self.tr_prev.get_children())
                self.prev_rows = []
                self.var_prevhint.set(T("Do uzupełnienia: ") + "  ".join(T(e) for e in errs[:3]))
            else:
                messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return None
        self.var_prevhint.set("")
        comps = self.components()
        items = positions_for(comps)
        binding, source = self.db.template(std)
        self.prev_rows = []
        self.tr_prev.delete(*self.tr_prev.get_children())
        for mat in mats:
            for dia in dias:
                if not self.db.bolt_exists(std, mat, dia):
                    status, code = T("pominięto: brak śruby %s Ø%s w SetBolts") % (mat, dia_text(dia)), "skip"
                else:
                    miss = [c["std"] + "/" + c["mat"] for c in comps
                            if self.db.nut_item(c["std"], c["mat"], dia) is None]
                    exists, own = self.db.set_owner(std, set_key, mat, dia)
                    if miss:
                        status, code = T("pominięto: brak w bazie ") + ", ".join(miss), "skip"
                    elif not exists:
                        status, code = T("NOWY"), "new"
                    elif is_own(own) and self.var_over.get():
                        status, code = T("istnieje (moj) - zostanie nadpisany"), "over"
                    elif is_own(own):
                        status, code = T("istnieje (moj) - pominięto (zaznacz nadpisywanie)"), "skip"
                    else:
                        status, code = T("istnieje (fabryczny) - pominięto"), "skip"
                row = build_set_row(std, set_key, mat, dia, owner, binding, source, items)
                self.prev_rows.append((code, row))
                self.tr_prev.insert("", "end", values=(std, set_key, mat, dia_text(dia), items_label(items), status))
        n_new = sum(1 for c, _ in self.prev_rows if c == "new")
        n_over = sum(1 for c, _ in self.prev_rows if c == "over")
        n_skip = sum(1 for c, _ in self.prev_rows if c == "skip")
        self.var_prevsum.set(T("Do zapisu: %d (nowe: %d, nadpisane: %d), pominięte: %d.") % (n_new + n_over, n_new, n_over, n_skip))
        if n_skip and not (n_new or n_over):
            self.var_prevhint.set(T("Nic nie zostanie zapisane. Jeśli zestaw o tym kluczu już istnieje, wpisz NOWY klucz "
                                    "zestawu (krok 2). Jeśli brakuje elementu, zaznacz go w składzie i kliknij 'Zamień...'."))
        return self.prev_rows

    def save_set(self):
        rows = self.preview()
        if rows is None:
            return False
        todo = [(c, r) for c, r in rows if c in ("new", "over")]
        if not todo:
            messagebox.showinfo("Zapis", "Brak wierszy do zapisu (zobacz kolumnę Status).")
            return False
        set_key = self.cb_set.get().strip()
        new_set = set_key not in [s[0] for s in self.sets]
        run = self.var_run.get().strip() or set_key
        msg = "Zapisać %d wierszy zestawu śrub?" % len(todo)
        if new_set:
            msg += "\nZostanie też dodany nowy typ zestawu '%s' do tabeli Sets." % set_key
        if not messagebox.askyesno("Potwierdź zapis", msg):
            return False
        if not self.backup_before_write():
            return False
        owner = self.var_owner.get().strip()[:15]

        def fn(cur):
            if new_set:
                sql, p = insert_sql("Sets", {"Key": set_key, "RunName": run[:64], "OwnerText": owner})
                cur.execute(sql, p)
            for code, r in todo:
                if code == "over":
                    cur.execute("DELETE FROM [SetOfBolts] WHERE [Standard]=? AND [Set]=? AND [Material]=? "
                                "AND ABS([Diameter]-?)<0.0001 AND ISNULL([OwnerText],'') NOT IN ('DSC','AUTODESK')",
                                [r["Standard"], r["Set"], r["Material"], r["Diameter"]])
                sql, p = insert_sql("SetOfBolts", r)
                cur.execute(sql, p)
        try:
            self.db.write(fn)
        except Exception as e:
            messagebox.showerror("Błąd zapisu (zmiany wycofane)", str(e))
            return False
        self.sets = self.db.sets()
        self.refresh_set_choices()
        self.preview()
        self.reload_browsers()
        messagebox.showinfo("Gotowe", "Zapisano %d wierszy.\nUruchom ponownie Advance Steel / Management Tools, "
                                      "aby zobaczyć zmiany." % len(todo))
        return True
