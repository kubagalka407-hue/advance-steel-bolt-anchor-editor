# -*- coding: utf-8 -*-
"""Pytajniki (?) przy polach: mały niebieski '?' obok etykiety otwiera okienko z wyjaśnieniem (po kliknięciu).

Działa automatycznie: install_field_help(root) podpina się pod pokazanie każdego okna (<Map>) i dokłada '?' do etykiet,
przycisków opcji i pól wyboru, których tekst pasuje do słownika help_data() (dopasowanie po początku tekstu).
Dymek zamyka się kliknięciem, Esc albo po zjechaniu myszą. Teksty: (polski, angielski)."""
from as_editor.i18n import T, get_language
from as_editor.ui.widgets import Tooltip, tk, ttk


def help_data():
    """(początek etykiety, polski opis, angielski opis). Wewnątrz funkcji, bo to treść pomocy (kontrola --check-i18n ją pomija)."""
    D = [
        # --- kotwy: wybór
        ("Norma kotwy", "Norma = rodzina / producent kotwy w katalogu (np. Hilti HST, Fischer FAZ). Wszystkie kotwy jednej normy "
         "mają wspólną nazwę. Wpisz fragment nazwy (np. 'hilti'), aby zawęzić listę.",
         "Standard = anchor family / manufacturer in the catalogue (e.g. Hilti HST, Fischer FAZ). All anchors of one standard share a name. "
         "Type part of the name (e.g. 'hilti') to narrow the list."),
        ("Nazwa (norma kotwy)", "Nazwa normy kotwy w katalogu (klucz w bazie). Wpisz nową, aby utworzyć nową rodzinę / producenta.",
         "Name of the anchor standard in the catalogue (database key). Type a new one to create a new family / manufacturer."),
        ("Nazwa wyświetlana", "Nazwa normy widoczna na listach w Advance Steel; zwykle taka sama jak nazwa normy.",
         "Name of the standard shown in lists in Advance Steel; usually the same as the standard name."),
        ("Zestaw (nakrętki", "Zestaw = nakrętki i podkładki przypisane do kotwy (np. nakrętka + podkładka nad blachą). To pole SetName w bazie. "
         "Ta sama kotwa (Ø + klasa) może istnieć z kilkoma zestawami, każdy jako osobny wpis.",
         "Set = the nuts and washers assigned to an anchor (e.g. nut + washer above the plate). It is the SetName field in the database. "
         "The same anchor (Ø + grade) can exist with several sets, each as a separate entry."),
        ("Zestaw (lub wpisz", "Nazwa zestawu nakrętek i podkładek (max 64 znaki). Wybierz istniejący albo wpisz nową nazwę - nowy zestaw powstaje "
         "obok istniejących, nic fabrycznego się nie zmienia.",
         "Name of the nut and washer set (max 64 characters). Pick an existing one or type a new name - a new set is created next to existing "
         "ones, nothing factory is changed."),
        ("Nazwa zestawu", "Nazwa zestawu nakrętek i podkładek widoczna w Advance Steel (max 64 znaki). Wpisz nową, aby utworzyć zestaw obok istniejących.",
         "Name of the nut and washer set shown in Advance Steel (max 64 characters). Type a new one to create a set next to existing ones."),
        ("Nazwa nowego zestawu", "Nazwa nowego zestawu (max 64 znaki). Istniejące zestawy zostają bez zmian - powstaje nowy wpis.",
         "Name of the new set (max 64 characters). Existing sets stay unchanged - a new entry is created."),
        ("Klasy materiałowe", "Klasa materiału kotwy (np. 5.8, 8.8, A4-70). Zaznacz kilka (Ctrl / Shift) - zmiana zostanie zastosowana do każdej "
         "zaznaczonej klasy i średnicy.",
         "Material grade of the anchor (e.g. 5.8, 8.8, A4-70). Select several (Ctrl / Shift) - the change applies to every selected grade and diameter."),
        ("Klasa materiału", "Klasa materiału kotwy (np. 5.8, 8.8). Wybierz z listy albo wpisz nową - nowa trafi do słownika klas.",
         "Material grade of the anchor (e.g. 5.8, 8.8). Pick from the list or type a new one - it is added to the grade dictionary."),
        ("Klasa (lub wpisz", "Klasa materiału kotwy (np. 5.8, 8.8). Wybierz z listy albo wpisz nową - nowa trafi do słownika klas.",
         "Material grade of the anchor (e.g. 5.8, 8.8). Pick from the list or type a new one - it is added to the grade dictionary."),
        ("Średnice", "Średnica w mm. Wymiary calowe są pokazane jako ułamki cala z mm w nawiasie, np. 1/2\" (12.7). Ctrl / Shift = kilka naraz.",
         "Diameter in mm. Inch sizes are shown as fractions with mm in brackets, e.g. 1/2\" (12.7). Ctrl / Shift = several at once."),
        ("Średnica Ø", "Nominalna średnica kotwy w mm. Dla wymiarów calowych wpisz mm (np. 12.7 dla 1/2\", 19.05 dla 3/4\").",
         "Nominal anchor diameter in mm. For inch sizes enter mm (e.g. 12.7 for 1/2\", 19.05 for 3/4\")."),
        ("Typ kotwy", "Typ określa wymiary i rysunek: Normal (zwykła), Headed (z główką), Threaded (gwintowana, z odległością od dołu), "
         "Hooked (L, z hakiem), J (z hakiem powrotnym). Tabela wymiarów dopasowuje się do typu.",
         "Type decides the dimensions and drawing: Normal, Headed, Threaded (with distance from the bottom), Hooked (L, with a hook), "
         "J (hook with return). The dimension table adapts to the type."),
        ("Typ", "Typ określa wymiary i rysunek kotwy: Normal, Headed (z główką), Threaded (gwintowana), Hooked (L), J.",
         "Type decides the anchor dimensions and drawing: Normal, Headed, Threaded, Hooked (L), J."),
        ("Źródło / norma", "Skrót (max 15 znaków) źródła wymiarów, np. HILTI - pole Source w bazie. Nowy skrót wymaga też opisu pełnej nazwy.",
         "Short code (max 15 characters) of the dimension source, e.g. HILTI - the Source field in the database. A new code also needs a full-name description."),
        ("Opis nowego źródła", "Pełna nazwa nowego źródła (np. 'Hilti HST3 - katalog 2024'). Zapisze się w słowniku źródeł.",
         "Full name of the new source (e.g. 'Hilti HST3 - 2024 catalogue'). Stored in the source dictionary."),
        ("Właściciel", "Twój znacznik wpisów (max 15 znaków, nie DSC / AUTODESK), np. MOJA. Po nim rozpoznasz i usuniesz swoje wpisy; "
         "wpisy fabryczne (DSC) są chronione i nigdy nie są zmieniane.",
         "Your entry tag (max 15 characters, not DSC / AUTODESK), e.g. MOJA. You recognise and delete your entries by it; factory (DSC) entries "
         "are protected and never changed."),
        ("Blacha [mm]", "Tylko do podglądu: grubość blachy podstawy na rysunku. Nie zapisuje się w bazie.",
         "Preview only: base plate thickness in the drawing. Not stored in the database."),
        ("Podlewka [mm]", "Tylko do podglądu: grubość podlewki pod blachą. Wpływa na pokazane zakotwienie (długość - wystawanie - blacha - podlewka). "
         "Nie zapisuje się w bazie.",
         "Preview only: grout thickness under the plate. Affects the shown embedment (length - protrusion - plate - grout). Not stored in the database."),
        ("Długości [mm]", "Długości całkowite kotwy: lista (300, 400, 500), zakres od-do/krok (300-1000/100) albo kolumna wklejona z Excela. "
         "Wymiary i ciężar każdej nowej długości program liczy z najbliższej istniejącej długości tej kotwy.",
         "Overall anchor lengths: a list (300, 400, 500), a range from-to/step (300-1000/100) or a column pasted from Excel. Dimensions and weight "
         "of each new length are derived from the nearest existing length of that anchor."),
        ("Wpisz nowe długości", "Lista, zakres od-do/krok (300-1000/100) albo kolumna z Excela. Długości, które kotwa już ma, są pomijane.",
         "A list, a range from-to/step (300-1000/100) or a column from Excel. Lengths the anchor already has are skipped."),
        ("Ciężar pierwszej", "Masa jednej sztuki w kg. Puste = program policzy (skaluje ze wzorca / średnicy). Kolejne długości skalują się proporcjonalnie.",
         "Weight of one piece in kg. Empty = calculated (scaled from the template / diameter). Further lengths scale proportionally."),
        ("Numer części", "Nazwa części widoczna w Advance Steel (max 64 znaki). Puste = automatyczna, np. 'HST M12x300'.",
         "Part name shown in Advance Steel (max 64 characters). Empty = automatic, e.g. 'HST M12x300'."),
        ("Wzorzec - norma", "Norma istniejącego elementu, z którego program weźmie typowe wymiary (wysokość, średnicę zewnętrzną) dla wszystkich średnic.",
         "Standard of the existing element from which typical dimensions (height, outside diameter) are taken for all diameters."),
        ("Wzorzec - klasa", "Klasa / twardość istniejącego elementu-wzoru (np. 8, 200HV).",
         "Grade / hardness of the existing template element (e.g. 8, 200HV)."),
        ("Wzorzec (opcjonalnie)", "Istniejąca kotwa, z której program przejmie typ, klasę, zestaw, źródło i wymiary. Potem zmieniasz tylko to, co ma być inne. "
         "To najszybszy sposób tworzenia nowej kotwy.",
         "An existing anchor from which type, grade, set, source and dimensions are taken. Then you change only what should differ. "
         "This is the fastest way to create a new anchor."),
        ("Wzorzec (kotwa", "Istniejąca kotwa jako wzór: przejmiesz jej typ, klasę, zestaw, źródło i wymiary. Z prawej możesz zawęzić listę typem.",
         "An existing anchor as a template: you take over its type, grade, set, source and dimensions. On the right you can narrow the list by type."),
        ("Norma wzorca", "Wzorzec możesz wziąć z innej normy niż ta, w której tworzysz kotwę (np. kotwa Hilti jako wzór dla własnej normy).",
         "The template may come from a different standard than the one you create the anchor in (e.g. a Hilti anchor as a template for your own standard)."),
        ("Weź wymiary z istniejącej długości", "Którą istniejącą długość kotwy wziąć jako wzór wymiarów (gwint, odległości, hak).",
         "Which existing anchor length to use as the dimension template (thread, distances, hook)."),
        ("Skład zestawu", "Skład układasz w trzech strefach: nad blachą (wiersz 1 najdalej od blachy), pod blachą (wiersz 1 leży na blasze) i koniec kotwy. "
         "Element to norma (np. 934 = nakrętka, 125 = podkładka) i klasa. Schemat po prawej pokazuje efekt.",
         "You arrange the composition in three zones: above the plate (row 1 farthest from the plate), below the plate (row 1 lies on the plate) and "
         "anchor end. An item is a standard (e.g. 934 = nut, 125 = washer) and a grade. The sketch on the right shows the result."),
        ("Zestawy, które już istnieją", "Zestawy już obecne dla wybranych kotew. Nowy zestaw nie zmienia ich - powstaje obok.",
         "Sets that already exist for the selected anchors. A new set does not change them - it is created next to them."),
        ("Gdzie ma powstać nowa kotwa", "W istniejącej normie (np. kolejna kotwa Hilti) albo w nowej normie (nowy producent / rodzina).",
         "In an existing standard (e.g. another Hilti anchor) or in a new standard (new manufacturer / family)."),
        ("Nowy zestaw (powstają nowe kotwy)", "Tworzy nowe wpisy kotew z nowym zestawem. Istniejące kotwy zostają bez zmian - bezpieczna opcja.",
         "Creates new anchor entries with the new set. Existing anchors stay unchanged - the safe option."),
        ("Zmień zestaw w tych kotwach", "Nadpisuje zestaw w Twoich kotwach. Działa tylko na Twoje wpisy; kotwy fabryczne są pomijane i nigdy nie są zmieniane.",
         "Overwrites the set in your anchors. Works on your entries only; factory anchors are skipped and never changed."),
        ("Zapisz bez brakujących", "Niektórych elementów zestawu nie ma w bazie dla tej średnicy. Po zaznaczeniu zapisze się reszta, a brakujące zostaną pominięte.",
         "Some set items do not exist in the database for this diameter. When ticked, the rest is saved and the missing ones are skipped."),
        # --- śruby
        ("Norma śruby", "Norma śruby w katalogu (np. DIN 933, ISO 4014). Wpisz fragment (np. 'din'), aby zawęzić listę.",
         "Bolt standard in the catalogue (e.g. DIN 933, ISO 4014). Type a part (e.g. 'din') to narrow the list."),
        ("Klasy śruby", "Klasa wytrzymałości śruby (4.6, 5.6, 8.8, 10.9, A2-70...). Zaznacz kilka (Ctrl / Shift) - zestaw powstanie dla każdej pary klasa + średnica.",
         "Bolt strength grade (4.6, 5.6, 8.8, 10.9, A2-70...). Select several (Ctrl / Shift) - a set is created for each grade + diameter pair."),
        ("Klasa źródłowa", "Klasa, którą kopiujesz: przepisane zostaną wszystkie jej wymiary i zestawy.",
         "The grade you copy: all its dimensions and sets are copied."),
        ("Nowa klasa", "Nowa klasa śruby (np. 5.6). Powstaje kopia z tymi samymi wymiarami i zestawami; zmieniasz tylko klasy elementów.",
         "New bolt grade (e.g. 5.6). A copy with the same dimensions and sets is created; you change only the item grades."),
        ("Dla których śrub", "Wybierz normę, klasy i średnice śrub, dla których powstanie nowy zestaw podkładek i nakrętek.",
         "Choose the standard, grades and diameters of the bolts that get the new washer and nut set."),
        ("Zacznij od istniejącego zestawu", "Zestaw-wzór: jego skład trafi do edytora, a Ty go zmieniasz (dodaj, zamień, usuń, duplikuj).",
         "Template set: its composition goes to the editor and you modify it (add, replace, delete, duplicate)."),
        ("Nazwa zestawu na liście", "Nazwa zestawu widoczna na liście w Advance Steel. Puste = taka sama jak klucz.",
         "Set name shown in the list in Advance Steel. Empty = same as the key."),
        ("Pakiet blach", "Łączna grubość łączonych blach: tylko do podglądu i podpowiedzi długości śruby. Nie zapisuje się w bazie.",
         "Total thickness of the connected plates: preview and bolt length hint only. Not stored in the database."),
        ("Grubość pakietu", "Łączna grubość łączonych blach: tylko do podglądu i podpowiedzi długości śruby. Nie zapisuje się w bazie.",
         "Total thickness of the connected plates: preview and bolt length hint only. Not stored in the database."),
        ("Klasa", "Klasa wytrzymałości lub twardości elementu (np. 8.8, 8, 200HV).",
         "Strength grade or hardness of the item (e.g. 8.8, 8, 200HV)."),
        # --- nowa podkładka / nakrętka
        ("Kod nowej normy", "Krótki kod nowej normy podkładki / nakrętki (max 32 znaki), np. PL-125.",
         "Short code of the new washer / nut standard (max 32 characters), e.g. PL-125."),
        ("Nazwa normy na liście", "Nazwa nowej normy widoczna na listach w Advance Steel.",
         "Name of the new standard shown in lists in Advance Steel."),
        ("Nowa klasa / twardość", "Klasa lub twardość nowego elementu (np. 300HV). Nie ma jej w słowniku? Zostanie dopisana.",
         "Grade or hardness of the new item (e.g. 300HV). Not in the dictionary? It will be added."),
        ("Wzór nazwy", "Wzór nazwy elementu: {run} = nazwa normy, {d} = średnica. Np. '{run} Ø{d}'.",
         "Item name pattern: {run} = standard name, {d} = diameter. E.g. '{run} Ø{d}'."),
        ("Mnożnik wysokości", "Skaluje wysokość (grubość) elementu względem wzorca. 1.0 = bez zmian; 1.2 = o 20% wyższy.",
         "Scales the item height (thickness) relative to the template. 1.0 = unchanged; 1.2 = 20% taller."),
        ("Mnożnik średnicy", "Skaluje średnicę zewnętrzną względem wzorca. 1.0 = bez zmian.",
         "Scales the outside diameter relative to the template. 1.0 = unchanged."),
        ("Filtr", "Tekst: fragment dowolnej nazwy. Liczby: >=20, <=30, >10, =16 albo zakres 10..20. Kilka warunków oddziel spacją (muszą zachodzić wszystkie).",
         "Text: part of any name. Numbers: >=20, <=30, >10, =16 or a range 10..20. Separate several conditions with spaces (all must hold)."),
            ("Długość kotwy", "Którą długość wybranej kotwy pokazuje rysunek. Domyślnie najdłuższa. Wymiary rysunku (np. długość gwintu) są brane z tej długości. "
         "Zmiana nic nie zapisuje - to tylko podgląd.",
         "Which length of the selected anchor the drawing shows. The longest by default. The drawing dimensions (e.g. thread length) come from that length. "
         "Changing it saves nothing - it is only a preview."),
        # --- filtry wyboru kotew
        ("Filtr typ kotwy", "Zawęża listę norm do tych, które mają kotwy wybranego typu (np. z hakiem, z łbem, gwintowane). Po wyborze normy "
         "pokazują się tylko kotwy tego typu. 'Wszystkie typy' = bez filtra; '✕' czyści oba filtry.",
         "Narrows the list of standards to those that have anchors of the chosen type (e.g. hooked, headed, threaded). After you pick a standard only anchors "
         "of that type are shown. 'All types' = no filter; '✕' clears both filters."),
        ("Filtr klasa materiału", "Zawęża listę norm do tych, które mają kotwy wybranej klasy materiału (np. 5.8, 8.8). Po wyborze normy zaznaczona "
         "zostaje od razu tylko ta klasa. 'Wszystkie klasy' = bez filtra.",
         "Narrows the list of standards to those that have anchors of the chosen material grade (e.g. 5.8, 8.8). After you pick a standard only that grade "
         "is selected. 'All grades' = no filter."),
        # --- katalog
        ("Normy / rodziny kotew", "Lista rodzin / producentów kotew z bazy (np. Hilti HST). W nawiasie liczba kotew w rodzinie; [MOJA] oznacza rodzinę "
         "utworzoną przez Ciebie. Kliknij pozycję, aby zobaczyć jej kotwy w tabeli. Pole nad listą zawęża ją po fragmencie nazwy.",
         "List of anchor families / manufacturers in the database (e.g. Hilti HST). The number in brackets is the number of anchors in the family; "
         "[MOJA] marks a family you created. Click an item to see its anchors in the table. The box above the list narrows it by part of the name."),
        ("Kotwy w wybranej normie", "Każdy wiersz to jedna kotwa: typ, średnica, klasa materiału, zestaw nakrętek i podkładek oraz liczba i zakres długości. "
         "Szare wiersze są fabryczne - nie zmieniamy ich. Kliknij nagłówek, aby sortować; pole 'Filtr' zawęża wiersze. Rysunek zaznaczonej kotwy jest po prawej.",
         "Each row is one anchor: type, diameter, material grade, nut and washer set, and the number and range of lengths. Grey rows are factory ones - we never change them. "
         "Click a header to sort; the 'Filter' box narrows the rows. The drawing of the selected anchor is on the right."),
        ("Normy śrub", "Lista norm śrub z bazy (np. DIN 933). W nawiasie liczba zestawów w normie; [MOJA] oznacza normę utworzoną przez Ciebie. "
         "Kliknij pozycję, aby zobaczyć jej zestawy w tabeli.",
         "List of bolt standards in the database (e.g. DIN 933). The number in brackets is the number of sets in the standard; [MOJA] marks a standard you created. "
         "Click an item to see its sets in the table."),
        ("Zestawy w wybranej normie", "Zestaw to podkładki i nakrętki przypisane do śruby. Wiersz = zestaw dla jednej klasy śruby (dla wielu średnic naraz). "
         "Kolumna 'Skład' pokazuje elementy od łba i od nakrętki. Szare wiersze są fabryczne - użyj 'Kopiuj zestaw', aby zrobić własną wersję.",
         "A set is the washers and nuts assigned to a bolt. A row = a set for one bolt grade (for several diameters at once). The 'Composition' column lists the parts "
         "on the head side and on the nut side. Grey rows are factory ones - use 'Copy set' to make your own version."),
]
    return sorted(D, key=lambda t: -len(t[0]))


_cache = {}


def lookup(text):
    """Zwraca (polski, angielski) opis dla tekstu etykiety albo None. Dopasowanie po początku tekstu (bez ':' i '*')."""
    if not _cache:
        from as_editor.i18n import T, set_language, get_language as gl
        data = help_data()
        _cache["data"] = data
        cur = gl()
        _cache["keys"] = [(k.casefold(), pl, en) for k, pl, en in data]
        try:
            set_language("en")
            _cache["keys_en"] = [(T(k).casefold(), pl, en) for k, pl, en in data]
        finally:
            set_language(cur)
    t = " ".join(str(text).replace("*", "").replace(":", " ").split()).casefold()
    if not t:
        return None
    for k, pl, en in _cache["keys"] + _cache["keys_en"]:
        if t == k or (len(k) > 5 and t.startswith(k)):
            return pl, en
    return None


class Popover(tk.Toplevel):
    """Dymek z wyjaśnieniem; zamyka się kliknięciem, Esc albo po zjechaniu myszą."""
    current = None

    def __init__(self, anchor, title, text):
        super().__init__(anchor.winfo_toplevel())
        if Popover.current is not None:
            try:
                Popover.current.destroy()
            except Exception:
                pass
        Popover.current = self
        self.overrideredirect(True)
        self.configure(background="#0b5cad")
        inner = tk.Frame(self, background="#fffdf3", padx=14, pady=10)
        inner.pack(padx=1, pady=1)
        tk.Label(inner, text=title, background="#fffdf3", foreground="#0b5cad", font=("TkDefaultFont", 10, "bold"),
                 anchor="w", justify="left", wraplength=360).pack(anchor="w")
        tk.Label(inner, text=text, background="#fffdf3", foreground="#222", justify="left", anchor="w", wraplength=360).pack(anchor="w", pady=(4, 0))
        tk.Label(inner, text=T("kliknij, aby zamknąć"), background="#fffdf3", foreground="#8a96a3",
                 font=("TkDefaultFont", 8)).pack(anchor="e", pady=(6, 0))
        self.update_idletasks()
        x = anchor.winfo_rootx() + 18
        y = anchor.winfo_rooty() + anchor.winfo_height() + 4
        w, h = self.winfo_reqwidth(), self.winfo_reqheight()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry("+%d+%d" % (max(4, min(x, sw - w - 8)), max(4, min(y, sh - h - 8) if y + h > sh else y)))
        self._entered = False
        self.bind("<Button-1>", lambda e: self.close())
        self.bind("<Escape>", lambda e: self.close())
        self.bind("<Enter>", lambda e: setattr(self, "_entered", True))
        self.bind("<Leave>", lambda e: self.close() if self._entered else None)
        self.after(25000, self.close)

    def close(self):
        if Popover.current is self:
            Popover.current = None
        try:
            self.destroy()
        except Exception:
            pass


def attach_help(widget, title, pl, en):
    """Dokłada '?' po prawej stronie widżetu (place - nie zmienia układu; widżet dostaje miejsce przez padding)."""
    try:
        widget.configure(padding=(0, 0, 22, 0))
    except tk.TclError:
        return None
    dot = ttk.Label(widget.master, text="?", style="HelpDot.TLabel", cursor="hand2")
    dot.place(in_=widget, relx=1.0, x=-20, rely=0.5, anchor="w")
    dot.lift()
    show = lambda e=None: Popover(dot, title, pl if get_language() == "pl" else en)
    dot.bind("<Button-1>", show)
    try:
        Tooltip(dot, T("Kliknij, aby zobaczyć wyjaśnienie"))
    except Exception:
        pass
    widget._help_dot = dot
    return dot


def auto_help(top):
    """Przechodzi po widżetach okna i dokłada '?' tam, gdzie tekst etykiety jest w słowniku pomocy. Bezpieczne do wielokrotnego wywołania."""
    if getattr(top, "_help_done", False):
        return 0
    top._help_done = True
    n = 0

    def walk(w):
        nonlocal n
        for ch in w.winfo_children():
            if isinstance(ch, tk.Toplevel):
                continue
            cls = ch.winfo_class()
            if cls in ("TLabel", "TRadiobutton", "TCheckbutton") and not getattr(ch, "_help_dot", None) \
                    and not str(ch.cget("style")).startswith(("Step", "Crumb", "Title", "Sub", "BigTitle", "HelpDot")):
                try:
                    if cls == "TLabel" and str(ch.cget("textvariable")):
                        pass
                    else:
                        txt = ch.cget("text")
                        hit = lookup(txt) if txt and len(txt) < 140 else None
                        if hit and attach_help(ch, str(txt).rstrip(": ").replace(" *", ""), hit[0], hit[1]):
                            n += 1
                except tk.TclError:
                    pass
            walk(ch)
    walk(top)
    return n


def install_field_help(root):
    """Podpina automatyczne '?' pod pokazanie każdego okna (główne i kreatory / dialogi)."""
    def on_map(e):
        w = e.widget
        if isinstance(w, (tk.Tk, tk.Toplevel)) and not getattr(w, "_help_done", False):
            w.after(30, lambda: auto_help(w))
    root.bind("<Map>", on_map, add="+")
    root.bind_class("Toplevel", "<Map>", on_map, add="+")
