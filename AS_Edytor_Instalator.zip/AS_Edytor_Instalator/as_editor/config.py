# -*- coding: utf-8 -*-
"""Stałe, ustawienia programu (plik JSON) i opcjonalny import pyodbc."""
import json
import os
import sys

try:
    import pyodbc
except ImportError:
    pyodbc = None


APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))


BACKUP_DIR = os.path.join(APP_DIR, "backups")


DEFAULT_OWNER = "MOJA"


FACTORY = ("DSC", "AUTODESK")


MAX_ITEMS = 6


RHO = 7.85e-6   # kg/mm3 (stal) - sprawdzone na wadze fabrycznej podkładki M12 (0.00627 kg)


# skok gwintu zwykłego [mm] - do orientacyjnego wystawania gwintu i rysunku
PITCH = {6: 1.0, 8: 1.25, 10: 1.5, 12: 1.75, 14: 2.0, 16: 2.0, 18: 2.5, 20: 2.5, 22: 2.5,
         24: 3.0, 27: 3.0, 30: 3.5, 33: 3.5, 36: 4.0, 39: 4.0, 42: 4.5, 48: 5.0}


SETTINGS_FILE = os.path.join(APP_DIR, "bolt_editor_settings.json")


def load_settings():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(data):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def remember(key, value):
    """Zapamiętuje wybór użytkownika (np. ostatnią normę) w pliku ustawień."""
    data = load_settings()
    if data.get(key) != value:
        data[key] = value
        save_settings(data)


def recall(key, default=None):
    return load_settings().get(key, default)
