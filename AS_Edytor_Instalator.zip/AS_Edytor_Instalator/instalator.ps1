﻿# Instalator: Edytor srub i kotew Advance Steel (instalacja dla biezacego uzytkownika, bez praw administratora)
# Uruchamiaj przez Instaluj.bat. Kopiuje program do %LOCALAPPDATA%\AS_Edytor_Srub, doinstaluje Pythona,
# modul pyodbc i sterownik ODBC (jesli ich brakuje) oraz tworzy skroty na pulpicie i w menu Start.
$ErrorActionPreference = 'Continue'   # bledy programow zewnetrznych (stderr) nie przerywaja skryptu; sprawdzamy kody wyjscia
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'AS_Edytor_Srub'
$title = 'Edytor srub i kotew Advance Steel'

function Write-Step($t) { Write-Host ''; Write-Host ('>> ' + $t) -ForegroundColor Cyan }
function Fail($t) { Write-Host ''; Write-Host ('BLAD: ' + $t) -ForegroundColor Red; Read-Host 'Nacisnij Enter, aby zamknac'; exit 1 }

function Get-PythonExe {
    foreach ($cmd in @('py', 'python')) {
        if (Get-Command $cmd -ErrorAction SilentlyContinue) {
            try {
                if ($cmd -eq 'py') { $p = & py -3 -c "import sys;print(sys.executable)" 2>$null }
                else { $p = & python -c "import sys;print(sys.executable)" 2>$null }
                $p = ([string]$p).Trim()
                if ($LASTEXITCODE -eq 0 -and $p -and (Test-Path $p)) { return $p }
            } catch { }
        }
    }
    foreach ($ver in @('Python313', 'Python312', 'Python311', 'Python310')) {
        $p = Join-Path $env:LOCALAPPDATA ('Programs\Python\' + $ver + '\python.exe')
        if (Test-Path $p) { return $p }
    }
    return $null
}

Write-Host '=============================================================='
Write-Host (' Instalator: ' + $title)
Write-Host '=============================================================='
if (-not (Test-Path (Join-Path $src 'advance_steel_bolt_editor.py')) -or -not (Test-Path (Join-Path $src 'as_editor'))) {
    Fail 'Brak plikow programu obok instalatora. Najpierw rozpakuj CALE archiwum ZIP do folderu, potem uruchom Instaluj.bat.'
}

# 1. Python
Write-Step '1/5 Sprawdzam Pythona'
$py = Get-PythonExe
if (-not $py) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host 'Nie znaleziono Pythona - instaluje przez winget (to moze potrwac kilka minut)...'
        try { & winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements } catch { }
        $py = Get-PythonExe
    }
}
if (-not $py) {
    Fail 'Nie udalo sie zainstalowac Pythona automatycznie. Zainstaluj Pythona 3.12 z https://www.python.org/downloads/ (zaznacz "tcl/tk and IDLE"), potem uruchom instalator ponownie.'
}
Write-Host ('Python: ' + $py)
& $py -c "import tkinter" 2>$null
if ($LASTEXITCODE -ne 0) {
    Fail 'Ten Python nie ma modulu tkinter (okna). Zainstaluj Pythona z python.org z opcja "tcl/tk and IDLE" i uruchom instalator ponownie.'
}

# 2. pyodbc
Write-Step '2/5 Instaluje modul pyodbc'
& $py -m pip install --quiet --upgrade pyodbc
if ($LASTEXITCODE -ne 0) { Fail 'Nie udalo sie zainstalowac pyodbc. Sprawdz polaczenie z internetem (lub zasady firmowego proxy) i uruchom ponownie.' }

# 3. sterownik ODBC
Write-Step '3/5 Sprawdzam sterownik ODBC dla SQL Server'
$haveOdbc = $false
try { $haveOdbc = [bool](Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) } catch { }
if ($haveOdbc) {
    Write-Host 'Sterownik jest zainstalowany.'
} else {
    Write-Host 'Brak sterownika ODBC 17/18 - probuje zainstalowac (Windows moze poprosic o zgode administratora)...'
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        try { & winget install -e --id Microsoft.msodbcsql.18 --accept-package-agreements --accept-source-agreements } catch { }
    }
    try { $haveOdbc = [bool](Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) } catch { }
    if (-not $haveOdbc) {
        Write-Host 'UWAGA: nie potwierdzono instalacji sterownika. Jesli program nie polaczy sie z baza, zainstaluj' -ForegroundColor Yellow
        Write-Host '"ODBC Driver 18 for SQL Server" ze strony Microsoft (poprosi o to administratora IT).' -ForegroundColor Yellow
    }
}

# 4. kopiowanie programu
Write-Step ('4/5 Kopiuje program do ' + $dest)
New-Item -ItemType Directory -Force -Path $dest -ErrorAction Stop | Out-Null
if (Test-Path (Join-Path $dest 'as_editor')) { Remove-Item (Join-Path $dest 'as_editor') -Recurse -Force }   # usun stare moduly
try {
foreach ($name in @('advance_steel_bolt_editor.py', 'as_editor', 'README_instrukcja.txt', 'README_EN.txt', 'as_anchor_probe.py', 'as_schema_dump.py',
                    'uruchom_sondaz_kotew.bat', 'uruchom_zrzut_as.bat', 'odinstaluj.ps1', 'Odinstaluj.bat')) {
    $item = Join-Path $src $name
    if (Test-Path $item) {
        Copy-Item $item -Destination $dest -Recurse -Force -ErrorAction Stop
    }
}
} catch { Fail ('Nie udalo sie skopiowac plikow do ' + $dest + ': ' + $_.Exception.Message) }
Get-ChildItem -Path $dest -Recurse -Directory -Filter '__pycache__' -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
# ustawienia (bolt_editor_settings.json) i kopie zapasowe (backups) w folderze instalacji zostaja nietkniete

# 5. skroty
Write-Step '5/5 Tworze skroty'
$pyw = Join-Path (Split-Path -Parent $py) 'pythonw.exe'
if (-not (Test-Path $pyw)) { $pyw = $py }
$ws = New-Object -ComObject WScript.Shell
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    if (-not $folder) { continue }
    $lnk = $ws.CreateShortcut((Join-Path $folder ($title + '.lnk')))
    $lnk.TargetPath = $pyw
    $lnk.Arguments = '"' + (Join-Path $dest 'advance_steel_bolt_editor.py') + '"'
    $lnk.WorkingDirectory = $dest
    $lnk.Description = $title
    $lnk.Save()
}

Write-Host ''
Write-Host '=============================================================='
Write-Host ' GOTOWE. Skrot "Edytor srub i kotew Advance Steel" jest na pulpicie i w menu Start.' -ForegroundColor Green
Write-Host (' Program: ' + $dest)
Write-Host ' Przed pierwszym zapisem do bazy zrob kopie folderu Data (patrz README_instrukcja.txt).'
Write-Host '=============================================================='
Read-Host 'Nacisnij Enter, aby zamknac'
