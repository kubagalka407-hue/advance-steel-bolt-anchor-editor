@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist "%~dp0advance_steel_bolt_editor.py" (
  echo Brak pliku advance_steel_bolt_editor.py w tym samym folderze.
  pause
  exit /b 1
)

set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY (
  echo Nie znaleziono Pythona - instaluje przez winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo Zamknij to okno i uruchom plik ponownie ^(Windows musi odswiezyc sciezki^).
  pause
  exit /b 0
)

%PY% -m pip install --quiet --upgrade pyodbc
if errorlevel 1 (
  echo Nie udalo sie zainstalowac pyodbc. Sprawdz polaczenie z internetem.
  pause
  exit /b 1
)

powershell -NoProfile -Command "if (Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) { exit 0 } else { exit 1 }"
if errorlevel 1 (
  echo Brak sterownika ODBC 17/18 - instaluje przez winget...
  winget install -e --id Microsoft.msodbcsql.18 --accept-package-agreements --accept-source-agreements
)

%PY% "%~dp0advance_steel_bolt_editor.py"
if errorlevel 1 (
  echo.
  echo Program zakonczyl sie bledem - wklej mi powyzszy komunikat.
  pause
)
