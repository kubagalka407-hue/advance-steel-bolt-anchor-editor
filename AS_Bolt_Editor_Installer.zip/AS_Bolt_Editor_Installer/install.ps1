# Installer: Advance Steel Bolt and Anchor Editor (per-user install, no administrator rights needed)
# Run it through Install.bat. It copies the program to %LOCALAPPDATA%\AS_Bolt_Editor, installs Python,
# the pyodbc module and the ODBC driver if they are missing, and creates shortcuts on the desktop and in the Start menu.
$ErrorActionPreference = 'Continue'   # errors of external programs (stderr) do not stop the script; exit codes are checked
$src   = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest  = Join-Path $env:LOCALAPPDATA 'AS_Bolt_Editor'
$title = 'Advance Steel Bolt and Anchor Editor'
$oldDest  = Join-Path $env:LOCALAPPDATA 'AS_Edytor_Srub'     # folder used by the earlier (Polish-named) package
$oldTitle = 'Edytor srub i kotew Advance Steel'              # shortcut name used by the earlier package

function Write-Step($t) { Write-Host ''; Write-Host ('>> ' + $t) -ForegroundColor Cyan }
function Fail($t) { Write-Host ''; Write-Host ('ERROR: ' + $t) -ForegroundColor Red; Read-Host 'Press Enter to close'; exit 1 }

function Get-PythonExe {
    foreach ($cmd in @('py', 'python')) {
        if (Get-Command $cmd -ErrorAction SilentlyContinue) {
            try {
                if ($cmd -eq 'py') { $p = & py -3 -c "import sys;print(sys.executable)" 2>$null }
                else { $p = & python -c "import sys;print(sys.executable)" 2>$null }
                $p = ([string]$p).Trim()
                if ($LASTEXITCODE -eq 0 -and $p -and (Test-Path $p)) { return $p }
            } catch { }
        }
    }
    foreach ($ver in @('Python313', 'Python312', 'Python311', 'Python310')) {
        $p = Join-Path $env:LOCALAPPDATA ('Programs\Python\' + $ver + '\python.exe')
        if (Test-Path $p) { return $p }
    }
    return $null
}

Write-Host '=============================================================='
Write-Host (' Installer: ' + $title)
Write-Host '=============================================================='
if (-not (Test-Path (Join-Path $src 'advance_steel_bolt_editor.py')) -or -not (Test-Path (Join-Path $src 'as_editor'))) {
    Fail 'The program files are missing next to the installer. Extract the WHOLE ZIP archive into a folder first, then run Install.bat.'
}

# 1. Python
Write-Step '1/5 Checking Python'
$py = Get-PythonExe
if (-not $py) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host 'Python not found - installing it with winget (this can take a few minutes)...'
        try { & winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements } catch { }
        $py = Get-PythonExe
    }
}
if (-not $py) {
    Fail 'Python could not be installed automatically. Install Python 3.12 from https://www.python.org/downloads/ (tick "tcl/tk and IDLE"), then run the installer again.'
}
Write-Host ('Python: ' + $py)
& $py -c "import tkinter" 2>$null
if ($LASTEXITCODE -ne 0) {
    Fail 'This Python has no tkinter module (needed for the windows). Install Python from python.org with the "tcl/tk and IDLE" option and run the installer again.'
}

# 2. pyodbc
Write-Step '2/5 Installing the pyodbc module'
& $py -m pip install --quiet --upgrade pyodbc
if ($LASTEXITCODE -ne 0) { Fail 'Could not install pyodbc. Check your internet connection (or the company proxy settings) and run the installer again.' }

# 3. ODBC driver
Write-Step '3/5 Checking the ODBC driver for SQL Server'
$haveOdbc = $false
try { $haveOdbc = [bool](Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) } catch { }
if ($haveOdbc) {
    Write-Host 'The driver is installed.'
} else {
    Write-Host 'ODBC Driver 17/18 not found - trying to install it (Windows may ask for administrator approval)...'
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        try { & winget install -e --id Microsoft.msodbcsql.18 --accept-package-agreements --accept-source-agreements } catch { }
    }
    try { $haveOdbc = [bool](Get-OdbcDriver | Where-Object { $_.Name -match 'ODBC Driver 1[78] for SQL Server' }) } catch { }
    if (-not $haveOdbc) {
        Write-Host 'WARNING: the driver installation could not be confirmed. If the program cannot connect to the database, install' -ForegroundColor Yellow
        Write-Host '"ODBC Driver 18 for SQL Server" from the Microsoft website (your IT administrator may need to do it).' -ForegroundColor Yellow
    }
}

# 4. copy the program
Write-Step ('4/5 Copying the program to ' + $dest)
New-Item -ItemType Directory -Force -Path $dest -ErrorAction Stop | Out-Null
if (Test-Path (Join-Path $dest 'as_editor')) { Remove-Item (Join-Path $dest 'as_editor') -Recurse -Force }   # remove old modules
try {
foreach ($name in @('advance_steel_bolt_editor.py', 'as_editor', 'README.txt', 'README_PL.txt', 'uninstall.ps1', 'Uninstall.bat', 'run_bolt_editor.bat')) {
    $item = Join-Path $src $name
    if (Test-Path $item) {
        Copy-Item $item -Destination $dest -Recurse -Force -ErrorAction Stop
    }
}
} catch { Fail ('Could not copy the files to ' + $dest + ': ' + $_.Exception.Message) }
Get-ChildItem -Path $dest -Recurse -Directory -Filter '__pycache__' -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
# settings (bolt_editor_settings.json), undo journal and backups in the install folder are left untouched

# 4b. take over data from the earlier Polish-named install (settings, undo journal, backups), then remove it
if (Test-Path $oldDest) {
    Write-Host ('Found an earlier installation in ' + $oldDest + ' - moving your settings and backups to the new folder...')
    $moved = $true
    foreach ($f in @('bolt_editor_settings.json', 'bolt_editor_journal.json')) {
        $o = Join-Path $oldDest $f
        if ((Test-Path $o) -and -not (Test-Path (Join-Path $dest $f))) {
            try { Move-Item $o -Destination $dest -ErrorAction Stop } catch { $moved = $false }
        }
    }
    $ob = Join-Path $oldDest 'backups'
    if (Test-Path $ob) {
        $nb = Join-Path $dest 'backups'
        try {
            if (-not (Test-Path $nb)) { Move-Item $ob -Destination $nb -ErrorAction Stop }
            else { Get-ChildItem $ob | Move-Item -Destination $nb -ErrorAction Stop }
        } catch { $moved = $false }
    }
    $oz = Join-Path $oldDest 'zgloszenia'
    if (Test-Path $oz) {
        $nr = Join-Path $dest 'reports'
        try {
            if (-not (Test-Path $nr)) { Move-Item $oz -Destination $nr -ErrorAction Stop }
            else { Get-ChildItem $oz | Move-Item -Destination $nr -ErrorAction Stop }
        } catch { }
    }
    if ($moved) {
        try { Set-Location $env:LOCALAPPDATA; Remove-Item $oldDest -Recurse -Force -ErrorAction Stop; Write-Host 'The earlier installation was removed.' }
        catch { Write-Host ('Note: could not remove the old folder ' + $oldDest + ' - you can delete it manually.') -ForegroundColor Yellow }
    } else {
        Write-Host ('Note: some old data could not be moved and stays in ' + $oldDest + ' - copy it manually if you need it.') -ForegroundColor Yellow
    }
    foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
        if (-not $folder) { continue }
        $oldLnk = Join-Path $folder ($oldTitle + '.lnk')
        if (Test-Path $oldLnk) { Remove-Item $oldLnk -Force -ErrorAction SilentlyContinue }
    }
}

# 5. shortcuts
Write-Step '5/5 Creating shortcuts'
$pyw = Join-Path (Split-Path -Parent $py) 'pythonw.exe'
if (-not (Test-Path $pyw)) { $pyw = $py }
$icon = Join-Path $dest 'as_editor\assets\anchor.ico'
$ws = New-Object -ComObject WScript.Shell
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    if (-not $folder) { continue }
    $lnk = $ws.CreateShortcut((Join-Path $folder ($title + '.lnk')))
    $lnk.TargetPath = $pyw
    $lnk.Arguments = '"' + (Join-Path $dest 'advance_steel_bolt_editor.py') + '"'
    $lnk.WorkingDirectory = $dest
    $lnk.Description = $title
    if (Test-Path $icon) { $lnk.IconLocation = $icon + ',0' }
    $lnk.Save()
}
$startMenu = [Environment]::GetFolderPath('Programs')
if ($startMenu) {
    $un = $ws.CreateShortcut((Join-Path $startMenu ('Uninstall ' + $title + '.lnk')))
    $un.TargetPath = Join-Path $dest 'Uninstall.bat'
    $un.WorkingDirectory = $dest
    $un.Description = 'Uninstall ' + $title
    if (Test-Path $icon) { $un.IconLocation = $icon + ',0' }
    $un.Save()
}

Write-Host ''
Write-Host '=============================================================='
Write-Host (' DONE. The shortcut "' + $title + '" is on the desktop and in the Start menu.') -ForegroundColor Green
Write-Host (' Program folder: ' + $dest)
Write-Host ' Before the first save to the database, make a copy of the Data folder (see README.txt).'
Write-Host '=============================================================='
$a = Read-Host 'Start the program now? (Y/N)'
if ($a -match '^[Yy]') {
    Start-Process -FilePath $pyw -ArgumentList ('"' + (Join-Path $dest 'advance_steel_bolt_editor.py') + '"') -WorkingDirectory $dest
}
