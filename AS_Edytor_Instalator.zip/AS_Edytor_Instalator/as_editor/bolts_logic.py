# -*- coding: utf-8 -*-
"""Logika śrub bez GUI i bazy: pozycje składu, wiersze SetOfBolts, długości, ciężar."""
import math
import re
from as_editor.config import MAX_ITEMS, PITCH, RHO
from as_editor.i18n import T


def pitch_for(d):
    if d in PITCH:
        return PITCH[d]
    k = min(PITCH, key=lambda x: abs(x - d))
    return PITCH[k]


def positions_for(components):
    """components: [{'side':'head'|'nut','std':..,'mat':..}] (kolejność od blachy na zewnątrz).
    Zwraca [(din, material, position)] - najpierw strona łba (+1,+2..), potem nakrętki (-1,-2..)."""
    head = [c for c in components if c["side"] == "head"]
    nut = [c for c in components if c["side"] == "nut"]
    items = []
    for i, c in enumerate(head, 1):
        items.append((c["std"], c["mat"], i))
    for i, c in enumerate(nut, 1):
        items.append((c["std"], c["mat"], -i))
    return items


def build_set_row(std, set_key, mat, dia, owner, binding, source, items):
    row = {"Standard": std, "Set": set_key, "Material": mat, "Diameter": dia,
           "BindingLength": binding, "Explodeable": 1, "OwnerText": owner[:15],
           "Source": (source or std)[:15], "Length": len(items)}
    for i in range(1, MAX_ITEMS + 1):
        if i <= len(items):
            din, m, pos = items[i - 1]
            row["DIN%d" % i] = din
            row["Diameter%d (mm)" % i] = dia
            row["Material%d" % i] = m
            row["Position%d" % i] = pos
        else:  # puste pozycje wg wierszy fabrycznych
            row["DIN%d" % i] = "-"
            row["Diameter%d (mm)" % i] = 0.0
            row["Material%d" % i] = "-"
            row["Position%d" % i] = 0
    return row


def items_label(items):
    return " | ".join("%+d %s/%s" % (pos, din, mat) for din, mat, pos in items)


def assembly_layout(d, head_w, head_h, head_items, grip, nut_items, prot):
    """Układ zestawu do rysunku (mm, oś pionowa, y rośnie w dół od góry łba).
    head_items: elementy FIZYCZNIE od łba do blachy; nut_items: od blachy do końca śruby.
    Każdy element: {'kind','label','w','h'}. Zwraca dict z elementami, trzonem i wymaganą długością."""
    els, y = [], 0.0
    els.append({"kind": "head", "label": "", "w": head_w, "h": head_h, "y": y})
    y += head_h
    under_head = y
    for it in head_items:
        els.append(dict(it, y=y))
        y += it["h"]
    plate = {"kind": "plate", "label": "", "w": 0.0, "h": grip, "y": y}
    els.append(plate)
    y += grip
    for it in nut_items:
        els.append(dict(it, y=y))
        y += it["h"]
    tip = y + prot
    others = [e["w"] for e in els if e["kind"] != "plate"] + [d]
    max_other = max(others)
    plate["w"] = max(2.0 * max_other, 4.0 * d)
    return {"elements": els, "shank_x": d, "shank_y0": under_head, "shank_y1": tip,
            "total_h": tip, "max_w": plate["w"], "req_len": tip - under_head}


def recalc_weight(kind, tpl_h, tpl_od, tpl_w, h, od):
    """Waga [kg] po zmianie wysokości/średnicy zewn. względem wzorca.
    Podkładka: z objętości pierścienia (otwór wyliczony z wagi wzorca). Nakrętka: proporcjonalnie do wysokości."""
    if not tpl_w or not tpl_h:
        return tpl_w
    if kind == "washer" and tpl_od and tpl_od > 0:
        k = 4.0 * tpl_w / (RHO * math.pi * tpl_h)      # = OD^2 - d^2
        d2 = tpl_od ** 2 - k
        if d2 > 0 and od > math.sqrt(d2):
            return RHO * math.pi / 4.0 * (od ** 2 - d2) * h
    return tpl_w * (h / tpl_h)


def parse_lengths(text):
    """'40-100/5, 110-200/10, 220' -> [40.0, 45.0, ...]. Zakres bez kroku ma krok 5."""
    out = set()
    num = r"\d+(?:[.,]\d+)?"
    for tok in re.split(r"[;,\s]+", (text or "").strip()):
        if not tok:
            continue
        m = re.fullmatch(r"(%s)-(%s)(?:/(%s))?" % (num, num, num), tok)
        if m:
            a, b = (float(m.group(i).replace(",", ".")) for i in (1, 2))
            st = float(m.group(3).replace(",", ".")) if m.group(3) else 5.0
            if st <= 0 or b < a:
                raise ValueError(T("Zły zakres: %s") % tok)
            n = int((b - a) / st + 1e-9) + 1
            if n > 500:
                raise ValueError(T("Zakres zbyt duży: %s") % tok)
            for i in range(n):
                out.add(round(a + i * st, 3))
        else:
            try:
                out.add(round(float(tok.replace(",", ".")), 3))
            except ValueError:
                raise ValueError(T("Nie rozumiem: %s") % tok)
    return sorted(out)


def compress_lengths(vals):
    """Odwrotność parse_lengths: [40,45,50,60] -> '40-50/5, 60'."""
    vals = sorted(vals)
    out, i = [], 0
    f = lambda x: "%g" % x
    while i < len(vals):
        j = i + 1
        if j < len(vals):
            step = vals[j] - vals[i]
            while j + 1 < len(vals) and abs((vals[j + 1] - vals[j]) - step) < 1e-9:
                j += 1
            if j - i >= 2 and step > 0:
                out.append("%s-%s/%s" % (f(vals[i]), f(vals[j]), f(step)))
                i = j + 1
                continue
        out.append(f(vals[i]))
        i += 1
    return ", ".join(out)


def bolt_weight(points, d, length):
    """Waga śruby [kg] dla nowej długości z najbliższego punktu wzorca [(długość, waga)]:
    W(L) = W_wzorca + ρ·π/4·d²·(L - L_wzorca). Łeb zostaje taki jak we wzorcu."""
    pts = [(l, w) for l, w in points if w is not None]
    if not pts:
        return 0.0
    lt, wt = min(pts, key=lambda p: abs(p[0] - length))
    return max(0.0, round(wt + RHO * math.pi / 4.0 * d * d * (length - lt), 6))


def remap_set_row(row, new_std, new_mat, owner, mapping):
    """Kopia wiersza SetOfBolts dla innej normy/klasy; mapping {(DIN, klasa): nowa klasa elementu}."""
    r = dict(row)
    r["Standard"], r["Material"], r["OwnerText"] = new_std, new_mat, owner[:15]
    for k in range(1, MAX_ITEMS + 1):
        key = (r.get("DIN%d" % k), r.get("Material%d" % k))
        if key in mapping:
            r["Material%d" % k] = mapping[key]
    return r
