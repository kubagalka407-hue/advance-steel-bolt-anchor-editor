# -*- coding: utf-8 -*-
"""Ilustracje techniczne (rysowane na Canvas) do kart i nagłówków: kotwa, śruba, zestaw, długość, podkładka / nakrętka itd.
Styl rysunku technicznego: jednolity ciemny kontur, przekroje z kreskowaniem, linie osi (kreska-kropka), wymiary ze strzałkami,
gwint jako cienkie linie wewnątrz trzpienia. Układ 100 x 100, skalowany do wybranego rozmiaru; tło canvasu = kolor karty."""
import math

from as_editor.ui.widgets import tk

INK = "#2b3a4a"        # kontur
ACC = "#0b5cad"        # akcent (wymiary, osie, elementy zestawu)
ACC_L = "#dbe9f7"      # jasny akcent (nakrętki, głowy)
STEEL = "#cfd8e0"      # stal
PLATE = "#f2d189"      # blacha
CONC = "#9aa5b1"       # kreskowanie betonu
GRID = "#c4ccd4"


class Pen:
    """Rysik w układzie 100 x 100; k / ox / oy pozwalają narysować pomniejszoną kopię w dowolnym miejscu."""

    def __init__(self, cv, size, ox=0.0, oy=0.0, k=1.0):
        self.cv, self.s, self.ox, self.oy, self.k = cv, size / 100.0, ox, oy, k

    def P(self, x, y):
        return ((self.ox + x * self.k) * self.s, (self.oy + y * self.k) * self.s)

    def pts(self, pts):
        out = []
        for x, y in pts:
            out += self.P(x, y)
        return out

    def lw(self, w):
        return max(1, int(round(w * self.s * self.k)))

    def rect(self, x0, y0, x1, y1, fill="", line=INK, w=1.5):
        a, b = self.P(x0, y0), self.P(x1, y1)
        return self.cv.create_rectangle(*a, *b, fill=fill, outline=line, width=self.lw(w) if line else 0)

    def line(self, *pts, fill=INK, w=1.5, dash=None, arrow=None, smooth=False, cap="butt"):
        flat = self.pts(list(zip(pts[0::2], pts[1::2])))
        kw = dict(fill=fill, width=self.lw(w), capstyle=cap, joinstyle="round")
        if dash:
            kw["dash"] = dash
        if arrow:
            kw["arrow"] = arrow
            kw["arrowshape"] = (max(5, 7 * self.s * self.k), max(6, 8 * self.s * self.k), max(2, 2.6 * self.s * self.k))
        if smooth:
            kw["smooth"] = True
        return self.cv.create_line(*flat, **kw)

    def poly(self, pts, fill="", line=INK, w=1.5):
        return self.cv.create_polygon(*self.pts(pts), fill=fill, outline=line, width=self.lw(w))

    def oval(self, x0, y0, x1, y1, fill="", line=INK, w=1.5):
        a, b = self.P(x0, y0), self.P(x1, y1)
        return self.cv.create_oval(*a, *b, fill=fill, outline=line, width=self.lw(w))

    def arc(self, x0, y0, x1, y1, start, extent, line=INK, w=1.5):
        a, b = self.P(x0, y0), self.P(x1, y1)
        return self.cv.create_arc(*a, *b, start=start, extent=extent, style="arc", outline=line, width=self.lw(w))

    def text(self, x, y, t, fill=ACC, size=13):
        return self.cv.create_text(*self.P(x, y), text=t, fill=fill, font=("TkDefaultFont", -max(10, int(size * self.s * self.k * 1.15)), "bold"))

    # --- elementy rysunku technicznego
    def hatch(self, x0, y0, x1, y1, step=7, color=CONC, w=1.0):
        """Kreskowanie 45 stopni (przekrój betonu) przycięte do prostokąta."""
        h = y1 - y0
        c = x0 - h
        while c < x1:
            t0, t1 = max(0.0, x0 - c), min(h, x1 - c)
            if t1 > t0:
                self.line(c + t0, y1 - t0, c + t1, y1 - t1, fill=color, w=w)
            c += step

    def center(self, x, y0, y1):
        self.line(x, y0, x, y1, fill=ACC, w=0.9, dash=(7, 2, 1, 2))

    def rod(self, x, y0, y1, w, thread=(None, None), chamfer=None):
        """Trzpień w widoku z boku; thread=(od, do) - zakres gwintu (dwie cienkie linie wewnątrz); chamfer='top'/'bottom' ścina koniec."""
        a, b, c = x - w / 2.0, x + w / 2.0, 1.6
        if chamfer == "bottom":
            self.poly([(a, y0), (b, y0), (b, y1 - c), (b - c, y1), (a + c, y1), (a, y1 - c)], fill=STEEL)
        elif chamfer == "top":
            self.poly([(a, y0 + c), (a + c, y0), (b - c, y0), (b, y0 + c), (b, y1), (a, y1)], fill=STEEL)
        else:
            self.rect(a, y0, b, y1, fill=STEEL)
        t0, t1 = thread
        if t0 is not None:
            d = max(1.5, w * 0.2)
            self.line(a + d, t0, a + d, t1, w=0.8)
            self.line(b - d, t0, b - d, t1, w=0.8)

    def hex_side(self, cx, y0, y1, w, fill=ACC_L):
        """Nakrętka / łeb w widoku z boku: ścięte narożniki i dwie widoczne krawędzie sześciokąta."""
        a, b, c = cx - w / 2.0, cx + w / 2.0, min(2.4, (y1 - y0) / 4.0)
        self.poly([(a, y0 + c), (a + c, y0), (b - c, y0), (b, y0 + c), (b, y1 - c), (b - c, y1), (a + c, y1), (a, y1 - c)], fill=fill)
        self.line(cx - w / 4.0, y0, cx - w / 4.0, y1, w=0.9)
        self.line(cx + w / 4.0, y0, cx + w / 4.0, y1, w=0.9)

    def hex_top(self, cx, cy, r, fill=ACC_L):
        pts = [(cx + r * math.cos(math.pi / 3 * k), cy + r * math.sin(math.pi / 3 * k)) for k in range(6)]
        self.poly(pts, fill=fill)

    def dim_v(self, x, y0, y1, ext_to=None, label=None):
        """Wymiar pionowy: linia ze strzałkami na obu końcach i linie pomocnicze (do ext_to)."""
        if ext_to is not None:
            self.line(ext_to, y0, x + 3, y0, fill=ACC, w=0.9)
            self.line(ext_to, y1, x + 3, y1, fill=ACC, w=0.9)
        self.line(x, y0, x, y1, fill=ACC, w=1.2, arrow="both")
        if label:
            self.rect(x - 7, (y0 + y1) / 2.0 - 8, x + 7, (y0 + y1) / 2.0 + 8, fill="white", line=None)
            self.text(x, (y0 + y1) / 2.0, label, size=16)


# ---------------------------------------------------------------------------------------- rysunki
def _anchor(p, with_set=True):
    """Kotwa wklejona w beton: przekrój betonu (kreskowanie), blacha, podkładka, nakrętka, gwint, zagięty koniec."""
    p.rect(8, 60, 92, 94, fill="white", line=INK, w=1.2)
    p.hatch(8, 60, 92, 94, step=7)
    p.center(50, 2, 98)
    p.line(50, 60, 50, 80, 53, 85, 59, 87, 65, 84, 68, 76, fill=INK, w=8.2, cap="round", smooth=True)      # zagięty trzpień (obrys)
    p.line(50, 60, 50, 80, 53, 85, 59, 87, 65, 84, 68, 76, fill=STEEL, w=5.2, cap="round", smooth=True)
    p.rod(50, 8, 56, 8, thread=(12, 52), chamfer="top")
    p.rect(20, 53, 80, 60, fill=PLATE)                                                                    # blacha
    if with_set:
        p.rect(34, 48, 66, 53, fill=STEEL)                                                                # podkładka
        p.hex_side(50, 34, 48, 28)                                                                        # nakrętka


def _bolt(p):
    """Śruba w złączu (przekrój): łeb, podkładka, dwie blachy, podkładka, nakrętka, wystający gwint."""
    p.center(50, 0, 100)
    p.rect(8, 22, 92, 34, fill=PLATE)
    p.rect(8, 34, 92, 46, fill=PLATE)
    p.rod(50, 14, 82, 12, thread=(52, 80), chamfer="bottom")
    p.rect(28, 18, 72, 22, fill=STEEL)
    p.hex_side(50, 4, 18, 40)
    p.rect(30, 46, 70, 50, fill=STEEL)
    p.hex_side(50, 50, 66, 34)


def _stud_set(p):
    """Zestaw: śruba / pręt przez blachę, nad nią rozstrzelone nakrętka i dwie podkładki, strzałka montażu."""
    p.center(50, 0, 100)
    p.rect(14, 74, 86, 84, fill=PLATE)
    p.rod(50, 6, 94, 11, thread=(10, 70), chamfer="top")
    p.rect(28, 56, 72, 62, fill=STEEL)
    p.rect(28, 44, 72, 50, fill=STEEL)
    p.hex_side(50, 14, 34, 38)
    p.line(90, 12, 90, 62, fill=ACC, w=1.4, arrow="last")


def _length(p):
    p.center(34, 2, 98)
    p.rod(34, 8, 92, 12, thread=(12, 44), chamfer="top")
    p.dim_v(70, 8, 92, ext_to=44, label="L")


def _washer(p):
    """Nakrętka (widok z góry, gwint jako łuk) i podkładka (dwa koła z osiami) - osobno, bez nakładania."""
    p.hex_top(32, 31, 21)
    p.oval(22, 21, 42, 41, fill="white", w=1.2)
    p.arc(25, 24, 39, 38, 30, 290, w=0.8)
    cx, cy = 66, 68
    p.oval(cx - 25, cy - 25, cx + 25, cy + 25, fill=STEEL)
    p.oval(cx - 11, cy - 11, cx + 11, cy + 11, fill="white", w=1.3)
    p.line(cx - 30, cy, cx + 30, cy, fill=ACC, w=0.9, dash=(7, 2, 1, 2))
    p.line(cx, cy - 30, cx, cy + 30, fill=ACC, w=0.9, dash=(7, 2, 1, 2))


def _copy(p):
    p.poly([(10, 8), (46, 8), (58, 20), (58, 66), (10, 66)], fill=ACC_L)
    p.poly([(46, 8), (46, 20), (58, 20)], fill="white", w=1.2)
    for y in (32, 42, 52):
        p.line(18, y, 50, y, fill=ACC, w=1.1)
    p.poly([(34, 32), (76, 32), (90, 46), (90, 92), (34, 92)], fill="white", w=1.7)
    p.poly([(76, 32), (76, 46), (90, 46)], fill=STEEL, w=1.2)
    for y in (58, 68, 78):
        p.line(42, y, 82, y, fill=INK, w=1.2)


def _mine(p):
    """Lista wpisów (tabela) z okrągłą strzałką cofania."""
    p.rect(8, 12, 92, 68, fill="white", w=1.6)
    p.rect(8, 12, 92, 27, fill=ACC_L, w=1.6)
    for y in (41, 55):
        p.line(8, y, 92, y, fill=GRID, w=1.0)
    p.line(38, 12, 38, 68, fill=GRID, w=1.0)
    p.oval(54, 52, 96, 94, fill="white", line=ACC, w=1.8)
    p.arc(64, 62, 86, 84, 40, 250, line=ACC, w=2.4)
    ex, ey = 75 + 11 * math.cos(math.radians(290)), 73 - 11 * math.sin(math.radians(290))
    p.poly([(ex + 1, ey - 7), (ex - 6, ey + 1), (ex + 6, ey + 3)], fill=ACC, line=ACC, w=1.0)


def _gear(p):
    pts = []
    for k in range(8):
        a = math.radians(k * 45)
        for da, r in ((-13, 31), (-8, 41), (8, 41), (13, 31)):
            pts.append((50 + r * math.cos(a + math.radians(da)), 50 + r * math.sin(a + math.radians(da))))
    p.poly(pts, fill=STEEL, w=1.8)
    p.oval(24, 24, 76, 76, fill="", line=INK, w=1.0)
    p.oval(38, 38, 62, 62, fill="white", w=1.8)


def _catalog(p, kind="anchor"):
    """Okno katalogu: lista norm, tabela pozycji i mały rysunek zaznaczonej pozycji."""
    p.rect(6, 10, 94, 90, fill="white", w=1.7)
    p.rect(6, 10, 94, 22, fill=ACC_L, w=1.7)
    p.rect(6, 22, 32, 90, fill="", w=1.2)
    p.rect(8, 28, 30, 38, fill=ACC_L, line=ACC, w=1.2)
    for y in (46, 56, 66, 76):
        p.line(10, y, 28, y, fill=GRID, w=1.4)
    for y in (34, 44, 54, 64, 74, 84):
        p.line(32, y, 66, y, fill=GRID, w=1.0)
    p.rect(32, 24, 66, 34, fill="", line=ACC, w=1.2)
    p.rect(66, 22, 94, 90, fill="", w=1.2)
    q = Pen(p.cv, p.s * 100, p.ox + 67.0 * p.k, p.oy + 32.0 * p.k, 0.3 * p.k)
    _anchor(q) if kind == "anchor" else _bolt(q)


ICONS = {"anchor": lambda p: _anchor(p), "bolt": _bolt, "set": _stud_set, "length": _length, "washer": _washer,
         "copy": _copy, "mine": _mine, "settings": _gear, "catalog": _catalog,
         "catalog_bolt": lambda p: _catalog(p, "bolt")}


def draw_icon(cv, name, size=84, clear=True):
    if clear:
        cv.delete("all")
    p = Pen(cv, size)
    if name == "newanchor":
        q = Pen(cv, size, 0, 14, 0.82)
        _anchor(q)
        p.oval(66, 4, 96, 34, fill=ACC, line=ACC, w=1.0)
        p.line(81, 11, 81, 27, fill="white", w=3.0)
        p.line(73, 19, 89, 19, fill="white", w=3.0)
    elif name in ICONS:
        ICONS[name](p)
    else:
        p.rect(10, 10, 90, 90, fill="", line=GRID, w=1.2)


def icon(parent, name, size=84, bg=None):
    """Canvas z ilustracją; bg = kolor tła karty (domyślnie tło karty z motywu)."""
    if bg is None:
        try:
            from tkinter import ttk
            bg = ttk.Style(parent).lookup("Card.TFrame", "background") or "#fdfdfd"
        except Exception:
            bg = "#fdfdfd"
    cv = tk.Canvas(parent, width=size, height=size, bg=bg, highlightthickness=0, bd=0)
    draw_icon(cv, name, size)
    return cv


def placeholder(cv, name, text, W, H, size=110):
    """Pusty stan podglądu: ilustracja + podpowiedź (zamiast samego szarego napisu)."""
    cv.delete("all")
    before = set(cv.find_all())
    draw_icon(cv, name, size, clear=False)
    ox, oy = (W - size) / 2.0, max(10, H / 2.0 - size / 2.0 - 26)
    for i in set(cv.find_all()) - before:
        cv.move(i, ox, oy)
    cv.create_text(W / 2.0, oy + size + 22, text=text, fill="#6b7682", width=max(120, W - 50), justify="center")
