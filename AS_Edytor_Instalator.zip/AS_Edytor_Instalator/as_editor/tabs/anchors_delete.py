# -*- coding: utf-8 -*-
"""Zakładka Kotwy: usuń moje kotwy."""
from as_editor.common import in_clause, is_own, q
from as_editor.ui.widgets import messagebox, tk, ttk


class AnchorsDeleteMixin:
    # --- 3. usuń moje kotwy ---
    def build_anchor_del(self):
        f = self.sub_adl
        ttk.Label(f, text="Usuwa wyłącznie kotwy z właścicielem innym niż DSC (np. MOJA, PL1) wraz z ich definicjami i "
                          "otworami. Kotwy fabryczne są chronione.", wraplength=900, foreground="#444").pack(
            anchor="w", padx=8, pady=8)
        row = ttk.Frame(f)
        row.pack(anchor="w", padx=8)
        ttk.Label(row, text="Norma:").pack(side="left")
        self.cb_adstd = ttk.Combobox(row, width=46, state="readonly")
        self.cb_adstd.pack(side="left", padx=6)
        self.cb_adstd.bind("<<ComboboxSelected>>", self.ad_on_std)
        ttk.Label(row, text="Klasa:").pack(side="left", padx=(12, 2))
        self.cb_adcl = ttk.Combobox(row, width=20, state="readonly")
        self.cb_adcl.pack(side="left")
        self.cb_adcl.bind("<<ComboboxSelected>>", lambda e: self.ad_count())
        ttk.Button(f, text="Usuń moje kotwy", command=self.ad_do).pack(anchor="w", padx=8, pady=10)
        self.var_adinfo = tk.StringVar()
        ttk.Label(f, textvariable=self.var_adinfo, wraplength=900).pack(anchor="w", padx=8)

    def ad_std(self):
        i = self.cb_adstd.current()
        return self.an_std_rows[i] if 0 <= i < len(self.an_std_rows) else None

    def ad_on_std(self, _=None):
        r = self.ad_std()
        if not r:
            return
        self.cb_adcl["values"] = [self.ALL_AK] + self.db.anchor_materials(r[0])
        self.cb_adcl.set(self.ALL_AK)
        self.ad_count()

    def ad_ids(self):
        r = self.ad_std()
        if not r:
            return None
        mat = self.cb_adcl.get()
        sql, params = "SELECT [ID] FROM [AnchorsName] WHERE [Standard]=? AND " + self.OWN_COND, [r[0]]
        if mat and mat != self.ALL_AK:
            sql += " AND [MaterialKey]=?"
            params.append(mat)
        ids = [x[0] for x in self.db.rows(sql, params)]
        return r, ids, (not mat or mat == self.ALL_AK)

    def ad_count(self):
        res = self.ad_ids() if self.db.conn else None
        if not res:
            return None
        r, ids, whole = res
        n_def = 0
        for i in range(0, len(ids), 500):
            c, p = in_clause("AnchorID", ids[i:i + 500])
            n_def += self.db.count("AnchorsDefinition", c, p)
        self.var_adinfo.set("Moje kotwy do usunięcia: %d (definicji długości: %d)." % (len(ids), n_def))
        return len(ids), n_def

    def ad_do(self):
        if not self.need_db():
            return
        res = self.ad_ids()
        if not res:
            messagebox.showinfo("Usuń", "Wybierz normę.")
            return
        r, ids, whole = res
        std_own = whole and is_own(r[2])
        if not ids and not std_own:
            messagebox.showinfo("Usuń", "Nie ma tu moich kotew do usunięcia.")
            return
        if not messagebox.askyesno("Potwierdź", "Usunąć %d kotew wraz z definicjami i otworami%s?" % (
                len(ids), " oraz (jeśli nic nie zostanie) wpis normy" if std_own else "")):
            return
        if not self.backup_before_write():
            return

        def fn(cur):
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                for table, col in (("AnchorsDefinition", "AnchorID"), ("AnchorsHoleDefinition", "AnchorNameID"),
                                   ("AnchorsName", "ID")):
                    c, p = in_clause(col, chunk)
                    cur.execute("DELETE FROM %s WHERE %s" % (q(table), c), p)
            if std_own:
                cur.execute("SELECT COUNT(*) FROM [AnchorsName] WHERE [Standard]=?", (r[0],))
                if cur.fetchone()[0] == 0:
                    cur.execute("DELETE FROM [AnchorsStandard] WHERE [Key]=?", (r[0],))
        if self.write_or_report(fn):
            self.reload()
            self.cb_adcl.set("")
            self.var_adinfo.set("Usunięto.")
