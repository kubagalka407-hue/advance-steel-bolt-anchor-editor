# -*- coding: utf-8 -*-
"""Edytor składu zestawu śruby w jednej liście, fizycznie od łba w dół (jak w Tekli); używany w kreatorach."""
from as_editor.config import MAX_ITEMS
from as_editor.i18n import T
from as_editor.ui.dialogs import CompDialog
from as_editor.ui.widgets import messagebox, style_listbox, tk, ttk


class CompEditor(ttk.Frame):
    """head: elementy po stronie łba (indeks 0 = przy blasze), nut: po stronie nakrętki (0 = przy blasze).
    get_dias() -> średnice, dla których element musi istnieć w bazie; on_change() po każdej zmianie."""

    def __init__(self, parent, app, get_dias, on_change=None):
        super().__init__(parent)
        self.app, self.db, self.get_dias, self.on_change = app, app.db, get_dias, on_change
        self.head, self.nut, self.map = [], [], []
        box = ttk.Frame(self)
        box.pack(fill="both", expand=True)
        self.lb = tk.Listbox(box, height=12, exportselection=False, selectmode="browse", activestyle="none", borderwidth=1, relief="solid",
                             highlightthickness=0, selectbackground="#cfe3f7", selectforeground="#000")
        style_listbox(self.lb)
        self.lb.configure(selectbackground="#cfe3f7", selectforeground="#000")
        sb = ttk.Scrollbar(box, orient="vertical", command=self.lb.yview)
        self.lb.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.lb.pack(side="left", fill="both", expand=True)
        b = ttk.Frame(self)
        b.pack(fill="x", pady=(8, 0))
        for txt, cmd in (("+ " + T("pod łbem"), lambda: self.add("head")), ("+ " + T("przy nakrętce"), lambda: self.add("nut")),
                         (T("Zamień..."), self.replace), (T("Duplikuj"), self.duplicate), (T("Usuń"), self.remove),
                         ("▲", lambda: self.move(-1)), ("▼", lambda: self.move(1))):
            ttk.Button(b, text=txt, command=cmd).pack(side="left", padx=(0, 6))

    # ------------------------------------------------------------ widok
    def set_items(self, head, nut):
        self.head, self.nut = [dict(c) for c in head], [dict(c) for c in nut]
        self.refresh()

    def label(self, comp):
        ds = self.get_dias()
        dia = ds[0] if ds else None
        kind, desc = "washer", ""
        if dia is not None:
            h, od, kind, desc, ok = self.app.item_dims(comp, dia)
        bad = any(self.db.nut_item(comp["std"], comp["mat"], d) is None for d in ds)
        name = {"washer": T("podkładka"), "nut": T("nakrętka"), "missing": T("BRAK")}.get(kind, T("element"))
        txt = "    %s  %s / %s" % (name, comp["std"], comp["mat"])
        if desc and not bad:
            txt += "   –   " + desc
        if bad:
            txt += "   (" + T("brak w bazie dla części średnic") + ")"
        return txt, bad

    def refresh(self, keep=None):
        self.lb.delete(0, "end")
        self.map = []

        def fixed(text):
            self.lb.insert("end", text)
            self.lb.itemconfig("end", foreground="#888888")
            self.map.append(None)

        def item(side, i, comp):
            txt, bad = self.label(comp)
            self.lb.insert("end", txt)
            if bad:
                self.lb.itemconfig("end", foreground="#b00000")
            self.map.append((side, i))
        fixed("■  " + T("łeb śruby"))
        for i in range(len(self.head) - 1, -1, -1):
            item("head", i, self.head[i])
        fixed("══  " + T("pakiet blach") + "  ══")
        for i, c in enumerate(self.nut):
            item("nut", i, c)
        fixed("■  " + T("koniec śruby"))
        if keep is not None and keep in self.map:
            self.lb.selection_set(self.map.index(keep))
        if self.on_change:
            self.on_change()

    def sel(self):
        s = self.lb.curselection()
        return self.map[s[0]] if s and self.map[s[0]] else None

    def lst(self, side):
        return self.head if side == "head" else self.nut

    # ------------------------------------------------------------ edycja
    def pick(self, title, kind):
        ds = self.get_dias()
        return CompDialog(self.winfo_toplevel(), self.db, title, ds[0] if ds else None, kind).result

    def add(self, side):
        if len(self.head) + len(self.nut) >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS, parent=self.winfo_toplevel())
            return
        lst = self.lst(side)
        r = self.pick(T("Dodaj element - ") + T("strona łba" if side == "head" else "strona nakrętki"),
                      "nut" if (side == "nut" and lst) else "washer")
        if r:
            lst.append(r)
            self.refresh((side, len(lst) - 1))

    def replace(self):
        ref = self.sel()
        if not ref:
            messagebox.showinfo("Zamień", "Zaznacz element na liście.", parent=self.winfo_toplevel())
            return
        r = self.pick(T("Zamień element"), "nut")
        if r:
            self.lst(ref[0])[ref[1]] = r
            self.refresh(ref)

    def duplicate(self):
        """Kopiuje zaznaczony element (wszystkie ustawienia: norma, klasa...) tuż obok oryginału; potem można go zamienić / przesunąć."""
        ref = self.sel()
        if not ref:
            messagebox.showinfo("Duplikuj", "Zaznacz element na liście.", parent=self.winfo_toplevel())
            return
        if len(self.head) + len(self.nut) >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS, parent=self.winfo_toplevel())
            return
        side, i = ref
        self.lst(side).insert(i + 1, dict(self.lst(side)[i]))
        self.refresh((side, i + 1))

    def remove(self):
        ref = self.sel()
        if ref:
            del self.lst(ref[0])[ref[1]]
            self.refresh()

    def move(self, direction):
        """direction: -1 = fizycznie w górę, +1 = w dół (jak w widoku Tekla)."""
        ref = self.sel()
        if not ref:
            return
        side, i = ref
        lst = self.lst(side)
        j = i + (-direction if side == "head" else direction)
        if 0 <= j < len(lst):
            lst[i], lst[j] = lst[j], lst[i]
            self.refresh((side, j))
