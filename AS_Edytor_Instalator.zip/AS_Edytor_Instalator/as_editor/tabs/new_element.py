# -*- coding: utf-8 -*-
"""Zakładka Śruby -> Nowa podkładka / nakrętka."""
from as_editor.bolts_logic import recalc_weight
from as_editor.common import fmt_dia, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER
from as_editor.ui.widgets import make_tree, messagebox, simpledialog, tk, ttk


class NewElementMixin:
    # ------------------------------------------------------------------ nowa podkładka / nakrętka
    def build_newelem(self):
        f = self.tab_new
        left = ttk.Frame(f)
        left.pack(side="left", fill="y", padx=8, pady=6)
        ttk.Label(left, text="Nowy element na wzór istniejącego (typowe wymiary z bazy)",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.ne_kind = tk.StringVar(value="washer")
        kb = ttk.Frame(left)
        kb.pack(anchor="w", pady=4)
        for txt, val in (("Podkładka", "washer"), ("Nakrętka", "nut")):
            ttk.Radiobutton(kb, text=txt, value=val, variable=self.ne_kind, command=self.ne_fill_std).pack(side="left", padx=6)
        ttk.Label(left, text="Wzorzec - norma").pack(anchor="w", pady=(6, 0))
        self.cb_nestd = ttk.Combobox(left, width=44, state="readonly")
        self.cb_nestd.pack(anchor="w")
        self.cb_nestd.bind("<<ComboboxSelected>>", self.ne_on_std)
        ttk.Label(left, text="Wzorzec - klasa / twardość").pack(anchor="w", pady=(6, 0))
        self.cb_nemat = ttk.Combobox(left, width=24, state="readonly")
        self.cb_nemat.pack(anchor="w")
        ttk.Button(left, text="Wczytaj wymiary wzorca", command=self.ne_load).pack(anchor="w", pady=6)
        self.v_nekey, self.v_nerun, self.v_nemat = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.v_neowner = tk.StringVar(value=DEFAULT_OWNER)
        self.v_nename = tk.StringVar(value="{run} Ø{d}")
        self.v_mh, self.v_mo = tk.StringVar(value="1.0"), tk.StringVar(value="1.0")
        for lab, var in (("Kod nowej normy (max 32 znaki)", self.v_nekey),
                         ("Nazwa normy na liście", self.v_nerun),
                         ("Nowa klasa / twardość", self.v_nemat),
                         ("Właściciel (max 15)", self.v_neowner),
                         ("Wzór nazwy ({run}, {d})", self.v_nename),
                         ("Mnożnik wysokości/grubości", self.v_mh),
                         ("Mnożnik średnicy zewnętrznej", self.v_mo)):
            ttk.Label(left, text=lab).pack(anchor="w", pady=(6, 0))
            ttk.Entry(left, textvariable=var, width=46).pack(anchor="w")
        ttk.Button(left, text="Zastosuj mnożniki i nazwy", command=self.ne_apply).pack(anchor="w", pady=8)
        right = ttk.Frame(f)
        right.pack(side="left", fill="both", expand=True, padx=8, pady=6)
        ttk.Label(right, text="Wymiary dla wszystkich średnic (dwuklik w komórkę = edycja; waga przelicza się sama)").pack(anchor="w")
        fr, self.tr_ne = make_tree(right, ("Ø", "Wysokość/grubość", "Ø zewnętrzna", "Waga [kg]", "Nazwa"),
                                   (60, 130, 110, 100, 300), 22)
        fr.pack(fill="both", expand=True)
        self.tr_ne.bind("<Double-1>", self.ne_edit)
        ttk.Label(right, text="Zaznacz wiersze do zapisu (bez zaznaczenia: wszystkie).").pack(anchor="w", pady=4)
        ttk.Button(right, text="Zapisz nowy element do bazy", command=self.ne_save).pack(anchor="e", pady=4)

    def ne_fill_std(self):
        if not self.db.conn:
            return
        self.ne_stds = self.db.nut_standards(self.ne_kind.get())
        self.cb_nestd["values"] = ["%s   |   %s" % (a, b) for a, b in self.ne_stds]
        self.cb_nestd.set("")
        self.cb_nemat.set("")
        self.cb_nemat["values"] = []

    def ne_cur_std(self):
        i = self.cb_nestd.current()
        return self.ne_stds[i][0] if i >= 0 else None

    def ne_on_std(self, _=None):
        mats = self.db.nut_materials(self.ne_cur_std())
        self.cb_nemat["values"] = mats
        if mats:
            self.cb_nemat.current(0)
        std = self.ne_cur_std()
        if std and not self.v_nekey.get():
            self.v_nekey.set(std + "-MOJA")
            self.v_nerun.set(std + " (moja)")
        self.v_nemat.set(self.cb_nemat.get())

    def ne_load(self):
        if not self.need_db():
            return
        std, mat = self.ne_cur_std(), self.cb_nemat.get()
        if not std or not mat:
            messagebox.showinfo("Wzorzec", "Wybierz normę i klasę wzorca.")
            return
        rows, cols = self.db.nut_rows(std, mat)
        self.ne_rows = []
        for r in rows:
            d = dict(zip(cols, r))
            h, od, w = d.get("Height") or 0.0, d.get("OutsideDiameter") or 0.0, d.get("Weight") or 0.0
            self.ne_rows.append({"dia": float(d["Diameter"]), "tpl": d, "h": h, "od": od, "w": w, "name": ""})
        if not self.v_nemat.get():
            self.v_nemat.set(mat)
        self.ne_apply()

    def ne_apply(self):
        try:
            mh = float(self.v_mh.get().replace(",", "."))
            mo = float(self.v_mo.get().replace(",", "."))
        except ValueError:
            messagebox.showwarning("Mnożniki", "Mnożniki muszą być liczbami (np. 1.0 lub 1.2).")
            return
        kind = self.ne_kind.get()
        pattern = self.v_nename.get() or "{run} Ø{d}"
        run = self.v_nerun.get().strip() or self.v_nekey.get().strip()
        for r in self.ne_rows:
            t = r["tpl"]
            th, tod, tw = t.get("Height") or 0.0, t.get("OutsideDiameter") or 0.0, t.get("Weight") or 0.0
            r["h"] = round(th * mh, 3)
            r["od"] = round(tod * mo, 3)
            r["w"] = round(recalc_weight(kind, th, tod, tw, r["h"], r["od"]) or 0.0, 6)
            r["name"] = pattern.replace("{run}", run).replace("{d}", fmt_dia(r["dia"]))
        self.ne_refresh()

    def ne_refresh(self):
        self.tr_ne.delete(*self.tr_ne.get_children())
        for i, r in enumerate(self.ne_rows):
            self.tr_ne.insert("", "end", iid=str(i), values=(fmt_dia(r["dia"]), r["h"], r["od"], r["w"], r["name"]))

    def ne_edit(self, event):
        iid = self.tr_ne.identify_row(event.y)
        col = self.tr_ne.identify_column(event.x)
        if not iid or col not in ("#2", "#3", "#4", "#5"):
            return
        r = self.ne_rows[int(iid)]
        key = {"#2": "h", "#3": "od", "#4": "w", "#5": "name"}[col]
        val = simpledialog.askstring("Edycja", "Nowa wartość:", initialvalue=str(r[key]), parent=self.root)
        if val is None:
            return
        try:
            r[key] = val if key == "name" else float(val.replace(",", "."))
        except ValueError:
            messagebox.showwarning("Wartość", "Podaj liczbę.")
            return
        if key in ("h", "od"):
            t = r["tpl"]
            r["w"] = round(recalc_weight(self.ne_kind.get(), t.get("Height") or 0.0, t.get("OutsideDiameter") or 0.0,
                                         t.get("Weight") or 0.0, r["h"], r["od"]) or 0.0, 6)
        self.ne_refresh()

    def ne_save(self):
        if not self.need_db() or not self.ne_rows:
            messagebox.showinfo("Zapis", "Najpierw wczytaj wymiary wzorca.")
            return
        key, run = self.v_nekey.get().strip(), self.v_nerun.get().strip() or self.v_nekey.get().strip()
        mat, owner = self.v_nemat.get().strip(), self.v_neowner.get().strip()
        errs = []
        if not key or len(key) > 32:
            errs.append("Klucz normy: wymagany, max 32 znaki.")
        if not mat or len(mat) > 64:
            errs.append("Klasa / twardość: wymagana, max 64 znaki.")
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        if key and mat and self.db.nutset_exists(key, mat):
            errs.append("Element %s / %s już istnieje - wybierz inny klucz albo klasę (lub usuń go w przeglądarce)." % (key, mat))
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return
        sel = [int(i) for i in self.tr_ne.selection()] or list(range(len(self.ne_rows)))
        if not messagebox.askyesno("Potwierdź", "Dodać %d wierszy do SetNutsBolts jako %s / %s?" % (len(sel), key, mat)):
            return
        if not self.backup_before_write():
            return
        add_std = not self.db.nutstd_exists(key)

        def fn(cur):
            if add_std:
                sql, p = insert_sql("StandardNuts", {"ID": key, "RunName": run[:64], "OwnerText": owner})
                cur.execute(sql, p)
            for i in sel:
                r = self.ne_rows[i]
                row = dict(r["tpl"])
                row.update({"Standard": key, "Material": mat, "Height": r["h"], "OutsideDiameter": r["od"],
                            "Weight": r["w"], "Name": r["name"][:255], "OwnerText": owner[:15]})
                sql, p = insert_sql("SetNutsBolts", row)
                cur.execute(sql, p)
        try:
            self.db.write(fn)
        except Exception as e:
            messagebox.showerror("Błąd zapisu (zmiany wycofane)", str(e))
            return
        self.ne_fill_std()
        self.reload_browsers()
        messagebox.showinfo("Gotowe", "Dodano element %s / %s (%d średnic).\nW zakładce 'Zestaw śrub' wybierzesz go "
                                      "w oknie dodawania elementu." % (key, mat, len(sel)))
