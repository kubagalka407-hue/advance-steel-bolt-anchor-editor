# -*- coding: utf-8 -*-
"""Pełny edytor kotwy (metody an_*) używany przez AnchorDialog."""
from as_editor.anchors_logic import ANCHOR_DEF_COLS, ANCHOR_DEF_FIELDS, ANCHOR_LABELS, anchor_positions, anchor_weight, build_anchor_def_row, build_anchor_name_row, empty_hole_row, pick_dia, rename_part, zone_of
from as_editor.bolts_logic import parse_lengths
from as_editor.common import fmt_dia, insert_sql, is_own
from as_editor.config import DEFAULT_OWNER, MAX_ITEMS
from as_editor.i18n import T
from as_editor.ui.anchor_shape import DEFAULT_PLATE, check_dims, draw as shape_draw, num, resolve_items
from as_editor.ui.dialogs import AnLoadDialog, ChoiceDialog, CompDialog
from as_editor.ui.widgets import edit_cell, make_list, make_tree, messagebox, simpledialog, tk, ttk


class AnchorEditorMixin:
    def an_fill_lists(self):
        """(okno kotwy) Wypełnia listy: normy, typy, źródła, klasy i zestawy oraz średnice danymi z bazy."""
        old_sel = self.an_sel_dias()
        std_disp = ["%s   |   %s%s" % (r[0], r[1], "   [MOJA]" if is_own(r[2]) else "") for r in self.an_std_rows]
        self.cb_anstd["values"] = std_disp
        self.cb_antype["values"] = ["%s   |   %s" % (r[0], r[1]) for r in self.an_type_rows]
        self.cb_ansrc["values"] = ["%s   |   %s" % (r[0], (r[1] or "")[:40]) for r in self.an_src_rows]
        self.an_refresh_choices()
        self.lb_andia.delete(0, "end")
        for r in self.an_dia_rows:
            self.lb_andia.insert("end", "Ø %s   (%s)" % (fmt_dia(float(r[0])), (r[1] or "").strip()))
        for i, v in enumerate(self.an_dia_vals):
            if any(abs(v - o) < 1e-9 for o in old_sel):
                self.lb_andia.selection_set(i)

    def an_scaled_rows(self, base_dia, rows, d2):
        """Kopia wierszy definicji dla innej średnicy: waga skalowana ~d², numer części z nową średnicą."""
        k = (d2 / base_dia) if base_dia else 1.0
        new = []
        for r in rows:
            nr = dict(r)
            if abs(k - 1.0) > 1e-9:
                if r.get("Weight"):
                    nr["Weight"] = round(r["Weight"] * k * k, 4)
                if r.get("PartName"):
                    nr["PartName"] = r["PartName"].replace("M%s" % fmt_dia(base_dia), "M%s" % fmt_dia(d2))[:64]
            new.append(nr)
        return new

    def an_fill_col(self):
        d = self.an_active_dia()
        rows = self.an_defs.get(d, [])
        if d is None or not rows:
            messagebox.showinfo("Kolumna", "Najpierw dodaj wiersze (długości) dla wybranej średnicy.")
            return
        dlg = ChoiceDialog(self.root, "Wypełnij kolumnę", "Parametr, który ustawić dla wszystkich wierszy tej średnicy:",
                           [T(ANCHOR_LABELS[c]) for c in self.an_cols])
        if not dlg.result:
            return
        key = next(c for c in self.an_cols if T(ANCHOR_LABELS[c]) == dlg.result)
        val = simpledialog.askstring("Wartość", "%s dla wszystkich wierszy (puste = brak wartości):" % dlg.result,
                                     parent=self.root)
        if val is None:
            return
        try:
            if not val.strip():
                v = None
            elif key == "PartName":
                v = val.strip()
            elif key == "NumberOfHeadEdges":
                v = int(val)
            else:
                v = float(val.replace(",", "."))
        except ValueError:
            messagebox.showwarning("Wartość", "Podaj liczbę.")
            return
        for r in rows:
            r[key] = v
        self.an_show_defs()
        self.an_draw()

    # --- 1. definicja kotwy ---
    def build_anchor_def(self):
        f = self.sub_ad
        left = ttk.Frame(f)
        left.pack(side="left", fill="y", padx=6, pady=6)
        g = ttk.Frame(left)
        g.pack(anchor="w")
        self.v_anrun, self.v_ansrclong = tk.StringVar(), tk.StringVar()
        self.v_anown = tk.StringVar(value=DEFAULT_OWNER)
        self.v_anexpl = tk.BooleanVar(value=True)
        self.var_anover = tk.BooleanVar(value=False)
        self.v_anplate = tk.StringVar(value=fmt_dia(DEFAULT_PLATE))
        self.v_angrout = tk.StringVar(value="0")
        for _v in (self.v_anplate, self.v_angrout):
            _v.trace_add("write", lambda *a: self.an_draw())
        self.var_anall = tk.BooleanVar(value=False)
        self.var_anchoice = tk.StringVar()

        def row(r, text, widget):
            ttk.Label(g, text=text).grid(row=r, column=0, sticky="w", pady=2, padx=(0, 6))
            widget.grid(row=r, column=1, pady=2, sticky="w")
        self.cb_anstd = ttk.Combobox(g, width=34)
        self.cb_anstd.bind("<<ComboboxSelected>>", self.an_on_std)
        self.cb_anstd.bind("<FocusOut>", lambda e: self.an_refresh_choices())
        self.cb_anstd.bind("<Return>", lambda e: self.an_refresh_choices())
        row(0, "Nazwa (norma kotwy)", self.cb_anstd)
        row(1, "Nazwa wyświetlana (nowa)", ttk.Entry(g, textvariable=self.v_anrun, width=36))
        self.cb_antype = ttk.Combobox(g, width=34, state="readonly")
        self.cb_antype.bind("<<ComboboxSelected>>", lambda e: self.an_on_type())
        row(2, "Typ", self.cb_antype)
        self.cb_ancls = ttk.Combobox(g, width=34)
        self.cb_ancls.bind("<<ComboboxSelected>>", self.an_on_class_sel)
        row(3, "Klasa (lub wpisz nową)", self.cb_ancls)
        self.cb_ansrc = ttk.Combobox(g, width=34)
        self.cb_ansrc.bind("<<ComboboxSelected>>", self.an_on_src)
        row(4, "Źródło / norma (max 15)", self.cb_ansrc)
        row(5, "Opis nowego źródła", ttk.Entry(g, textvariable=self.v_ansrclong, width=36))
        self.cb_anset = ttk.Combobox(g, width=34)
        self.cb_anset.bind("<<ComboboxSelected>>", self.an_on_set_sel)
        row(6, "Zestaw (lub wpisz nowy)", self.cb_anset)
        row(7, "Właściciel (max 15)", ttk.Entry(g, textvariable=self.v_anown, width=20))
        ttk.Checkbutton(g, text="Możliwe rozbicie zestawu", variable=self.v_anexpl).grid(row=8, column=1, sticky="w")
        ttk.Checkbutton(g, text="pokaż wszystkie klasy i zestawy (także nieprzypisane do normy)", variable=self.var_anall,
                        command=self.an_refresh_choices).grid(row=9, column=0, columnspan=2, sticky="w")
        ttk.Label(g, textvariable=self.var_anchoice, wraplength=400, foreground="#555").grid(
            row=10, column=0, columnspan=2, sticky="w")
        ttk.Label(left, text="Średnice (wielokrotny wybór)").pack(anchor="w", pady=(8, 0))
        fr, self.lb_andia = make_list(left, 8, 34)
        fr.pack(anchor="w")
        self.lb_andia.bind("<<ListboxSelect>>", lambda e: self.an_refresh_dias())
        self.var_anhint = tk.StringVar()
        ttk.Label(left, textvariable=self.var_anhint, wraplength=330, foreground="#a05000").pack(anchor="w", pady=(4, 0))
        rw = ttk.Frame(left)
        rw.pack(anchor="w", pady=4)
        ttk.Label(rw, text="Dodaj średnicę [mm]:").pack(side="left")
        self.v_andianew = tk.StringVar()
        ttk.Entry(rw, textvariable=self.v_andianew, width=8).pack(side="left", padx=4)
        ttk.Button(rw, text="Dodaj", command=self.an_add_dia).pack(side="left")

        mid = ttk.Frame(f)
        mid.pack(side="left", padx=6, pady=6)
        ttk.Label(mid, text="Schemat kotwy (poglądowy) - pokazuje wiersz zaznaczony w tabeli wymiarów",
                  font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.an_canvas = tk.Canvas(mid, width=330, height=520, bg="white", highlightthickness=1,
                                   highlightbackground="#999")
        self.an_canvas.pack(pady=4)
        mb = ttk.Frame(mid)
        mb.pack(fill="x")
        ttk.Label(mb, text="Blacha [mm]:").grid(row=0, column=0, sticky="w")
        ttk.Entry(mb, textvariable=self.v_anplate, width=7).grid(row=0, column=1, sticky="w", padx=2)
        ttk.Label(mb, text="Podlewka [mm]:").grid(row=1, column=0, sticky="w")
        ttk.Entry(mb, textvariable=self.v_angrout, width=7).grid(row=1, column=1, sticky="w", padx=2)
        self.var_aninfo = tk.StringVar()
        ttk.Label(mid, textvariable=self.var_aninfo, wraplength=330, foreground="#333").pack(anchor="w")

        right = ttk.Frame(f)
        right.pack(side="left", fill="both", expand=True, padx=6, pady=6)
        b2 = ttk.Frame(right)
        b2.pack(side="bottom", fill="x", pady=4)
        ttk.Checkbutton(b2, text="Nadpisz istniejące MOJE kotwy", variable=self.var_anover).pack(side="left")
        ttk.Button(b2, text="Zapisz do bazy", command=self.an_save).pack(side="right", padx=4)
        ttk.Button(b2, text="Podgląd", command=self.an_preview).pack(side="right", padx=4)
        ttk.Button(b2, text="Zamknij", command=self.destroy).pack(side="right", padx=4)
        top = ttk.Frame(right)
        top.pack(fill="x")
        ttk.Label(top, text="Definicje (długości) dla Ø:").pack(side="left")
        self.cb_andia = ttk.Combobox(top, width=9, state="readonly")
        self.cb_andia.pack(side="left", padx=4)
        self.cb_andia.bind("<<ComboboxSelected>>", lambda e: self.an_on_active_dia())
        for txt, cmd in (("+ Wiersz", self.an_add_row), ("Usuń wiersz", self.an_del_row),
                         ("Generuj długości...", self.an_gen_lengths), ("Wypełnij kolumnę...", self.an_fill_col),
                         ("Kopiuj do pozostałych Ø", self.an_copy_others)):
            ttk.Button(top, text=txt, command=cmd).pack(side="left", padx=2)
        self.an_defs_frame = ttk.Frame(right)
        self.an_defs_frame.pack(fill="x", pady=4)
        ttk.Label(right, text="Zestaw: nakrętki i podkładki. W każdej strefie wiersz 1 jest najdalej od blachy, "
                              "ostatni przy blasze (pozycje w bazie: góra +1.., pod blachą -1.., koniec kotwy -101..)."
                  ).pack(anchor="w")
        fr, self.tr_ancomp = make_tree(right, ("Strefa", "Nr", "Norma elementu", "Klasa", "Opis (dla wybranej Ø)"),
                                       (124, 28, 126, 74, 350), 6, "browse")
        fr.pack(fill="x")
        self.tr_ancomp.tag_configure("fixed", foreground="#666", background="#f0f0f0")
        self.tr_ancomp.tag_configure("washer", background="#e3effa")
        self.tr_ancomp.tag_configure("nut", background="#fbe9d6")
        self.tr_ancomp.tag_configure("missing", background="#f8d6d6")
        bar = ttk.Frame(right)
        bar.pack(fill="x", pady=4)
        for txt, cmd in (("+ Nad blachą", lambda: self.an_add_comp("top")), ("+ Pod blachą", lambda: self.an_add_comp("below")),
                         ("+ Koniec kotwy", lambda: self.an_add_comp("end")), ("Usuń", self.an_del_comp),
                         ("▲", lambda: self.an_move_comp(-1)), ("▼", lambda: self.an_move_comp(1)),
                         ("Wczytaj wzorzec kotwy...", self.an_load_template)):
            ttk.Button(bar, text=txt, command=cmd).pack(side="left", padx=2)
        ttk.Label(right, text="Podgląd kotew do zapisu").pack(anchor="w", pady=(6, 0))
        fr, self.tr_anprev = make_tree(right, ("Norma", "Typ", "Klasa", "Ø", "Zestaw", "Źródło", "Def.", "Status"),
                                       (110, 40, 70, 50, 130, 90, 40, 260), 4)
        fr.pack(fill="both", expand=True)
        self.an_rebuild_defs_tree()
        self.an_draw()

    def an_type_id(self):
        i = self.cb_antype.current()
        return self.an_type_rows[i][0] if 0 <= i < len(self.an_type_rows) else None

    def an_class_key(self):
        t = self.cb_ancls.get().strip()
        if "   |   " in t:
            t = t.split("   |   ")[0].strip()
        return t or None

    def an_sel_dias(self):
        return [self.an_dia_vals[i] for i in self.lb_andia.curselection() if i < len(self.an_dia_vals)]

    def an_active_dia(self):
        dias = self.an_sel_dias()
        i = self.cb_andia.current()
        return dias[i] if 0 <= i < len(dias) else None

    def an_on_std(self, _=None):
        i = self.cb_anstd.current()
        if 0 <= i < len(self.an_std_rows):
            self.cb_anstd.set(self.an_std_rows[i][0])
        self.an_std_changed()

    def an_refresh_choices(self):
        """Lista klas i zestawów: tylko te użyte przez wybraną normę (albo wszystkie po zaznaczeniu opcji / dla nowej normy)."""
        std = self.cb_anstd.get().strip()
        known = bool(self.db.conn and std in [r[0] for r in self.an_std_rows])
        if self.var_anall.get() or not known:
            self.an_class_choices = [(r[0], r[1] or r[0]) for r in self.cls_rows]
            self.an_set_choices = [(x[0], x[1] or x[0]) for x in self.sets]
        else:
            cls_map = {r[0]: (r[1] or r[0]) for r in self.cls_rows}
            self.an_class_choices = [(m, cls_map.get(m, m)) for m in self.db.anchor_materials(std)]
            self.an_set_choices = [(r[0], r[1]) for r in self.db.anchor_set_names(std)]
        self.cb_ancls["values"] = ["%s   |   %s" % (k, r) for k, r in self.an_class_choices]
        self.cb_anset["values"] = ["%s   |   %s" % (k, r) for k, r in self.an_set_choices]
        if not self.db.conn:
            self.var_anchoice.set("")
        elif not known:
            self.var_anchoice.set("Nowa norma: lista zawiera wszystkie klasy i zestawy. Nową klasę lub zestaw wpisz w polu - "
                                  "zostanie utworzona przy zapisie.")
        elif self.var_anall.get():
            self.var_anchoice.set("Pokazuję wszystkie klasy i zestawy. Nową klasę lub zestaw możesz też wpisać w polu.")
        else:
            self.var_anchoice.set("Norma ma klas: %d, zestawów: %d. Nową klasę lub zestaw wpisz w polu (zostanie utworzona "
                                  "przy zapisie) albo zaznacz 'pokaż wszystkie'." % (
                                      len(self.an_class_choices), len(self.an_set_choices)))

    def an_std_changed(self):
        """Po wyborze normy z listy: zawęża klasy i zestawy do dostępnych, ustawia typ i źródło, jeśli są jednoznaczne."""
        self.an_refresh_choices()
        std = self.cb_anstd.get().strip()
        if not (self.db.conn and std in [r[0] for r in self.an_std_rows]):
            return
        types = [r[0] for r in self.db.rows("SELECT DISTINCT [ClassID] FROM [AnchorsName] WHERE [Standard]=?", (std,))]
        if len(types) == 1:
            idx = [k for k, r in enumerate(self.an_type_rows) if r[0] == types[0]]
            if idx and self.cb_antype.current() != idx[0]:
                self.cb_antype.current(idx[0])
                self.an_on_type()
        srcs = [r[0] for r in self.db.rows("SELECT DISTINCT [Source] FROM [AnchorsName] WHERE [Standard]=?", (std,))
                if r[0]]
        if len(srcs) == 1:
            self.cb_ansrc.set(srcs[0])
        for cb, getter, choices in ((self.cb_ancls, self.an_class_key, self.an_class_choices),
                                    (self.cb_anset, lambda: self.cb_anset.get().strip() or None, self.an_set_choices)):
            keys = [k for k, _ in choices]
            if choices and getter() not in keys:
                cb.set(keys[0])

    def an_on_class_sel(self, _=None):
        i = self.cb_ancls.current()
        if 0 <= i < len(self.an_class_choices):
            self.cb_ancls.set(self.an_class_choices[i][0])

    def an_on_set_sel(self, _=None):
        i = self.cb_anset.current()
        if 0 <= i < len(self.an_set_choices):
            self.cb_anset.set(self.an_set_choices[i][0])

    def an_on_src(self, _=None):
        i = self.cb_ansrc.current()
        if 0 <= i < len(self.an_src_rows):
            self.cb_ansrc.set(self.an_src_rows[i][0])

    def an_on_type(self):
        self.an_rebuild_defs_tree()
        self.an_draw()

    def an_refresh_dias(self):
        dias = self.an_sel_dias()
        for d in dias:
            self.an_defs.setdefault(d, [])
            if not self.an_defs[d] and self.an_tpl:          # nowa średnica: wymiary z kotwy-wzorca (przeskalowane)
                self.an_defs[d] = self.an_scaled_rows(self.an_tpl[0], self.an_tpl[1], d)
        self.cb_andia["values"] = ["Ø " + fmt_dia(d) for d in dias]
        if dias:
            self.cb_andia.current(dias.index(self.an_cur) if self.an_cur in dias else 0)
        else:
            self.cb_andia.set("")
        self.an_on_active_dia()

    def an_on_active_dia(self):
        self.an_cur = self.an_active_dia()
        self.an_show_defs()
        self.an_refresh_comps()
        self.an_draw()

    def an_add_dia(self):
        if not self.need_db():
            return
        try:
            v = float(self.v_andianew.get().replace(",", "."))
            assert v > 0
        except (ValueError, AssertionError):
            messagebox.showwarning("Średnica", "Podaj dodatnią liczbę (mm).")
            return
        if any(abs(v - x) < 1e-6 for x in self.an_dia_vals):
            messagebox.showinfo("Średnica", "Taka średnica już jest na liście.")
            return
        if not self.backup_before_write():
            return
        if self.write_or_report(lambda cur: cur.execute(*insert_sql(
                "BoltsDiameters", {"Key": v, "RunName": "%g mm" % v, "Description": None}))):
            self.v_andianew.set("")
            self.refresh_anchor_tabs()
            self.an_fill_lists()

    # --- tabela definicji (kolumny zależne od typu) ---
    def an_rebuild_defs_tree(self):
        for w in self.an_defs_frame.winfo_children():
            w.destroy()
        t = self.an_type_id()
        self.an_cols = ANCHOR_DEF_COLS.get(t, ANCHOR_DEF_COLS[3])
        labels = [ANCHOR_LABELS[c] for c in self.an_cols]
        fr, self.tr_andef = make_tree(self.an_defs_frame, labels,
                                      [250 if c == "PartName" else 80 for c in self.an_cols], 7, "extended")
        fr.pack(fill="both", expand=True)
        self.tr_andef.bind("<Double-1>", self.an_def_edit)
        self.tr_andef.bind("<Control-v>", self.an_paste)
        self.tr_andef.bind("<Control-V>", self.an_paste)
        self.tr_andef.bind("<<TreeviewSelect>>", lambda e: self.an_draw())
        self.an_show_defs()

    def an_show_defs(self, select=None):
        """Odświeża tabelę długości i wymiarów; zachowuje zaznaczenie, bo schemat rysuje zaznaczony wiersz."""
        t = self.tr_andef
        if t is None:
            return
        keep = t.selection()
        t.delete(*t.get_children())
        rows = self.an_defs.get(self.an_active_dia(), [])
        for i, r in enumerate(rows):
            t.insert("", "end", iid=str(i), values=["" if r.get(c) is None else r.get(c) for c in self.an_cols])
        if not rows:
            return
        i = select if select is not None else (int(keep[0]) if keep else 0)
        i = min(max(i, 0), len(rows) - 1)
        t.selection_set(str(i))
        t.see(str(i))

    def an_row_index(self, length):
        """Numer wiersza o podanej długości (do zaznaczenia po dodaniu długości)."""
        rows = self.an_defs.get(self.an_active_dia(), [])
        for i, r in enumerate(rows):
            if r.get("Length") == length:
                return i
        return None

    def an_conv(self, key, val):
        """Tekst z komórki -> wartość kolumny (ValueError przy złym formacie)."""
        val = val.strip()
        if key == "PartName":
            return val or None
        if not val:
            return None
        if key == "NumberOfHeadEdges":
            return int(val)
        return float(val.replace(",", "."))

    def an_def_edit(self, event):
        """Dwuklik w komórkę tabeli wymiarów: edycja wprost w komórce."""
        iid = self.tr_andef.identify_row(event.y)
        col = self.tr_andef.identify_column(event.x)
        d = self.an_active_dia()
        if not iid or d is None:
            return
        idx = int(col.replace("#", "")) - 1
        if not 0 <= idx < len(self.an_cols):
            return
        key = self.an_cols[idx]
        row = self.an_defs[d][int(iid)]

        def commit(txt):
            try:
                row[key] = self.an_conv(key, txt)
            except ValueError:
                raise ValueError(T("Podaj liczbę."))
            self.an_show_defs(int(iid))
            self.an_draw()
        edit_cell(self.tr_andef, iid, col, "" if row.get(key) is None else str(row[key]), commit)

    def an_paste(self, _=None):
        """Ctrl+V w tabeli wymiarów: wkleja z Excela. Jedna kolumna = długości; więcej kolumn = Długość + kolejne wymiary
        w kolejności kolumn tabeli (wiersz o tej samej długości jest aktualizowany, inne dopisywane)."""
        d = self.an_active_dia()
        if d is None:
            messagebox.showinfo("Średnica", "Zaznacz średnicę na liście i wybierz ją w polu 'Definicje dla Ø'.")
            return "break"
        try:
            txt = self.clipboard_get()
        except tk.TclError:
            return "break"
        lines = [ln.split("\t") for ln in txt.splitlines() if ln.strip()]
        if not lines:
            return "break"
        try:
            if max(len(f) for f in lines) == 1:
                self.an_add_lengths(parse_lengths(" ".join(f[0] for f in lines)))
                return "break"
            n = min(max(len(f) for f in lines), len(self.an_cols))
            rows = self.an_defs.setdefault(d, [])
            sel = self.tr_andef.selection()
            base = dict(rows[int(sel[0])]) if sel else (dict(rows[-1]) if rows else
                                                        {"ThreadLength": 100.0, "TopDistance": 40.0, "HookRadius": round(2 * d, 1)})
            first = None
            for f in lines:
                vals = {self.an_cols[i]: self.an_conv(self.an_cols[i], f[i]) for i in range(min(len(f), n)) if f[i].strip()}
                length = vals.get("Length")
                if length is None:
                    raise ValueError(T("Brak długości w wierszu: %s") % "; ".join(f))
                row = next((r for r in rows if r.get("Length") == length), None)
                if row is None:
                    row = dict(base)
                    row["Weight"] = anchor_weight(base.get("Length"), base.get("Weight"), d, length)
                    row["PartName"] = rename_part(base.get("PartName"), base.get("Length"), length, d,
                                                  self.cb_anstd.get().strip() or "Kotwa")
                    rows.append(row)
                row.update(vals)
                first = first if first is not None else length
            rows.sort(key=lambda r: r.get("Length") or 0)
            self.an_show_defs(self.an_row_index(first))
            self.an_draw()
        except ValueError as e:
            messagebox.showwarning("Wklejanie", str(e))
        return "break"

    def an_add_row(self):
        d = self.an_active_dia()
        if d is None:
            messagebox.showinfo("Średnica", "Zaznacz średnicę na liście i wybierz ją w polu 'Definicje dla Ø'.")
            return
        rows = self.an_defs.setdefault(d, [])
        base = dict(rows[-1]) if rows else {"Length": 400.0, "ThreadLength": 100.0, "TopDistance": 40.0,
                                            "HookRadius": round(2 * d, 1)}
        length = (rows[-1]["Length"] + 100.0) if rows and rows[-1].get("Length") else base["Length"]
        base["Weight"] = anchor_weight(base.get("Length"), base.get("Weight"), d, length)
        base["PartName"] = rename_part(base.get("PartName"), base.get("Length"), length, d,
                                       self.cb_anstd.get().strip() or "Kotwa")
        base["Length"] = length
        rows.append(base)
        self.an_show_defs(len(rows) - 1)
        self.an_draw()

    def an_del_row(self):
        d = self.an_active_dia()
        if d is None or self.tr_andef is None:
            return
        for i in sorted((int(x) for x in self.tr_andef.selection()), reverse=True):
            del self.an_defs[d][i]
        self.an_show_defs()
        self.an_draw()

    def an_gen_lengths(self):
        d = self.an_active_dia()
        if d is None:
            messagebox.showinfo("Średnica", "Zaznacz średnicę na liście i wybierz ją w polu 'Definicje dla Ø'.")
            return
        txt = simpledialog.askstring("Generuj długości", "Długości (lista lub zakresy, np. 300-1000/100, 1200):",
                                     parent=self.root)
        if not txt:
            return
        try:
            lens = parse_lengths(txt)
        except ValueError as e:
            messagebox.showwarning("Długości", str(e))
            return
        self.an_add_lengths(lens)

    def an_add_lengths(self, lens):
        d = self.an_active_dia()
        if not lens:
            return
        rows = self.an_defs.setdefault(d, [])
        sel = self.tr_andef.selection() if self.tr_andef is not None else ()
        base = (dict(rows[int(sel[0])]) if sel else (dict(rows[-1]) if rows else
                {"ThreadLength": 100.0, "TopDistance": 40.0, "HookRadius": round(2 * d, 1)}))
        have = {r.get("Length") for r in rows}
        name = self.cb_anstd.get().strip() or "Kotwa"
        for length in lens:
            if length in have:
                continue
            nr = dict(base)
            nr["Weight"] = anchor_weight(base.get("Length"), base.get("Weight"), d, length)
            nr["PartName"] = rename_part(base.get("PartName"), base.get("Length"), length, d, name)
            nr["Length"] = length
            rows.append(nr)
        rows.sort(key=lambda r: r.get("Length") or 0)
        self.an_show_defs(self.an_row_index(lens[0]))
        self.an_draw()

    def an_copy_others(self):
        d = self.an_active_dia()
        rows = self.an_defs.get(d, [])
        if not rows:
            messagebox.showinfo("Kopiuj", "Aktywna średnica nie ma jeszcze definicji.")
            return
        n = 0
        for d2 in self.an_sel_dias():
            if d2 == d or self.an_defs.get(d2):
                continue
            self.an_defs[d2] = self.an_scaled_rows(d, rows, d2)
            n += 1
        messagebox.showinfo("Kopiuj", "Skopiowano wiersze do %d średnic (wartości wymiarowe skopiowane bez zmian - "
                                      "popraw je w razie potrzeby)." % n)

    # --- zestaw kotwy ---
    def an_comp_dia(self, comp, dia):
        return pick_dia(self.db.nut_diameters(comp["std"], comp["mat"]), dia) if (self.db.conn and dia is not None) else None

    def an_refresh_comps(self):
        t = self.tr_ancomp
        t.delete(*t.get_children())
        self.an_comp_map = {}
        dia = self.an_active_dia()
        names = {"top": T("nad blachą"), "below": T("pod blachą"), "end": T("koniec kotwy")}

        def put_comp(zone, i):
            c = self.an_zone[zone][i]
            desc, tag = "", "washer"
            if dia is not None and self.db.conn:
                cd = self.an_comp_dia(c, dia)
                it = self.db.nut_item(c["std"], c["mat"], cd) if cd is not None else None
                if it:
                    desc = self.db.describe(c["std"], c["mat"], cd)
                    tag = "washer" if not it[1] else "nut"
                else:
                    desc, tag = "BRAK elementu dla Ø%s" % fmt_dia(dia), "missing"
            iid = "%s%d" % (zone[0], i)
            t.insert("", "end", iid=iid, values=(names[zone], i + 1, c["std"], c["mat"], desc), tags=(tag,))
            self.an_comp_map[iid] = (zone, i)
        for i in range(len(self.an_zone["top"])):                  # wiersz 1 najdalej od blachy
            put_comp("top", i)
        t.insert("", "end", iid="plate", values=(T("— BLACHA PODSTAWY —"), "", "", "", ""), tags=("fixed",))
        for i in range(len(self.an_zone["below"])):
            put_comp("below", i)
        for i in range(len(self.an_zone["end"])):
            put_comp("end", i)

    def an_add_comp(self, zone):
        if not self.need_db():
            return
        if sum(len(v) for v in self.an_zone.values()) >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS)
            return
        lst = self.an_zone[zone]
        default = "washer" if (zone != "end" and not lst) else "nut"
        title = {"top": T("nad blachą"), "below": T("pod blachą"), "end": T("koniec kotwy")}[zone]
        dlg = CompDialog(self.root, self.db, T("Dodaj element - ") + title, self.an_active_dia(), default)
        if dlg.result:
            lst.append(dlg.result)
            self.an_on_active_dia()

    def an_sel_comp(self):
        sel = self.tr_ancomp.selection()
        return self.an_comp_map.get(sel[0]) if sel else None

    def an_del_comp(self):
        ref = self.an_sel_comp()
        if ref:
            del self.an_zone[ref[0]][ref[1]]
            self.an_on_active_dia()

    def an_move_comp(self, direction):
        ref = self.an_sel_comp()
        if not ref:
            return
        zone, i = ref
        j = i + direction
        lst = self.an_zone[zone]
        if 0 <= j < len(lst):
            lst[i], lst[j] = lst[j], lst[i]
            self.an_on_active_dia()
            self.tr_ancomp.selection_set("%s%d" % (zone[0], j))

    def an_load_template(self):
        if not self.need_db():
            return
        dlg = AnLoadDialog(self.root, self.db, self.an_std_rows)
        if not dlg.result:
            return
        std, mat, set_name = dlg.result
        names = self.db.anchor_names(std, [mat], None, set_name)
        if not names:
            return
        defs, holes = self.db.anchor_children([n["ID"] for n in names])
        first = names[0]
        self.cb_anstd.set(std)
        self.an_refresh_choices()
        ti = [i for i, r in enumerate(self.an_type_rows) if r[0] == first["ClassID"]]
        if ti:
            self.cb_antype.current(ti[0])
        self.cb_ancls.set(mat)
        self.cb_ansrc.set(first.get("Source") or "")
        self.cb_anset.set(set_name)
        self.v_anexpl.set(bool(first.get("Explodable")))
        dias = [float(n["Diameter"]) for n in names]
        self.lb_andia.selection_clear(0, "end")
        for i, v in enumerate(self.an_dia_vals):
            if any(abs(v - d) < 1e-6 for d in dias):
                self.lb_andia.selection_set(i)
        self.an_defs = {}
        for n in names:
            d = next((v for v in self.an_dia_vals if abs(v - float(n["Diameter"])) < 1e-6), float(n["Diameter"]))
            self.an_defs[d] = [{f: r.get(f) for f in ANCHOR_DEF_FIELDS} for r in defs.get(n["ID"], [])]
        self.an_zone = {"top": [], "below": [], "end": []}
        comps = []
        for k in range(1, MAX_ITEMS + 1):
            din, pos, m = first.get("DIN%d" % k), first.get("Position%d" % k), first.get("Material%d" % k)
            if din not in (None, "", "-") and pos:
                comps.append((pos, {"std": din, "mat": m}))
        for pos, c in sorted(comps, key=lambda t: abs(t[0])):
            self.an_zone[zone_of(pos)].append(c)
        self.an_tpl, self.an_edit_id = None, None
        self.an_cur = None
        self.an_on_type()
        self.an_refresh_dias()

    # --- rysunek ---
    def an_draw(self):
        """Schemat kotwy dla zaznaczonego wiersza wymiarów (wspólny rysunek z oknem 'Dodaj kotwę')."""
        t, d = self.an_type_id(), self.an_active_dia()
        if t is None or d is None:
            shape_draw(self.an_canvas, None, {}, None, None, hint=T("Wybierz typ kotwy i średnicę"))
            self.var_aninfo.set("")
            return
        rows = self.an_defs.get(d, [])
        sel = self.tr_andef.selection() if self.tr_andef is not None else ()
        row = rows[int(sel[0])] if (sel and int(sel[0]) < len(rows)) else (rows[0] if rows else {})
        P = {k: num(row.get(k)) for k in ANCHOR_DEF_FIELDS if k not in ("PartName", "Weight")}
        items = {z: resolve_items(self.db, self.an_zone[z], d) for z in ("top", "below", "end")}
        info = shape_draw(self.an_canvas, t, P, d, num(row.get("Length")), items,
                          plate=num(self.v_anplate.get(), 0.0), grout=num(self.v_angrout.get(), 0.0))
        warn = check_dims(t, P, num(row.get("Length")))
        self.var_aninfo.set(info + ("  " + " ".join(warn) if warn else ""))

    # --- podgląd i zapis ---
    def an_collect(self):
        std = self.cb_anstd.get().strip()
        tid, mat = self.an_type_id(), self.an_class_key()
        src, set_name = self.cb_ansrc.get().strip(), self.cb_anset.get().strip()
        owner, dias = self.v_anown.get().strip(), self.an_sel_dias()
        errs = []
        if not std or len(std) > 64:
            errs.append("Nazwa (norma kotwy): wymagana, max 64 znaki.")
        if tid is None:
            errs.append("Wybierz typ kotwy.")
        if not mat or len(mat) > 64:
            errs.append("Klasa: wybierz z listy albo wpisz nową (max 64 znaki).")
        if not src or len(src) > 15:
            errs.append("Źródło: wymagane, max 15 znaków.")
        if not set_name or len(set_name) > 64:
            errs.append("Zestaw: wymagany, max 64 znaki.")
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        if not dias:
            errs.append("Zaznacz co najmniej jedną średnicę.")
        for d in dias:
            if not self.an_defs.get(d):
                errs.append("Brak definicji (długości) dla Ø%s." % fmt_dia(d))
        return std, tid, mat, src, set_name, owner, dias, errs

    def an_preview(self):
        if not self.need_db():
            return None
        std, tid, mat, src, set_name, owner, dias, errs = self.an_collect()
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return None
        self.tr_anprev.delete(*self.tr_anprev.get_children())
        pos_items = anchor_positions(self.an_zone["top"], self.an_zone["below"], self.an_zone["end"])
        plan = []
        for d in dias:
            items, miss = [], []
            for din, m, pos in pos_items:
                cd = pick_dia(self.db.nut_diameters(din, m), d)
                if cd is None:
                    miss.append("%s/%s" % (din, m))
                else:
                    items.append((din, m, pos, cd))
            ex = self.db.anchor_exists(std, mat, d, set_name)
            if miss:
                status, code = T("pominięto: brak w bazie ") + ", ".join(miss), "skip"
            elif not ex:
                status, code = T("NOWA"), "new"
            elif ex[0] == self.an_edit_id and is_own(ex[1]):
                status, code = T("edycja - zastąpi dotychczasową kotwę"), "over"
            elif is_own(ex[1]) and self.var_anover.get():
                status, code = T("istnieje (moja) - zostanie nadpisana"), "over"
            elif is_own(ex[1]):
                status, code = T("istnieje (moja) - pominięto (zaznacz nadpisywanie)"), "skip"
            else:
                status, code = T("istnieje (fabryczna) - pominięto"), "skip"
            plan.append({"dia": d, "code": code, "items": items, "exist": ex[0] if ex else None})
            self.tr_anprev.insert("", "end", values=(std, tid, mat, fmt_dia(d), set_name, src,
                                                     len(self.an_defs[d]), status))
        self.an_prev = plan
        return plan

    def an_save(self):
        plan = self.an_preview()
        if plan is None:
            return
        todo = [p for p in plan if p["code"] in ("new", "over")]
        if not todo:
            messagebox.showinfo("Zapis", "Brak kotew do zapisu (zobacz kolumnę Status).")
            return
        std, tid, mat, src, set_name, owner, dias, errs = self.an_collect()
        run = self.v_anrun.get().strip() or std
        new_std = std not in [r[0] for r in self.an_std_rows]
        new_src = src not in [r[0] for r in self.an_src_rows]
        new_set = set_name not in [x[0] for x in self.sets]
        new_cls = mat.lower() not in [r[0].lower() for r in self.cls_rows]
        explodable = self.v_anexpl.get()
        n_def = sum(len(self.an_defs[p["dia"]]) for p in todo)
        msg = "Zapisać %d kotew i %d definicji długości?" % (len(todo), n_def)
        for flag, text in ((new_std, T("nową normę kotwy '%s'") % std), (new_src, T("nowe źródło '%s'") % src),
                           (new_set, T("nowy zestaw '%s'") % set_name), (new_cls, T("nową klasę '%s'") % mat)):
            if flag:
                msg += T("\nZostanie dodane: %s.") % text
        if not messagebox.askyesno("Potwierdź zapis", msg):
            return
        if not self.backup_before_write():
            return
        nid = self.db.max_id("AnchorsName")
        did = self.db.max_id("AnchorsDefinition")
        hid = self.db.max_id("AnchorsHoleDefinition")
        rows_n, rows_d, rows_h, deletes = [], [], [], []
        if self.an_edit_id:
            deletes.append(self.an_edit_id)
        for p in todo:
            if p["code"] == "over" and p["exist"] not in deletes:
                deletes.append(p["exist"])
            nid += 1
            rows_n.append(build_anchor_name_row(nid, std, tid, mat, p["dia"], src, set_name, owner, explodable, p["items"]))
            for vals in self.an_defs[p["dia"]]:
                did += 1
                rows_d.append(build_anchor_def_row(did, nid, vals, owner))
            hid += 1
            rows_h.append(empty_hole_row(hid, nid))
        long_txt = (self.v_ansrclong.get().strip() or src)[:200]

        def fn(cur):
            if new_std:
                cur.execute(*insert_sql("AnchorsStandard", {"Key": std[:64], "RunName": run[:64], "OwnerText": owner[:15]}))
            if new_src:
                cur.execute(*insert_sql("Sources", {"Short": src, "Long": long_txt}))
            if new_set:
                cur.execute(*insert_sql("Sets", {"Key": set_name[:64], "RunName": set_name[:64], "OwnerText": owner[:15]}))
            if new_cls:
                cur.execute(*insert_sql("StrengthClass", {"Key": mat[:64], "RunName": mat[:64], "OwnerText": owner[:15]}))
            for old in deletes:
                cur.execute("DELETE FROM [AnchorsDefinition] WHERE [AnchorID]=?", (old,))
                cur.execute("DELETE FROM [AnchorsHoleDefinition] WHERE [AnchorNameID]=?", (old,))
                cur.execute("DELETE FROM [AnchorsName] WHERE [ID]=?", (old,))
            for r in rows_n:
                cur.execute(*insert_sql("AnchorsName", r))
            for r in rows_d:
                cur.execute(*insert_sql("AnchorsDefinition", r))
            for r in rows_h:
                cur.execute(*insert_sql("AnchorsHoleDefinition", r))
        if self.write_or_report(fn):
            getattr(self, "app", self).an_last_std = std
            self.reload()
            messagebox.showinfo("Gotowe", "Zapisano %d kotew. Odśwież dane w Advance Steel (przycisk 'Update defaults') "
                                          "albo uruchom go ponownie." % len(todo))
            self.close_after_save()
