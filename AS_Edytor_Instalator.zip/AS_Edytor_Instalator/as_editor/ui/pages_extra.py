# -*- coding: utf-8 -*-
"""Dodatkowe strony powłoki: 'Moje wpisy' (własne kotwy i zestawy, dziennik zapisów, cofanie) i 'Ustawienia' (połączenie, kopie)."""
import os
import subprocess
import sys

from as_editor import config, journal
from as_editor.common import dia_text, fmt_dia, in_clause, is_own, q
from as_editor.config import BACKUP_DIR
from as_editor.db import DB
from as_editor.i18n import T
from as_editor.ui.widgets import make_tree, messagebox, tk, ttk

OWN = "ISNULL(%s[OwnerText],'') NOT IN ('DSC','AUTODESK')"


class ExtraPagesMixin:
    # ------------------------------------------------------------------ Ustawienia
    def build_page_settings(self, page):
        box = ttk.Frame(page)
        box.place(relx=0.5, rely=0.42, anchor="center")
        ttk.Label(box, text=T("Ustawienia"), style="Title.TLabel").pack(anchor="w", pady=(0, 14))
        ttk.Label(box, text=T("Połączenie z bazą"), style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(box, text=T("Zwykle nic nie trzeba zmieniać: program sam łączy się z Advance Steel. Zmień, jeśli masz inną "
                              "wersję programu albo wersję krajową bazy."), style="Hint.TLabel", wraplength=640).pack(anchor="w", pady=(2, 8))
        top = ttk.Frame(box)
        top.pack(anchor="w")
        ttk.Label(top, text=T("Instancja LocalDB:")).pack(side="left")
        insts = DB.instances() or ["AdvanceSteel2026"]
        self.cb_inst = ttk.Combobox(top, values=insts, width=22)
        pref = [i for i in insts if i.lower().startswith("advancesteel")]
        self.cb_inst.set(pref[0] if pref else insts[0])
        self.cb_inst.pack(side="left", padx=4)
        ttk.Button(top, text=T("Wykryj wersje"), command=self.detect_langs).pack(side="left", padx=2)
        ttk.Label(top, text=T("Wersja:")).pack(side="left", padx=(10, 2))
        self.cb_lang = ttk.Combobox(top, values=["INT"], width=6)
        self.cb_lang.set("INT")
        self.cb_lang.pack(side="left")
        ttk.Button(top, text=T("Połącz"), style="Accent.TButton", command=self.connect).pack(side="left", padx=8)
        ttk.Separator(box).pack(fill="x", pady=16)
        from as_editor.version import BUILD
        ttk.Label(box, text=T("Wersja programu"), style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(box, text=T("Wersja: %s") % BUILD + "\n" + T("Uruchomiony z folderu: %s") % os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                  style="Hint.TLabel", wraplength=640, justify="left").pack(anchor="w", pady=(2, 0))
        ttk.Separator(box).pack(fill="x", pady=16)
        ttk.Label(box, text=T("Właściciel nowych wpisów"), style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(box, text=T("Nazwa (max 15 znaków, nie DSC/AUTODESK), którą program wpisze przy każdym nowym wierszu - "
                              "po niej poznasz swoje wpisy."), style="Hint.TLabel", wraplength=640).pack(anchor="w", pady=(2, 6))
        self.v_def_owner = tk.StringVar(value=config.recall("owner", config.DEFAULT_OWNER))
        row = ttk.Frame(box)
        row.pack(anchor="w")
        ttk.Entry(row, textvariable=self.v_def_owner, width=16).pack(side="left")
        ttk.Button(row, text=T("Zapisz"), command=self.save_default_owner).pack(side="left", padx=8)
        ttk.Separator(box).pack(fill="x", pady=16)
        ttk.Label(box, text=T("Kopie zapasowe i tryb ekspercki"), style="CardTitle.TLabel").pack(anchor="w")
        row = ttk.Frame(box)
        row.pack(anchor="w", pady=(6, 0))
        ttk.Button(row, text=T("Otwórz folder kopii zapasowych"), command=self.open_backups).pack(side="left")
        ttk.Button(row, text=T("Tryb ekspercki: wszystkie tabele i narzędzia"), command=self.open_expert).pack(side="left", padx=10)

    def save_default_owner(self):
        o = self.v_def_owner.get().strip()
        if not o or len(o) > 15 or not is_own(o):
            messagebox.showwarning("Właściciel", "Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
            return
        config.remember("owner", o)
        self.say(T("Zapisano właściciela: %s") % o, "ok")

    def open_backups(self):
        os.makedirs(BACKUP_DIR, exist_ok=True)
        try:
            if sys.platform.startswith("win"):
                os.startfile(BACKUP_DIR)
            else:
                subprocess.Popen(["xdg-open", BACKUP_DIR])
        except Exception:
            messagebox.showinfo("Kopie zapasowe", T("Folder kopii: %s") % BACKUP_DIR)

    # ------------------------------------------------------------------ Moje wpisy
    def build_page_mine(self, page):
        f = ttk.Frame(page)
        f.pack(fill="both", expand=True, padx=40, pady=(10, 14))
        ttk.Label(f, text=T("Moje wpisy"), style="Title.TLabel").pack(anchor="w")
        ttk.Label(f, text=T("Wszystko, co dodałeś Ty (właściciel inny niż DSC / AUTODESK). Wpisów fabrycznych tu nie ma i nie da się ich usunąć."),
                  style="Hint.TLabel").pack(anchor="w", pady=(0, 8))
        nb = ttk.Notebook(f)
        nb.pack(fill="both", expand=True)
        a = ttk.Frame(nb, padding=8)
        b = ttk.Frame(nb, padding=8)
        c = ttk.Frame(nb, padding=8)
        nb.add(a, text=T("Moje kotwy"))
        nb.add(b, text=T("Moje zestawy śrub"))
        nb.add(c, text=T("Ostatnie zapisy i cofanie"))
        from as_editor.ui.preview_panel import BoltPreview
        from as_editor.ui.wizard_anchor import ShapePreview, zone_of_anchor
        pa = ttk.LabelFrame(a, text=T("Podgląd kotwy"), padding=6, width=390)
        pa.pack(side="right", fill="y", padx=(12, 0))
        pa.pack_propagate(False)
        self.mine_shape = ShapePreview(pa, self, lambda: zone_of_anchor(self.mine_shape.anchors[0]) if self.mine_shape.anchors else
                                       {"top": [], "below": [], "end": []})
        self.mine_shape.v_cap.set(T("Zaznacz kotwę na liście - zobaczysz jej rysunek ze składem zestawu."))
        self.mine_shape.pack(fill="both", expand=True)
        fr, self.tr_mine_a = make_tree(a, ("Norma", "Typ", "Ø", "Klasa", "Zestaw", "Długości", "Właściciel"), (150, 80, 50, 70, 150, 70, 80), 12, sort=True, filt=True)
        fr.pack(fill="both", expand=True)
        self.tr_mine_a.bind("<<TreeviewSelect>>", lambda e: self.mine_preview_a())
        bar = ttk.Frame(a)
        bar.pack(fill="x", pady=(8, 0))
        ttk.Button(bar, text=T("Usuń zaznaczone kotwy"), command=self.mine_del_anchors).pack(side="left")
        self.var_mine_a = tk.StringVar()
        ttk.Label(bar, textvariable=self.var_mine_a, style="Hint.TLabel").pack(side="left", padx=12)
        pb = ttk.LabelFrame(b, text=T("Podgląd śruby"), padding=6, width=390)
        pb.pack(side="right", fill="y", padx=(12, 0))
        pb.pack_propagate(False)
        self.mine_bolt = BoltPreview(pb, self, self.mine_bolt_state)
        self.mine_bolt.pack(fill="both", expand=True)
        fr, self.tr_mine_b = make_tree(b, ("Norma", "Zestaw", "Klasa", "Ø", "Właściciel"), (150, 150, 70, 60, 80), 12, sort=True, filt=True)
        fr.pack(fill="both", expand=True)
        self.tr_mine_b.bind("<<TreeviewSelect>>", lambda e: self.mine_bolt.refresh())
        bar = ttk.Frame(b)
        bar.pack(fill="x", pady=(8, 0))
        ttk.Button(bar, text=T("Usuń zaznaczone zestawy"), command=self.mine_del_sets).pack(side="left")
        self.var_mine_b = tk.StringVar()
        ttk.Label(bar, textvariable=self.var_mine_b, style="Hint.TLabel").pack(side="left", padx=12)
        ttk.Label(c, text=T("Każdy zapis do bazy trafia do dziennika. Możesz cofnąć OSTATNI zapis - program usunie dokładnie to, co dodał "
                            "(albo przywróci to, co zmienił). Kopia zapasowa bazy nadal powstaje przed pierwszym zapisem."),
                  style="Hint.TLabel", wraplength=900).pack(anchor="w", pady=(0, 8))
        fr, self.tr_mine_c = make_tree(c, ("Czas", "Opis", "Zmiany", "Cofanie"), (150, 360, 260, 150), 10, "browse")
        fr.pack(fill="both", expand=True)
        bar = ttk.Frame(c)
        bar.pack(fill="x", pady=(8, 0))
        self.btn_undo = ttk.Button(bar, text=T("Cofnij ostatni zapis"), style="Accent.TButton", command=self.undo_last_ui)
        self.btn_undo.pack(side="left")
        self.mine_nb = nb

    def mine_preview_a(self):
        """Zaznaczona własna kotwa -> jej rysunek (z pełnego wiersza AnchorsName)."""
        sel = self.tr_mine_a.selection()
        if not sel or int(sel[0]) >= len(self.mine_a):
            return
        rows, cols = self.db.query("SELECT * FROM [AnchorsName] WHERE [ID]=?", (self.mine_a[int(sel[0])][0],))
        if rows:
            self.mine_shape.set_anchors([dict(zip(cols, rows[0]))])
            self.mine_shape.v_cap.set(T("Podgląd zaznaczonej kotwy (najdłuższa z jej długości)."))

    def mine_bolt_state(self):
        sel = self.tr_mine_b.selection()
        if not sel or int(sel[0]) >= len(self.mine_b):
            return {"caption": T("Zaznacz zestaw na liście - zobaczysz śrubę z jego podkładkami i nakrętkami.")}
        std, set_key, mat, dia = self.mine_b[int(sel[0])][:4]
        res = self.components_from_set(std, set_key, mat) or ([], [])
        return {"std": std, "mats": [mat], "dias": [float(dia)], "head": res[0], "nut": res[1],
                "caption": T("Zestaw %s (klasa %s).") % (set_key, mat)}

    def refresh_mine(self):
        if not self.db.conn:
            return
        names = {r[0]: r[1] for r in self.db.anchor_types()}
        t = self.tr_mine_a
        t.delete(*t.get_children())
        self.mine_a = self.db.rows(
            "SELECT n.[ID], n.[Standard], n.[ClassID], n.[Diameter], n.[MaterialKey], n.[SetName], n.[OwnerText], "
            "(SELECT COUNT(*) FROM [AnchorsDefinition] d WHERE d.[AnchorID]=n.[ID]) FROM [AnchorsName] n WHERE " + OWN % "n." +
            " ORDER BY n.[Standard], n.[Diameter], n.[MaterialKey]")
        for i, r in enumerate(self.mine_a):
            t.insert("", "end", iid=str(i), values=(r[1], T(names.get(r[2], "?")), dia_text(float(r[3])), r[4], r[5], r[7], r[6] or ""))
        self.var_mine_a.set(T("Moich kotew: %d") % len(self.mine_a))
        t = self.tr_mine_b
        t.delete(*t.get_children())
        self.mine_b = self.db.rows(
            "SELECT [Standard],[Set],[Material],[Diameter],[OwnerText] FROM [SetOfBolts] WHERE " + OWN % "" +
            " ORDER BY [Standard],[Set],[Material],[Diameter]")
        for i, r in enumerate(self.mine_b):
            t.insert("", "end", iid=str(i), values=(r[0], r[1], r[2], dia_text(float(r[3])), r[4] or ""))
        self.var_mine_b.set(T("Moich zestawów (wierszy): %d") % len(self.mine_b))
        t = self.tr_mine_c
        t.delete(*t.get_children())
        entries = journal.load()
        for i, e in enumerate(reversed(entries)):
            kinds = journal.describe(e)
            txt = ", ".join("%s %s: %d" % ({"insert": T("dodano"), "delete": T("usunięto"), "update": T("zmieniono")}[k[0]], k[1], n)
                            for k, n in sorted(kinds.items()))
            ok = T("tak (ostatni)") if (i == 0 and e.get("undoable")) else (T("nie da się") if not e.get("undoable") else "-")
            t.insert("", "end", values=(e.get("time", ""), e.get("label") or T("Zapis"), txt or "-", ok))
        last = entries[-1] if entries else None
        self.btn_undo.state(["!disabled"] if last and last.get("undoable") else ["disabled"])

    def mine_sel(self, tree, rows):
        return [rows[int(i)] for i in tree.selection() if int(i) < len(rows)]

    def mine_del_anchors(self):
        sel = self.mine_sel(self.tr_mine_a, self.mine_a)
        if not sel:
            messagebox.showinfo("Usuń", "Zaznacz kotwy na liście.")
            return
        if self.delete_anchors([r[0] for r in sel]):
            self.refresh_mine()

    def delete_anchors(self, ids):
        """Usuwa WŁASNE kotwy (z definicjami długości i otworami) po potwierdzeniu; fabrycznych (DSC/AUTODESK) nigdy nie rusza,
        nawet jeśli ich ID trafi na listę. Zwraca True po zapisie."""
        ids = list(ids)
        own = set()
        for i in range(0, len(ids), 500):
            c, p = in_clause("ID", ids[i:i + 500])
            own |= {r[0] for r in self.db.rows("SELECT [ID] FROM [AnchorsName] WHERE " + c + " AND " + OWN % "", p)}
        ids = [i for i in ids if i in own]
        if not ids:
            messagebox.showinfo("Usuń", "Zaznaczone kotwy są fabryczne - ich nie usuwamy.")
            return False
        if not messagebox.askyesno("Potwierdź", T("Usunąć %d kotew wraz z definicjami długości? Możesz to potem cofnąć w 'Ostatnie zapisy i cofanie'.") % len(ids)):
            return False
        if not self.backup_before_write():
            return False

        def fn(cur):
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                for table, col in (("AnchorsDefinition", "AnchorID"), ("AnchorsHoleDefinition", "AnchorNameID"), ("AnchorsName", "ID")):
                    c, p = in_clause(col, chunk)
                    cur.execute("DELETE FROM %s WHERE %s" % (q(table), c), p)
        if self.write_or_report(fn, label=T("Usunięcie moich kotew: %d") % len(ids)):
            self.reload()
            self.refresh_anchor_tabs()
            return True
        return False

    def mine_del_sets(self):
        sel = self.mine_sel(self.tr_mine_b, self.mine_b)
        if not sel:
            messagebox.showinfo("Usuń", "Zaznacz zestawy na liście.")
            return
        if self.delete_bolt_sets(sel):
            self.refresh_mine()

    def delete_bolt_sets(self, sel):
        """sel: lista (norma, zestaw, klasa, średnica, właściciel). Usuwa tylko wiersze o własnym właścicielu (warunek jest też w SQL)."""
        sel = [r for r in sel if is_own(r[4])]
        if not sel:
            messagebox.showinfo("Usuń", "Zaznaczone zestawy są fabryczne - ich nie usuwamy.")
            return False
        if not messagebox.askyesno("Potwierdź", T("Usunąć %d wierszy zestawów śrub? Możesz to potem cofnąć w 'Ostatnie zapisy i cofanie'.") % len(sel)):
            return False
        if not self.backup_before_write():
            return False

        def fn(cur):
            for std, st, mat, dia, own in sel:
                cur.execute("DELETE FROM [SetOfBolts] WHERE [Standard]=? AND [Set]=? AND [Material]=? AND ABS([Diameter]-?)<0.0001 AND "
                            "ISNULL([OwnerText],'') NOT IN ('DSC','AUTODESK')", (std, st, mat, float(dia)))
        if self.write_or_report(fn, label=T("Usunięcie moich zestawów śrub: %d") % len(sel)):
            self.reload()
            return True
        return False

    def undo_last_ui(self):
        e = journal.last_entry()
        if not e or not e.get("undoable"):
            messagebox.showinfo("Cofnij", "Ostatniego zapisu nie da się cofnąć automatycznie.")
            return
        if not self.need_db():
            return
        if not messagebox.askyesno("Cofnij ostatni zapis", T("Cofnąć zapis z %s: %s?\nProgram usunie dodane wiersze albo przywróci zmienione.") % (
                e.get("time", ""), e.get("label") or T("Zapis"))):
            return
        if not self.backup_before_write():
            return
        try:
            self.db.undo_last()
        except Exception as ex:
            messagebox.showerror("Błąd cofania (zmiany wycofane)", str(ex))
            return
        self.reload()
        try:
            self.refresh_anchor_tabs()
        except Exception:
            pass
        self.say(T("Cofnięto ostatni zapis."), "ok")
        self.refresh_mine()
