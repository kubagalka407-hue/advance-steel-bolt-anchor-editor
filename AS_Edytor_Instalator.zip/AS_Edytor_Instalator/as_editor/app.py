# -*- coding: utf-8 -*-
"""Główne okno: interfejs, połączenie z bazą, wspólne zapisy. Zakładki dołączone jako mixiny z pakietu tabs."""
from as_editor.common import is_own
from as_editor.config import load_settings, recall, save_settings
from as_editor.db import DB
from as_editor.i18n import T, get_language, set_language
from as_editor.tabs.anchors_copy import AnchorsCopyMixin
from as_editor.tabs.anchors_delete import AnchorsDeleteMixin
from as_editor.tabs.anchors_main import AnchorsMainMixin
from as_editor.tabs.builder import BuilderMixin
from as_editor.tabs.clone import CloneMixin
from as_editor.tabs.new_element import NewElementMixin
from as_editor.tabs.norms_add_class import NormsAddClassMixin
from as_editor.tabs.norms_classes import NormsClassesMixin
from as_editor.tabs.norms_delete import NormsDeleteMixin
from as_editor.tabs.norms_new import NormsNewMixin
from as_editor.ui.table_browser import TableBrowser
from as_editor.ui.widgets import add_tip, fit_window, messagebox, selected_index, set_choices, tk, ttk
import datetime


class App(BuilderMixin, NewElementMixin, NormsClassesMixin, NormsNewMixin, NormsAddClassMixin, NormsDeleteMixin, AnchorsMainMixin, AnchorsCopyMixin, AnchorsDeleteMixin, CloneMixin):
    def __init__(self, root):
        self.root = root
        fit_window(root, 1380, 840, 1000, 640)
        self.db = DB()
        self.db.on_write = lambda: self.say(T("Zapisano zmiany w bazie (%s).") % datetime.datetime.now().strftime("%H:%M:%S"), "ok")
        self.stds, self.sets = [], []
        self.head_items, self.nut_items = [], []   # [{'std','mat'}], od blachy na zewnątrz
        self.mat_vals, self.dia_vals, self.pdia_vals = [], [], []
        self.prev_rows = []
        self.stack_map = {}
        self.ne_rows, self.ne_stds = [], []
        self.build_ui()
        if load_settings().get("auto_connect", True):
            root.after(300, self.auto_connect)

    def build_ui(self):
        """Buduje cały interfejs (wywoływane przy starcie i po zmianie języka)."""
        root = self.root
        root.title("Edytor śrub Advance Steel (styl Tekla)")
        self.var_bar = tk.StringVar(value=T("Gotowy."))
        bar = ttk.Frame(root)
        bar.pack(side="bottom", fill="x")      # pasek stanu: najpierw, żeby nie znikał przy małym oknie
        ttk.Separator(bar).pack(fill="x")
        self.lbl_bar = ttk.Label(bar, textvariable=self.var_bar, style="Hint.TLabel")
        self.lbl_bar.pack(side="left", padx=10, pady=2)
        top = ttk.Frame(root)
        top.pack(fill="x", padx=8, pady=6)
        ttk.Label(top, text="Instancja LocalDB:").pack(side="left")
        insts = DB.instances() or ["AdvanceSteel2026"]
        self.cb_inst = ttk.Combobox(top, values=insts, width=22)
        pref = [i for i in insts if i.lower().startswith("advancesteel")]
        self.cb_inst.set(pref[0] if pref else insts[0])
        self.cb_inst.pack(side="left", padx=4)
        ttk.Button(top, text="Wykryj wersje", command=self.detect_langs).pack(side="left", padx=2)
        ttk.Label(top, text="Wersja:").pack(side="left", padx=(10, 2))
        self.cb_lang = ttk.Combobox(top, values=["INT"], width=6)
        self.cb_lang.set("INT")
        self.cb_lang.pack(side="left")
        ttk.Button(top, text="Połącz", command=self.connect).pack(side="left", padx=8)
        self.lbl_dot = tk.Label(top, text="\u25cf", foreground="#b00000", font=("TkDefaultFont", 14))
        self.lbl_dot.pack(side="left")
        self.status = tk.StringVar(value=T("Niepołączono. Uruchom Advance Steel / Management Tools, potem kliknij 'Połącz'."))
        self.lbl_status = ttk.Label(top, textvariable=self.status, foreground="#a00")
        self.lbl_status.pack(side="left", padx=10)
        ttk.Button(top, text="English" if get_language() == "pl" else "Polski", command=self.switch_language).pack(side="right", padx=6)

        self.browsers = []
        nb = ttk.Notebook(root)
        self.nb_main = nb
        nb.pack(fill="both", expand=True, padx=8, pady=4)
        # trzy zakładki główne: najczęstsze zadania na wierzchu, rzadkie funkcje w "Narzędziach"
        self.tab_anch = ttk.Frame(nb)
        self.tab_build = ttk.Frame(nb)
        self.tab_tools = ttk.Frame(nb)
        nb.add(self.tab_anch, text="   Kotwy   ")
        nb.add(self.tab_build, text="   Zestawy śrub   ")
        nb.add(self.tab_tools, text="   Narzędzia   ")
        nbt = ttk.Notebook(self.tab_tools)
        self.nb_tools = nbt
        nbt.pack(fill="both", expand=True, padx=4, pady=4)
        self.tab_new, self.tab_norms, self.tab_clone, self.tab_browse_b = (ttk.Frame(nbt) for _ in range(4))
        self.sub_ak, self.sub_adl, self.sub_abr = (ttk.Frame(nbt) for _ in range(3))
        self.sub_ls = self.tab_anch                       # konfigurator kotew zajmuje całą zakładkę "Kotwy"
        nbt.add(self.tab_new, text="Nowa podkładka / nakrętka")
        nbt.add(self.tab_norms, text="Normy i klasy śrub")
        nbt.add(self.tab_clone, text="Kopia normy śruby (szybka)")
        nbt.add(self.sub_ak, text="Kopiuj kotwy / dodaj klasę")
        nbt.add(self.sub_adl, text="Usuń moje kotwy")
        nbt.add(self.tab_browse_b, text="Przeglądarka tabel (śruby)")
        nbt.add(self.sub_abr, text="Przeglądarka tabel (kotwy)")
        self.build_builder()
        self.build_newelem()
        self.build_norms()
        self.build_clone()
        self.browsers.append(TableBrowser(self, self.tab_browse_b, "SetOfBolts"))
        self.build_anchors()
        self.draw()

    def open_tool(self, frame):
        """Przechodzi do podzakładki w "Narzędziach"."""
        self.nb_main.select(self.tab_tools)
        self.nb_tools.select(frame)

    def switch_language(self):
        """Przełącza język całej aplikacji (PL <-> EN): interfejs jest budowany od nowa, połączenie z bazą zostaje."""
        set_language("pl" if get_language() == "en" else "en")
        data = load_settings()
        data["lang"] = get_language()
        save_settings(data)
        connected = self.db.conn is not None
        for w in self.root.winfo_children():
            w.destroy()
        self.head_items, self.nut_items, self.ne_rows = [], [], []
        self.build_ui()
        if connected:
            self.cb_inst.set(self.db.server.split("\\")[-1])
            self.cb_lang.set(self.db.lang)
            try:
                self.reload()
            except Exception as e:
                messagebox.showerror("Błąd", str(e))
                return
            self.status.set("Połączono: %s  /  wersja %s" % (self.db.server, self.db.lang))
            self.set_connected(True)
            self.draw()

    # ------------------------------------------------------------------ połączenie
    def server(self):
        return "(LocalDB)\\" + self.cb_inst.get().strip()

    def detect_langs(self):
        try:
            langs = self.db.languages(self.server())
        except Exception as e:
            messagebox.showerror("Błąd", str(e))
            return
        if not langs:
            messagebox.showinfo("Wersje", "Nie wykryto podłączonych baz AstorBase. Uruchom Advance Steel.")
            return
        self.cb_lang["values"] = langs
        self.cb_lang.set("INT" if "INT" in langs else langs[0])
        messagebox.showinfo("Wersje", T("Wykryte wersje krajowe: %s") % ", ".join(langs))

    def say(self, text, kind="info"):
        """Komunikat na pasku stanu (u dołu okna): kind = info / ok / err."""
        try:
            self.var_bar.set(text)
            self.lbl_bar.configure(style={"ok": "Ok.TLabel", "err": "Err.TLabel"}.get(kind, "Hint.TLabel"))
        except tk.TclError:
            pass

    def set_connected(self, on):
        self.lbl_dot.configure(foreground="#0a7a0a" if on else "#b00000")
        self.lbl_status.configure(foreground="#070" if on else "#a00")

    def connect(self, silent=False):
        try:
            self.db.connect(self.server(), self.cb_lang.get().strip().upper())
            self.reload()
        except Exception as e:
            self.status.set(T("Niepołączono. Uruchom Advance Steel / Management Tools, potem kliknij 'Połącz'."))
            self.set_connected(False)
            self.say(T("Brak połączenia z bazą: %s") % str(e).splitlines()[0][:160], "err")
            if not silent:
                messagebox.showerror("Błąd połączenia", str(e))
            return False
        self.status.set("Połączono: %s  /  wersja %s" % (self.server(), self.db.lang))
        self.set_connected(True)
        self.say(T("Połączono z bazą (wersja %s). Wybierz normę i zacznij pracę.") % self.db.lang, "ok")
        data = load_settings()
        data["instance"], data["dblang"] = self.cb_inst.get().strip(), self.db.lang
        save_settings(data)
        self.draw()
        return True

    def auto_connect(self):
        """Próba połączenia zaraz po starcie (bez okienek błędu): instancja i wersja z ostatniej udanej sesji."""
        if self.db.conn:
            return
        data = load_settings()
        if data.get("instance"):
            self.cb_inst.set(data["instance"])
        if data.get("dblang"):
            self.cb_lang.set(data["dblang"])
        self.say(T("Łączę z bazą..."))
        self.root.update_idletasks()
        self.connect(silent=True)

    def need_db(self):
        if not self.db.conn:
            messagebox.showwarning("Brak połączenia", "Najpierw kliknij 'Połącz'.")
            return False
        return True

    def reload(self):
        self.stds = self.db.standards()
        self.sets = self.db.sets()
        vals = ["%s   |   %s%s" % (s[0], s[1], "   [MOJA]" if is_own(s[4]) else "") for s in self.stds]
        set_choices(self.cb_std, vals)
        self.cb_src["values"] = vals
        self.std_vals = vals
        if selected_index(self.cb_std) < 0:                      # przywróć ostatnio użytą normę śruby (także po zmianie języka)
            last = recall("last_bolt_std")
            for i, st in enumerate(self.stds):
                if st[0] == last:
                    self.cb_std.current(i)
                    self.on_std()
                    break
        self.refresh_set_choices()
        for b in self.browsers:
            b.refresh_tables()
        self.ne_fill_std()
        self.refresh_norm_tabs()
        self.refresh_anchor_tabs()

    def backup_before_write(self):
        try:
            fn = self.db.ensure_backup()
        except Exception as e:
            return messagebox.askyesno(
                "Kopia zapasowa nieudana",
                "Nie udało się wykonać kopii zapasowej bazy:\n%s\n\nKontynuować BEZ kopii?" % e, icon="warning")
        if fn:
            messagebox.showinfo("Kopia zapasowa", "Wykonano kopię zapasową bazy:\n%s" % fn)
        return True

    def write_or_report(self, fn, title="Błąd zapisu (zmiany wycofane)"):
        try:
            self.db.write(fn)
            return True
        except Exception as e:
            messagebox.showerror(title, str(e))
            return False

    # ------------------------------------------------------------------ przeglądarki tabel
    def reload_browsers(self):
        for b in self.browsers:
            b.reload()
