# -*- coding: utf-8 -*-
"""Kreatory kotew (krok po kroku):
  AnchorSetWizard     - 'Dodaj set do kotew': wybrane kotwy (norma + zestaw + klasy + średnice) dostają NOWY zestaw nakrętek/podkładek,
  AnchorLengthsWizard - 'Dodaj długości do kotew z danym setem i klasami': dopisuje długości do wielu kotew naraz,
  NewAnchorWizard     - 'Nowa kotwa': norma -> typ, średnica, wymiary, długości -> skład zestawu -> zapis.
Zapisują przez te same funkcje co reszta programu (kopia zapasowa, transakcja); wiersze fabryczne nigdy nie są zmieniane."""
from as_editor.anchors_logic import (ANCHOR_DEF_COLS, ANCHOR_LABELS, ANCHOR_TIPS, anchor_positions, anchor_weight,
                                     build_anchor_def_row, build_anchor_name_row, empty_hole_row, pick_dia, rename_part, zone_of)
from as_editor.bolts_logic import parse_lengths
from as_editor.common import dia_text, fmt_dia, insert_sql, is_own, q
from as_editor.config import DEFAULT_OWNER, MAX_ITEMS, recall, remember
from as_editor.i18n import T
from as_editor.ui.anchor_shape import DEFAULT_PLATE, check_dims, draw as shape_draw, num, resolve_items
from as_editor.ui.dialogs import CompDialog
from as_editor.ui.widgets import (order_button, add_tip, ask_range, clean_paste, make_filterable, make_list, make_tree, messagebox,
                                  selected_index, set_choices, tk, ttk)
from as_editor.ui.wizard import Wizard

SKIP = ("Length", "Weight", "PartName")
ZONE_NAMES = {"top": "nad blachą", "below": "pod blachą", "end": "koniec kotwy"}


def read_lengths(text):
    """Długości z pola tekstowego -> lista dodatnich liczb; ValueError z czytelnym komunikatem."""
    try:
        lens = parse_lengths(text)
    except ValueError as e:
        raise ValueError(T("Nie rozumiem długości: %s. Wpisz liczby oddzielone przecinkami (300, 400) albo zakres 300-1000/100.")
                         % str(e).replace("Nie rozumiem:", "").strip())
    if not lens:
        raise ValueError(T("Podaj co najmniej jedną długość."))
    if any(x <= 0 for x in lens):
        raise ValueError(T("Długości muszą być większe od zera."))
    return lens


def zone_of_anchor(n):
    """Skład zestawu kotwy (wiersz AnchorsName) -> {'top': [...], 'below': [...], 'end': [...]} (nad blachą wiersz 1 najdalej od blachy, pod blachą wiersz 1 przy blasze)."""
    zone = {"top": [], "below": [], "end": []}
    comps = []
    for k in range(1, MAX_ITEMS + 1):
        din, pos, m = n.get("DIN%d" % k), n.get("Position%d" % k), n.get("Material%d" % k)
        if din not in (None, "", "-") and pos:
            comps.append((pos, {"std": din, "mat": m}))
    for pos, c in sorted(comps, key=lambda t: abs(t[0])):
        zone[zone_of(pos)].append(c)
    return zone


def items_for(db, zone, dia):
    """Skład zestawu dla średnicy kotwy -> (items [(din, klasa, pozycja, Ø elementu)], brakujące ['din/klasa'])."""
    items, miss = [], []
    for din, m, pos in anchor_positions(zone["top"], zone["below"], zone["end"]):
        cd = pick_dia(db.nut_diameters(din, m), dia)
        if cd is None:
            miss.append("%s/%s" % (din, m))
        else:
            items.append((din, m, pos, cd))
    return items, miss


def status_tags(tree):
    """Kolory kolumny Status w podsumowaniach: zielony = zostanie zapisane, pomarańczowy = pominięte."""
    tree.tag_configure("ok", foreground="#0a6a0a")
    tree.tag_configure("skip", foreground="#b36b00")


class ZoneEditor(ttk.Frame):
    """Skład zestawu kotwy w trzech strefach (nad blachą / pod blachą / koniec kotwy)."""

    def __init__(self, parent, app, get_dia, on_change=None):
        super().__init__(parent)
        self.app, self.get_dia, self.on_change = app, get_dia, on_change
        self.zone = {"top": [], "below": [], "end": []}
        self.map = {}
        fr, self.tr = make_tree(self, ("Strefa", "Nr", "Norma elementu", "Klasa"), (120, 36, 150, 90), 9, "browse")
        fr.pack(fill="both", expand=True)
        self.tr.tag_configure("miss", foreground="#b00")
        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(6, 0))
        for txt, z in (("+ Nad blachą", "top"), ("+ Pod blachą", "below"), ("+ Koniec kotwy", "end")):
            ttk.Button(bar, text=T(txt), command=lambda z=z: self.add(z)).pack(side="left", padx=(0, 4))
        bar2 = ttk.Frame(self)
        bar2.pack(fill="x", pady=4)
        for txt, cmd, w in (("▲", lambda: self.move(-1), 3), ("▼", lambda: self.move(1), 3),
                            ("Zamień...", self.replace, 10), ("Duplikuj", self.duplicate, 10), ("Usuń", self.remove, 7)):
            ttk.Button(bar2, text=T(txt), command=cmd, width=w).pack(side="left", padx=(0, 4))
        ttk.Label(self, text=T("Nad blachą: wiersz 1 jest najdalej od blachy. Pod blachą: wiersz 1 leży przy blasze, kolejne niżej."), style="Hint.TLabel").pack(anchor="w")

    def set_zone(self, zone):
        self.zone = {z: [dict(c) for c in zone.get(z, [])] for z in ("top", "below", "end")}
        self.refresh()

    def count(self):
        return sum(len(v) for v in self.zone.values())

    def refresh(self):
        t = self.tr
        t.delete(*t.get_children())
        self.map = {}
        dia = self.get_dia()
        for z in ("top", "below", "end"):
            for i, c in enumerate(self.zone[z]):
                iid = "%s%d" % (z[0], i)
                miss = False
                if dia:
                    try:
                        miss = pick_dia(self.app.db.nut_diameters(c["std"], c["mat"]), dia) is None
                    except Exception:
                        miss = False
                t.insert("", "end", iid=iid, tags=("miss",) if miss else (),
                         values=(T(ZONE_NAMES[z]), i + 1, c["std"] + (T("  (brak)") if miss else ""), c["mat"]))
                self.map[iid] = (z, i)
        if self.on_change:
            self.on_change()

    def add(self, zone):
        if self.count() >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS)
            return
        # pierwszy wiersz: nad blachą = nakrętka (najdalej), pod blachą = podkładka (przy blasze); dalsze odwrotnie
        first = {"top": "nut", "below": "washer", "end": "nut"}[zone]
        default = first if not self.zone[zone] else ("washer" if zone == "top" else "nut")
        dlg = CompDialog(self, self.app.db, T("Dodaj element - ") + T(ZONE_NAMES[zone]), self.get_dia(), default)
        if dlg.result:
            self.zone[zone].append(dlg.result)
            self.refresh()

    def cur(self):
        sel = self.tr.selection()
        return self.map.get(sel[0]) if sel else None

    def move(self, d):
        c = self.cur()
        if c:
            z, i = c
            j = i + d
            if 0 <= j < len(self.zone[z]):
                self.zone[z][i], self.zone[z][j] = self.zone[z][j], self.zone[z][i]
                self.refresh()
                self.tr.selection_set("%s%d" % (z[0], j))

    def duplicate(self):
        """Kopiuje zaznaczony element (norma, klasa i inne ustawienia) tuż za oryginałem w tej samej strefie."""
        c = self.cur()
        if not c:
            messagebox.showinfo("Duplikuj", "Zaznacz element zestawu na liście.")
            return
        if self.count() >= MAX_ITEMS:
            messagebox.showinfo("Limit", "Maksymalnie %d elementów w zestawie." % MAX_ITEMS)
            return
        z, i = c
        self.zone[z].insert(i + 1, dict(self.zone[z][i]))
        self.refresh()
        self.tr.selection_set("%s%d" % (z[0], i + 1))

    def remove(self):
        c = self.cur()
        if c:
            del self.zone[c[0]][c[1]]
            self.refresh()

    def replace(self):
        c = self.cur()
        if not c:
            messagebox.showinfo("Zamień", "Zaznacz element zestawu na liście.")
            return
        z, i = c
        dlg = CompDialog(self, self.app.db, T("Zamień element - ") + T(ZONE_NAMES[z]), self.get_dia(), "nut")
        if dlg.result:
            self.zone[z][i] = dlg.result
            self.refresh()
            self.tr.selection_set("%s%d" % (z[0], i))


class ShapePreview(ttk.Frame):
    """Schemat kotwy (jak w oknie kotwy): pokazuje wybraną kotwę ze składem zestawu; get_zone() daje bieżący skład."""

    def __init__(self, parent, app, get_zone, get_length=None):
        super().__init__(parent)
        self.app, self.get_zone, self.get_length, self._job = app, get_zone, get_length, None
        self.v_cap = tk.StringVar()
        self.anchors, self.cache = [], {}
        self.v_pick, self.v_shape = tk.StringVar(), tk.StringVar()
        self.v_plate, self.v_grout = tk.StringVar(value=fmt_dia(DEFAULT_PLATE)), tk.StringVar(value="0")
        ttk.Label(self, textvariable=self.v_cap, style="Hint.TLabel", wraplength=350, justify="left").pack(anchor="w", pady=(0, 4))
        r = ttk.Frame(self)
        r.pack(fill="x", pady=(0, 4))
        self.cb = ttk.Combobox(r, textvariable=self.v_pick, state="readonly", width=34)
        self.cb.pack(side="left")
        self.cb.bind("<<ComboboxSelected>>", lambda e: (self.fill_lengths(), self.schedule()))
        r2 = ttk.Frame(self)
        r2.pack(fill="x", pady=(0, 4))
        ttk.Label(r2, text=T("Długość kotwy [mm]")).pack(side="left")
        self.cb_len = ttk.Combobox(r2, state="readonly", width=12)
        self.cb_len.pack(side="left", padx=6)
        self.cb_len.bind("<<ComboboxSelected>>", lambda e: self.schedule())
        self.len_defs = []
        self.cv = tk.Canvas(self, width=360, height=360, bg="white", highlightthickness=1, highlightbackground="#cccccc")
        self.cv.pack(fill="both", expand=True)
        self.cv.bind("<Configure>", lambda e: self.schedule())
        mb = ttk.Frame(self)
        mb.pack(fill="x", pady=4)
        ttk.Label(mb, text=T("Blacha [mm]:")).pack(side="left")
        ttk.Entry(mb, textvariable=self.v_plate, width=6).pack(side="left", padx=4)
        ttk.Label(mb, text=T("Podlewka [mm]:")).pack(side="left")
        ttk.Entry(mb, textvariable=self.v_grout, width=6).pack(side="left", padx=4)
        ttk.Label(self, textvariable=self.v_shape, style="Hint.TLabel", wraplength=350, justify="left").pack(anchor="w")
        for v in (self.v_plate, self.v_grout):
            v.trace_add("write", lambda *a: self.schedule())

    def set_anchors(self, anchors):
        self.anchors = list(anchors)
        self.cb["values"] = ["Ø%s | %s | %s" % (dia_text(float(n["Diameter"])), n["MaterialKey"], n["SetName"]) for n in self.anchors]
        if self.anchors:
            self.cb.current(0)
        else:
            self.cb.set("")
        self.fill_lengths()
        self.schedule()

    def schedule(self):
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(100, self.draw)

    def defs_of(self, n):
        if n["ID"] not in self.cache:
            defs, _ = self.app.db.anchor_children([n["ID"]])
            self.cache[n["ID"]] = sorted(defs.get(n["ID"], []), key=lambda r: r.get("Length") or 0)
        return self.cache[n["ID"]]

    def fill_lengths(self):
        """Lista długości wybranej kotwy (rosnąco); domyślnie zaznaczona najdłuższa - rysunek pokazuje wybraną długość."""
        i = self.cb.current()
        self.len_defs = []
        if 0 <= i < len(self.anchors):
            try:
                self.len_defs = [d for d in self.defs_of(self.anchors[i]) if d.get("Length") is not None]
            except Exception:
                self.len_defs = []
        self.cb_len["values"] = [fmt_dia(d["Length"]) for d in self.len_defs]
        if self.len_defs:
            self.cb_len.current(len(self.len_defs) - 1)
        else:
            self.cb_len.set("")

    def base_def(self, n):
        d = self.defs_of(n)
        j = self.cb_len.current()
        if 0 <= j < len(self.len_defs) and self.len_defs[j] in d:
            return self.len_defs[j]
        return d[-1] if d else {}

    def draw(self):
        self._job = None
        i = self.cb.current()
        if not (0 <= i < len(self.anchors)):
            from as_editor.ui.icons import placeholder
            placeholder(self.cv, "anchor", T("Wybierz kotwy - tu zobaczysz kotwę ze składem zestawu."),
                        max(self.cv.winfo_width(), 200), max(self.cv.winfo_height(), 200))
            self.v_shape.set("")
            return
        n = self.anchors[i]
        try:
            base = self.base_def(n)
            dia, tid = float(n["Diameter"]), n["ClassID"]
            P = {c: num(base.get(c)) for c in ANCHOR_DEF_COLS.get(tid, ANCHOR_DEF_COLS[3]) if c not in SKIP}
            L = base.get("Length")
            ext = self.get_length() if self.get_length else None
            if ext:                                              # kreator podaje własną długość (np. nową): lista długości wyłączona
                L = ext
                self.cb_len.state(["disabled"])
            else:
                self.cb_len.state(["!disabled"])
            zone = self.get_zone()
            items = {z: resolve_items(self.app.db, zone[z], dia) for z in ("top", "below", "end")}
            info = shape_draw(self.cv, tid, P, dia, L, items, plate=num(self.v_plate.get(), 0.0), grout=num(self.v_grout.get(), 0.0))
            warn = check_dims(tid, P, L)
            self.v_shape.set(info + ("  " + " ".join(warn) if warn else ""))
        except Exception as e:
            self.cv.delete("all")
            self.v_shape.set(T("Podgląd niedostępny: %s") % e)


# ====================================================================== wybór kotew (wspólny krok 1)
class AnchorSelWizard(Wizard):
    """Krok 1 dla 'dodaj set' i 'dodaj długości': norma kotwy + zestaw + klasy + średnice => lista wybranych kotew."""

    def init_select(self):
        self.std_rows, self.std_all, self.set_names, self.sel, self.pool = [], [], [], [], []
        self.mats, self.dias = [], []

    def build_filters(self, f, on_change):
        """Wiersz filtrów nad listą norm: typ kotwy i klasa materiału. Zawęża listę norm do tych, które mają kotwy takiego typu / klasy."""
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(0, 8))
        ttk.Label(r, text=T("Filtr: typ kotwy")).pack(side="left")
        self.cb_ftype = ttk.Combobox(r, width=20, state="readonly",
                                     values=[T("Wszystkie typy")] + ["%s   |   %s" % (x[0], T(x[1])) for x in self.app.an_type_rows])
        self.cb_ftype.current(0)
        self.cb_ftype.pack(side="left", padx=(6, 18))
        ttk.Label(r, text=T("Filtr: klasa materiału")).pack(side="left")
        mats = sorted({m for ms in getattr(self.app, "an_std_mats", {}).values() for m in ms})
        self.cb_fmat = ttk.Combobox(r, width=14, state="readonly", values=[T("Wszystkie klasy")] + mats)
        self.cb_fmat.current(0)
        self.cb_fmat.pack(side="left", padx=6)
        ttk.Button(r, text="✕", width=3, command=lambda: (self.cb_ftype.current(0), self.cb_fmat.current(0), on_change())).pack(side="left", padx=4)
        for cb in (self.cb_ftype, self.cb_fmat):
            cb.bind("<<ComboboxSelected>>", lambda e: on_change())
        return r

    def filter_type(self):
        i = self.cb_ftype.current() if hasattr(self, "cb_ftype") else 0
        return self.app.an_type_rows[i - 1][0] if i > 0 else None

    def filter_mat(self):
        i = self.cb_fmat.current() if hasattr(self, "cb_fmat") else 0
        return self.cb_fmat["values"][i] if i > 0 else None

    def filtered_stds(self):
        tid, mat = self.filter_type(), self.filter_mat()
        types, mats = getattr(self.app, "an_std_types", {}), getattr(self.app, "an_std_mats", {})
        return [r for r in self.std_all if (tid is None or tid in types.get(r[0], ())) and (mat is None or mat in mats.get(r[0], ()))]

    def on_filters(self):
        """Zmiana filtra: odświeża listę norm (zachowuje wybraną, jeśli nadal pasuje) i listę klas / średnic."""
        keep = self.std_key()
        self.std_rows = self.filtered_stds()
        set_choices(self.cb_std, ["%s   |   %s%s" % (r[0], r[1], "   [MOJA]" if is_own(r[2]) else "") for r in self.std_rows])
        keys = [r[0] for r in self.std_rows]
        if keep in keys:
            self.cb_std.current(keys.index(keep))
            self.cb_std._last = keys.index(keep)
            self.on_set() if self.set_key() else self.fill_mats()
        else:
            self.cb_std.set("")
            self.cb_std._last = -1
            self.on_std()
        self.var_fcount.set(T("Pasujących norm: %d z %d") % (len(self.std_rows), len(self.std_all)))

    def build_select(self, f, intro):
        ttk.Label(f, text=intro, style="Sub.TLabel", wraplength=900).pack(anchor="w", pady=(0, 10))
        self.var_fcount = tk.StringVar()
        self.build_filters(f, self.on_filters)
        ttk.Label(f, textvariable=self.var_fcount, style="Hint.TLabel").pack(anchor="w", pady=(0, 6))
        row = ttk.Frame(f)
        row.pack(fill="x")
        c1 = ttk.Frame(row)
        c1.pack(side="left", padx=(0, 20))
        ttk.Label(c1, text="Norma kotwy (wpisz np. Hilti)").pack(anchor="w")
        self.cb_std = make_filterable(ttk.Combobox(c1, width=46))
        self.cb_std.pack(anchor="w")
        self.cb_std.bind("<<ComboboxSelected>>", lambda e: self.on_std())
        c2 = ttk.Frame(row)
        c2.pack(side="left")
        ttk.Label(c2, text="Zestaw (nakrętki / podkładki)").pack(anchor="w")
        self.cb_set = ttk.Combobox(c2, width=34, state="readonly")
        self.cb_set.pack(anchor="w")
        self.cb_set.bind("<<ComboboxSelected>>", lambda e: self.on_set())
        cols = ttk.Frame(f)
        cols.pack(anchor="w", fill="y", expand=True, pady=(12, 0))
        a = ttk.Frame(cols)
        a.pack(side="left", padx=(0, 24), fill="y")
        ttk.Label(a, text="Klasy materiałowe").pack(anchor="w")
        fr, self.lb_mat = make_list(a, 10, 18)
        fr.pack(fill="y", expand=True)
        self.lb_mat.bind("<<ListboxSelect>>", lambda e: self.on_mats())
        bb = ttk.Frame(a)
        bb.pack(anchor="w", pady=(4, 0))
        ttk.Button(bb, text=T("Wszystkie"), command=lambda: (self.lb_mat.selection_set(0, "end"), self.on_mats())).pack(side="left")
        b = ttk.Frame(cols)
        b.pack(side="left", fill="y")
        ttk.Label(b, text="Średnice").pack(anchor="w")
        fr, self.lb_dia = make_list(b, 10, 12)
        fr.pack(fill="y", expand=True)
        self.lb_dia.bind("<<ListboxSelect>>", lambda e: self.on_dias())
        bb = ttk.Frame(b)
        bb.pack(anchor="w", pady=(4, 0))
        ttk.Button(bb, text=T("Wszystkie"), command=lambda: (self.lb_dia.selection_set(0, "end"), self.on_dias())).pack(side="left")
        order_button(bb, self, self.on_mats).pack(side="left", padx=(6, 0))
        c3 = ttk.Frame(cols)
        c3.pack(side="left", fill="both", expand=True, padx=(24, 0))
        self.var_sel = tk.StringVar()
        ttk.Label(c3, textvariable=self.var_sel, style="CardTitle.TLabel").pack(anchor="w")
        fr, self.tr_sel = make_tree(c3, ("Ø", "Klasa", "Zestaw", "Długości", "Właściciel"), (50, 70, 150, 150, 80), 10, sort=True, filt=True)
        fr.pack(fill="both", expand=True)
        self.tr_sel.tag_configure("fact", foreground="#888")
        ttk.Label(c3, text=T("Szare wiersze to kotwy fabryczne - nigdy ich nie zmieniamy."), style="Hint.TLabel").pack(anchor="w")

    def enter_select(self):
        if self.std_all:
            return
        self.std_all = list(self.app.an_std_rows)
        self.std_rows = self.filtered_stds()
        self.var_fcount.set(T("Pasujących norm: %d z %d") % (len(self.std_rows), len(self.std_all)))
        set_choices(self.cb_std, ["%s   |   %s%s" % (r[0], r[1], "   [MOJA]" if is_own(r[2]) else "") for r in self.std_rows])
        want = recall("last_anchor_std")
        for i, r in enumerate(self.std_rows):
            if r[0] == want:
                self.cb_std.current(i)
                self.cb_std._last = i
                self.on_std()
                break

    def std_key(self):
        i = selected_index(self.cb_std)
        return self.std_rows[i][0] if 0 <= i < len(self.std_rows) else None

    def set_key(self):
        i = self.cb_set.current()
        return self.set_names[i] if 0 <= i < len(self.set_names) else None

    def on_std(self):
        std = self.std_key()
        self.set_names = [r[0] for r in self.db.anchor_set_names(std)] if std else []
        self.cb_set["values"] = self.set_names
        self.cb_set.set("")
        self.pool = []
        self.fill_mats()
        if len(self.set_names) == 1:                       # jeden zestaw w normie: wybierz go od razu
            self.cb_set.current(0)
            self.on_set()

    def on_set(self):
        self.pool = self.type_filtered(self.db.anchor_names(self.std_key(), set_name=self.set_key())) if self.set_key() else []
        self.fill_mats()

    def type_filtered(self, names):
        tid = self.filter_type()
        return [n for n in names if tid is None or n["ClassID"] == tid]

    def fill_mats(self):
        self.mats = sorted({n["MaterialKey"] for n in self.pool})
        self.lb_mat.delete(0, "end")
        for m in self.mats:
            self.lb_mat.insert("end", m)
        fm = self.filter_mat()
        if fm in self.mats:                                  # filtr klasy: zaznacz od razu tylko ją
            self.lb_mat.selection_set(self.mats.index(fm))
        else:
            self.lb_mat.selection_set(0, "end")
        self.on_mats()

    def sel_mats(self):
        return [self.mats[i] for i in self.lb_mat.curselection()]

    def on_mats(self):
        keep = self.sel_dias()
        ms = self.sel_mats()
        self.dias = sorted({float(n["Diameter"]) for n in self.pool if n["MaterialKey"] in ms}, reverse=getattr(self, "dia_desc", False))
        self.lb_dia.delete(0, "end")
        for d in self.dias:
            self.lb_dia.insert("end", dia_text(d))
        for i, d in enumerate(self.dias):
            if not keep or d in keep:
                self.lb_dia.selection_set(i)
        self.on_dias()

    def sel_dias(self):
        return [self.dias[i] for i in self.lb_dia.curselection()]

    def on_dias(self):
        ms, ds = self.sel_mats(), self.sel_dias()
        self.sel = [n for n in self.pool if n["MaterialKey"] in ms and float(n["Diameter"]) in ds]
        self.var_sel.set(T("Wybrane kotwy: %d") % len(self.sel) if self.sel else T("Nie wybrano żadnej kotwy"))
        self.tr_sel.delete(*self.tr_sel.get_children())
        if getattr(self, "shape", None) is not None:
            self.shape.set_anchors(self.sel)
        defs = self.db.anchor_children([n["ID"] for n in self.sel])[0] if self.sel else {}
        for i, n in enumerate(self.sel):
            ls = sorted(r["Length"] for r in defs.get(n["ID"], []) if r.get("Length") is not None)
            rng = "%d: %s - %s" % (len(ls), fmt_dia(ls[0]), fmt_dia(ls[-1])) if ls else "0"
            self.tr_sel.insert("", "end", iid=str(i), tags=() if is_own(n.get("OwnerText")) else ("fact",),
                               values=(dia_text(float(n["Diameter"])), n["MaterialKey"], n["SetName"], rng,
                                       n.get("OwnerText") or ""))

    def preselect(self, std, set_name=None, mats=None, dias=None):
        """Wstępny wybór (z Katalogu): norma, zestaw, klasy i średnice. Zwraca False, gdy takiej normy nie ma."""
        if std not in [r[0] for r in self.std_rows]:             # filtr ukrywa normę: wyczyść filtry
            self.cb_ftype.current(0)
            self.cb_fmat.current(0)
            self.on_filters()
        for i, r in enumerate(self.std_rows):
            if r[0] == std:
                self.cb_std.current(i)
                self.cb_std._last = i
                self.on_std()
                break
        else:
            return False
        if set_name and set_name in self.set_names:
            self.cb_set.current(self.set_names.index(set_name))
            self.on_set()
        if mats:
            self.lb_mat.selection_clear(0, "end")
            for i, m in enumerate(self.mats):
                if m in mats:
                    self.lb_mat.selection_set(i)
            self.on_mats()
        if dias:
            self.lb_dia.selection_clear(0, "end")
            for i, d in enumerate(self.dias):
                if any(abs(d - float(x)) < 1e-6 for x in dias):
                    self.lb_dia.selection_set(i)
            self.on_dias()
        return True

    def leave_select(self):
        if not self.std_key():
            return "Wybierz normę kotwy.", self.cb_std
        if not self.set_key():
            return "Wybierz zestaw.", self.cb_set
        if not self.sel:
            return "Zaznacz co najmniej jedną klasę i średnicę."
        remember("last_anchor_std", self.std_key())


# ====================================================================== dodaj set do kotew
class AnchorSetWizard(AnchorSelWizard):
    finish_text = "Dodaj set do kotew"

    def __init__(self, app):
        super().__init__(app, "Dodaj set do kotew")
        self.init_select()
        self.plans = []
        self.v_new = tk.StringVar()
        self.mode = tk.StringVar(value="new")
        self.v_owner = tk.StringVar(value=recall("owner", DEFAULT_OWNER))
        self.v_skipmiss = tk.BooleanVar(value=False)
        self.loaded_for = None
        self.shape = ShapePreview(self.make_side("Podgląd kotwy", 400), app, self.shape_zone)
        self.shape.pack(fill="both", expand=True)
        self.add_step("Które kotwy", self.build1, self.enter_select, self.leave_select, help="anchor_set.1")
        self.add_step("Nowy set", self.build2, self.enter2, self.leave2, help="anchor_set.2")
        self.add_step("Podsumowanie", self.build3, self.enter3, None, help="anchor_set.3")
        self.start()

    def build1(self, f):
        self.build_select(f, "Do których kotew dodać nowy zestaw? Wybierz normę i zestaw-wzór, potem klasy i średnice "
                             "(Ctrl / Shift = kilka). W następnym kroku wybierzesz: nowy zestaw (kopie kotew) albo zmianę zestawu w tych kotwach.")

    def build2(self, f):
        f.columnconfigure(0, weight=1)
        f.columnconfigure(1, weight=1)
        f.rowconfigure(2, weight=1)
        rm = ttk.Frame(f)
        rm.grid(row=0, column=0, columnspan=2, sticky="we", pady=(0, 6))
        ttk.Radiobutton(rm, text=T("Nowy zestaw (powstają nowe kotwy)"), value="new", variable=self.mode,
                        command=self.on_mode).pack(side="left", padx=(0, 20))
        ttk.Radiobutton(rm, text=T("Zmień zestaw w tych kotwach (nadpisz)"), value="over", variable=self.mode,
                        command=self.on_mode).pack(side="left")
        r = ttk.Frame(f)
        r.grid(row=1, column=0, columnspan=2, sticky="we", pady=(0, 8))
        ttk.Label(r, text="Nazwa nowego zestawu").pack(side="left")
        self.cb_new = ttk.Combobox(r, textvariable=self.v_new, width=30)
        self.cb_new.pack(side="left", padx=8)
        ttk.Label(r, text="Właściciel").pack(side="left", padx=(16, 4))
        self.en_owner = ttk.Entry(r, textvariable=self.v_owner, width=12)
        self.en_owner.pack(side="left")
        self.ze = ZoneEditor(f, self.app, self.ref_dia, lambda: self.shape.schedule())
        self.ze.grid(row=2, column=0, columnspan=2, sticky="nsew")
        self.var_h2 = tk.StringVar()
        ttk.Label(f, textvariable=self.var_h2, style="Hint.TLabel", wraplength=900).grid(row=3, column=0, columnspan=2, sticky="w", pady=(8, 0))

    def ref_dia(self):
        d = self.sel_dias()
        return d[0] if d else None

    def shape_zone(self):
        """Skład na rysunku: w kroku 1 obecny zestaw wybranej kotwy, od kroku 2 - nowy skład z edytora."""
        if self.cur >= 1 and hasattr(self, "ze"):
            return self.ze.zone
        i = self.shape.cb.current()
        return zone_of_anchor(self.shape.anchors[i]) if 0 <= i < len(self.shape.anchors) else {"top": [], "below": [], "end": []}

    def refresh_side(self):
        self.shape.v_cap.set(T("Podgląd: kotwa z obecnym zestawem. Wybierz inną z listy, aby zobaczyć inny wariant.") if self.cur < 1 else
                             T("Podgląd: kotwa z NOWYM zestawem nakrętek i podkładek (zmiany po lewej widać od razu)."))
        self.shape.schedule()

    def on_mode(self):
        """Nadpisanie: nazwa zestawu domyślnie zostaje ta sama (można ją zmienić = zmiana nazwy zestawu w kotwach)."""
        if self.mode.get() == "over" and not self.v_new.get().strip():
            self.v_new.set(self.set_key() or "")
        elif self.mode.get() == "new" and self.v_new.get().strip() == self.set_key():
            self.v_new.set("")

    def enter2(self):
        key = (self.std_key(), self.set_key(), tuple(self.sel_mats()), tuple(self.sel_dias()))
        self.cb_new["values"] = self.set_names
        if self.loaded_for != key:
            self.loaded_for = key
            self.ze.set_zone(zone_of_anchor(self.sel[0]))
            self.v_new.set("")
            self.mode.set("new")
        else:
            self.ze.refresh()
        self.shape.set_anchors(self.sel)
        self.var_h2.set(T("Skład jest wzięty z zestawu '%s' - zmień go: dodaj, zamień albo usuń elementy. "
                          "Dotyczy wszystkich wybranych kotew (%d).") % (self.set_key(), len(self.sel)))

    def leave2(self):
        name = self.v_new.get().strip()
        if not name or len(name) > 64:
            return "Podaj nazwę nowego zestawu (max 64 znaki).", self.cb_new
        if self.ze.count() == 0:
            return "Dodaj co najmniej jeden element zestawu."
        o = self.v_owner.get().strip()
        if not o or len(o) > 15 or not is_own(o):
            return "Właściciel: 1-15 znaków, nie DSC/AUTODESK.", self.en_owner

    def build3(self, f):
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        ttk.Label(f, text="Sprawdź, co zostanie zapisane. Kotwy fabryczne zostają bez zmian (nadpisywane są tylko Twoje kotwy).",
                  style="Sub.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        fr, self.tr = make_tree(f, ("Ø", "Klasa", "Z zestawu", "Nowy zestaw", "Długości", "Status"), (60, 100, 150, 150, 80, 360), 12, sort=True, filt=True)
        fr.grid(row=1, column=0, sticky="nsew")
        status_tags(self.tr)
        self.chk_skip = ttk.Checkbutton(f, text="Zapisz bez brakujących elementów (pomiń je)", variable=self.v_skipmiss,
                                        command=self.enter3)
        self.chk_skip.grid(row=2, column=0, sticky="w", pady=(8, 0))
        self.var_h3 = tk.StringVar()
        ttk.Label(f, textvariable=self.var_h3, style="Hint.TLabel", wraplength=900).grid(row=3, column=0, sticky="w")

    def make_plans(self):
        new_set = self.v_new.get().strip()
        ids = [n["ID"] for n in self.sel]
        defs, _ = self.db.anchor_children(ids)
        plans = []
        for n in self.sel:
            dia = float(n["Diameter"])
            items, miss = items_for(self.db, self.ze.zone, dia)
            ex = self.db.anchor_exists(self.std_key(), n["MaterialKey"], dia, new_set)
            nd = len(defs.get(n["ID"], []))
            over = self.mode.get() == "over"
            if over and not is_own(n.get("OwnerText")):
                st, code = T("kotwa fabryczna - nie nadpisuję (użyj trybu 'Nowy zestaw')"), "skip"
            elif over and ex and ex[0] != n["ID"]:
                st, code = T("już istnieje kotwa z tą nazwą zestawu - pominięto"), "skip"
            elif over and not items:
                st, code = T("pominięto: brak elementów w bazie"), "skip"
            elif over and miss and not self.v_skipmiss.get():
                st, code = T("pominięto: brak w bazie ") + ", ".join(miss), "skip"
            elif over:
                st, code = T("NADPISANIE zestawu") + (T(" (bez: ") + ", ".join(miss) + ")" if miss else ""), "over"
            elif ex:
                st, code = T("już istnieje kotwa z tym zestawem - pominięto"), "skip"
            elif not items:
                st, code = T("pominięto: brak elementów w bazie"), "skip"
            elif miss and not self.v_skipmiss.get():
                st, code = T("pominięto: brak w bazie ") + ", ".join(miss), "skip"
            else:
                st, code = T("NOWA") + (T(" (bez: ") + ", ".join(miss) + ")" if miss else ""), "new"
            plans.append({"n": n, "items": items, "defs": defs.get(n["ID"], []), "code": code, "status": st, "nd": nd,
                          "miss": miss})
        return plans

    def enter3(self):
        self.plans = self.make_plans()
        self.tr.delete(*self.tr.get_children())
        for i, p in enumerate(self.plans):
            n = p["n"]
            self.tr.insert("", "end", iid=str(i), tags=("ok" if p["code"] in ("new", "over") else "skip",),
                           values=(dia_text(float(n["Diameter"])), n["MaterialKey"], n["SetName"],
                                   self.v_new.get().strip(), p["nd"], p["status"]))
        if any(p["miss"] for p in self.plans) or self.v_skipmiss.get():
            self.chk_skip.grid()
        else:
            self.chk_skip.grid_remove()
        k = sum(1 for p in self.plans if p["code"] in ("new", "over"))
        self.var_h3.set(T("Do zapisu: %d z %d kotew.") % (k, len(self.plans)))
        sk = len(self.plans) - k
        nm = self.v_new.get().strip()
        if self.mode.get() == "over":
            story = T("Zestaw '%s' zostanie podmieniony w %d Twoich kotwach (norma %s). Długości i wymiary kotew się nie zmienią.") % (nm, k, self.std_key())
        else:
            story = T("Powstanie %d nowych kotew z zestawem '%s' (norma %s), każda z tymi samymi długościami co kotwa źródłowa. "
                      "Kotwy źródłowe i fabryczne zostają bez zmian.") % (k, nm, self.std_key())
        if sk:
            story += " " + T("Pominiętych: %d (powód w kolumnie Status).") % sk
        self.var_story.set(story)
        self.finish_text = "Nadpisz set w kotwach" if self.mode.get() == "over" else "Dodaj set do kotew"
        self.btn_next.configure(text=T(self.finish_text))

    def finish_over(self):
        todo = [p for p in self.plans if p["code"] == "over"]
        if not todo:
            messagebox.showinfo("Zapis", "Brak kotew do zapisu (zobacz kolumnę Status).")
            return
        new_set, std = self.v_new.get().strip(), self.std_key()
        add_set = new_set not in [x[0] for x in self.app.sets]
        if not messagebox.askyesno("Potwierdź zapis", T("Nadpisać zestaw w %d Twoich kotwach (nowy zestaw '%s')? "
                                                        "Dotychczasowy skład zestawu tych kotew zostanie zastąpiony.") % (len(todo), new_set)):
            return
        if not self.app.backup_before_write():
            return
        ups = []
        for p in todo:
            n = p["n"]
            row = build_anchor_name_row(n["ID"], std, n["ClassID"], n["MaterialKey"], float(n["Diameter"]), n["Source"] or "",
                                        new_set, n.get("OwnerText") or "", n.get("Explodable"), p["items"])
            for k in ("ID", "Standard", "ClassID", "MaterialKey", "Diameter", "Source", "Explodable", "OwnerText"):
                row.pop(k)
            ups.append((n["ID"], row))
        owner = self.v_owner.get().strip()

        def fn(cur):
            if add_set:
                cur.execute(*insert_sql("Sets", {"Key": new_set[:64], "RunName": new_set[:64], "OwnerText": owner[:15]}))
            for aid, row in ups:
                cols = list(row)
                cur.execute("UPDATE [AnchorsName] SET %s WHERE [ID]=?" % ",".join("%s=?" % q(c) for c in cols),
                            [row[c] for c in cols] + [aid])
        if self.app.write_or_report(fn, label=T("Nadpisanie zestawu w kotwach: %s") % new_set):
            remember("owner", owner)
            self.app.an_last_std = std
            self.app.reload()
            self.app.refresh_anchor_tabs()
            messagebox.showinfo("Gotowe", T("Zmieniono zestaw w %d kotwach (nowy zestaw '%s'). Odśwież dane w Advance Steel "
                                            "(przycisk 'Update defaults') albo uruchom go ponownie.") % (len(ups), new_set))
            self.destroy()

    def finish(self):
        if not self.app.need_db():
            return
        if self.mode.get() == "over":
            return self.finish_over()
        todo = [p for p in self.plans if p["code"] == "new"]
        if not todo:
            messagebox.showinfo("Zapis", "Brak kotew do zapisu (zobacz kolumnę Status).")
            return
        new_set, owner, std = self.v_new.get().strip(), self.v_owner.get().strip(), self.std_key()
        add_set = new_set not in [x[0] for x in self.app.sets]
        if not messagebox.askyesno("Potwierdź zapis", T("Utworzyć %d kotew z nowym zestawem '%s' (norma %s)?") % (
                len(todo), new_set, std) + (T("\nZostanie dodany nowy zestaw w słowniku.") if add_set else "")):
            return
        if not self.app.backup_before_write():
            return
        nid, did, hid = self.db.max_id("AnchorsName"), self.db.max_id("AnchorsDefinition"), self.db.max_id("AnchorsHoleDefinition")
        rows = []
        for p in todo:
            n = p["n"]
            nid += 1
            hid += 1
            rn = build_anchor_name_row(nid, std, n["ClassID"], n["MaterialKey"], float(n["Diameter"]), n["Source"] or "",
                                       new_set, owner, n.get("Explodable"), p["items"])
            rd = []
            for d in p["defs"]:
                did += 1
                rd.append(build_anchor_def_row(did, nid, d, owner))
            rows.append((rn, rd, empty_hole_row(hid, nid)))

        def fn(cur):
            if add_set:
                cur.execute(*insert_sql("Sets", {"Key": new_set[:64], "RunName": new_set[:64], "OwnerText": owner[:15]}))
            for rn, rd, rh in rows:
                cur.execute(*insert_sql("AnchorsName", rn))
                for r in rd:
                    cur.execute(*insert_sql("AnchorsDefinition", r))
                cur.execute(*insert_sql("AnchorsHoleDefinition", rh))
        if self.app.write_or_report(fn, label=T("Dodanie kotew z zestawem: %s") % new_set):
            remember("owner", owner)
            self.app.an_last_std = std
            self.app.reload()
            self.app.refresh_anchor_tabs()
            messagebox.showinfo("Gotowe", T("Dodano %d kotew z zestawem '%s'. Odśwież dane w Advance Steel (przycisk "
                                            "'Update defaults') albo uruchom go ponownie.") % (len(rows), new_set))
            self.destroy()


# ====================================================================== dodaj długości do kotew
class AnchorLengthsWizard(AnchorSelWizard):
    finish_text = "Dopisz długości"

    def __init__(self, app):
        super().__init__(app, "Dodaj długości do kotew")
        self.init_select()
        self.plan = []
        self.v_len = tk.StringVar()
        self.v_owner = tk.StringVar(value=recall("owner", DEFAULT_OWNER))
        self.focus_len = None
        self.shape = ShapePreview(self.make_side("Podgląd kotwy", 400), app, self.cur_zone, self.new_length)
        self.shape.pack(fill="both", expand=True)
        self.v_len.trace_add("write", lambda *a: self.shape.schedule())
        self.add_step("Które kotwy", self.build1, self.enter_select, self.leave_select, help="anchor_len.1")
        self.add_step("Nowe długości", self.build2, self.enter2, self.leave2, help="anchor_len.2")
        self.add_step("Podsumowanie", self.build3, self.enter3, None, help="anchor_len.3")
        self.start()

    def build1(self, f):
        self.build_select(f, "Do jakich kotew dodać długości? Wybierz normę i zestaw, potem klasy materiałowe i średnice "
                             "(Ctrl / Shift = kilka). Długości zostaną dopisane do każdej wybranej kotwy.")

    def build2(self, f):
        ttk.Label(f, text="Wpisz nowe długości [mm]: lista, zakresy np. 300-1000/100 albo kolumna wklejona z Excela.",
                  style="Sub.TLabel").pack(anchor="w", pady=(0, 10))
        r = ttk.Frame(f)
        r.pack(anchor="w")
        en = self.en_len = ttk.Entry(r, textvariable=self.v_len, width=60)
        en.pack(side="left")
        clean_paste(en)
        ttk.Button(r, text="Od-do co...", command=self.add_range).pack(side="left", padx=6)
        r2 = ttk.Frame(f)
        r2.pack(anchor="w", pady=14)
        ttk.Label(r2, text="Właściciel nowych wierszy").pack(side="left")
        self.en_owner = ttk.Entry(r2, textvariable=self.v_owner, width=12)
        self.en_owner.pack(side="left", padx=8)
        self.var_have = tk.StringVar()
        ttk.Label(f, textvariable=self.var_have, style="CardTitle.TLabel", wraplength=860).pack(anchor="w", pady=(0, 10))
        ttk.Label(f, text=T("Wymiary (gwint, odległości, haki...), ciężar i numer części każdej nowej długości są liczone "
                            "z najbliższej istniejącej długości TEJ kotwy (ciężar skaluje się z długością). "
                            "Długości, które kotwa już ma, są pomijane."),
                  style="Hint.TLabel", wraplength=860).pack(anchor="w")

    def enter2(self):
        defs, _ = self.db.anchor_children([n["ID"] for n in self.sel])
        have = sorted({r["Length"] for n in self.sel for r in defs.get(n["ID"], []) if r.get("Length") is not None})
        self.var_have.set(T("Wybrane kotwy: %d. Długości, które już mają: %s") % (len(self.sel), ", ".join(fmt_dia(x) for x in have) or "-"))

    def add_range(self):
        r = ask_range(self)
        if r:
            cur = self.v_len.get().strip()
            self.v_len.set((cur + ", " if cur else "") + r)

    def leave2(self):
        try:
            read_lengths(self.v_len.get())
        except ValueError as e:
            return str(e), self.en_len
        o = self.v_owner.get().strip()
        if not o or len(o) > 15 or not is_own(o):
            return "Właściciel: 1-15 znaków, nie DSC/AUTODESK.", self.en_owner

    def build3(self, f):
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        ttk.Label(f, text="Sprawdź, co zostanie dopisane. Istniejące wiersze (także fabryczne) nie są zmieniane.",
                  style="Sub.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        fr, self.tr = make_tree(f, ("Ø", "Klasa", "Długość", "Nr części", "Ciężar", "Status"), (50, 70, 70, 190, 60, 170), 13, sort=True, filt=True)
        fr.grid(row=1, column=0, sticky="nsew")
        status_tags(self.tr)
        self.tr.bind("<<TreeviewSelect>>", self.on_row)
        self.var_h3 = tk.StringVar()
        ttk.Label(f, textvariable=self.var_h3, style="Hint.TLabel", wraplength=900).grid(row=2, column=0, sticky="w", pady=(8, 0))

    def cur_zone(self):
        i = self.shape.cb.current()
        return zone_of_anchor(self.shape.anchors[i]) if 0 <= i < len(self.shape.anchors) else {"top": [], "below": [], "end": []}

    def new_length(self):
        """Długość na rysunku: zaznaczony wiersz podsumowania, a w kroku 2 - największa wpisana długość."""
        if self.cur >= 2 and self.focus_len:
            return self.focus_len
        try:
            return max(read_lengths(self.v_len.get()))
        except (ValueError, TypeError):
            return None

    def refresh_side(self):
        self.shape.v_cap.set(T("Podgląd: kotwa, do której dopiszesz długości.") if self.cur < 1 else
                             T("Podgląd: kotwa z nową długością (największa wpisana albo zaznaczona w tabeli)."))
        self.shape.schedule()

    def on_row(self, _=None):
        sel = self.tr.selection()
        if sel:
            p = self.plan[int(sel[0])]
            self.focus_len = p["len"]
            if p["n"] in self.shape.anchors:
                self.shape.cb.current(self.shape.anchors.index(p["n"]))
                self.shape.schedule()

    def make_plan(self):
        lens = read_lengths(self.v_len.get())
        defs, _ = self.db.anchor_children([n["ID"] for n in self.sel])
        std, plan = self.std_key(), []
        for n in self.sel:
            dia = float(n["Diameter"])
            have = defs.get(n["ID"], [])
            have_l = {r.get("Length") for r in have}
            for length in lens:
                if length in have_l:
                    plan.append({"n": n, "len": length, "vals": None, "status": T("już istnieje - pominięto")})
                    continue
                if not have:
                    plan.append({"n": n, "len": length, "vals": None, "status": T("kotwa nie ma żadnej długości (wzoru) - pominięto")})
                    continue
                base = min(have, key=lambda r: abs((r.get("Length") or 0) - length))
                vals = {c: base.get(c) for c in ANCHOR_DEF_COLS.get(n["ClassID"], ANCHOR_DEF_COLS[3]) if c not in SKIP}
                vals["Length"] = length
                vals["Weight"] = anchor_weight(base.get("Length"), base.get("Weight"), dia, length)
                vals["PartName"] = rename_part(base.get("PartName"), base.get("Length"), length, dia, std)
                plan.append({"n": n, "len": length, "vals": vals, "status": T("NOWA długość")})
        return plan

    def enter3(self):
        self.focus_len = None
        self.plan = self.make_plan()
        self.tr.delete(*self.tr.get_children())
        for i, p in enumerate(self.plan):
            v = p["vals"] or {}
            self.tr.insert("", "end", iid=str(i), tags=("ok" if p["vals"] else "skip",),
                           values=(dia_text(float(p["n"]["Diameter"])), p["n"]["MaterialKey"],
                                                          fmt_dia(p["len"]), v.get("PartName", ""), v.get("Weight", ""), p["status"]))
        self.shape.set_anchors(self.sel)
        k = sum(1 for p in self.plan if p["vals"])
        na = len({p["n"]["ID"] for p in self.plan if p["vals"]})
        self.var_h3.set(T("Do dopisania: %d wierszy długości w %d kotwach.") % (k, na))
        self.var_story.set(T("Do %d kotew (zestaw %s) zostanie dopisanych %d nowych wierszy długości. Istniejące wiersze - także "
                             "fabryczne - nie zmienią się.") % (na, self.set_key(), k) + (
            " " + T("Pominięto %d powtórzeń lub kotew bez wzoru.") % (len(self.plan) - k) if len(self.plan) > k else ""))

    def finish(self):
        if not self.app.need_db():
            return
        todo = [p for p in self.plan if p["vals"]]
        if not todo:
            messagebox.showinfo("Zapis", "Wszystkie podane długości już istnieją - nie ma nic do dopisania.")
            return
        owner = self.v_owner.get().strip()
        fact = sum(1 for p in todo if not is_own(p["n"].get("OwnerText")))
        msg = T("Dopisać %d wierszy długości do %d kotew (zestaw %s)?") % (len(todo), len({p["n"]["ID"] for p in todo}), self.set_key())
        if fact:
            msg += "\n" + T("Wśród nich są kotwy fabryczne: ich wiersze zostają bez zmian, dopisane będą tylko nowe z właścicielem %s.") % owner
        if not messagebox.askyesno("Potwierdź zapis", msg):
            return
        if not self.app.backup_before_write():
            return
        did = self.db.max_id("AnchorsDefinition")
        rows = []
        for p in todo:
            did += 1
            rows.append(build_anchor_def_row(did, p["n"]["ID"], p["vals"], owner))

        def fn(cur):
            for r in rows:
                cur.execute(*insert_sql("AnchorsDefinition", r))
        if self.app.write_or_report(fn, label=T("Dopisanie długości do kotew (zestaw %s)") % self.set_key()):
            remember("owner", owner)
            self.app.an_last_std = self.std_key()
            self.app.reload()
            self.app.refresh_anchor_tabs()
            messagebox.showinfo("Gotowe", T("Dopisano %d wierszy długości. Odśwież dane w Advance Steel (przycisk "
                                            "'Update defaults') albo uruchom go ponownie.") % len(rows))
            self.destroy()


# ====================================================================== nowa kotwa
class NewAnchorWizard(Wizard):
    finish_text = "Zapisz kotwę"

    def __init__(self, app):
        super().__init__(app, "Nowa kotwa", (1300, 740))
        self.std_rows, self.names, self.tpl_rows = [], [], []
        self.pvars = {}
        self.v_newstd = tk.StringVar()
        self.v_dia, self.v_src, self.v_len, self.v_w = (tk.StringVar() for _ in range(4))
        self.v_cls, self.v_set = tk.StringVar(), tk.StringVar()
        self.v_owner = tk.StringVar(value=recall("owner", DEFAULT_OWNER))
        self.v_expl = tk.BooleanVar(value=True)
        self.v_skipmiss = tk.BooleanVar(value=False)
        self.v_plate, self.v_grout = tk.StringVar(value=fmt_dia(DEFAULT_PLATE)), tk.StringVar(value="0")
        self.v_shape = tk.StringVar()
        self.mode = tk.StringVar(value="old")
        self._job = None
        self.plan = None
        self.build_side(self.make_side("Podgląd kotwy", 400))
        self.add_step("Norma kotwy", self.build1, self.enter1, self.leave1, help="anchor_new.1")
        self.add_step("Typ, wymiary, długości", self.build2, self.enter2, self.leave2, help="anchor_new.2")
        self.add_step("Zestaw nakrętek i podkładek", self.build3, self.enter3, self.leave3, help="anchor_new.3")
        self.add_step("Podsumowanie", self.build4, self.enter4, None, help="anchor_new.4")
        self.start()

    def build_side(self, side):
        """Stały rysunek kotwy, którą tworzysz: rysuje się na żywo z wpisywanych typu, średnicy, długości, wymiarów i zestawu."""
        self.v_cap = tk.StringVar()
        ttk.Label(side, textvariable=self.v_cap, style="Hint.TLabel", wraplength=350, justify="left").pack(anchor="w", pady=(0, 4))
        self.cv = tk.Canvas(side, width=360, height=360, bg="white", highlightthickness=1, highlightbackground="#cccccc")
        self.cv.pack(fill="both", expand=True)
        self.cv.bind("<Configure>", lambda e: self.draw())
        mb = ttk.Frame(side)
        mb.pack(fill="x", pady=4)
        ttk.Label(mb, text=T("Blacha [mm]:")).pack(side="left")
        ttk.Entry(mb, textvariable=self.v_plate, width=6).pack(side="left", padx=4)
        ttk.Label(mb, text=T("Podlewka [mm]:")).pack(side="left")
        ttk.Entry(mb, textvariable=self.v_grout, width=6).pack(side="left", padx=4)
        ttk.Label(side, textvariable=self.v_shape, style="Hint.TLabel", wraplength=350, justify="left").pack(anchor="w")
        for v in (self.v_plate, self.v_grout, self.v_dia, self.v_len):
            v.trace_add("write", lambda *a: self.schedule_draw())

    def refresh_side(self):
        self.v_cap.set({0: T("Podgląd pojawi się, gdy wybierzesz typ kotwy i wpiszesz średnicę oraz długość (krok 2)."),
                        1: T("Kotwa rysuje się na żywo z tego, co wpisujesz: typ, Ø, długość i wymiary."),
                        2: T("Dodaj nakrętki i podkładki - rysunek pokazuje ich położenie na kotwie."),
                        3: T("Tak będzie wyglądała nowa kotwa (pokazana najdłuższa z podanych długości).")}[min(self.cur, 3)])
        self.schedule_draw()

    # ------------------------------------------------------------ krok 1
    def build1(self, f):
        ttk.Label(f, text="Gdzie ma powstać nowa kotwa?", style="Sub.TLabel").pack(anchor="w", pady=(0, 10))
        ttk.Radiobutton(f, text=T("W istniejącej normie kotwy"), value="old", variable=self.mode,
                        command=self.on_mode).pack(anchor="w")
        self.cb_std = make_filterable(ttk.Combobox(f, width=60))
        self.cb_std.pack(anchor="w", padx=24, pady=(2, 12))
        self.cb_std.bind("<<ComboboxSelected>>", lambda e: self.on_std())
        ttk.Radiobutton(f, text=T("W nowej normie kotwy (nowy producent / rodzina)"), value="new", variable=self.mode,
                        command=self.on_mode).pack(anchor="w")
        self.en_newstd = ttk.Entry(f, textvariable=self.v_newstd, width=48)
        self.en_newstd.pack(anchor="w", padx=24, pady=(2, 12))
        self.var_h1 = tk.StringVar()
        ttk.Label(f, textvariable=self.var_h1, style="Hint.TLabel", wraplength=860).pack(anchor="w")

    def enter1(self):
        if not self.std_rows:
            self.std_rows = list(self.app.an_std_rows)
            set_choices(self.cb_std, ["%s   |   %s%s" % (r[0], r[1], "   [MOJA]" if is_own(r[2]) else "") for r in self.std_rows])
            want = recall("last_anchor_std")
            for i, r in enumerate(self.std_rows):
                if r[0] == want:
                    self.cb_std.current(i)
                    self.cb_std._last = i
                    self.on_std()
                    break
        self.on_mode()

    def on_mode(self):
        old = self.mode.get() == "old"
        self.cb_std.state(["!disabled"] if old else ["disabled"])
        self.en_newstd.state(["disabled"] if old else ["!disabled"])

    def std_key(self):
        if self.mode.get() == "new":
            return self.v_newstd.get().strip()
        i = selected_index(self.cb_std)
        return self.std_rows[i][0] if 0 <= i < len(self.std_rows) else None

    def on_std(self):
        r = self.std_key()
        n = len(self.db.anchor_names(r)) if r else 0
        self.var_h1.set(T("Kotew w tej normie: %d.") % n if r else "")

    def leave1(self):
        k = self.std_key()
        w = self.en_newstd if self.mode.get() == "new" else self.cb_std
        if not k:
            return "Wybierz normę kotwy albo wpisz nazwę nowej normy.", w
        if self.mode.get() == "new":
            if len(k) > 64:
                return "Nazwa normy: max 64 znaki.", w
            if any(r[0].lower() == k.lower() for r in self.app.an_std_rows):
                return "Norma o takiej nazwie już istnieje - wybierz ją z listy.", w
        else:
            remember("last_anchor_std", k)
        self.names = self.db.anchor_names(k) if self.mode.get() == "old" else []

    # ------------------------------------------------------------ krok 2
    def build2(self, f):
        f.columnconfigure(1, weight=1)
        f.rowconfigure(0, weight=1)
        left = ttk.Frame(f)
        left.grid(row=0, column=0, sticky="nsw", padx=(0, 18))
        ttk.Label(left, text=T("Najszybciej: wybierz wzorzec - wypełni typ, klasę, zestaw, źródło i wymiary. Potem wpisz średnicę i długości."),
                  style="Hint.TLabel", wraplength=480).pack(anchor="w", pady=(0, 8))
        ts = ttk.Frame(left)
        ts.pack(anchor="w", pady=(0, 2))
        ttk.Label(ts, text=T("Norma wzorca (może być inna niż nowa)")).grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.cb_tplstd = make_filterable(ttk.Combobox(ts, width=40))
        self.cb_tplstd.grid(row=0, column=1, sticky="w")
        self.cb_tplstd.bind("<<ComboboxSelected>>", lambda e: self.on_tplstd())
        g = ttk.Frame(left)
        g.pack(anchor="w")

        def row(r, text, w):
            ttk.Label(g, text=T(text)).grid(row=r, column=0, sticky="w", pady=3, padx=(0, 8))
            w.grid(row=r, column=1, sticky="w", pady=3)
        self.cb_tpl = ttk.Combobox(g, width=34, state="readonly")
        self.cb_tpl.bind("<<ComboboxSelected>>", lambda e: self.on_tpl())
        row(0, "Wzorzec (opcjonalnie)", self.cb_tpl)
        self.cb_type = ttk.Combobox(g, width=34, state="readonly",
                                    values=["%s   |   %s" % (r[0], r[1]) for r in self.app.an_type_rows])
        self.cb_type.bind("<<ComboboxSelected>>", lambda e: self.rebuild_params())
        row(1, "Typ kotwy *", self.cb_type)
        self.cb_dia = ttk.Combobox(g, width=12, textvariable=self.v_dia,
                                   values=[fmt_dia(float(r[0])) for r in self.app.an_dia_rows])
        row(2, "Średnica Ø [mm] *", self.cb_dia)
        cls_map = {r[0]: (r[1] or r[0]) for r in self.app.cls_rows}
        self.cb_cls = ttk.Combobox(g, width=34, textvariable=self.v_cls,
                                   values=["%s   |   %s" % (k, v) for k, v in cls_map.items()])
        self.cb_cls.bind("<<ComboboxSelected>>", lambda e: self.v_cls.set(self.v_cls.get().split("   |   ")[0]))
        row(3, "Klasa materiału * (lub wpisz nową)", self.cb_cls)
        self.cb_setname = ttk.Combobox(g, width=34, textvariable=self.v_set, values=[x[0] for x in self.app.sets])
        row(4, "Nazwa zestawu * (lub wpisz nową)", self.cb_setname)
        self.cb_src = ttk.Combobox(g, width=34, textvariable=self.v_src, values=[r[0] for r in self.app.an_src_rows])
        row(5, "Źródło / norma * (max 15)", self.cb_src)
        self.en_owner = ttk.Entry(g, textvariable=self.v_owner, width=18)
        row(6, "Właściciel (max 15)", self.en_owner)
        ttk.Checkbutton(g, text=T("Możliwe rozbicie zestawu"), variable=self.v_expl).grid(row=7, column=1, sticky="w")
        ttk.Label(left, text=T("Długości [mm] * (lista, zakresy np. 300-1000/100 albo kolumna z Excela)")).pack(anchor="w", pady=(10, 2))
        lf = ttk.Frame(left)
        lf.pack(anchor="w")
        en = self.en_len = ttk.Entry(lf, textvariable=self.v_len, width=34)
        en.pack(side="left")
        clean_paste(en)
        ttk.Button(lf, text="Od-do co...", command=self.add_range).pack(side="left", padx=4)
        lw = ttk.Frame(left)
        lw.pack(anchor="w", pady=6)
        ttk.Label(lw, text=T("Ciężar pierwszej długości [kg] (puste = obliczony)")).pack(side="left")
        ttk.Entry(lw, textvariable=self.v_w, width=9).pack(side="left", padx=6)
        self.fr_par = ttk.LabelFrame(f, text=T("Wymiary kotwy (zależne od typu)"))
        self.fr_par.grid(row=0, column=1, sticky="nsew")
        ttk.Label(self.fr_par, text=T("Wybierz typ kotwy albo wzorzec - tu pojawią się jej wymiary."),
                  style="Hint.TLabel").grid(row=0, column=0, padx=12, pady=12)

    def add_range(self):
        r = ask_range(self)
        if r:
            cur = self.v_len.get().strip()
            self.v_len.set((cur + ", " if cur else "") + r)

    def type_id(self):
        i = self.cb_type.current()
        return self.app.an_type_rows[i][0] if 0 <= i < len(self.app.an_type_rows) else None

    def rebuild_params(self):
        for w in self.fr_par.winfo_children():
            w.destroy()
        old = {c: v.get() for c, v in self.pvars.items()}
        self.pvars = {}
        tid = self.type_id()
        if tid is None:
            return
        cols = [c for c in ANCHOR_DEF_COLS.get(tid, ANCHOR_DEF_COLS[3]) if c not in SKIP]
        self.schedule_draw()
        for i, c in enumerate(cols):
            lab = ttk.Label(self.fr_par, text=T(ANCHOR_LABELS[c]) + (" [mm]" if c != "NumberOfHeadEdges" else ""))
            lab.grid(row=i, column=0, sticky="w", padx=(10, 6), pady=4)
            add_tip(lab, T(ANCHOR_TIPS[c]))
            v = tk.StringVar(value=old.get(c, ""))
            v.trace_add("write", lambda *a: self.schedule_draw())
            self.pvars[c] = v
            ttk.Entry(self.fr_par, textvariable=v, width=10).grid(row=i, column=1, sticky="w", pady=4)

    def enter2(self):
        key = self.std_key()
        if getattr(self, "_tpl_for", None) != (key, self.mode.get()):
            self._tpl_for = (key, self.mode.get())
            self.tplstd_rows = list(self.app.an_std_rows)
            set_choices(self.cb_tplstd, ["%s   |   %s" % (r[0], r[1]) for r in self.tplstd_rows])
            self.cb_tplstd.set("")
            self.cb_tplstd._last = -1
            if self.mode.get() == "old":                 # istniejąca norma: domyślnie wzorce z niej samej
                for i, r in enumerate(self.tplstd_rows):
                    if r[0] == key:
                        self.cb_tplstd.current(i)
                        self.cb_tplstd._last = i
            self.on_tplstd()
            src = [r[0] for r in self.app.an_src_rows]
            self.cb_src["values"] = src
            if self.mode.get() == "new":
                self.v_src.set(self.v_src.get() or key[:15])

    def preset(self, std, tpl_id=None):
        """Wstępny wybór (z Katalogu): istniejąca norma i - opcjonalnie - wzorzec (ID kotwy); przechodzi od razu do kroku 2."""
        i = next((k for k, r in enumerate(self.std_rows) if r[0] == std), -1)
        if i < 0:
            return False
        self.mode.set("old")
        self.cb_std.current(i)
        self.cb_std._last = i
        self.on_std()
        self.on_mode()
        if tpl_id is not None:
            self.next()
            j = next((k for k, n in enumerate(self.tpl_rows) if n["ID"] == tpl_id), -1)
            if j >= 0:
                self.cb_tpl.current(j)
                self.on_tpl()
        return True

    def on_tplstd(self):
        """Lista wzorców z wybranej normy wzorca (w nowej normie: dowolna norma; bez wyboru lista jest pusta)."""
        i = selected_index(self.cb_tplstd)
        std = self.tplstd_rows[i][0] if 0 <= i < len(self.tplstd_rows) else None
        names = self.db.anchor_names(std) if std else []
        self.tpl_rows = sorted(names, key=lambda n: (n["ClassID"], float(n["Diameter"]), n["MaterialKey"]))
        tn = {r[0]: r[1] for r in self.app.an_type_rows}
        self.cb_tpl["values"] = ["%s | Ø%s | %s | %s" % (tn.get(n["ClassID"], "?"), dia_text(float(n["Diameter"])),
                                                          n["MaterialKey"], n["SetName"]) for n in self.tpl_rows]
        self.cb_tpl.set("")

    def on_tpl(self):
        """Wzorzec: wczytuje typ, klasę, zestaw, źródło, wymiary pierwszej długości i skład zestawu."""
        i = self.cb_tpl.current()
        if not (0 <= i < len(self.tpl_rows)):
            return
        n = self.tpl_rows[i]
        ti = [r[0] for r in self.app.an_type_rows].index(n["ClassID"]) if n["ClassID"] in [r[0] for r in self.app.an_type_rows] else -1
        if ti >= 0:
            self.cb_type.current(ti)
        self.rebuild_params()
        self.v_cls.set(n["MaterialKey"])
        self.v_set.set(n["SetName"])
        if self.mode.get() == "old" or not self.v_src.get().strip():       # nowa norma: zostaje jej własne źródło
            self.v_src.set(n["Source"] or "")
        self.v_expl.set(bool(n.get("Explodable", 1)))
        defs, _ = self.db.anchor_children([n["ID"]])
        base = (defs.get(n["ID"]) or [{}])[0]
        for c, v in self.pvars.items():
            val = base.get(c)
            v.set("" if val is None else fmt_dia(val) if isinstance(val, float) else str(val))
        self.tpl_zone = zone_of_anchor(n)

    def collect(self):
        errs, d = [], {}
        d["tid"] = self.type_id()
        if d["tid"] is None:
            errs.append("Wybierz typ kotwy.")
        try:
            d["dia"] = float(self.v_dia.get().replace(",", "."))
            assert d["dia"] > 0
        except (ValueError, AssertionError):
            d["dia"] = None
            errs.append("Średnica: podaj dodatnią liczbę (mm).")
        d["mat"] = self.v_cls.get().split("   |   ")[0].strip()
        d["set"], d["src"], d["owner"] = self.v_set.get().strip(), self.v_src.get().strip(), self.v_owner.get().strip()
        if not d["mat"] or len(d["mat"]) > 64:
            errs.append("Klasa: wybierz z listy albo wpisz nową (max 64 znaki).")
        if not d["set"] or len(d["set"]) > 64:
            errs.append("Zestaw: wymagany, max 64 znaki.")
        if not d["src"] or len(d["src"]) > 15:
            errs.append("Źródło: wymagane, max 15 znaków.")
        if not d["owner"] or len(d["owner"]) > 15 or not is_own(d["owner"]):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        try:
            d["lens"] = read_lengths(self.v_len.get())
        except ValueError as e:
            d["lens"] = []
            errs.append(str(e))
        params = {}
        for c, v in self.pvars.items():
            s = v.get().strip()
            try:
                params[c] = None if not s else (int(s) if c == "NumberOfHeadEdges" else float(s.replace(",", ".")))
            except ValueError:
                errs.append("%s: %s" % (T(ANCHOR_LABELS[c]), T("podaj liczbę.")))
        d["params"] = params
        try:
            d["w0"] = float(self.v_w.get().replace(",", ".")) if self.v_w.get().strip() else None
        except ValueError:
            d["w0"] = None
            errs.append("Ciężar: podaj liczbę.")
        return d, errs

    def leave2(self):
        d, errs = self.collect()
        if errs:
            e = errs[0]
            widget = None
            for pref, w in (("Wybierz typ", self.cb_type), ("Średnica", self.cb_dia), ("Klasa", self.cb_cls),
                            ("Zestaw", self.cb_setname), ("Źródło", self.cb_src), ("Właściciel", self.en_owner),
                            ("Długości", self.en_len), ("Podaj co najmniej", self.en_len), ("Nie rozumiem", self.en_len)):
                if e.startswith(pref):
                    widget = w
                    break
            return (e, widget) if widget is not None else e
        self.d = d

    # ------------------------------------------------------------ krok 3
    def build3(self, f):
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        ttk.Label(f, text="Dobierz nakrętki i podkładki: nad blachą, pod blachą i na końcu kotwy. Schemat pokazuje efekt.",
                  style="Sub.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        self.ze = ZoneEditor(f, self.app, lambda: getattr(self, "d", {}).get("dia") or num(self.v_dia.get()), self.schedule_draw)
        self.ze.grid(row=1, column=0, sticky="nsew")

    def enter3(self):
        if getattr(self, "tpl_zone", None) is not None and self.ze.count() == 0:
            self.ze.set_zone(self.tpl_zone)
        else:
            self.ze.refresh()

    def schedule_draw(self):
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(120, self.draw)

    def draw(self):
        """Rysunek na żywo (z pól kreatora, bez walidacji): potrzebuje typu, średnicy i choć jednej długości."""
        self._job = None
        cv = getattr(self, "cv", None)
        if cv is None:
            return
        W, H = max(cv.winfo_width(), 200), max(cv.winfo_height(), 200)

        def hint(text):
            from as_editor.ui.icons import placeholder
            placeholder(cv, "newanchor", T(text), W, H)
            self.v_shape.set("")
        try:
            tid, dia = self.type_id(), num(self.v_dia.get())
            if tid is None or not dia or dia <= 0:
                return hint("Wybierz typ kotwy i wpisz średnicę - tu zobaczysz kotwę.")
            try:
                lens = read_lengths(self.v_len.get())
            except ValueError:
                lens = []
            if not lens:
                return hint("Wpisz długość kotwy (krok 2) - tu zobaczysz kotwę.")
            P = {c: num(v.get()) for c, v in self.pvars.items()}
            zone = self.ze.zone if self.ze.count() else (getattr(self, "tpl_zone", None) or {"top": [], "below": [], "end": []})
            items = {z: resolve_items(self.db, zone[z], dia) for z in ("top", "below", "end")}
            L = max(lens)
            info = shape_draw(cv, tid, P, dia, L, items, plate=num(self.v_plate.get(), 0.0), grout=num(self.v_grout.get(), 0.0))
            warn = check_dims(tid, P, L)
            self.v_shape.set(info + ("  " + " ".join(warn) if warn else ""))
        except Exception as e:
            self.v_shape.set(T("Podgląd niedostępny: %s") % e)

    def leave3(self):
        if self.ze.count() == 0:
            return "Dodaj co najmniej jeden element zestawu."

    # ------------------------------------------------------------ krok 4
    def build4(self, f):
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        self.var_h4 = tk.StringVar()
        ttk.Label(f, textvariable=self.var_h4, style="Sub.TLabel", wraplength=960).grid(row=0, column=0, sticky="w", pady=(0, 8))
        fr, self.tr = make_tree(f, ("Długość", "Nr części", "Ciężar", "Status"), (90, 380, 90, 330), 11, sort=True, filt=True)
        fr.grid(row=1, column=0, sticky="nsew")
        status_tags(self.tr)
        self.chk_skip = ttk.Checkbutton(f, text="Zapisz bez brakujących elementów (pomiń je)", variable=self.v_skipmiss,
                                        command=self.enter4)
        self.chk_skip.grid(row=2, column=0, sticky="w", pady=(8, 0))
        self.var_e4 = tk.StringVar()
        ttk.Label(f, textvariable=self.var_e4, style="Err.TLabel", wraplength=960).grid(row=3, column=0, sticky="w")

    def build_defs(self, d):
        rows, l0 = [], d["lens"][0]
        for length in d["lens"]:
            r = dict(d["params"])
            r["Length"] = length
            r["Weight"] = anchor_weight(l0, d["w0"], d["dia"], length) if d["w0"] else anchor_weight(None, None, d["dia"], length)
            r["PartName"] = rename_part(None, l0, length, d["dia"], self.std_key())
            rows.append(r)
        return rows

    def enter4(self):
        d, std = self.d, self.std_key()
        items, miss = items_for(self.db, self.ze.zone, d["dia"])
        ex = self.db.anchor_exists(std, d["mat"], d["dia"], d["set"]) if self.mode.get() == "old" else None
        self.items, self.miss = items, miss
        code, err = "new", ""
        if ex:
            code, err = "skip", (T("Kotwa o tej średnicy, klasie i zestawie już istnieje w tej normie (ID %s, właściciel %s) - zmień zestaw/klasę/średnicę albo usuń ją w 'Moje wpisy' (lub cofnij ostatni zapis na stronie głównej).")
                                 % (ex[0], ex[1] or "-"))
        elif not items:
            code, err = "skip", T("Żaden element zestawu nie istnieje w bazie dla tej średnicy.")
        elif miss and not self.v_skipmiss.get():
            code, err = "skip", T("Brak w bazie elementów: %s. Wróć i je zamień albo zaznacz zapis bez nich.") % ", ".join(miss)
        defs = self.build_defs(d)
        self.tr.delete(*self.tr.get_children())
        for i, r in enumerate(defs):
            self.tr.insert("", "end", iid=str(i), tags=("ok" if code == "new" else "skip",),
                           values=(fmt_dia(r["Length"]), r["PartName"], r["Weight"], T("NOWA") if code == "new" else T("pominięto")))
        if miss or self.v_skipmiss.get():
            self.chk_skip.grid()
        else:
            self.chk_skip.grid_remove()
        self.plan = {"d": d, "defs": defs, "code": code}
        tn = {r[0]: r[1] for r in self.app.an_type_rows}
        self.var_h4.set(T("Nowa kotwa: %s, Ø%s, klasa %s, zestaw %s, norma %s%s. Elementów zestawu: %d.") % (
            tn.get(d["tid"], "?"), dia_text(d["dia"]), d["mat"], d["set"], std,
            T(" (NOWA norma)") if self.mode.get() == "new" else "", len(items)))
        self.var_e4.set(err)
        self.var_story.set(T("Powstanie 1 nowa kotwa: Ø%s, klasa %s, zestaw %s, norma %s - z %d długościami i zestawem z %d elementów. "
                             "Nic fabrycznego nie zostanie zmienione.") % (dia_text(d["dia"]), d["mat"], d["set"], std, len(defs), len(items)) if code == "new"
                           else T("Nic nie zostanie zapisane - zobacz komunikat poniżej."))

    def finish(self):
        if not self.app.need_db():
            return
        p = self.plan
        if not p or p["code"] != "new":
            messagebox.showinfo("Zapis", "Brak kotwy do zapisu (zobacz komunikat).")
            return
        d, defs, std, owner = p["d"], p["defs"], self.std_key(), p["d"]["owner"]
        dia, mat, set_name, src = d["dia"], d["mat"], d["set"], d["src"]
        new_std = self.mode.get() == "new"
        new_dia = not any(abs(dia - float(r[0])) < 1e-6 for r in self.app.an_dia_rows)
        new_src = src not in [r[0] for r in self.app.an_src_rows]
        new_set = set_name not in [x[0] for x in self.app.sets]
        new_cls = mat.lower() not in [r[0].lower() for r in self.app.cls_rows]
        msg = T("Zapisać kotwę Ø%s klasa %s zestaw %s (norma %s) z %d definicjami długości?") % (
            dia_text(dia), mat, set_name, std, len(defs))
        for flag, text in ((new_std, T("nową normę '%s'") % std), (new_dia, T("nową średnicę %s mm") % dia_text(dia)),
                           (new_src, T("nowe źródło '%s'") % src), (new_set, T("nowy zestaw '%s'") % set_name),
                           (new_cls, T("nową klasę '%s'") % mat)):
            if flag:
                msg += T("\nZostanie dodane: %s.") % text
        if not messagebox.askyesno("Potwierdź zapis", msg):
            return
        if not self.app.backup_before_write():
            return
        nid = self.db.max_id("AnchorsName") + 1
        did = self.db.max_id("AnchorsDefinition")
        hid = self.db.max_id("AnchorsHoleDefinition") + 1
        row_n = build_anchor_name_row(nid, std, d["tid"], mat, dia, src, set_name, owner, self.v_expl.get(), self.items)
        rows_d = []
        for vals in defs:
            did += 1
            rows_d.append(build_anchor_def_row(did, nid, vals, owner))

        def fn(cur):
            if new_std:
                cur.execute(*insert_sql("AnchorsStandard", {"Key": std[:64], "RunName": std[:64], "OwnerText": owner[:15]}))
            if new_dia:
                cur.execute(*insert_sql("BoltsDiameters", {"Key": dia, "RunName": "%g mm" % dia, "Description": None}))
            if new_src:
                cur.execute(*insert_sql("Sources", {"Short": src, "Long": src}))
            if new_set:
                cur.execute(*insert_sql("Sets", {"Key": set_name[:64], "RunName": set_name[:64], "OwnerText": owner[:15]}))
            if new_cls:
                cur.execute(*insert_sql("StrengthClass", {"Key": mat[:64], "RunName": mat[:64], "OwnerText": owner[:15]}))
            cur.execute(*insert_sql("AnchorsName", row_n))
            for r in rows_d:
                cur.execute(*insert_sql("AnchorsDefinition", r))
            cur.execute(*insert_sql("AnchorsHoleDefinition", empty_hole_row(hid, nid)))
        if self.app.write_or_report(fn, label=T("Nowa kotwa: %s Ø%s") % (std, dia_text(dia))):
            remember("owner", owner)
            remember("last_anchor_std", std)
            self.app.an_last_std = std
            self.app.reload()
            self.app.refresh_anchor_tabs()
            messagebox.showinfo("Gotowe", T("Zapisano kotwę Ø%s z %d długościami. Odśwież dane w Advance Steel (przycisk "
                                            "'Update defaults') albo uruchom go ponownie.") % (dia_text(dia), len(defs)))
            self.destroy()
