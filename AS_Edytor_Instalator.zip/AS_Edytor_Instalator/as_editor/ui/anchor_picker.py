# -*- coding: utf-8 -*-
"""Wybierak kotwy dla trzech zadań z ekranu 'Kotwy': nowe wymiary do istniejącej kotwy (dims), nowa kotwa (new),
nowa kotwa na podstawie istniejącej (copy). Potem otwiera sprawdzone okna: AddLengthsDialog / SingleAnchorDialog / AnchorDialog."""
from as_editor.common import dia_text, fmt_dia, is_own
from as_editor.config import recall, remember
from as_editor.i18n import T
from as_editor.ui.add_lengths import AddLengthsDialog
from as_editor.ui.anchor_dialog import AnchorDialog
from as_editor.ui.single_anchor import SingleAnchorDialog
from as_editor.ui.widgets import fit_window, make_filterable, make_tree, messagebox, selected_index, set_choices, tk, ttk

TITLES = {"dims": "Nowa średnica, klasa lub kopia kotwy", "new": "Nowa kotwa", "copy": "Nowa kotwa z istniejącej"}
HINTS = {"dims": "Wybierz normę i kotwę-wzorzec, potem: dodaj długości, nową średnicę, nową klasę albo utwórz jej kopię jako nową kotwę.",
         "new": "Wybierz istniejącą normę kotwy, do której dodasz nową kotwę, albo załóż całkiem nową normę.",
         "copy": "Wybierz kotwę-wzorzec. Nowa kotwa dostanie jej wymiary i zestaw, a Ty zmienisz to, co trzeba."}


class AnchorPickerDialog(tk.Toplevel):
    def __init__(self, app, purpose):
        super().__init__(app.root)
        self.app, self.db, self.purpose = app, app.db, purpose
        self.title(T(TITLES[purpose]))
        self.transient(app.root)
        fit_window(self, 1020, 640 if purpose != "new" else 360, 820, 320)
        self.std_rows, self.anchors = [], []
        ttk.Label(self, text=T(TITLES[purpose]), style="CardTitle.TLabel").pack(anchor="w", padx=24, pady=(18, 0))
        ttk.Label(self, text=T(HINTS[purpose]), style="Sub.TLabel", wraplength=900).pack(anchor="w", padx=24, pady=(2, 12))
        top = ttk.Frame(self)
        top.pack(fill="x", padx=24)
        if purpose != "new":
            ttk.Label(top, text="Typ kotwy").pack(side="left")
            self.cb_type = ttk.Combobox(top, state="readonly", width=18,
                                        values=[T("Wszystkie typy")] + ["%s" % r[1] for r in app.an_type_rows])
            self.cb_type.current(0)
            self.cb_type.pack(side="left", padx=(6, 18))
            self.cb_type.bind("<<ComboboxSelected>>", lambda e: self.on_type())
        else:
            self.cb_type = None
        ttk.Label(top, text="Norma kotwy (wpisz np. Hilti)").pack(side="left")
        self.cb_std = make_filterable(ttk.Combobox(top, width=44))
        self.cb_std.pack(side="left", padx=6)
        self.cb_std.bind("<<ComboboxSelected>>", lambda e: self.on_std())
        if purpose != "new":
            self.var_info = tk.StringVar()
            ttk.Label(self, textvariable=self.var_info, style="Hint.TLabel").pack(anchor="w", padx=24, pady=(10, 2))
            fr, self.tr = make_tree(self, ("Typ", "Klasa", "Ø", "Zestaw", "Źródło", "Długości", "Zakres [mm]", "Właściciel"),
                                    (120, 90, 60, 200, 120, 80, 120, 90), 12, "browse", sort=True, filt=True)
            fr.pack(fill="both", expand=True, padx=24, pady=(0, 6))
            self.tr.tag_configure("own", background="#e6f4e6")
            self.tr.bind("<<TreeviewSelect>>", lambda e: self.update_buttons())
        bar = ttk.Frame(self)
        bar.pack(side="bottom", fill="x", padx=24, pady=14)
        ttk.Button(bar, text=T("Zamknij"), command=self.destroy).pack(side="right")
        self.buttons = []
        if purpose == "dims":
            for txt, cmd in (("+ Długości", lambda: self.act("length")), ("+ Średnica", lambda: self.act("dia")),
                             ("+ Klasa", lambda: self.act("class")), ("Kopia kotwy", lambda: self.act("copy"))):
                self.buttons.append(ttk.Button(bar, text=T(txt), style="Accent.TButton", command=cmd))
        elif purpose == "copy":
            self.buttons.append(ttk.Button(bar, text=T("Utwórz nową kotwę na podstawie wybranej") + "  →",
                                           style="Accent.TButton", command=lambda: self.act("copy")))
        else:
            self.buttons.append(ttk.Button(bar, text=T("Dodaj kotwę do wybranej normy") + "  →",
                                           style="Accent.TButton", command=lambda: self.act("scratch")))
            self.buttons.append(ttk.Button(bar, text=T("Utwórz nową normę kotwy..."), command=self.new_standard))
        for b in self.buttons:
            b.pack(side="left", padx=(0, 10))
        self.var_err = tk.StringVar()
        ttk.Label(self, textvariable=self.var_err, style="Err.TLabel").pack(side="bottom", anchor="w", padx=24)
        self.fill_stds(recall("last_anchor_std"))
        self.update_buttons()
        self.focus_set()

    # ------------------------------------------------------------ listy
    def type_id(self):
        i = self.cb_type.current() if self.cb_type else 0
        return self.app.an_type_rows[i - 1][0] if 1 <= i <= len(self.app.an_type_rows) else None

    def fill_stds(self, want=None):
        keep = want or (self.cur_std()[0] if self.cur_std() else None)
        tid = self.type_id()
        self.std_rows = [r for r in self.app.an_std_rows if tid is None or tid in self.app.an_std_types.get(r[0], ())]
        set_choices(self.cb_std, ["%s   |   %s%s" % (r[0], r[1], "   [MOJA]" if is_own(r[2]) else "") for r in self.std_rows])
        self.cb_std.set("")
        for i, r in enumerate(self.std_rows):
            if r[0] == keep:
                self.cb_std.current(i)
                self.cb_std._last = i
                break
        self.refresh()

    def cur_std(self):
        i = selected_index(self.cb_std)
        return self.std_rows[i] if 0 <= i < len(self.std_rows) else None

    def on_type(self):
        self.fill_stds()

    def on_std(self):
        r = self.cur_std()
        if r:
            remember("last_anchor_std", r[0])
        self.refresh()

    def refresh(self):
        if self.purpose == "new":
            self.update_buttons()
            return
        t = self.tr
        prev = self.selected()
        prev_id = prev[0] if prev else None
        t.delete(*t.get_children())
        self.anchors = []
        r = self.cur_std()
        if not r:
            self.var_info.set(T("Wybierz normę kotwy."))
            self.update_buttons()
            return
        tid = self.type_id()
        rows, cols = self.db.query(
            "SELECT n.[ID], n.[ClassID], n.[MaterialKey], n.[Diameter], n.[SetName], n.[Source], n.[OwnerText], "
            "(SELECT COUNT(*) FROM [AnchorsDefinition] d WHERE d.[AnchorID]=n.[ID]) AS defs, "
            "(SELECT MIN(d.[Length]) FROM [AnchorsDefinition] d WHERE d.[AnchorID]=n.[ID]) AS lmin, "
            "(SELECT MAX(d.[Length]) FROM [AnchorsDefinition] d WHERE d.[AnchorID]=n.[ID]) AS lmax FROM [AnchorsName] n "
            "WHERE n.[Standard]=?" + (" AND n.[ClassID]=?" if tid is not None else "") +
            " ORDER BY n.[Diameter], n.[MaterialKey], n.[SetName]", (r[0],) + ((tid,) if tid is not None else ()))
        names = {x[0]: x[1] for x in self.app.an_type_rows}
        for i, x in enumerate(rows):
            self.anchors.append(x)
            t.insert("", "end", iid=str(i), tags=("own",) if is_own(x[6]) else (), values=(
                names.get(x[1], "?"), x[2], dia_text(float(x[3])), x[4], x[5], x[7],
                "%s - %s" % (fmt_dia(float(x[8])), fmt_dia(float(x[9]))) if x[8] is not None else "", x[6] or ""))
        self.var_info.set(T("Kotwy w normie: %d. Zaznacz jedną.") % len(rows))
        for i, x in enumerate(rows):                       # zaznaczenie zostaje po odświeżeniu (np. po dopisaniu długości)
            if x[0] == prev_id:
                t.selection_set(str(i))
                break
        self.update_buttons()

    def selected(self):
        sel = self.tr.selection() if self.purpose != "new" else ()
        return self.anchors[int(sel[0])] if sel and int(sel[0]) < len(self.anchors) else None

    def update_buttons(self):
        ok = bool(self.cur_std()) if self.purpose == "new" else bool(self.selected())
        for b in self.buttons:
            if b is self.buttons[-1] and self.purpose == "new":
                continue                                   # 'nowa norma' zawsze dostępna
            b.state(["!disabled"] if ok else ["disabled"])

    # ------------------------------------------------------------ akcje
    def act(self, kind):
        r, a = self.cur_std(), self.selected()
        if kind == "scratch":
            if not r:
                self.var_err.set(T("Najpierw wybierz normę kotwy."))
                return
            if not self.db.anchor_names(r[0]):
                self.var_err.set(T("Ta norma nie ma jeszcze żadnej kotwy - użyj 'Utwórz nową normę kotwy...'."))
                return
            SingleAnchorDialog(self.app, r[0], template_id=None)
        elif not (r and a):
            self.var_err.set(T("Zaznacz na liście kotwę."))
            return
        elif kind == "length":
            AddLengthsDialog(self.app, r[0], a[0])
        elif kind in ("dia", "class"):
            SingleAnchorDialog(self.app, r[0], template_id=a[0], mode=kind)
        else:
            SingleAnchorDialog(self.app, r[0], template_id=a[0])
        self.var_err.set("")
        self.app.refresh_anchor_tabs()
        self.refresh()

    def new_standard(self):
        AnchorDialog(self.app)
        self.app.refresh_anchor_tabs()
        self.fill_stds()
