# Projekt: edytor śrub i kotew Advance Steel (zewnętrzny, w stylu Tekla)

## Cel
Zewnętrzny program (Windows), który edytuje katalogi śrub i kotew w bazie Advance Steel (SQL Server LocalDB,
`AstorBase`) wygodniej niż Management Tools: widok zestawu jak w Tekli, kopie norm, nowe klasy (5.6, A4...),
nowe podkładki/nakrętki z typowymi wymiarami, kotwy. Język interfejsu i komunikatów: polski.

## Stan
- Prototyp: pakiet `as_editor/` (Python, tkinter, pyodbc; ok. 5000 linii w 26 modułach) + mały punkt startowy
  `advance_steel_bolt_editor.py`. Mapa modułów i "co gdzie zmienić": `MODULY.md` - czytaj ją przed edycją.
- Test end-to-end zrobiony przez użytkownika: zestaw śrub zapisany edytorem był widoczny w Advance Steel i dało się go użyć.
- GUI da się uruchomić w piaskownicy: `uv python install 3.12` (ma tkinter) + `xvfb-run`, zrzut przez `import -window root`;
  bez prawdziwej bazy - testy na atrapie `DB`. Brakujące polskie znaki na zrzutach to czcionka Xvfb, nie błąd.
- (historia) GUI początkowo nie było uruchamiane przez Claude (brak tkintera). Sprawdzano tylko logikę
  funkcji czystych i statycznie atrybuty `self.*`. Pierwsze zadanie w Claude Code: uruchomić program, przejść
  zakładki, zrobić zrzuty, poprawić błędy układu i wyjątki.
- Zakładka „Kotwy" jest świeża i nietestowana na prawdziwej bazie (poza porównaniem struktury wierszy z tym,
  co zapisał Management Tools).

## Środowisko użytkownika
- Windows, Advance Steel 2026, wersja krajowa **INT**, instancja `(LocalDB)\AdvanceSteel2026`.
- Nazwa bazy w `sys.databases` to pełna ścieżka MDF wielkimi literami, np.
  `C:\PROGRAMDATA\AUTODESK\ADVANCE STEEL 2026\INT\STEEL\DATA\ASTORBASE.MDF` (nie `AstorBase`!). Program wyszukuje ją
  przez `sys.master_files` + `sys.databases` (`DB._astorbases`).
- Połączenie: ODBC Driver 17/18, `Trusted_Connection=yes;TrustServerCertificate=yes;Encrypt=no;`.
- Bazy mogą być podłączone dla kilku wersji krajowych (INT, GBR, POL, DEU) - edytor pracuje na jednej (domyślnie INT).
- Management Tools tłumaczy nazwy w oknie (np. AnchorsClass po polsku), dane w bazie są angielskie.

## Struktura bazy (zweryfikowana zrzutami schematu i porównaniami przed/po)
Śruby:
- `Standard(Key, RunName, AutoLengthCalc, StandardSet, OwnerText)` - normy śrub.
- `SetBolts` PK(Diameter, Length, Material, Standard): ScrewHeadOuterDiameter, HeadHeight, NumberOfCorners, Name, Weight, OwnerText, Source, Type.
- `SetNutsBolts` PK(Diameter, Material, Standard): Height, NumberOfCorners (0 = podkładka), OutsideDiameter, Name, Weight, ItemNumber, OwnerText, Source, Type.
- `StandardNuts(ID, RunName, OwnerText)`, `Sets(Key, RunName, OwnerText)`, `StrengthClass(Key, RunName, OwnerText)` (słownik klas),
  `BoltsDiameters(Key float, RunName, Description)`, `BoltsCoating`, `Sources(PK Short, Long)`.
- `SetOfBolts` PK(Diameter, Material, Set, Standard): BindingLength, Explodeable, OwnerText, Source, Length (= liczba elementów),
  DIN1..6, **`Diameter1 (mm)`..6** (kolumny ze spacją i nawiasem - zawsze cytować `[...]`), Material1..6, Position1..6.
  Position: +1,+2.. strona łba (od blachy na zewnątrz), -1,-2.. strona nakrętki. Puste pozycje: DIN `-`, średnica 0.0, klasa `-`, pozycja 0.
- Brak tabeli AutoLength. Reguły długości z zakładki Parameters (Management Tools) zapisują się gdzieś indziej - tabele `Screw`, `ScrewNew`,
  `Tools`, baza `AstorRules` nie były jeszcze przeglądane. (Do zbadania metodą przed/po.)

Kotwy:
- `AnchorsStandard(Key, RunName, OwnerText)`; `AnchorsClass(ID, RunName)`: 0 Normal, 1 Headed (młoteczkowe), 2 Threaded, 3 Hooked (L), 4 J.
- `AnchorsName` PK(ID): Standard, ClassID, MaterialKey, Explodable, Source (max 15), Diameter, SetName, OwnerText, NumItems,
  DIN1..6, Diameter1..6, Material1..6, Position1..6 (te same wzorce co zestaw śruby; kolumny bez "(mm)").
- `AnchorsDefinition` PK(ID), AnchorID -> AnchorsName.ID: Length, ThreadLength, TopDistance, DistanceF/E/A/O/C, BottomDistance,
  HeadHeight, HeadDiameter, NumberOfHeadEdges, HookRadius, PartName (max 64), Weight, OwnerText.
- `AnchorsHoleDefinition` PK(AnchorNameID), ID: Location, HoleType, HoleTolerance, Depth, Angle, HeadDiameter.
  Management Tools zakłada pusty wiersz otworu (same NULL) dla każdej nowej kotwy.
- Kolumny tabeli definicji zależą od typu (zrzuty Management Tools, wszystkie 5 typów potwierdzone 2026-10):
  0 Zwykłe (Fischer FAZ) i 1 Młoteczkowe - Length, ThreadLength, TopDistance, Head height/diameter, No. Head Edges;
  2 Gwintowane - dodatkowo BottomDistance; 3 Fajkowe L - F, E, A, O + Hook radius; 4 J - dodatkowo C.
- **Znaczenie wymiarów** (opis użytkownika do zrzutów, 2026-10; pełny opis w `ui/anchor_shape.py` i `ANCHOR_TIPS`):
  - `Length` - długość całkowita (dla haków do spodu haka); `ThreadLength` - gwint liczony OD CZUBKA w dół;
  - `TopDistance` - ile kotwy wystaje ponad płaszczyznę przyłożenia (górną powierzchnię blachy);
  - `BottomDistance` - mierzona OD DOŁU kotwy w górę (typ 2; od niej idzie w górę zestaw "koniec kotwy");
  - `HeadHeight` - główka na DOLNYM końcu kotwy; `HeadDiameter` - okrąg OPISANY na główce, `NumberOfHeadEdges` -
    liczba boków wieloboku wpisanego w ten okrąg (6 = sześciokąt). Główkę rysujemy TYLKO dla typu 1 (Młoteczkowe) -
    typ 0 (Zwykła) główki nie ma, choć Management Tools pokazuje te kolumny (a wpisy fabryczne bywają wypełnione);
  - hak: `DistanceF` - wysokość ukosu, `DistanceE` - wysokość prostego odcinka pod ukosem, `DistanceO` - przesunięcie
    poziome ukosu, `DistanceA` - szerokość haka od zewnętrznej krawędzi dolnego odcinka do końca ramienia,
    `DistanceC` - wysokość powrotu (typ J), `HookRadius` - promień gięcia. Reguła: F + E <= Length - ThreadLength.
  - Grubość blachy i podlewka NIE są w bazie - to tylko pola podglądu (domyślnie 12 mm / 0 mm);
    zakotwienie = Length - TopDistance - blacha - podlewka.
- Strefy zestawu kotwy: +1.. nad blachą, -1.. pod blachą, -101.. koniec kotwy. **W każdej strefie wiersz 1 (pozycja
  o numerze 1) jest NAJDALEJ od blachy, a ostatni wiersz przylega do blachy** (zrzut zakładki Set: zestaw NaW =
  nakrętka/1 nad podkładką/2 leżącą na blasze; wpisy fabryczne bywają niespójne - `934/1 7089/2` i `934/2 125/1`).
  Strefa "koniec kotwy" układa się w górę od punktu odniesienia: `BottomDistance` (typ 2) albo góra główki (typ 1).
- Nowe `ID` = MAX(ID)+1 (potwierdzone dla AnchorsName, AnchorsDefinition, AnchorsHoleDefinition).
- Nowa kotwa w Management Tools zapisała: AnchorsName, AnchorsDefinition, pusty AnchorsHoleDefinition, AnchorsStandard
  (Key = RunName = nazwa), Sets (Key = RunName), Sources (Short, Long), StrengthClass - wpisy użytkownika mają OwnerText `PL1`.
- W bazie **nie ma** kluczy obcych, ograniczeń CHECK ani wyzwalaczy - spójność pilnuje tylko aplikacja.

Właściciele wpisów: fabryczne `DSC` (Management Tools bywa pokazuje AUTODESK); własne: `MOJA` (domyślny w edytorze), `PL1`
(Management Tools), sporadycznie `-`. Funkcja `is_own()` = wszystko poza DSC/AUTODESK.

## Zasady bezpieczeństwa (obowiązkowe)
1. Nigdy nie modyfikować ani nie usuwać wierszy fabrycznych (OwnerText DSC/AUTODESK). Wyjątek za zgodą użytkownika: do kotwy
   fabrycznej wolno DOPISAĆ nowe wiersze `AnchorsDefinition` z własnym właścicielem (`AddLengthsDialog`); istniejących nie zmieniamy,
   a własne dopisane długości można usunąć (`ls_delete_defs`, tylko wiersze nie-DSC).
2. Przed pierwszym zapisem w sesji `BACKUP DATABASE` do `backups/` (`DB.ensure_backup`); zapisy tylko przez `DB.write()` (transakcja + rollback).
3. Testy zapisu wykonywać na **kopii bazy w osobnej instancji LocalDB**, nie na produkcyjnym `AdvanceSteel2026`
   (np. `sqllocaldb create TestAS`, dołączyć skopiowane pliki MDF/LDF). Produkcyjną bazę tylko czytać.
4. Przed każdą zmianą zapisu w nowej tabeli zrobić migawkę przed/po (`as_anchor_probe.py snapshot/diff`) i porównać z tym,
   co zapisuje Management Tools.
5. Zmiany w Advance Steel widać po `Update defaults` albo po restarcie (niesprawdzone dla naszych wpisów).

## Układ okna i architektura GUI
- Trzy główne zakładki: **Kotwy** (konfigurator kotew, pierwsza), **Zestawy śrub** (widok Tekla) i **Narzędzia** (Nowa
  podkładka/nakrętka, Normy i klasy śrub, Kopia normy, Kopiuj kotwy/dodaj klasę, Usuń moje kotwy, dwie przeglądarki tabel).
  Przejście do podzakładki Narzędzi: `App.open_tool(frame)`. Ostatnia norma kotwy/śruby i właściciel: `config.remember/recall`.
- Konfigurator kotew = lista kotew wybranej normy + podgląd długości/wymiarów; przyciski otwierają okno `AnchorDialog`
  (dodanie wymiaru z kotwy-wzorca, edycja własnej kotwy, nowa norma). Okno zawiera pełny edytor: parametry, tabelę
  długości z kolumnami zależnymi od typu, zestaw w strefach i schemat.
- Schemat kotwy (kształt z wymiarami, blacha, podlewka, nakrętki i podkładki z bazy) rysuje wspólny
  `ui/anchor_shape.py` - używają go oba okna kotew. Wzorzec w `SingleAnchorDialog` można wziąć z innej normy.
- Schemat zawsze pokazuje JEDNĄ długość: w `AnchorDialog` wiersz zaznaczony w tabeli wymiarów (`an_show_defs`
  zachowuje zaznaczenie i zaznacza nowo dodane wiersze), w `SingleAnchorDialog` wiersz zaznaczony w podglądzie
  zapisu (podgląd odświeża się sam przy każdej zmianie: `preview(silent=True)` w `draw`).
- Listy norm (śruby: `cb_std`, kotwy: `cb_lsstd`) filtrują się po wpisaniu tekstu (np. 'hilti'; kilka słów = wszystkie muszą
  wystąpić, Enter wybiera pierwszą pasującą): `widgets.make_filterable/set_choices/selected_index`. Wartości ustawiaj przez
  `set_choices`, a wybór czytaj przez `selected_index` (NIE `current()` - liczy indeks w liście zawężonej).
- Filtr typu kotwy (Normal/Headed/Threaded/Hooked/J) w Konfiguratorze: `cb_lstype`; zawęża listę norm (`ls_fill_stds`, `DB.anchor_std_types`) i
  kotwy normy; w `SingleAnchorDialog` filtr typu na liście wzorców (`cb_ttype`, `tpl_shown`).
- "+ Długość" otwiera osobne, uproszczone okno `ui/add_lengths.py` (`AddLengthsDialog`): tylko nowe długości, wymiary (domyślnie z
  wybranej istniejącej długości), ciężar/nr części, schemat; typ/Ø/klasa/zestaw są nieedytowalne. Zapisuje WYŁĄCZNIE nowe wiersze
  `AnchorsDefinition` (także dla kotwy fabrycznej). Dawny `SingleAnchorDialog(mode='length')` jest już nieużywany przez GUI.
- Szybkie akcje w Konfiguratorze kotew (`ls_quick`, wzorzec = zaznaczona kotwa): "+ Długość" -> `AddLengthsDialog`;
  "+ Średnica" / "+ Klasa" -> `SingleAnchorDialog(mode='dia'|'class')` (nowa kotwa na wzorcu). W `SingleAnchorDialog` brakujące
  w bazie elementy zestawu są na czerwono ("(brak)"), przycisk "Zamień..." podmienia element, opcja "Zapisz bez brakujących
  elementów" pozwala zapisać resztę.
- `SingleAnchorDialog` (przycisk "Dodaj kotwę do normy..."): prosty formularz jednej kotwy w istniejącej normie
  (typ, Ø, klasa, zestaw, źródło, wymiary wg typu, długości, ciężar, skład); samodzielna klasa, nie używa metod `an_*`.
  Ciężar bez wpisu = skalowany ze wzorca (~d^2), nr części = automatyczny.
- Edytor kotwy to `AnchorEditorMixin` (`ui/anchor_editor.py`, metody `an_*`), używany przez `AnchorDialog`; brakujące
  atrybuty okno bierze z aplikacji przez `__getattr__`. `App` nie wywołuje metod `an_*`.
- Zakładki to mixiny w `tabs/`, `App` w `app.py` łączy je dziedziczeniem.
- `TableBrowser` - osobna instancja przeglądarki tabel dla Śrub i Kotew; po zapisach `App.reload_browsers()`.

## Tłumaczenia (PL / EN)
- Język przełącza przycisk w oknie (`App.switch_language` odbudowuje interfejs przez `build_ui`); wybór zapisuje `bolt_editor_settings.json`.
- Mechanizm: `T(tekst)` + słownik `EN` (klucz = polski tekst dokładnie jak w kodzie, wartość = angielski). Teksty z `%s`/`%d` dopasowywane
  są jako szablony, komunikaty wielowierszowe tłumaczone wiersz po wierszu. Brak wpisu = tekst zostaje po polsku.
- `install_translation_hooks()` (wywoływane w `main`) podpina `T()` pod tworzenie widżetów ttk (`text=`), nagłówki Treeview, zakładki,
  `StringVar.set`, napisy na Canvas, tytuły okien i komunikaty (`messagebox`, `simpledialog.askstring`). Dlatego zwykle wystarczy
  dopisać polski tekst w kodzie i jego tłumaczenie do `EN`.
- **Jawne `T()` potrzebne** tam, gdzie tekst trafia poza te punkty: wartości w `Treeview.insert`, `Combobox`, słowniki nazw wyświetlanych,
  teksty składane z fragmentów (`T("...%s") % x`, nie `"..." + x`). Wartości-sentinele zależne od języka to właściwości (`ALL_CLASSES`, `ALL_AK`).
- Kontrola pokrycia: `python advance_steel_bolt_editor.py --check-i18n` wypisuje teksty z polskimi znakami bez tłumaczenia.
  Po dodaniu nowych tekstów uruchom ją i uzupełnij `EN` (zachowaj te same znaczniki `%s`/`%d` w tej samej kolejności).
- Angielskie tłumaczenia wykonano bez weryfikacji przez osobę techniczną - warto je przejrzeć.

## Pliki
- `advance_steel_bolt_editor.py` - mały punkt startowy; kod jest w pakiecie `as_editor/` (mapa: `MODULY.md`).
- `as_editor/` - moduły: `config`, `i18n`/`i18n_en`, `common`, `bolts_logic`, `anchors_logic`, `db`, `app`, `main`,
  `ui/` (okna, widżety, przeglądarka tabel, edytor kotwy), `tabs/` (zakładki jako mixiny).
- `tests/` - `smoke_gui.py` (przejście przez wszystkie zakładki + zmiana języka), `test_single_anchor.py`
  (okno "Dodaj kotwę" na atrapie bazy), `test_anchor_dialog.py` (pełne okno kotwy: strefy zestawu i schemat), `test_builder.py` (zestaw śrub: podsumowanie podglądu, zamiana elementu), `test_remember.py` (ustawienia, wklejanie do pola), `test_add_lengths.py` (okno "+ Długość").
  Wklejanie z Excela w tabeli wymiarów: `AnchorEditorMixin.an_paste`; edycja w komórce: `widgets.edit_cell`.
- `uruchom_edytor_srub.bat` - doinstalowuje Pythona/pyodbc/sterownik ODBC i uruchamia program.
- `as_schema_dump.py` + `uruchom_zrzut_as.bat` - zrzut schematu i przykładowych wierszy (tylko odczyt).
- `as_anchor_probe.py` + `uruchom_sondaz_kotew.bat` - sondaż kotew oraz tryby `snapshot NAZWA` i `diff NAZWA` (porównanie zmian w całej bazie).
- `README_instrukcja.txt` (PL) i `README_EN.txt` (EN) - instrukcja testowa dla kolegów; zmieniaj obie razem.

## Testowanie
- Funkcje czyste: import z `as_editor.bolts_logic`, `as_editor.anchors_logic`, `as_editor.common` i test funkcji (`positions_for`,
  `build_set_row`, `clone_sql`, `parse_lengths`, `bolt_weight`, `remap_set_row`, `anchor_*`, `plan_anchor_copy`).
- GUI: `xvfb-run -a python tests/smoke_gui.py`, `tests/test_single_anchor.py`, `tests/test_anchor_dialog.py`
  (w piaskownicy: `uv python install 3.12`).
- Tłumaczenia: `python advance_steel_bolt_editor.py --check-i18n` (ma wypisać 0 braków).
- Na prawdziwej (skopiowanej) bazie: zapis przez edytor -> `diff` -> porównanie z tym, co zapisuje Management Tools -> sprawdzenie
  w Management Tools i w modelu Advance Steel.

## Konwencje
- Biblioteka standardowa + `pyodbc`; interfejs tkinter/ttk; komunikaty po polsku.
- Pliki `.bat`: tylko ASCII i końce linii CRLF; `README_instrukcja.txt` i `README_EN.txt`: UTF-8 z BOM i CRLF.
- Każdy zapis do bazy: walidacja, podgląd/status, potwierdzenie, kopia zapasowa, transakcja.

## Znane braki i pomysły
- Testy automatyczne na kopii bazy; dalszy podział dużych plików (`tabs/builder.py`, `ui/anchor_editor.py`).
- Reguły długości śrub (tabele `Screw`, `ScrewNew`, `Tools`, `AstorRules`) - zbadać metodą przed/po.
- `Tools`, zakładka Holes śrub, `MapInternToExtern` (AstorAddIn) - nieobsłużone.
- Eksport/import własnych wpisów (MOJA/PL1) do pliku, żeby przetrwały aktualizację Advance Steel.
- Edycja wymiarów łba przy kopiowaniu śrub; ewentualny panel w modelu przez API .NET Advance Steel (niezweryfikowane).
- Wpisy dodane przy okazji (Sources, Sets, StrengthClass) zostają po usunięciu kotwy; przeglądarka tabel nie usuwa z tabel bez OwnerText (Sources).
