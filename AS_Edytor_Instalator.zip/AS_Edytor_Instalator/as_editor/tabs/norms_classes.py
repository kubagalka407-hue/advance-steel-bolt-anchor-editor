# -*- coding: utf-8 -*-
"""Zakładka Śruby -> Normy i klasy: słownik klas."""
from as_editor.common import insert_sql, is_own
from as_editor.config import DEFAULT_OWNER
from as_editor.ui.widgets import make_tree, messagebox, tk, ttk


class NormsClassesMixin:
    # ------------------------------------------------------------------ normy i klasy
    def build_norms(self):
        nb2 = ttk.Notebook(self.tab_norms)
        nb2.pack(fill="both", expand=True, padx=4, pady=4)
        self.sub_cls, self.sub_new, self.sub_add, self.sub_del = (ttk.Frame(nb2) for _ in range(4))
        nb2.add(self.sub_cls, text="1. Słownik klas (5.6, A4...)")
        nb2.add(self.sub_new, text="2. Nowa norma śruby")
        nb2.add(self.sub_add, text="3. Dodaj klasę do normy")
        nb2.add(self.sub_del, text="4. Usuń moje wpisy")
        self.std_vals, self.cls_rows = [], []
        self.nb_rows, self.ac_pairs, self.ac_map, self.ac_dias = [], [], {}, []
        self.build_cls_dict()
        self.build_new_norm()
        self.build_add_class()
        self.build_del_own()

    def refresh_norm_tabs(self):
        for cb in (self.cb_nbstd, self.cb_acstd, self.cb_dlstd):
            cb["values"] = self.std_vals
        self.cb_nbset["values"] = [x[0] for x in self.sets]
        self.cls_refresh()

    # --- 1. słownik klas ---
    def build_cls_dict(self):
        f = self.sub_cls
        ttk.Label(f, text="Klasa to wpis w słowniku klas (kod używany w bazie i nazwa pokazywana na liście). Przykłady: 5.6 "
                          "(kod 5.6), A4-70 (kod A4-70). Uwaga: w bazie jest już klasa 1.4401 o nazwie A4. "
                          "Sprawdź filtrem, czy potrzebnej klasy już nie ma.",
                  wraplength=1000, foreground="#444").pack(anchor="w", padx=8, pady=6)
        bar = ttk.Frame(f)
        bar.pack(fill="x", padx=8, pady=4)
        self.v_ckey, self.v_crun = tk.StringVar(), tk.StringVar()
        self.v_cown = tk.StringVar(value=DEFAULT_OWNER)
        self.v_cfilter = tk.StringVar()
        for lab, var, w in (("Kod klasy:", self.v_ckey, 18), ("Nazwa na liście:", self.v_crun, 18), ("Właściciel:", self.v_cown, 10)):
            ttk.Label(bar, text=lab).pack(side="left", padx=(8, 2))
            ttk.Entry(bar, textvariable=var, width=w).pack(side="left")
        ttk.Button(bar, text="Dodaj klasę do słownika", command=self.cls_add).pack(side="left", padx=10)
        ttk.Button(bar, text="Usuń zaznaczoną (moją)", command=self.cls_delete).pack(side="left", padx=4)
        ttk.Label(bar, text="Filtr:").pack(side="left", padx=(20, 2))
        self.v_cfilter.trace_add("write", lambda *a: self.cls_fill())
        ttk.Entry(bar, textvariable=self.v_cfilter, width=20).pack(side="left")
        fr, self.tr_cls = make_tree(f, ("Key", "RunName", "OwnerText"), (220, 280, 120), 20, "browse")
        fr.pack(fill="both", expand=True, padx=8, pady=6)

    def cls_refresh(self):
        self.cls_rows = self.db.classes() if self.db.conn else []
        self.cls_fill()
        disp = ["%s   |   %s" % (r[0], r[1] or r[0]) for r in self.cls_rows]
        self.lb_nbcls.delete(0, "end")
        for d in disp:
            self.lb_nbcls.insert("end", d)
        self.cb_accls["values"] = disp
        self.cb_accls.set("")

    def cls_fill(self):
        t = self.tr_cls
        t.delete(*t.get_children())
        qs = self.v_cfilter.get().lower()
        for i, r in enumerate(self.cls_rows):
            if qs and not any(qs in str(v).lower() for v in r):
                continue
            t.insert("", "end", iid=str(i), values=["" if v is None else v for v in r])

    def cls_add(self):
        if not self.need_db():
            return
        key, run, owner = self.v_ckey.get().strip(), self.v_crun.get().strip(), self.v_cown.get().strip()
        errs = []
        if not key or len(key) > 64:
            errs.append("Kod klasy: wymagany, max 64 znaki.")
        if key.lower() in [r[0].lower() for r in self.cls_rows]:
            errs.append("Klasa '%s' już istnieje w słowniku." % key)
        if not owner or len(owner) > 15 or not is_own(owner):
            errs.append("Właściciel: 1-15 znaków, nie DSC/AUTODESK.")
        if errs:
            messagebox.showwarning("Uzupełnij dane", "\n".join(errs))
            return
        if not self.backup_before_write():
            return

        def fn(cur):
            sql, p = insert_sql("StrengthClass", {"Key": key, "RunName": (run or key)[:64], "OwnerText": owner})
            cur.execute(sql, p)
        if self.write_or_report(fn):
            self.v_ckey.set("")
            self.v_crun.set("")
            self.cls_refresh()
            messagebox.showinfo("Gotowe", "Dodano klasę '%s'. Przypiszesz ją do normy w zakładce 3 albo użyjesz "
                                          "przy tworzeniu nowej normy (zakładka 2)." % key)

    def cls_delete(self):
        sel = self.tr_cls.selection()
        if not self.need_db() or not sel:
            return
        r = self.cls_rows[int(sel[0])]
        if not is_own(r[2]):
            messagebox.showinfo("Usuń", "To klasa fabryczna - program jej nie usuwa.")
            return
        used = sum(self.db.count(t, "[Material]=?", (r[0],)) for t in ("SetBolts", "SetOfBolts", "SetNutsBolts"))
        if used:
            messagebox.showinfo("Usuń", "Klasa jest używana w %d wierszach. Najpierw usuń je w zakładce 4." % used)
            return
        if not messagebox.askyesno("Potwierdź", "Usunąć klasę '%s' ze słownika?" % r[0]):
            return
        if not self.backup_before_write():
            return
        if self.write_or_report(lambda cur: cur.execute("DELETE FROM [StrengthClass] WHERE [Key]=?", (r[0],))):
            self.cls_refresh()
