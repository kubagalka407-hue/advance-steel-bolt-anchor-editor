# -*- coding: utf-8 -*-
"""Zakładka Kotwy: konfigurator kotew (lista kotew normy)."""
from as_editor.anchors_logic import ANCHOR_DEF_COLS, ANCHOR_LABELS, zone_of
from as_editor.common import dia_text, fmt_dia, is_own
from as_editor.config import MAX_ITEMS, recall, remember
from as_editor.i18n import T
from as_editor.ui.add_lengths import AddLengthsDialog
from as_editor.ui.anchor_dialog import AnchorDialog
from as_editor.ui.single_anchor import SingleAnchorDialog
from as_editor.ui.table_browser import TableBrowser
from as_editor.ui.widgets import make_filterable, make_tree, messagebox, selected_index, set_choices, tk, ttk


class AnchorsMainMixin:
    # ------------------------------------------------------------------ KOTWY
    def build_anchors(self):
        self.an_std_rows, self.an_type_rows, self.an_src_rows, self.an_dia_rows = [], [], [], []
        self.an_dia_vals, self.ls_anchors = [], []
        self.an_last_std = None
        self.an_std_types, self.ls_std_rows = {}, []
        self.build_anchor_list()
        self.build_anchor_copy()
        self.build_anchor_del()
        self.browsers.append(TableBrowser(self, self.sub_abr, "AnchorsName"))

    def refresh_anchor_tabs(self):
        if not self.db.conn:
            return
        self.an_std_rows = self.db.anchor_standards()
        self.an_type_rows = self.db.anchor_types()
        self.an_src_rows = self.db.sources()
        self.an_dia_rows = self.db.all_diameters()
        self.an_dia_vals = [float(r[0]) for r in self.an_dia_rows]
        std_disp = ["%s   |   %s%s" % (r[0], r[1], "   [MOJA]" if is_own(r[2]) else "") for r in self.an_std_rows]
        cls_disp = ["%s   |   %s" % (r[0], r[1] or r[0]) for r in self.cls_rows]
        self.cb_akstd["values"] = std_disp
        self.cb_aknewcls["values"] = [T("(bez zmiany)")] + cls_disp
        self.cb_adstd["values"] = std_disp
        self.an_std_types = self.db.anchor_std_types()
        self.an_std_mats = self.db.anchor_std_mats()
        prev_t = self.cb_lstype.current()
        self.cb_lstype["values"] = [T("Wszystkie typy")] + ["%s   |   %s" % (r[0], r[1]) for r in self.an_type_rows]
        self.cb_lstype.current(prev_t if 0 <= prev_t <= len(self.an_type_rows) else 0)
        self.ls_fill_stds(self.an_last_std or (recall("last_anchor_std") if selected_index(self.cb_lsstd) < 0 else None))
        self.an_last_std = None
        self.ls_refresh()

    # --- konfigurator kotew: lista kotew normy + okno dodawania/edycji ---
    def build_anchor_list(self):
        f = self.sub_ls
        top = ttk.Frame(f)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Label(top, text="Typ kotwy:").pack(side="left")
        self.cb_lstype = ttk.Combobox(top, width=18, state="readonly", values=[T("Wszystkie typy")])
        self.cb_lstype.current(0)
        self.cb_lstype.pack(side="left", padx=(4, 10))
        self.cb_lstype.bind("<<ComboboxSelected>>", self.ls_type_changed)
        ttk.Label(top, text="Norma kotwy (wpisz np. Hilti):").pack(side="left")
        self.cb_lsstd = make_filterable(ttk.Combobox(top, width=40))
        self.cb_lsstd.pack(side="left", padx=6)
        self.cb_lsstd.bind("<<ComboboxSelected>>", self.ls_std_changed)
        q = ttk.LabelFrame(f, text="Dodaj do zaznaczonej kotwy (zaznaczona kotwa jest wzorcem)")
        q.pack(fill="x", padx=8, pady=(0, 4))
        self.btn_ls_quick = []
        for txt, mode in (("+ Długość", "length"), ("+ Średnica", "dia"), ("+ Klasa", "class")):
            b = ttk.Button(q, text=txt, width=14, command=lambda m=mode: self.ls_quick(m))
            b.pack(side="left", padx=6, pady=4)
            self.btn_ls_quick.append(b)
        self.btn_ls_deldef = ttk.Button(q, text="Usuń zaznaczone moje długości", command=self.ls_delete_defs)
        self.btn_ls_deldef.pack(side="right", padx=6)
        ttk.Label(q, text="+ Długość dopisuje długości do zaznaczonej kotwy. + Średnica / + Klasa tworzą nową kotwę na jej wzorcu.",
                  foreground="#555").pack(side="left", padx=8)
        ttk.Button(top, text="Dodaj kotwę...", command=self.ls_add_single).pack(side="left", padx=(6, 3))
        self.btn_ls_edit = ttk.Button(top, text="Edytuj zaznaczoną...", command=self.ls_edit)
        self.btn_ls_edit.pack(side="left", padx=3)
        self.btn_ls_del = ttk.Button(top, text="Usuń zaznaczoną", command=self.ls_delete)
        self.btn_ls_del.pack(side="left", padx=3)
        mb = ttk.Menubutton(top, text=T("Więcej") + " \u25be")
        menu = tk.Menu(mb, tearoff=False)
        menu.add_command(label=T("Dodaj kilka średnic naraz (zaawansowane)..."), command=self.ls_add)
        menu.add_command(label=T("Nowa norma kotwy..."), command=self.ls_new_std)
        menu.add_command(label=T("Kopiuj kotwy do nowej normy / dodaj klasę..."),
                         command=lambda: self.open_tool(self.sub_ak))
        mb["menu"] = menu
        mb.pack(side="left", padx=3)
        self.var_lsinfo = tk.StringVar()
        ttk.Label(f, textvariable=self.var_lsinfo, foreground="#555").pack(anchor="w", padx=8)
        ttk.Label(f, text="Kotwy tej normy - każdy wiersz to jedna średnica i klasa (zielone = moje, można je edytować):").pack(
            anchor="w", padx=8, pady=(6, 0))
        fr, self.tr_lsanc = make_tree(f, ("Typ", "Klasa", "Ø", "Zestaw", "Źródło", "Długości", "Zakres [mm]", "Właściciel"),
                                      (130, 100, 60, 200, 130, 70, 110, 90), 9, "browse", sort=True, filt=True)
        fr.pack(fill="x", padx=8)
        self.tr_lsanc.tag_configure("own", background="#e6f4e6")
        self.tr_lsanc.bind("<<TreeviewSelect>>", self.ls_show_defs)
        self.tr_lsanc.bind("<<TreeviewSelect>>", lambda e: self.ls_update_buttons(), add="+")
        self.var_lscomp = tk.StringVar()
        ttk.Label(f, textvariable=self.var_lscomp, wraplength=1150, foreground="#333").pack(anchor="w", padx=8, pady=(6, 0))
        ttk.Label(f, text="Wymiary i długości zaznaczonej kotwy (podgląd). Inna kotwa w tej normie: 'Dodaj kotwę...'.",
                  foreground="#555").pack(anchor="w", padx=8)
        self.ls_defs_frame = ttk.Frame(f)
        self.ls_defs_frame.pack(fill="both", expand=True, padx=8, pady=4)

    def ls_update_buttons(self):
        """Edycja i usuwanie dostępne tylko dla zaznaczonej kotwy własnej (fabryczne są chronione)."""
        a = self.ls_selected()
        on = bool(a and is_own(a[6]))
        for b in (self.btn_ls_edit, self.btn_ls_del):
            b.state(["!disabled"] if on else ["disabled"])
        for b in self.btn_ls_quick:
            b.state(["!disabled"] if a else ["disabled"])
        self.btn_ls_deldef.state(["!disabled"] if a else ["disabled"])

    def ls_type_id(self):
        """Wybrany filtr typu kotwy (ClassID) albo None = wszystkie typy."""
        i = self.cb_lstype.current()
        return self.an_type_rows[i - 1][0] if 1 <= i <= len(self.an_type_rows) else None

    def ls_fill_stds(self, want=None):
        """Lista norm kotew: po wybraniu typu tylko normy, które mają kotwy tego typu (wybór normy zostaje, jeśli pasuje)."""
        keep = want or (self.ls_std()[0] if self.ls_std() else None)
        tid = self.ls_type_id()
        self.ls_std_rows = [r for r in self.an_std_rows if tid is None or tid in self.an_std_types.get(r[0], ())]
        set_choices(self.cb_lsstd, ["%s   |   %s%s" % (r[0], r[1], "   [MOJA]" if is_own(r[2]) else "") for r in self.ls_std_rows])
        self.cb_lsstd.set("")
        for i, r in enumerate(self.ls_std_rows):
            if r[0] == keep:
                self.cb_lsstd.current(i)
                break

    def ls_type_changed(self, _=None):
        self.ls_fill_stds()
        self.ls_refresh()

    def ls_std_changed(self, _=None):
        r = self.ls_std()
        if r:
            remember("last_anchor_std", r[0])
        self.ls_refresh()

    def ls_std(self):
        i = selected_index(self.cb_lsstd)
        return self.ls_std_rows[i] if 0 <= i < len(self.ls_std_rows) else None

    def ls_selected(self):
        sel = self.tr_lsanc.selection()
        return self.ls_anchors[int(sel[0])] if sel and int(sel[0]) < len(self.ls_anchors) else None

    def ls_refresh(self, _=None):
        prev = self.ls_selected()
        prev_id = prev[0] if prev else None
        t = self.tr_lsanc
        t.delete(*t.get_children())
        self.ls_anchors = []
        r = self.ls_std() if self.db.conn else None
        if not r:
            self.var_lsinfo.set("Wybierz normę kotwy albo kliknij 'Nowa norma kotwy...'." if self.db.conn else "")
            self.ls_show_defs()
            self.ls_update_buttons()
            return
        rows, cols = self.db.query(
            "SELECT n.[ID], n.[ClassID], n.[MaterialKey], n.[Diameter], n.[SetName], n.[Source], n.[OwnerText], "
            "(SELECT COUNT(*) FROM [AnchorsDefinition] d WHERE d.[AnchorID]=n.[ID]) AS defs, "
            "(SELECT MIN(d.[Length]) FROM [AnchorsDefinition] d WHERE d.[AnchorID]=n.[ID]) AS lmin, "
            "(SELECT MAX(d.[Length]) FROM [AnchorsDefinition] d WHERE d.[AnchorID]=n.[ID]) AS lmax FROM [AnchorsName] n "
            "WHERE n.[Standard]=?" + (" AND n.[ClassID]=?" if self.ls_type_id() is not None else "") +
            " ORDER BY n.[Diameter], n.[MaterialKey], n.[SetName]",
            (r[0],) + ((self.ls_type_id(),) if self.ls_type_id() is not None else ()))
        type_names = {x[0]: x[1] for x in self.an_type_rows}
        for i, x in enumerate(rows):
            self.ls_anchors.append(x)
            t.insert("", "end", iid=str(i), tags=("own",) if is_own(x[6]) else (), values=(
                "%s | %s" % (x[1], type_names.get(x[1], "?")), x[2], dia_text(float(x[3])), x[4], x[5], x[7],
                "%s - %s" % (fmt_dia(float(x[8])), fmt_dia(float(x[9]))) if x[8] is not None else "", x[6] or ""))
        own = sum(1 for x in rows if is_own(x[6]))
        self.var_lsinfo.set("Kotwy w normie: %d (w tym moich: %d)." % (len(rows), own))
        for i, x in enumerate(rows):
            if x[0] == prev_id:
                t.selection_set(str(i))
                break
        self.ls_show_defs()
        self.ls_update_buttons()

    def ls_show_defs(self, _=None):
        for w in self.ls_defs_frame.winfo_children():
            w.destroy()
        a = self.ls_selected() if self.db.conn else None
        if not a:
            self.var_lscomp.set("")
            return
        defs, holes = self.db.anchor_children([a[0]])
        cols = ANCHOR_DEF_COLS.get(a[1], ANCHOR_DEF_COLS[3])
        fr, tr = make_tree(self.ls_defs_frame, [ANCHOR_LABELS[c] for c in cols],
                           [260 if c == "PartName" else 85 for c in cols], 12, sort=True)
        fr.pack(fill="both", expand=True)
        tr.tag_configure("own", background="#e6f4e6")
        self.tr_lsdef = tr
        self.ls_defs = defs.get(a[0], [])
        for i, d in enumerate(self.ls_defs):
            tr.insert("", "end", iid=str(i), tags=("own",) if is_own(d.get("OwnerText")) else (),
                      values=["" if d.get(c) is None else d.get(c) for c in cols])
        rows, ncols = self.db.query("SELECT * FROM [AnchorsName] WHERE [ID]=?", (a[0],))
        if rows:
            n = dict(zip(ncols, rows[0]))
            zones = {"top": [], "below": [], "end": []}
            for k in range(1, MAX_ITEMS + 1):
                din, pos, m = n.get("DIN%d" % k), n.get("Position%d" % k), n.get("Material%d" % k)
                if din not in (None, "", "-") and pos:
                    zones[zone_of(pos)].append((abs(pos), "%s/%s" % (din, m)))
            names = {"top": T("góra"), "below": T("pod blachą"), "end": T("koniec kotwy")}
            parts = ["%s: %s" % (names[z], ", ".join(t for _, t in sorted(zones[z]))) for z in ("top", "below", "end") if zones[z]]
            self.var_lscomp.set("Zestaw '%s':  %s" % (n["SetName"], "   |   ".join(parts) if parts else "(brak elementów)"))

    def ls_add(self):
        if not self.need_db():
            return
        r, a = self.ls_std(), self.ls_selected()
        AnchorDialog(self, std_key=r[0] if r else None, template_id=a[0] if a else None)
        self.ls_refresh()

    def ls_add_single(self):
        if not self.need_db():
            return
        r, a = self.ls_std(), self.ls_selected()
        if not r:
            messagebox.showinfo("Dodaj kotwę", "Najpierw wybierz normę kotwy (zestaw kotew) na liście.")
            return
        if not self.db.anchor_names(r[0]):
            messagebox.showinfo("Dodaj kotwę", "Ta norma nie ma jeszcze żadnej kotwy - użyj 'Nowa norma kotwy...'.")
            return
        SingleAnchorDialog(self, r[0], template_id=a[0] if a else None)
        self.ls_refresh()

    def ls_quick(self, mode):
        """Szybka akcja: + długość / + średnica / + klasa na wzorcu zaznaczonej kotwy."""
        if not self.need_db():
            return
        r, a = self.ls_std(), self.ls_selected()
        if not r:
            messagebox.showinfo("Dodaj", "Najpierw wybierz normę kotwy.")
            return
        if not a:
            messagebox.showinfo("Dodaj", "Zaznacz na liście kotwę, która ma być wzorcem.")
            return
        if mode == "length":                                  # tylko dopisanie długości do tej kotwy (bez edycji reszty)
            AddLengthsDialog(self, r[0], a[0])
        else:
            SingleAnchorDialog(self, r[0], template_id=a[0], mode=mode)
        self.ls_refresh()

    def ls_delete_defs(self):
        """Usuwa zaznaczone długości (wiersze AnchorsDefinition) dopisane przez użytkownika; fabrycznych nie rusza."""
        a = self.ls_selected()
        tr = getattr(self, "tr_lsdef", None)
        if not self.need_db() or not a or tr is None or not tr.winfo_exists():
            messagebox.showinfo("Usuń", "Zaznacz kotwę, a w tabeli poniżej długości do usunięcia (zielone = moje).")
            return
        sel = [self.ls_defs[int(i)] for i in tr.selection() if int(i) < len(self.ls_defs)]
        own = [d for d in sel if is_own(d.get("OwnerText"))]
        if not sel:
            messagebox.showinfo("Usuń", "Zaznacz w tabeli długości do usunięcia (zielone = moje).")
            return
        if not own:
            messagebox.showinfo("Usuń", "Zaznaczone długości są fabryczne - program ich nie usuwa.")
            return
        if len(own) == len(self.ls_defs):
            messagebox.showinfo("Usuń", "To wszystkie długości tej kotwy. Aby usunąć całą kotwę, użyj 'Usuń zaznaczoną'.")
            return
        msg = T("Usunąć %d moich długości z kotwy Ø%s (klasa %s)?") % (len(own), dia_text(float(a[3])), a[2])
        if len(own) < len(sel):
            msg += "\n" + T("Fabryczne wiersze (%d) zostaną pominięte.") % (len(sel) - len(own))
        if not messagebox.askyesno("Potwierdź", msg):
            return
        if not self.backup_before_write():
            return

        def fn(cur):
            for d in own:
                cur.execute("DELETE FROM [AnchorsDefinition] WHERE [ID]=? AND ISNULL([OwnerText],'') NOT IN ('DSC','AUTODESK')",
                            (d["ID"],))
        if self.write_or_report(fn):
            self.reload()

    def ls_new_std(self):
        if not self.need_db():
            return
        AnchorDialog(self)
        self.ls_refresh()

    def ls_edit(self):
        a = self.ls_selected()
        if not self.need_db() or not a:
            messagebox.showinfo("Edytuj", "Zaznacz kotwę na liście.")
            return
        if not is_own(a[6]):
            messagebox.showinfo("Edytuj", "To kotwa fabryczna - nie edytuję jej. Użyj 'Dodaj kotwę...' "
                                          "(nowa kotwa na jej wzorcu).")
            return
        AnchorDialog(self, edit_id=a[0])
        self.ls_refresh()

    def ls_delete(self):
        a = self.ls_selected()
        if not self.need_db() or not a:
            messagebox.showinfo("Usuń", "Zaznacz kotwę na liście.")
            return
        if not is_own(a[6]):
            messagebox.showinfo("Usuń", "To kotwa fabryczna - program jej nie usuwa.")
            return
        if not messagebox.askyesno("Potwierdź", "Usunąć kotwę Ø%s klasa %s wraz z jej %s definicjami długości?" % (
                dia_text(float(a[3])), a[2], a[7])):
            return
        if not self.backup_before_write():
            return

        def fn(cur):
            cur.execute("DELETE FROM [AnchorsDefinition] WHERE [AnchorID]=?", (a[0],))
            cur.execute("DELETE FROM [AnchorsHoleDefinition] WHERE [AnchorNameID]=?", (a[0],))
            cur.execute("DELETE FROM [AnchorsName] WHERE [ID]=?", (a[0],))
        if self.write_or_report(fn):
            self.reload()
